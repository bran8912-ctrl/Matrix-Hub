import{j as t}from"./jsx-runtime.D_zvdyIk.js";import{r as a}from"./index.Dc61JUVC.js";const m=[{title:"Cyberpunk City",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/140/140.mp3"},{title:"Deep Techno Ambience",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/134/134.mp3"},{title:"Techno Fest Vibes",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/124/124.mp3"},{title:"Hazy After Hours",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/132/132.mp3"},{title:"Minimal Techno 01",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/162/162.mp3"},{title:"Minimal Emotion",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/160/160.mp3"},{title:"Machine Drum Vibes",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/117/117.mp3"},{title:"Dub Techno Groove",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/133/133.mp3"},{title:"Trance Party",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/166/166.mp3"},{title:"Infected Vibes",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/157/157.mp3"},{title:"Goa Trance Mantra",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/137/137.mp3"},{title:"Tech House vibes",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/130/130.mp3"},{title:"Kodama Night Town",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/114/114.mp3"},{title:"Digital Clouds",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/175/175.mp3"},{title:"Slow Rain",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/122/122.mp3"},{title:"Sun in Your Eyes",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/131/131.mp3"},{title:"Better Times are Coming",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/173/173.mp3"},{title:"Lonerism",artist:"Alejandro Magaña",url:"https://assets.mixkit.co/music/159/159.mp3"},{title:"B.O.R.N",artist:"Eugenio Mininni",url:"https://assets.mixkit.co/music/620/620.mp3"},{title:"Deep Urban",artist:"Eugenio Mininni",url:"https://assets.mixkit.co/music/623/623.mp3"},{title:"Feedback Dreams",artist:"Eugenio Mininni",url:"https://assets.mixkit.co/music/588/588.mp3"},{title:"Fragments Of Bangkok",artist:"Eugenio Mininni",url:"https://assets.mixkit.co/music/625/625.mp3"},{title:"Skyline",artist:"Eugenio Mininni",url:"https://assets.mixkit.co/music/601/601.mp3"},{title:"Silent Descent",artist:"Eugenio Mininni",url:"https://assets.mixkit.co/music/614/614.mp3"},{title:"Echoes",artist:"Andrew Ev",url:"https://assets.mixkit.co/music/188/188.mp3"},{title:"Sci-Fi Game",artist:"Arulo",url:"https://assets.mixkit.co/music/395/395.mp3"},{title:"Sci-Fi Score",artist:"Arulo",url:"https://assets.mixkit.co/music/464/464.mp3"},{title:"Neon Skyline",artist:"Eugenio Mininni",url:"https://assets.mixkit.co/music/626/626.mp3"},{title:"Digital Mirage",artist:"Eugenio Mininni",url:"https://assets.mixkit.co/music/627/627.mp3"},{title:"Night Drive",artist:"Arulo",url:"https://assets.mixkit.co/music/396/396.mp3"},{title:"Retro Future",artist:"Arulo",url:"https://assets.mixkit.co/music/397/397.mp3"},{title:"Dream Sequence",artist:"Andrew Ev",url:"https://assets.mixkit.co/music/189/189.mp3"},{title:"Dreamwalker",artist:"Matrix Hub",url:"/music/dreamwalker.mp3"},{title:"Cipher",artist:"Matrix Hub",url:"/music/cipher.mp3"},{title:"Digital Ghost",artist:"Matrix Hub",url:"/music/digital-ghost.mp3"},{title:"Sci-Fi Ambient 2",artist:"Matrix Hub",url:"/music/sci-fi-ambient-2.mp3"},{title:"Night Owl",artist:"Matrix Hub",url:"/music/night-owl.mp3"},{title:"Dark Sci-Fi Synth",artist:"Matrix Hub",url:"/music/dark-sci-fi-synth.mp3"},{title:"Industrial Cyberpunk",artist:"Matrix Hub",url:"/music/industrial-cyberpunk.mp3"},{title:"Sci-Fi Ambient 1",artist:"Matrix Hub",url:"/music/sci-fi-ambient-1.mp3"},{title:"The Ambient",artist:"Matrix Hub",url:"/music/the-ambient.mp3"}];function C(){const i=a.useRef(null),[s,g]=a.useState(0),[x,l]=a.useState(!1),[o,v]=a.useState(!1),[u,M]=a.useState(!1),[d,S]=a.useState(!0),[p,j]=a.useState(!0),[b,A]=a.useState([]);a.useEffect(()=>{const e=localStorage.getItem("matrixPlayerIndex"),r=localStorage.getItem("matrixPlayerShuffle"),n=localStorage.getItem("matrixPlayerLoop"),c=localStorage.getItem("matrixPlayerAutoplay"),h=localStorage.getItem("matrixPlayerTime"),I=localStorage.getItem("matrixPlayerMinimized");e&&g(parseInt(e,10)),r&&v(r==="true"),n&&M(n==="true"),c&&S(c==="true"),I&&j(I==="true"),i.current&&h&&(i.current.currentTime=parseFloat(h))},[]),a.useEffect(()=>{localStorage.setItem("matrixPlayerIndex",s.toString())},[s]),a.useEffect(()=>{localStorage.setItem("matrixPlayerShuffle",o.toString())},[o]),a.useEffect(()=>{localStorage.setItem("matrixPlayerLoop",u.toString())},[u]),a.useEffect(()=>{localStorage.setItem("matrixPlayerAutoplay",d.toString())},[d]),a.useEffect(()=>{localStorage.setItem("matrixPlayerMinimized",p.toString())},[p]),a.useEffect(()=>{let e=0;const r=setInterval(()=>{const n=i.current;if(n&&!n.paused){const c=n.currentTime;Math.abs(c-e)>=5&&(localStorage.setItem("matrixPlayerTime",c.toString()),e=c)}},1e3);return()=>clearInterval(r)},[]);const N=()=>{i.current&&(i.current.play().catch(e=>{console.error("Audio playback failed:",e),l(!1)}),l(!0))},T=()=>{i.current&&(i.current.pause(),l(!1))},P=a.useCallback(()=>{const e=m.map((c,h)=>h).filter(c=>!b.includes(c));if(e.length===0)return A([]),Math.floor(Math.random()*m.length);const r=Math.floor(Math.random()*e.length),n=e[r];return A([...b,n]),n},[b]),y=a.useCallback(()=>{let e;o?e=Math.floor(Math.random()*m.length):e=(s-1+m.length)%m.length,g(e),x&&i.current&&i.current.play().catch(r=>{console.error("Audio playback failed:",r),l(!1)})},[s,o,x]),f=a.useCallback(()=>{let e;o?e=P():e=(s+1)%m.length,g(e),x&&i.current&&i.current.play().catch(r=>{console.error("Audio playback failed:",r),l(!1)})},[s,o,x,P]);a.useEffect(()=>{if("mediaSession"in navigator&&i.current){const e=m[s];navigator.mediaSession.metadata=new MediaMetadata({title:e.title,artist:e.artist,album:"Matrix Hub Playlist",artwork:[{src:"/favicon.ico",sizes:"96x96",type:"image/x-icon"}]}),navigator.mediaSession.setActionHandler("play",()=>{i.current?.play().catch(r=>{console.error("Audio playback failed:",r)}),l(!0)}),navigator.mediaSession.setActionHandler("pause",()=>{i.current?.pause(),l(!1)}),navigator.mediaSession.setActionHandler("previoustrack",y),navigator.mediaSession.setActionHandler("nexttrack",f)}},[s,y,f]);const z=()=>{d&&!u&&f()},k=m[s];return t.jsxs("div",{className:`persistent-music-player ${p?"minimized":""}`,children:[t.jsx("audio",{ref:i,src:k.url,preload:"auto",crossOrigin:"anonymous",loop:u,onEnded:z,onPlay:()=>l(!0),onPause:()=>l(!1)}),t.jsxs("div",{className:"player-header",children:[t.jsx("button",{className:"minimize-btn",onClick:()=>j(!p),title:p?"Expand Player":"Minimize Player","aria-label":p?"Expand Player":"Minimize Player",children:p?"▼":"▲"}),t.jsx("span",{className:"player-title",children:"MATRIX MP3 PLAYER"})]}),!p&&t.jsxs("div",{className:"player-content",children:[t.jsxs("div",{className:"now-playing",children:[t.jsx("div",{className:"now-playing-label",children:"Now Playing"}),t.jsx("div",{className:"track-title",children:k.title}),t.jsx("div",{className:"track-artist",children:k.artist}),t.jsxs("div",{className:"track-number",children:["Track ",s+1," of ",m.length]})]}),t.jsxs("div",{className:"player-controls",children:[t.jsx("button",{onClick:y,title:"Previous","aria-label":"Previous track",children:"⏮"}),x?t.jsx("button",{onClick:T,title:"Pause","aria-label":"Pause",children:"⏸"}):t.jsx("button",{onClick:N,title:"Play","aria-label":"Play",children:"▶"}),t.jsx("button",{onClick:f,title:"Next","aria-label":"Next track",children:"⏭"})]}),t.jsxs("div",{className:"secondary-controls",children:[t.jsx("button",{className:o?"active":"",onClick:()=>v(!o),title:"Shuffle","aria-label":"Toggle shuffle","aria-pressed":o,children:"🔀"}),t.jsx("button",{className:u?"active":"",onClick:()=>M(!u),title:"Loop","aria-label":"Toggle loop","aria-pressed":u,children:"🔁"}),t.jsx("button",{className:d?"active":"",onClick:()=>S(!d),title:"Autoplay","aria-label":"Toggle autoplay","aria-pressed":d,children:"🔊"})]}),t.jsxs("div",{className:"player-status",children:["Loop: ",u?"ON":"OFF"," | Shuffle: ",o?"ON":"OFF"," | Autoplay: ",d?"ON":"OFF"]}),t.jsxs("div",{className:"music-notice",children:[t.jsx("strong",{children:"Music License:"})," All tracks are royalty-free or licensed under Creative Commons.",t.jsx("br",{}),t.jsxs("span",{style:{fontSize:"0.85em"},children:["Kevin MacLeod (incompetech.com): CC BY 4.0 |"," ",t.jsx("a",{href:"https://creativecommons.org/licenses/by/4.0/",target:"_blank",rel:"noopener noreferrer",children:"https://creativecommons.org/licenses/by/4.0/"})]})]})]}),t.jsx("style",{children:`
        .persistent-music-player {
          position: sticky;
          top: 0;
          z-index: var(--z-index-navigation);
          background: var(--theme-bg-panel, rgba(0, 20, 0, 0.95));
          border-bottom: 2px solid var(--theme-primary, #00ff00);
          box-shadow: 0 4px 20px var(--theme-glow, rgba(0, 255, 0, 0.3));
          font-family: 'Courier New', monospace;
          backdrop-filter: blur(10px);
        }

        .player-header {
          display: flex;
          align-items: center;
          padding: 8px 16px;
          gap: 12px;
        }

        .minimize-btn {
          background: transparent;
          color: var(--theme-primary, #00ff00);
          border: 1px solid var(--theme-border, #00ff00);
          padding: 4px 10px;
          cursor: pointer;
          font-family: inherit;
          border-radius: 4px;
          transition: 0.2s;
          font-size: 12px;
        }

        .minimize-btn:hover {
          background: var(--theme-primary, #00ff00);
          color: black;
        }

        .player-title {
          font-size: 14px;
          color: var(--theme-primary, #00ff00);
          text-shadow: 0 0 8px var(--theme-glow, rgba(0, 255, 0, 0.5));
          flex: 1;
        }

        .player-content {
          padding: 16px;
          border-top: 1px solid var(--theme-border, rgba(0, 255, 0, 0.3));
        }

        .now-playing {
          background: rgba(0, 255, 65, 0.1);
          border: 1px solid var(--theme-border, #00ff00);
          border-radius: 5px;
          padding: 12px;
          margin-bottom: 15px;
          text-align: center;
        }

        .now-playing-label {
          font-size: 10px;
          color: var(--theme-primary, #00ff00);
          margin-bottom: 5px;
          text-transform: uppercase;
          opacity: 0.7;
        }

        .track-title {
          font-size: 14px;
          color: var(--theme-primary, #00ff00);
          font-weight: bold;
          margin-bottom: 3px;
          text-shadow: 0 0 5px var(--theme-glow, rgba(0, 255, 0, 0.5));
        }

        .track-artist {
          font-size: 12px;
          color: var(--theme-secondary, #00ffff);
        }

        .track-number {
          font-size: 11px;
          color: var(--theme-text, #00ffff);
          margin-top: 5px;
          opacity: 0.7;
        }

        .player-controls {
          text-align: center;
          margin-bottom: 10px;
        }

        .player-controls button {
          background: black;
          color: var(--theme-primary, #00ff00);
          border: 1px solid var(--theme-border, #00ff00);
          padding: 10px 14px;
          margin: 4px;
          cursor: pointer;
          font-family: inherit;
          border-radius: 5px;
          transition: 0.2s;
          font-size: 14px;
        }

        .player-controls button:hover {
          background: var(--theme-primary, #00ff00);
          color: black;
        }

        .secondary-controls {
          display: flex;
          justify-content: center;
          gap: 8px;
          margin-bottom: 12px;
        }

        .secondary-controls button {
          background: black;
          color: var(--theme-primary, #00ff00);
          border: 1px solid var(--theme-border, #00ff00);
          padding: 6px 10px;
          cursor: pointer;
          font-family: inherit;
          border-radius: 5px;
          transition: 0.2s;
          font-size: 12px;
        }

        .secondary-controls button:hover,
        .secondary-controls button.active {
          background: var(--theme-primary, #00ff00);
          color: black;
        }

        .player-status {
          text-align: center;
          font-size: 11px;
          color: var(--theme-text, #00ffff);
          opacity: 0.7;
          margin-bottom: 12px;
        }

        .music-notice {
          margin-top: 12px;
          font-size: 0.85em;
          color: var(--theme-secondary, #00ffff);
          background: rgba(0, 0, 0, 0.3);
          border-radius: 6px;
          padding: 8px;
          text-align: center;
        }

        .music-notice a {
          color: var(--theme-primary, #00ff00);
          text-decoration: underline;
        }

        @media (max-width: 768px) {
          .player-header {
            padding: 6px 12px;
          }

          .player-title {
            font-size: 12px;
          }

          .player-content {
            padding: 12px;
          }

          .player-controls button {
            padding: 8px 12px;
            font-size: 12px;
          }
        }
      `})]})}export{C as default};
