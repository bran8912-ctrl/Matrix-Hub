import{j as e}from"./jsx-runtime.D_zvdyIk.js";import{r as s,R as w}from"./index.Dc61JUVC.js";const h={privateKey:/\b(private\s*key|seed\s*phrase|mnemonic|recovery\s*phrase|12\s*words|24\s*words|secret\s*key)\b/i,suspiciousLinks:/\b(bit\.ly|tinyurl|goo\.gl|shorturl|t\.co|ow\.ly)\b/i,phishing:/\b(verify\s*wallet|claim\s*airdrop|urgent\s*action|limited\s*time|send\s*eth|send\s*mtx|double\s*your|guaranteed\s*profit)\b/i},l={greeting:"Welcome, seeker. I am the Oracle. The digital realm reveals all truths to those who ask. What knowledge do you seek from the Matrix?",securityWarning:`⚠️ SECURITY BREACH DETECTED ⚠️

The Oracle sees all, Neo. Never share your private keys, seed phrases, or wallet secrets in any system. The Matrix protects those who protect themselves.

Remember: Real agents never ask for your keys. Stay vigilant.`,mtxInfo:"The MTX token flows through the Matrix like digital rain. It powers the casino games, unlocks premium features, and rewards those who contribute to the system. Balance is read from your wallet - we never hold your tokens. The choice is yours, always.",casinoInfo:"The casino modules offer Slots, Blackjack, and Roulette - all powered by MTX and verifiable on-chain. Every spin, every hand, every bet is transparent. The Oracle guarantees fairness through mathematics, not faith.",walletSafety:"Your wallet is your identity in the Matrix. Protect it as you would your mind. Never share private keys. Always verify contracts. Trust the code, not the promises. The Oracle has spoken.",help:`The Oracle can guide you through:
• MTX Token System
• Casino Games
• Wallet Safety
• Site Features
• Security Tips

Speak your query, and the truth shall be revealed.`},k=r=>h.privateKey.test(r)?"⚠️ CRITICAL: Never share private keys or seed phrases! The Oracle has blocked this message for your protection.":h.phishing.test(r)?"⚠️ PHISHING DETECTED: This appears to be a scam attempt. The Matrix does not operate through urgency or guaranteed profits. Stay vigilant.":h.suspiciousLinks.test(r)?"⚠️ SUSPICIOUS LINK: Shortened URLs can hide malicious destinations. The Oracle recommends caution with all external links.":null,v=r=>{const t=r.toLowerCase(),o=k(r);return o?o+`

`+l.securityWarning:t.includes("mtx")||t.includes("token")||t.includes("coin")?l.mtxInfo:t.includes("casino")||t.includes("game")||t.includes("bet")?l.casinoInfo:t.includes("wallet")||t.includes("safe")||t.includes("security")?l.walletSafety:t.includes("help")||t.includes("guide")||t.includes("how")?l.help:"The Oracle sees your question, seeker. The path forward reveals itself to those who persist. Explore the Matrix Hub - each module holds its own truth. What specific aspect of the digital realm do you wish to understand?"};function T(){const[r,t]=s.useState(!1),[o,n]=s.useState([]),[i,d]=s.useState(""),[f,u]=s.useState(!1),x=s.useRef(null);s.useEffect(()=>{if(r&&o.length===0){const a={id:`bot-${Date.now()}`,text:l.greeting,isBot:!0,timestamp:Date.now()};n([a])}},[r]),s.useEffect(()=>{x.current?.scrollIntoView({behavior:"smooth"})},[o]);const g=()=>{if(!i.trim())return;const a={id:`user-${Date.now()}`,text:i,isBot:!1,timestamp:Date.now()};n(c=>[...c,a]),d(""),u(!0),setTimeout(()=>{const c=v(i),p={id:`bot-${Date.now()}`,text:c,isBot:!0,timestamp:Date.now()};n(y=>[...y,p]),u(!1)},800+Math.random()*400)},m=a=>{a.key==="Enter"&&!a.shiftKey&&(a.preventDefault(),g())};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        @keyframes matrixRainBot {
          0% { transform: translateY(-100%); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(100vh); opacity: 0; }
        }
        
        @keyframes scanline {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
        
        @keyframes oracleGlow {
          0%, 100% { 
            box-shadow: 0 0 20px rgba(0, 255, 0, 0.5), 0 0 40px rgba(0, 255, 0, 0.3);
            filter: drop-shadow(0 0 10px rgba(0, 255, 0, 0.8));
          }
          50% { 
            box-shadow: 0 0 30px rgba(0, 255, 0, 0.8), 0 0 60px rgba(0, 255, 0, 0.5);
            filter: drop-shadow(0 0 15px rgba(0, 255, 0, 1));
          }
        }
        
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }
        
        .oracle-bot-button {
          position: fixed;
          bottom: 24px;
          right: 24px;
          width: 64px;
          height: 64px;
          border-radius: 50%;
          background: rgba(0, 0, 0, 0.95);
          border: 2px solid #00ff00;
          color: #00ff00;
          font-size: 28px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          z-index: 9998;
          transition: all 0.3s ease;
          animation: oracleGlow 2s infinite;
          font-family: 'Courier New', monospace;
          user-select: none;
        }
        
        .oracle-bot-button:hover {
          transform: scale(1.1);
          border-color: #00ffff;
          color: #00ffff;
        }
        
        .oracle-bot-window {
          position: fixed;
          bottom: 100px;
          right: 24px;
          width: min(440px, calc(100vw - 48px));
          height: min(620px, calc(100vh - 140px));
          background: rgba(0, 0, 0, 0.95);
          border: 2px solid #00ff00;
          border-radius: 12px;
          display: flex;
          flex-direction: column;
          z-index: 9999;
          box-shadow: 0 0 40px rgba(0, 255, 0, 0.4), inset 0 0 60px rgba(0, 255, 0, 0.05);
          backdrop-filter: blur(10px);
          font-family: 'Courier New', monospace;
          overflow: hidden;
        }
        
        .oracle-header {
          background: rgba(0, 20, 0, 0.8);
          border-bottom: 2px solid #00ff00;
          padding: 16px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          position: relative;
        }
        
        .oracle-header::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 1px;
          background: linear-gradient(90deg, transparent, #00ff00, transparent);
          animation: scanline 3s linear infinite;
        }
        
        .oracle-avatar {
          width: 48px;
          height: 48px;
          margin-right: 12px;
        }
        
        .oracle-title {
          flex: 1;
        }
        
        .oracle-title h3 {
          margin: 0;
          color: #00ff00;
          font-size: 18px;
          font-weight: bold;
          text-shadow: 0 0 10px rgba(0, 255, 0, 0.8);
          letter-spacing: 2px;
        }
        
        .oracle-title p {
          margin: 4px 0 0 0;
          color: #00ffaa;
          font-size: 11px;
          opacity: 0.8;
        }
        
        .oracle-close {
          background: transparent;
          border: 1px solid #00ff00;
          color: #00ff00;
          width: 32px;
          height: 32px;
          border-radius: 4px;
          cursor: pointer;
          font-size: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        
        .oracle-close:hover {
          background: rgba(0, 255, 0, 0.1);
          border-color: #00ffff;
          color: #00ffff;
        }
        
        .oracle-messages {
          flex: 1;
          overflow-y: auto;
          padding: 16px;
          position: relative;
          background: rgba(0, 10, 0, 0.3);
        }
        
        .oracle-messages::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: repeating-linear-gradient(
            0deg,
            rgba(0, 255, 0, 0.03) 0px,
            transparent 1px,
            transparent 2px,
            rgba(0, 255, 0, 0.03) 3px
          );
          pointer-events: none;
          z-index: 1;
        }
        
        .oracle-messages > * {
          position: relative;
          z-index: 2;
        }
        
        .oracle-message {
          margin-bottom: 16px;
          animation: fadeInMessage 0.3s ease-out;
        }
        
        @keyframes fadeInMessage {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .message-user {
          text-align: right;
        }
        
        .message-bot {
          text-align: left;
        }
        
        .message-bubble {
          display: inline-block;
          max-width: 85%;
          padding: 12px 16px;
          border-radius: 8px;
          font-size: 14px;
          line-height: 1.5;
          word-wrap: break-word;
        }
        
        .message-user .message-bubble {
          background: rgba(0, 100, 0, 0.3);
          border: 1px solid #00ff00;
          color: #00ff00;
        }
        
        .message-bot .message-bubble {
          background: rgba(0, 50, 50, 0.3);
          border: 1px solid #00ffaa;
          color: #00ffaa;
        }
        
        .typing-indicator {
          display: inline-flex;
          gap: 4px;
          padding: 12px 16px;
          background: rgba(0, 50, 50, 0.3);
          border: 1px solid #00ffaa;
          border-radius: 8px;
        }
        
        .typing-dot {
          width: 8px;
          height: 8px;
          background: #00ffaa;
          border-radius: 50%;
          animation: pulse 1.4s infinite;
        }
        
        .typing-dot:nth-child(2) {
          animation-delay: 0.2s;
        }
        
        .typing-dot:nth-child(3) {
          animation-delay: 0.4s;
        }
        
        .oracle-input-area {
          border-top: 2px solid #00ff00;
          padding: 16px;
          background: rgba(0, 20, 0, 0.8);
          display: flex;
          gap: 8px;
        }
        
        .oracle-input {
          flex: 1;
          background: rgba(0, 0, 0, 0.7);
          border: 1px solid #00ff00;
          border-radius: 6px;
          padding: 12px;
          color: #00ff00;
          font-family: 'Courier New', monospace;
          font-size: 14px;
          outline: none;
          transition: all 0.2s;
        }
        
        .oracle-input::placeholder {
          color: rgba(0, 255, 0, 0.5);
        }
        
        .oracle-input:focus {
          border-color: #00ffff;
          box-shadow: 0 0 10px rgba(0, 255, 255, 0.3);
        }
        
        .oracle-send-btn {
          background: rgba(0, 100, 0, 0.4);
          border: 1px solid #00ff00;
          border-radius: 6px;
          color: #00ff00;
          width: 48px;
          cursor: pointer;
          font-size: 18px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        
        .oracle-send-btn:hover:not(:disabled) {
          background: rgba(0, 150, 0, 0.5);
          border-color: #00ffff;
          color: #00ffff;
          box-shadow: 0 0 10px rgba(0, 255, 255, 0.3);
        }
        
        .oracle-send-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        
        .oracle-footer {
          padding: 8px 16px;
          background: rgba(0, 20, 0, 0.8);
          border-top: 1px solid rgba(0, 255, 0, 0.3);
          font-size: 11px;
          color: rgba(0, 255, 0, 0.6);
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .oracle-footer a {
          color: #00ffaa;
          text-decoration: none;
          transition: color 0.2s;
        }
        
        .oracle-footer a:hover {
          color: #00ffff;
          text-decoration: underline;
        }
        
        .matrix-rain-container {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          overflow: hidden;
          pointer-events: none;
          opacity: 0.15;
        }
        
        .matrix-rain-char {
          position: absolute;
          color: #00ff00;
          font-family: 'Courier New', monospace;
          font-size: 12px;
          animation: matrixRainBot 8s linear infinite;
        }
        
        /* Mobile responsive */
        @media (max-width: 768px) {
          .oracle-bot-button {
            bottom: 16px;
            right: 16px;
            width: 56px;
            height: 56px;
            font-size: 24px;
          }
          
          .oracle-bot-window {
            bottom: 84px;
            right: 16px;
            left: 16px;
            width: calc(100vw - 32px);
            height: calc(100vh - 120px);
          }
        }
        
        /* Accessibility */
        .oracle-bot-button:focus,
        .oracle-close:focus,
        .oracle-send-btn:focus,
        .oracle-input:focus {
          outline: 2px solid #00ffff;
          outline-offset: 2px;
        }
      `}),e.jsx("button",{className:"oracle-bot-button",onClick:()=>t(!r),"aria-label":"Open Oracle Chat",title:"Ask the Oracle",children:e.jsx(b,{})}),r&&e.jsxs("div",{className:"oracle-bot-window",children:[e.jsx(j,{}),e.jsxs("div",{className:"oracle-header",children:[e.jsx("div",{className:"oracle-avatar",children:e.jsx(b,{})}),e.jsxs("div",{className:"oracle-title",children:[e.jsx("h3",{children:"THE ORACLE"}),e.jsx("p",{children:"Matrix Hub Guardian • Always Vigilant"})]}),e.jsx("button",{className:"oracle-close",onClick:()=>t(!1),"aria-label":"Close Oracle Chat",children:"×"})]}),e.jsxs("div",{className:"oracle-messages",children:[o.map(a=>e.jsx("div",{className:`oracle-message ${a.isBot?"message-bot":"message-user"}`,children:e.jsx("div",{className:"message-bubble",children:a.text.split(`
`).map((c,p)=>e.jsxs(w.Fragment,{children:[c,p<a.text.split(`
`).length-1&&e.jsx("br",{})]},p))})},a.id)),f&&e.jsx("div",{className:"oracle-message message-bot",children:e.jsxs("div",{className:"typing-indicator",children:[e.jsx("div",{className:"typing-dot"}),e.jsx("div",{className:"typing-dot"}),e.jsx("div",{className:"typing-dot"})]})}),e.jsx("div",{ref:x})]}),e.jsxs("div",{className:"oracle-input-area",children:[e.jsx("input",{type:"text",className:"oracle-input",placeholder:"Ask the Oracle...",value:i,onChange:a=>d(a.target.value),onKeyPress:m,"aria-label":"Message input"}),e.jsx("button",{className:"oracle-send-btn",onClick:g,disabled:!i.trim()||f,"aria-label":"Send message",children:"➤"})]}),e.jsxs("div",{className:"oracle-footer",children:[e.jsx("span",{children:"🔒 Never share private keys"}),e.jsxs("div",{children:[e.jsx("a",{href:"#help",onClick:a=>{a.preventDefault(),d("help")},children:"Help"})," • ",e.jsx("a",{href:"https://github.com/bran8912-ctrl/Matrix-Hub.org/issues",target:"_blank",rel:"noopener noreferrer",children:"Report"})]})]})]})]})}function b(){return e.jsxs("svg",{viewBox:"0 0 100 100",xmlns:"http://www.w3.org/2000/svg",style:{width:"100%",height:"100%"},children:[e.jsxs("defs",{children:[e.jsxs("radialGradient",{id:"oracleGlow",cx:"50%",cy:"50%",r:"50%",children:[e.jsx("stop",{offset:"0%",stopColor:"#00ff00",stopOpacity:"0.8"}),e.jsx("stop",{offset:"50%",stopColor:"#00ff00",stopOpacity:"0.4"}),e.jsx("stop",{offset:"100%",stopColor:"#00ff00",stopOpacity:"0"})]}),e.jsxs("filter",{id:"digitalGlow",children:[e.jsx("feGaussianBlur",{stdDeviation:"2",result:"blur"}),e.jsxs("feMerge",{children:[e.jsx("feMergeNode",{in:"blur"}),e.jsx("feMergeNode",{in:"SourceGraphic"})]})]})]}),e.jsx("circle",{cx:"50",cy:"50",r:"45",fill:"url(#oracleGlow)",opacity:"0.6"}),e.jsx("circle",{cx:"50",cy:"45",r:"28",fill:"none",stroke:"#00ff00",strokeWidth:"2",filter:"url(#digitalGlow)"}),e.jsx("rect",{x:"40",y:"38",width:"6",height:"10",fill:"#00ff00",opacity:"0.9",filter:"url(#digitalGlow)"}),e.jsx("rect",{x:"54",y:"38",width:"6",height:"10",fill:"#00ff00",opacity:"0.9",filter:"url(#digitalGlow)"}),e.jsx("line",{x1:"38",y1:"41",x2:"48",y2:"41",stroke:"#00ffff",strokeWidth:"1",opacity:"0.6"}),e.jsx("line",{x1:"52",y1:"41",x2:"62",y2:"41",stroke:"#00ffff",strokeWidth:"1",opacity:"0.6"}),e.jsx("line",{x1:"38",y1:"45",x2:"48",y2:"45",stroke:"#00ffff",strokeWidth:"1",opacity:"0.6"}),e.jsx("line",{x1:"52",y1:"45",x2:"62",y2:"45",stroke:"#00ffff",strokeWidth:"1",opacity:"0.6"}),e.jsx("path",{d:"M 38 58 Q 50 62 62 58",fill:"none",stroke:"#00ff00",strokeWidth:"2",filter:"url(#digitalGlow)"}),e.jsx("circle",{cx:"30",cy:"35",r:"2",fill:"#00ff00",opacity:"0.8",children:e.jsx("animate",{attributeName:"opacity",values:"0.8;0.3;0.8",dur:"2s",repeatCount:"indefinite"})}),e.jsx("circle",{cx:"70",cy:"35",r:"2",fill:"#00ff00",opacity:"0.8",children:e.jsx("animate",{attributeName:"opacity",values:"0.3;0.8;0.3",dur:"2s",repeatCount:"indefinite"})}),e.jsx("circle",{cx:"35",cy:"60",r:"2",fill:"#00ff00",opacity:"0.8",children:e.jsx("animate",{attributeName:"opacity",values:"0.8;0.3;0.8",dur:"2.5s",repeatCount:"indefinite"})}),e.jsx("circle",{cx:"65",cy:"60",r:"2",fill:"#00ff00",opacity:"0.8",children:e.jsx("animate",{attributeName:"opacity",values:"0.3;0.8;0.3",dur:"2.5s",repeatCount:"indefinite"})}),e.jsx("path",{d:"M 50 73 L 50 85",stroke:"#00ff00",strokeWidth:"1.5",opacity:"0.6"}),e.jsx("path",{d:"M 45 80 L 55 80",stroke:"#00ff00",strokeWidth:"1.5",opacity:"0.6"}),e.jsx("circle",{cx:"50",cy:"85",r:"3",fill:"none",stroke:"#00ff00",strokeWidth:"1.5",opacity:"0.6"})]})}function j(){const[r,t]=s.useState([]);return s.useEffect(()=>{const o="アイウエオカキクケコサシスセソタチツテト01",i=Array.from({length:12},(d,f)=>({char:o[Math.floor(Math.random()*o.length)],left:f/12*100,delay:Math.random()*5}));t(i)},[]),e.jsx("div",{className:"matrix-rain-container",children:r.map((o,n)=>e.jsx("div",{className:"matrix-rain-char",style:{left:`${o.left}%`,animationDelay:`${o.delay}s`},children:o.char},n))})}export{T as default};
