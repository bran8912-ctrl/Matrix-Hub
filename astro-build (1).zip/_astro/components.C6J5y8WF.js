const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["_astro/index.CzvxWjdH.js","_astro/parseSignature.B_n7ushk.js","_astro/hashTypedData.UlPK0Qd1.js","_astro/index.Bv67j0dl.js","_astro/PhArrowCircleDown.DpTlEmjn.js","_astro/property.DG_zVZHr.js","_astro/PhArrowClockwise.DU2_XBhG.js","_astro/PhArrowDown.BbOcQoFa.js","_astro/PhArrowLeft.C0hwOvkE.js","_astro/PhArrowRight.B3N_MsWO.js","_astro/PhArrowSquareOut.CFK5dEhN.js","_astro/PhArrowsDownUp.N2PvwKLd.js","_astro/PhArrowsLeftRight.Cc-F68gA.js","_astro/PhArrowUp.SN6CI-jL.js","_astro/PhArrowUpRight.BnS67Kzh.js","_astro/PhArrowsClockwise.yF9hERLY.js","_astro/PhBank.BMnogOUG.js","_astro/PhBrowser.gW-agjVt.js","_astro/PhCaretDown.BtyvyF9R.js","_astro/PhCaretLeft.CdQcRrju.js","_astro/PhCaretRight.BiYkkFoB.js","_astro/PhCaretUp.Dyjid-5C.js","_astro/PhCheck.DlYt6a6X.js","_astro/PhCircleHalf.CuKM9E54.js","_astro/PhClock.CfY33k15.js","_astro/PhCompass.q1sqZw0y.js","_astro/PhCopy.ChWE7L-X.js","_astro/PhCreditCard.Cs2VF4ME.js","_astro/PhCurrencyDollar.BetClcFM.js","_astro/PhDesktop.DZ44q8KV.js","_astro/PhDeviceMobile.BYTsoJFv.js","_astro/PhDotsThree.CZl-eiZJ.js","_astro/PhVault.CVlykDI9.js","_astro/PhEnvelope.DffTKA6H.js","_astro/PhFunnelSimple.BgL9D_9c.js","_astro/PhGlobe.Bu5QHqxs.js","_astro/PhIdentificationCard.BmdwlhZM.js","_astro/PhImage.Cw1zzbVt.js","_astro/PhInfo.DWWHh28B.js","_astro/PhLightbulb.B88rUY5q.js","_astro/PhMagnifyingGlass.Xl-MBUds.js","_astro/PhPaperPlaneRight.CeWoaYLA.js","_astro/PhPlus.BOh0VIBX.js","_astro/PhPower.CFW3N-Js.js","_astro/PhPuzzlePiece.D9Tojhi5.js","_astro/PhQrCode.Ccd2EEMd.js","_astro/PhQuestion.BkXZv5hE.js","_astro/PhQuestionMark.CeXm2EQz.js","_astro/PhSealCheck.D9d9Qyuj.js","_astro/PhSignOut.CD7kynsO.js","_astro/PhSpinner.m0odOB7o.js","_astro/PhTrash.HCBZ7UKb.js","_astro/PhUser.X51TxfNz.js","_astro/PhWallet.Dw50jz15.js","_astro/PhWarning.CCjNwBAf.js","_astro/PhWarningCircle.CXrpBVHt.js","_astro/PhX.CF9mDFKD.js"])))=>i.map(i=>d[i]);
import{g as Ei,b as Xf,c as xn,R as xc}from"./index.Dc61JUVC.js";const Qf=Symbol(),yd=Symbol(),ko="a",gp="f",cu="p",wp="c",bp="t",Cd="h",Oo="w",vd="o",Ed="k";let em=(e,t)=>new Proxy(e,t);const Ml=Object.getPrototypeOf,Ul=new WeakMap,yp=e=>e&&(Ul.has(e)?Ul.get(e):Ml(e)===Object.prototype||Ml(e)===Array.prototype),Pa=e=>typeof e=="object"&&e!==null,tm=e=>Object.values(Object.getOwnPropertyDescriptors(e)).some(t=>!t.configurable&&!t.writable),nm=e=>{if(Array.isArray(e))return Array.from(e);const t=Object.getOwnPropertyDescriptors(e);return Object.values(t).forEach(n=>{n.configurable=!0}),Object.create(Ml(e),t)},rm=(e,t)=>{const n={[gp]:t};let r=!1;const o=(a,c)=>{if(!r){let l=n[ko].get(e);if(l||(l={},n[ko].set(e,l)),a===Oo)l[Oo]=!0;else{let d=l[a];d||(d=new Set,l[a]=d),d.add(c)}}},i=()=>{r=!0,n[ko].delete(e)},s={get(a,c){return c===yd?e:(o(Ed,c),im(Reflect.get(a,c),n[ko],n[wp],n[bp]))},has(a,c){return c===Qf?(i(),!0):(o(Cd,c),Reflect.has(a,c))},getOwnPropertyDescriptor(a,c){return o(vd,c),Reflect.getOwnPropertyDescriptor(a,c)},ownKeys(a){return o(Oo),Reflect.ownKeys(a)}};return t&&(s.set=s.deleteProperty=()=>!1),[s,n]},_d=e=>e[yd]||e,im=(e,t,n,r)=>{if(!yp(e))return e;let o=r&&r.get(e);if(!o){const c=_d(e);tm(c)?o=[c,nm(c)]:o=[c],r?.set(e,o)}const[i,s]=o;let a=n&&n.get(i);return(!a||a[1][gp]!==!!s)&&(a=rm(i,!!s),a[1][cu]=em(s||i,a[0]),n&&n.set(i,a)),a[1][ko]=t,a[1][wp]=n,a[1][bp]=r,a[1][cu]},om=(e,t)=>{const n=Reflect.ownKeys(e),r=Reflect.ownKeys(t);return n.length!==r.length||n.some((o,i)=>o!==r[i])},sm=(e,t,n,r,o=Object.is)=>{if(o(e,t))return!1;if(!Pa(e)||!Pa(t))return!0;const i=n.get(_d(e));if(!i)return!0;if(r){if(r.get(e)===t)return!1;r.set(e,t)}let s=null;for(const a of i[Cd]||[])if(s=Reflect.has(e,a)!==Reflect.has(t,a),s)return s;if(i[Oo]===!0){if(s=om(e,t),s)return s}else for(const a of i[vd]||[]){const c=!!Reflect.getOwnPropertyDescriptor(e,a),l=!!Reflect.getOwnPropertyDescriptor(t,a);if(s=c!==l,s)return s}for(const a of i[Ed]||[])if(s=sm(e[a],t[a],n,r,o),s)return s;if(s===null)throw new Error("invalid used");return s},am=e=>yp(e)&&e[yd]||null,lu=(e,t=!0)=>{Ul.set(e,t)},Q4=(e,t,n)=>{const r=[],o=new WeakSet,i=(s,a)=>{var c,l,d;if(o.has(s))return;Pa(s)&&o.add(s);const h=Pa(s)&&t.get(_d(s));if(h){if((c=h[Cd])===null||c===void 0||c.forEach(f=>{const w=`:has(${String(f)})`;r.push(a?[...a,w]:[w])}),h[Oo]===!0){const f=":ownKeys";r.push(a?[...a,f]:[f])}else(l=h[vd])===null||l===void 0||l.forEach(f=>{const w=`:hasOwn(${String(f)})`;r.push(a?[...a,w]:[w])});(d=h[Ed])===null||d===void 0||d.forEach(f=>{"value"in(Object.getOwnPropertyDescriptor(s,f)||{})&&i(s[f],a?[...a,f]:[f])})}else a&&r.push(a)};return i(e),r},La={},Ad=e=>typeof e=="object"&&e!==null,cm=e=>Ad(e)&&!Ds.has(e)&&(Array.isArray(e)||!(Symbol.iterator in e))&&!(e instanceof WeakMap)&&!(e instanceof WeakSet)&&!(e instanceof Error)&&!(e instanceof Number)&&!(e instanceof Date)&&!(e instanceof String)&&!(e instanceof RegExp)&&!(e instanceof ArrayBuffer)&&!(e instanceof Promise),Cp=(e,t)=>{const n=Bl.get(e);if(n?.[0]===t)return n[1];const r=Array.isArray(e)?[]:Object.create(Object.getPrototypeOf(e));return lu(r,!0),Bl.set(e,[t,r]),Reflect.ownKeys(e).forEach(o=>{if(Object.getOwnPropertyDescriptor(r,o))return;const i=Reflect.get(e,o),{enumerable:s}=Reflect.getOwnPropertyDescriptor(e,o),a={value:i,enumerable:s,configurable:!0};if(Ds.has(i))lu(i,!1);else if(mr.has(i)){const[c,l]=mr.get(i);a.value=Cp(c,l())}Object.defineProperty(r,o,a)}),Object.preventExtensions(r)},lm=(e,t,n,r)=>({deleteProperty(o,i){const s=Reflect.get(o,i);n(i);const a=Reflect.deleteProperty(o,i);return a&&r(["delete",[i],s]),a},set(o,i,s,a){const c=!e()&&Reflect.has(o,i),l=Reflect.get(o,i,a);if(c&&(du(l,s)||Bo.has(s)&&du(l,Bo.get(s))))return!0;n(i),Ad(s)&&(s=am(s)||s);const d=!mr.has(s)&&um(s)?ze(s):s;return t(i,d),Reflect.set(o,i,d,a),r(["set",[i],s,l]),!0}}),mr=new WeakMap,Ds=new WeakSet,Bl=new WeakMap,Aa=[1],Bo=new WeakMap;let du=Object.is,dm=(e,t)=>new Proxy(e,t),um=cm,hm=Cp,pm=lm;function ze(e={}){if(!Ad(e))throw new Error("object required");const t=Bo.get(e);if(t)return t;let n=Aa[0];const r=new Set,o=($,I=++Aa[0])=>{n!==I&&(i=n=I,r.forEach(k=>k($,I)))};let i=n;const s=($=Aa[0])=>(i!==$&&(i=$,c.forEach(([I])=>{const k=I[1]($);k>n&&(n=k)})),n),a=$=>(I,k)=>{const D=[...I];D[1]=[$,...D[1]],o(D,k)},c=new Map,l=($,I)=>{const k=!Ds.has(I)&&mr.get(I);if(k){if((La?"production":void 0)!=="production"&&c.has($))throw new Error("prop listener already exists");if(r.size){const D=k[2](a($));c.set($,[k,D])}else c.set($,[k])}},d=$=>{var I;const k=c.get($);k&&(c.delete($),(I=k[1])==null||I.call(k))},h=$=>(r.add($),r.size===1&&c.forEach(([k,D],C)=>{if((La?"production":void 0)!=="production"&&D)throw new Error("remove already exists");const A=k[2](a(C));c.set(C,[k,A])}),()=>{r.delete($),r.size===0&&c.forEach(([k,D],C)=>{D&&(D(),c.set(C,[k]))})});let f=!0;const w=pm(()=>f,l,d,o),v=dm(e,w);Bo.set(e,v);const y=[e,s,h];return mr.set(v,y),Reflect.ownKeys(e).forEach($=>{const I=Object.getOwnPropertyDescriptor(e,$);"value"in I&&I.writable&&(v[$]=e[$])}),f=!1,v}function ot(e,t,n){const r=mr.get(e);(La?"production":void 0)!=="production"&&!r&&console.warn("Please use proxy object");let o;const i=[],s=r[2];let a=!1;const l=s(d=>{i.push(d),o||(o=Promise.resolve().then(()=>{o=void 0,a&&t(i.splice(0))}))});return a=!0,()=>{a=!1,l()}}function Wo(e){const t=mr.get(e);(La?"production":void 0)!=="production"&&!t&&console.warn("Please use proxy object");const[n,r]=t;return hm(n,r())}function Yi(e){return Ds.add(e),e}function fm(){return{proxyStateMap:mr,refSet:Ds,snapCache:Bl,versionHolder:Aa,proxyCache:Bo}}function st(e,t,n,r){let o=e[t];return ot(e,()=>{const i=e[t];Object.is(o,i)||n(o=i)})}const{proxyStateMap:mm,snapCache:gm}=fm(),sa=e=>mm.has(e);function wm(e){const t=[];let n=0;const r=new Map,o=new WeakMap,i=()=>{const l=gm.get(a),d=l?.[1];if(d&&!o.has(d)){const h=new Map(r);o.set(d,h)}},s=l=>o.get(l)||r,a={data:t,index:n,epoch:0,get size(){return sa(this)||i(),s(this).size},get(l){const h=s(this).get(l);if(h===void 0){this.epoch;return}return this.data[h]},has(l){const d=s(this);return this.epoch,d.has(l)},set(l,d){if(!sa(this))throw new Error("Cannot perform mutations on a snapshot");const h=r.get(l);return h===void 0?(r.set(l,this.index),this.data[this.index++]=d):this.data[h]=d,this.epoch++,this},delete(l){if(!sa(this))throw new Error("Cannot perform mutations on a snapshot");const d=r.get(l);return d===void 0?!1:(delete this.data[d],r.delete(l),this.epoch++,!0)},clear(){if(!sa(this))throw new Error("Cannot perform mutations on a snapshot");this.data.length=0,this.index=0,this.epoch++,r.clear()},forEach(l){this.epoch,s(this).forEach((h,f)=>{l(this.data[h],f,this)})},*entries(){this.epoch;const l=s(this);for(const[d,h]of l)yield[d,this.data[h]]},*keys(){this.epoch;const l=s(this);for(const d of l.keys())yield d},*values(){this.epoch;const l=s(this);for(const d of l.values())yield this.data[d]},[Symbol.iterator](){return this.entries()},get[Symbol.toStringTag](){return"Map"},toJSON(){return new Map(this.entries())}},c=ze(a);return Object.defineProperties(c,{size:{enumerable:!1},index:{enumerable:!1},epoch:{enumerable:!1},data:{enumerable:!1},toJSON:{enumerable:!1}}),Object.seal(c),c}const vp={isLowerCaseMatch(e,t){return e?.toLowerCase()===t?.toLowerCase()}};var xa={exports:{}},bm=xa.exports,uu;function ym(){return uu||(uu=1,(function(e,t){(function(n,r){e.exports=r()})(bm,(function(){var n=1e3,r=6e4,o=36e5,i="millisecond",s="second",a="minute",c="hour",l="day",d="week",h="month",f="quarter",w="year",v="date",y="Invalid Date",$=/^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,I=/\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,k={name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),ordinal:function(V){var b=["th","st","nd","rd"],E=V%100;return"["+V+(b[(E-20)%10]||b[E]||b[0])+"]"}},D=function(V,b,E){var H=String(V);return!H||H.length>=b?V:""+Array(b+1-H.length).join(E)+V},C={s:D,z:function(V){var b=-V.utcOffset(),E=Math.abs(b),H=Math.floor(E/60),F=E%60;return(b<=0?"+":"-")+D(H,2,"0")+":"+D(F,2,"0")},m:function V(b,E){if(b.date()<E.date())return-V(E,b);var H=12*(E.year()-b.year())+(E.month()-b.month()),F=b.clone().add(H,h),re=E-F<0,Z=b.clone().add(H+(re?-1:1),h);return+(-(H+(E-F)/(re?F-Z:Z-F))||0)},a:function(V){return V<0?Math.ceil(V)||0:Math.floor(V)},p:function(V){return{M:h,y:w,w:d,d:l,D:v,h:c,m:a,s,ms:i,Q:f}[V]||String(V||"").toLowerCase().replace(/s$/,"")},u:function(V){return V===void 0}},A="en",_={};_[A]=k;var P="$isDayjsObject",B=function(V){return V instanceof Y||!(!V||!V[P])},j=function V(b,E,H){var F;if(!b)return A;if(typeof b=="string"){var re=b.toLowerCase();_[re]&&(F=re),E&&(_[re]=E,F=re);var Z=b.split("-");if(!F&&Z.length>1)return V(Z[0])}else{var Ne=b.name;_[Ne]=b,F=Ne}return!H&&F&&(A=F),F||!H&&A},W=function(V,b){if(B(V))return V.clone();var E=typeof b=="object"?b:{};return E.date=V,E.args=arguments,new Y(E)},z=C;z.l=j,z.i=B,z.w=function(V,b){return W(V,{locale:b.$L,utc:b.$u,x:b.$x,$offset:b.$offset})};var Y=(function(){function V(E){this.$L=j(E.locale,null,!0),this.parse(E),this.$x=this.$x||E.x||{},this[P]=!0}var b=V.prototype;return b.parse=function(E){this.$d=(function(H){var F=H.date,re=H.utc;if(F===null)return new Date(NaN);if(z.u(F))return new Date;if(F instanceof Date)return new Date(F);if(typeof F=="string"&&!/Z$/i.test(F)){var Z=F.match($);if(Z){var Ne=Z[2]-1||0,We=(Z[7]||"0").substring(0,3);return re?new Date(Date.UTC(Z[1],Ne,Z[3]||1,Z[4]||0,Z[5]||0,Z[6]||0,We)):new Date(Z[1],Ne,Z[3]||1,Z[4]||0,Z[5]||0,Z[6]||0,We)}}return new Date(F)})(E),this.init()},b.init=function(){var E=this.$d;this.$y=E.getFullYear(),this.$M=E.getMonth(),this.$D=E.getDate(),this.$W=E.getDay(),this.$H=E.getHours(),this.$m=E.getMinutes(),this.$s=E.getSeconds(),this.$ms=E.getMilliseconds()},b.$utils=function(){return z},b.isValid=function(){return this.$d.toString()!==y},b.isSame=function(E,H){var F=W(E);return this.startOf(H)<=F&&F<=this.endOf(H)},b.isAfter=function(E,H){return W(E)<this.startOf(H)},b.isBefore=function(E,H){return this.endOf(H)<W(E)},b.$g=function(E,H,F){return z.u(E)?this[H]:this.set(F,E)},b.unix=function(){return Math.floor(this.valueOf()/1e3)},b.valueOf=function(){return this.$d.getTime()},b.startOf=function(E,H){var F=this,re=!!z.u(H)||H,Z=z.p(E),Ne=function(St,it){var sr=z.w(F.$u?Date.UTC(F.$y,it,St):new Date(F.$y,it,St),F);return re?sr:sr.endOf(l)},We=function(St,it){return z.w(F.toDate()[St].apply(F.toDate("s"),(re?[0,0,0,0]:[23,59,59,999]).slice(it)),F)},He=this.$W,Re=this.$M,Ve=this.$D,Wn="set"+(this.$u?"UTC":"");switch(Z){case w:return re?Ne(1,0):Ne(31,11);case h:return re?Ne(1,Re):Ne(0,Re+1);case d:var lt=this.$locale().weekStart||0,bt=(He<lt?He+7:He)-lt;return Ne(re?Ve-bt:Ve+(6-bt),Re);case l:case v:return We(Wn+"Hours",0);case c:return We(Wn+"Minutes",1);case a:return We(Wn+"Seconds",2);case s:return We(Wn+"Milliseconds",3);default:return this.clone()}},b.endOf=function(E){return this.startOf(E,!1)},b.$set=function(E,H){var F,re=z.p(E),Z="set"+(this.$u?"UTC":""),Ne=(F={},F[l]=Z+"Date",F[v]=Z+"Date",F[h]=Z+"Month",F[w]=Z+"FullYear",F[c]=Z+"Hours",F[a]=Z+"Minutes",F[s]=Z+"Seconds",F[i]=Z+"Milliseconds",F)[re],We=re===l?this.$D+(H-this.$W):H;if(re===h||re===w){var He=this.clone().set(v,1);He.$d[Ne](We),He.init(),this.$d=He.set(v,Math.min(this.$D,He.daysInMonth())).$d}else Ne&&this.$d[Ne](We);return this.init(),this},b.set=function(E,H){return this.clone().$set(E,H)},b.get=function(E){return this[z.p(E)]()},b.add=function(E,H){var F,re=this;E=Number(E);var Z=z.p(H),Ne=function(Re){var Ve=W(re);return z.w(Ve.date(Ve.date()+Math.round(Re*E)),re)};if(Z===h)return this.set(h,this.$M+E);if(Z===w)return this.set(w,this.$y+E);if(Z===l)return Ne(1);if(Z===d)return Ne(7);var We=(F={},F[a]=r,F[c]=o,F[s]=n,F)[Z]||1,He=this.$d.getTime()+E*We;return z.w(He,this)},b.subtract=function(E,H){return this.add(-1*E,H)},b.format=function(E){var H=this,F=this.$locale();if(!this.isValid())return F.invalidDate||y;var re=E||"YYYY-MM-DDTHH:mm:ssZ",Z=z.z(this),Ne=this.$H,We=this.$m,He=this.$M,Re=F.weekdays,Ve=F.months,Wn=F.meridiem,lt=function(it,sr,Ao,oa){return it&&(it[sr]||it(H,re))||Ao[sr].slice(0,oa)},bt=function(it){return z.s(Ne%12||12,it,"0")},St=Wn||function(it,sr,Ao){var oa=it<12?"AM":"PM";return Ao?oa.toLowerCase():oa};return re.replace(I,(function(it,sr){return sr||(function(Ao){switch(Ao){case"YY":return String(H.$y).slice(-2);case"YYYY":return z.s(H.$y,4,"0");case"M":return He+1;case"MM":return z.s(He+1,2,"0");case"MMM":return lt(F.monthsShort,He,Ve,3);case"MMMM":return lt(Ve,He);case"D":return H.$D;case"DD":return z.s(H.$D,2,"0");case"d":return String(H.$W);case"dd":return lt(F.weekdaysMin,H.$W,Re,2);case"ddd":return lt(F.weekdaysShort,H.$W,Re,3);case"dddd":return Re[H.$W];case"H":return String(Ne);case"HH":return z.s(Ne,2,"0");case"h":return bt(1);case"hh":return bt(2);case"a":return St(Ne,We,!0);case"A":return St(Ne,We,!1);case"m":return String(We);case"mm":return z.s(We,2,"0");case"s":return String(H.$s);case"ss":return z.s(H.$s,2,"0");case"SSS":return z.s(H.$ms,3,"0");case"Z":return Z}return null})(it)||Z.replace(":","")}))},b.utcOffset=function(){return 15*-Math.round(this.$d.getTimezoneOffset()/15)},b.diff=function(E,H,F){var re,Z=this,Ne=z.p(H),We=W(E),He=(We.utcOffset()-this.utcOffset())*r,Re=this-We,Ve=function(){return z.m(Z,We)};switch(Ne){case w:re=Ve()/12;break;case h:re=Ve();break;case f:re=Ve()/3;break;case d:re=(Re-He)/6048e5;break;case l:re=(Re-He)/864e5;break;case c:re=Re/o;break;case a:re=Re/r;break;case s:re=Re/n;break;default:re=Re}return F?re:z.a(re)},b.daysInMonth=function(){return this.endOf(h).$D},b.$locale=function(){return _[this.$L]},b.locale=function(E,H){if(!E)return this.$L;var F=this.clone(),re=j(E,H,!0);return re&&(F.$L=re),F},b.clone=function(){return z.w(this.$d,this)},b.toDate=function(){return new Date(this.valueOf())},b.toJSON=function(){return this.isValid()?this.toISOString():null},b.toISOString=function(){return this.$d.toISOString()},b.toString=function(){return this.$d.toUTCString()},V})(),ue=Y.prototype;return W.prototype=ue,[["$ms",i],["$s",s],["$m",a],["$H",c],["$W",l],["$M",h],["$y",w],["$D",v]].forEach((function(V){ue[V[1]]=function(b){return this.$g(b,V[0],V[1])}})),W.extend=function(V,b){return V.$i||(V(b,Y,W),V.$i=!0),W},W.locale=j,W.isDayjs=B,W.unix=function(V){return W(1e3*V)},W.en=_[A],W.Ls=_,W.p={},W}))})(xa)),xa.exports}var Cm=ym();const Vi=Ei(Cm);var Sa={exports:{}},vm=Sa.exports,hu;function Em(){return hu||(hu=1,(function(e,t){(function(n,r){e.exports=r()})(vm,(function(){return{name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),ordinal:function(n){var r=["th","st","nd","rd"],o=n%100;return"["+n+(r[(o-20)%10]||r[o]||r[0])+"]"}}}))})(Sa)),Sa.exports}var _m=Em();const Am=Ei(_m);var Ta={exports:{}},xm=Ta.exports,pu;function Sm(){return pu||(pu=1,(function(e,t){(function(n,r){e.exports=r()})(xm,(function(){return function(n,r,o){n=n||{};var i=r.prototype,s={future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"};function a(l,d,h,f){return i.fromToBase(l,d,h,f)}o.en.relativeTime=s,i.fromToBase=function(l,d,h,f,w){for(var v,y,$,I=h.$locale().relativeTime||s,k=n.thresholds||[{l:"s",r:44,d:"second"},{l:"m",r:89},{l:"mm",r:44,d:"minute"},{l:"h",r:89},{l:"hh",r:21,d:"hour"},{l:"d",r:35},{l:"dd",r:25,d:"day"},{l:"M",r:45},{l:"MM",r:10,d:"month"},{l:"y",r:17},{l:"yy",d:"year"}],D=k.length,C=0;C<D;C+=1){var A=k[C];A.d&&(v=f?o(l).diff(h,A.d,!0):h.diff(l,A.d,!0));var _=(n.rounding||Math.round)(Math.abs(v));if($=v>0,_<=A.r||!A.r){_<=1&&C>0&&(A=k[C-1]);var P=I[A.l];w&&(_=w(""+_)),y=typeof P=="string"?P.replace("%d",_):P(_,d,A.l,$);break}}if(d)return y;var B=$?I.future:I.past;return typeof B=="function"?B(y):B.replace("%s",y)},i.to=function(l,d){return a(l,d,this,!0)},i.from=function(l,d){return a(l,d,this)};var c=function(l){return l.$u?o.utc():o()};i.toNow=function(l){return this.to(c(this),l)},i.fromNow=function(l){return this.from(c(this),l)}}}))})(Ta)),Ta.exports}var Tm=Sm();const $m=Ei(Tm);var $a={exports:{}},Nm=$a.exports,fu;function Rm(){return fu||(fu=1,(function(e,t){(function(n,r){e.exports=r()})(Nm,(function(){return function(n,r,o){o.updateLocale=function(i,s){var a=o.Ls[i];if(a)return(s?Object.keys(s):[]).forEach((function(c){a[c]=s[c]})),a}}}))})($a)),$a.exports}var km=Rm();const Im=Ei(km);Vi.extend($m);Vi.extend(Im);const Om={...Am,name:"en-web3-modal",relativeTime:{future:"in %s",past:"%s ago",s:"%d sec",m:"1 min",mm:"%d min",h:"1 hr",hh:"%d hrs",d:"1 d",dd:"%d d",M:"1 mo",MM:"%d mo",y:"1 yr",yy:"%d yr"}},Pm=["January","February","March","April","May","June","July","August","September","October","November","December"];Vi.locale("en-web3-modal",Om);const Wl={getMonthNameByIndex(e){return Pm[e]},getYear(e=new Date().toISOString()){return Vi(e).year()},getRelativeDateFromNow(e){return Vi(e).locale("en-web3-modal").fromNow(!0)},formatDate(e,t="DD MMM"){return Vi(e).format(t)}};var mu={};const N={WC_NAME_SUFFIX:".reown.id",WC_NAME_SUFFIX_LEGACY:".wcn.id",BLOCKCHAIN_API_RPC_URL:"https://rpc.walletconnect.org",PULSE_API_URL:"https://pulse.walletconnect.org",W3M_API_URL:"https://api.web3modal.org",CONNECTOR_ID:{WALLET_CONNECT:"walletConnect",INJECTED:"injected",WALLET_STANDARD:"announced",COINBASE:"coinbaseWallet",COINBASE_SDK:"coinbaseWalletSDK",BASE_ACCOUNT:"baseAccount",SAFE:"safe",LEDGER:"ledger",OKX:"okx",EIP6963:"eip6963",AUTH:"AUTH"},CONNECTOR_NAMES:{AUTH:"Auth"},AUTH_CONNECTOR_SUPPORTED_CHAINS:["eip155","solana"],LIMITS:{PENDING_TRANSACTIONS:99},CHAIN:{EVM:"eip155",SOLANA:"solana",POLKADOT:"polkadot",BITCOIN:"bip122",TON:"ton"},CHAIN_NAME_MAP:{eip155:"EVM Networks",solana:"Solana",polkadot:"Polkadot",bip122:"Bitcoin",cosmos:"Cosmos",sui:"Sui",stacks:"Stacks",ton:"TON"},ADAPTER_TYPES:{BITCOIN:"bitcoin",SOLANA:"solana",WAGMI:"wagmi",ETHERS:"ethers",ETHERS5:"ethers5",TON:"ton"},USDT_CONTRACT_ADDRESSES:["0xdac17f958d2ee523a2206206994597c13d831ec7","0xc2132d05d31c914a87c6611c10748aeb04b58e8f","0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7","0x919C1c267BC06a7039e03fcc2eF738525769109c","0x48065fbBE25f71C9282ddf5e1cD6D6A887483D5e","0x55d398326f99059fF775485246999027B3197955","0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9"],SOLANA_SPL_TOKEN_ADDRESSES:{SOL:"So11111111111111111111111111111111111111112"},NATIVE_IMAGE_IDS_BY_NAMESPACE:{eip155:"ba0ba0cd-17c6-4806-ad93-f9d174f17900",solana:"3e8119e5-2a6f-4818-c50c-1937011d5900",bip122:"0b4838db-0161-4ffe-022d-532bf03dba00"},TOKEN_SYMBOLS_BY_ADDRESS:{"0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48":"USDC","0x833589fcd6edb6e08f4c7c32d4f71b54bda02913":"USDC","0x0b2c639c533813f4aa9d7837caf62653d097ff85":"USDC","0xaf88d065e77c8cc2239327c5edb3a432268e5831":"USDC","0x3c499c542cef5e3811e1192ce70d8cc03d5c3359":"USDC","0x2791bca1f2de4661ed88a30c99a7a9449aa84174":"USDC",EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v:"USDC","0xdac17f958d2ee523a2206206994597c13d831ec7":"USDT","0x94b008aa00579c1307b0ef2c499ad98a8ce58e58":"USDT","0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9":"USDT","0xc2132d05d31c914a87c6611c10748aeb04b58e8f":"USDT",Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB:"USDT"},HTTP_STATUS_CODES:{SERVER_ERROR:500,TOO_MANY_REQUESTS:429,SERVICE_UNAVAILABLE:503,FORBIDDEN:403},UNSUPPORTED_NETWORK_NAME:"Unknown Network",SECURE_SITE_SDK_ORIGIN:(typeof process<"u"&&typeof mu<"u"?mu.NEXT_PUBLIC_SECURE_SITE_ORIGIN:void 0)||"https://secure.walletconnect.org",REMOTE_FEATURES_ALERTS:{MULTI_WALLET_NOT_ENABLED:{DEFAULT:{displayMessage:"Multi-Wallet Not Enabled",debugMessage:"Multi-wallet support is not enabled. Please enable it in your AppKit configuration at cloud.reown.com."},CONNECTIONS_HOOK:{displayMessage:"Multi-Wallet Not Enabled",debugMessage:"Multi-wallet support is not enabled. Please enable it in your AppKit configuration at cloud.reown.com to use the useAppKitConnections hook."},CONNECTION_HOOK:{displayMessage:"Multi-Wallet Not Enabled",debugMessage:"Multi-wallet support is not enabled. Please enable it in your AppKit configuration at cloud.reown.com to use the useAppKitConnection hook."}},HEADLESS_NOT_ENABLED:{DEFAULT:{displayMessage:"",debugMessage:"Headless support is not enabled. Please enable it with the features.headless option in the AppKit configuration and make sure your current plan supports it."}}},IS_DEVELOPMENT:typeof process<"u"&&!1,DEFAULT_ALLOWED_ANCESTORS:["http://localhost:*","https://localhost:*","http://127.0.0.1:*","https://127.0.0.1:*","https://*.pages.dev","https://*.vercel.app","https://*.ngrok-free.app","https://secure-mobile.walletconnect.com","https://secure-mobile.walletconnect.org"],METMASK_CONNECTOR_NAME:"MetaMask",TRUST_CONNECTOR_NAME:"Trust Wallet",SOLFLARE_CONNECTOR_NAME:"Solflare",PHANTOM_CONNECTOR_NAME:"Phantom",COIN98_CONNECTOR_NAME:"Coin98",MAGIC_EDEN_CONNECTOR_NAME:"Magic Eden",BACKPACK_CONNECTOR_NAME:"Backpack",BITGET_CONNECTOR_NAME:"Bitget Wallet",FRONTIER_CONNECTOR_NAME:"Frontier",XVERSE_CONNECTOR_NAME:"Xverse Wallet",LEATHER_CONNECTOR_NAME:"Leather",OKX_CONNECTOR_NAME:"OKX Wallet",BINANCE_CONNECTOR_NAME:"Binance Wallet",EIP155:"eip155",ADD_CHAIN_METHOD:"wallet_addEthereumChain",EIP6963_ANNOUNCE_EVENT:"eip6963:announceProvider",EIP6963_REQUEST_EVENT:"eip6963:requestProvider",CONNECTOR_RDNS_MAP:{coinbaseWallet:"com.coinbase.wallet",coinbaseWalletSDK:"com.coinbase.wallet"},CONNECTOR_TYPE_EXTERNAL:"EXTERNAL",CONNECTOR_TYPE_WALLET_CONNECT:"WALLET_CONNECT",CONNECTOR_TYPE_INJECTED:"INJECTED",CONNECTOR_TYPE_ANNOUNCED:"ANNOUNCED",CONNECTOR_TYPE_AUTH:"AUTH",CONNECTOR_TYPE_MULTI_CHAIN:"MULTI_CHAIN",CONNECTOR_TYPE_W3M_AUTH:"AUTH"},Lm={caipNetworkIdToNumber(e){return e?Number(e.split(":")[1]):void 0},parseEvmChainId(e){return typeof e=="string"?this.caipNetworkIdToNumber(e):e},getNetworksByNamespace(e,t){return e?.filter(n=>n.chainNamespace===t)||[]},getFirstNetworkByNamespace(e,t){return this.getNetworksByNamespace(e,t)[0]},getNetworkNameByCaipNetworkId(e,t){if(!t)return;const n=e.find(o=>o.caipNetworkId===t);if(n)return n.name;const[r]=t.split(":");return N.CHAIN_NAME_MAP?.[r]||void 0}},Ep=["eip155","solana","polkadot","bip122","cosmos","sui","stacks"];var Dm=20,Mm=1,Kr=1e6,gu=1e6,Um=-7,Bm=21,Wm=!1,Ms="[big.js] ",_i=Ms+"Invalid ",Sc=_i+"decimal places",jm=_i+"rounding mode",_p=Ms+"Division by zero",Me={},Nn=void 0,Fm=/^-?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;function Ap(){function e(t){var n=this;if(!(n instanceof e))return t===Nn?Ap():new e(t);if(t instanceof e)n.s=t.s,n.e=t.e,n.c=t.c.slice();else{if(typeof t!="string"){if(e.strict===!0&&typeof t!="bigint")throw TypeError(_i+"value");t=t===0&&1/t<0?"-0":String(t)}zm(n,t)}n.constructor=e}return e.prototype=Me,e.DP=Dm,e.RM=Mm,e.NE=Um,e.PE=Bm,e.strict=Wm,e.roundDown=0,e.roundHalfUp=1,e.roundHalfEven=2,e.roundUp=3,e}function zm(e,t){var n,r,o;if(!Fm.test(t))throw Error(_i+"number");for(e.s=t.charAt(0)=="-"?(t=t.slice(1),-1):1,(n=t.indexOf("."))>-1&&(t=t.replace(".","")),(r=t.search(/e/i))>0?(n<0&&(n=r),n+=+t.slice(r+1),t=t.substring(0,r)):n<0&&(n=t.length),o=t.length,r=0;r<o&&t.charAt(r)=="0";)++r;if(r==o)e.c=[e.e=0];else{for(;o>0&&t.charAt(--o)=="0";);for(e.e=n-r-1,e.c=[],n=0;r<=o;)e.c[n++]=+t.charAt(r++)}return e}function Ai(e,t,n,r){var o=e.c;if(n===Nn&&(n=e.constructor.RM),n!==0&&n!==1&&n!==2&&n!==3)throw Error(jm);if(t<1)r=n===3&&(r||!!o[0])||t===0&&(n===1&&o[0]>=5||n===2&&(o[0]>5||o[0]===5&&(r||o[1]!==Nn))),o.length=1,r?(e.e=e.e-t+1,o[0]=1):o[0]=e.e=0;else if(t<o.length){if(r=n===1&&o[t]>=5||n===2&&(o[t]>5||o[t]===5&&(r||o[t+1]!==Nn||o[t-1]&1))||n===3&&(r||!!o[0]),o.length=t,r){for(;++o[--t]>9;)if(o[t]=0,t===0){++e.e,o.unshift(1);break}}for(t=o.length;!o[--t];)o.pop()}return e}function xi(e,t,n){var r=e.e,o=e.c.join(""),i=o.length;if(t)o=o.charAt(0)+(i>1?"."+o.slice(1):"")+(r<0?"e":"e+")+r;else if(r<0){for(;++r;)o="0"+o;o="0."+o}else if(r>0)if(++r>i)for(r-=i;r--;)o+="0";else r<i&&(o=o.slice(0,r)+"."+o.slice(r));else i>1&&(o=o.charAt(0)+"."+o.slice(1));return e.s<0&&n?"-"+o:o}Me.abs=function(){var e=new this.constructor(this);return e.s=1,e};Me.cmp=function(e){var t,n=this,r=n.c,o=(e=new n.constructor(e)).c,i=n.s,s=e.s,a=n.e,c=e.e;if(!r[0]||!o[0])return r[0]?i:o[0]?-s:0;if(i!=s)return i;if(t=i<0,a!=c)return a>c^t?1:-1;for(s=(a=r.length)<(c=o.length)?a:c,i=-1;++i<s;)if(r[i]!=o[i])return r[i]>o[i]^t?1:-1;return a==c?0:a>c^t?1:-1};Me.div=function(e){var t=this,n=t.constructor,r=t.c,o=(e=new n(e)).c,i=t.s==e.s?1:-1,s=n.DP;if(s!==~~s||s<0||s>Kr)throw Error(Sc);if(!o[0])throw Error(_p);if(!r[0])return e.s=i,e.c=[e.e=0],e;var a,c,l,d,h,f=o.slice(),w=a=o.length,v=r.length,y=r.slice(0,a),$=y.length,I=e,k=I.c=[],D=0,C=s+(I.e=t.e-e.e)+1;for(I.s=i,i=C<0?0:C,f.unshift(0);$++<a;)y.push(0);do{for(l=0;l<10;l++){if(a!=($=y.length))d=a>$?1:-1;else for(h=-1,d=0;++h<a;)if(o[h]!=y[h]){d=o[h]>y[h]?1:-1;break}if(d<0){for(c=$==a?o:f;$;){if(y[--$]<c[$]){for(h=$;h&&!y[--h];)y[h]=9;--y[h],y[$]+=10}y[$]-=c[$]}for(;!y[0];)y.shift()}else break}k[D++]=d?l:++l,y[0]&&d?y[$]=r[w]||0:y=[r[w]]}while((w++<v||y[0]!==Nn)&&i--);return!k[0]&&D!=1&&(k.shift(),I.e--,C--),D>C&&Ai(I,C,n.RM,y[0]!==Nn),I};Me.eq=function(e){return this.cmp(e)===0};Me.gt=function(e){return this.cmp(e)>0};Me.gte=function(e){return this.cmp(e)>-1};Me.lt=function(e){return this.cmp(e)<0};Me.lte=function(e){return this.cmp(e)<1};Me.minus=Me.sub=function(e){var t,n,r,o,i=this,s=i.constructor,a=i.s,c=(e=new s(e)).s;if(a!=c)return e.s=-c,i.plus(e);var l=i.c.slice(),d=i.e,h=e.c,f=e.e;if(!l[0]||!h[0])return h[0]?e.s=-c:l[0]?e=new s(i):e.s=1,e;if(a=d-f){for((o=a<0)?(a=-a,r=l):(f=d,r=h),r.reverse(),c=a;c--;)r.push(0);r.reverse()}else for(n=((o=l.length<h.length)?l:h).length,a=c=0;c<n;c++)if(l[c]!=h[c]){o=l[c]<h[c];break}if(o&&(r=l,l=h,h=r,e.s=-e.s),(c=(n=h.length)-(t=l.length))>0)for(;c--;)l[t++]=0;for(c=t;n>a;){if(l[--n]<h[n]){for(t=n;t&&!l[--t];)l[t]=9;--l[t],l[n]+=10}l[n]-=h[n]}for(;l[--c]===0;)l.pop();for(;l[0]===0;)l.shift(),--f;return l[0]||(e.s=1,l=[f=0]),e.c=l,e.e=f,e};Me.mod=function(e){var t,n=this,r=n.constructor,o=n.s,i=(e=new r(e)).s;if(!e.c[0])throw Error(_p);return n.s=e.s=1,t=e.cmp(n)==1,n.s=o,e.s=i,t?new r(n):(o=r.DP,i=r.RM,r.DP=r.RM=0,n=n.div(e),r.DP=o,r.RM=i,this.minus(n.times(e)))};Me.neg=function(){var e=new this.constructor(this);return e.s=-e.s,e};Me.plus=Me.add=function(e){var t,n,r,o=this,i=o.constructor;if(e=new i(e),o.s!=e.s)return e.s=-e.s,o.minus(e);var s=o.e,a=o.c,c=e.e,l=e.c;if(!a[0]||!l[0])return l[0]||(a[0]?e=new i(o):e.s=o.s),e;if(a=a.slice(),t=s-c){for(t>0?(c=s,r=l):(t=-t,r=a),r.reverse();t--;)r.push(0);r.reverse()}for(a.length-l.length<0&&(r=l,l=a,a=r),t=l.length,n=0;t;a[t]%=10)n=(a[--t]=a[t]+l[t]+n)/10|0;for(n&&(a.unshift(n),++c),t=a.length;a[--t]===0;)a.pop();return e.c=a,e.e=c,e};Me.pow=function(e){var t=this,n=new t.constructor("1"),r=n,o=e<0;if(e!==~~e||e<-gu||e>gu)throw Error(_i+"exponent");for(o&&(e=-e);e&1&&(r=r.times(t)),e>>=1,!!e;)t=t.times(t);return o?n.div(r):r};Me.prec=function(e,t){if(e!==~~e||e<1||e>Kr)throw Error(_i+"precision");return Ai(new this.constructor(this),e,t)};Me.round=function(e,t){if(e===Nn)e=0;else if(e!==~~e||e<-Kr||e>Kr)throw Error(Sc);return Ai(new this.constructor(this),e+this.e+1,t)};Me.sqrt=function(){var e,t,n,r=this,o=r.constructor,i=r.s,s=r.e,a=new o("0.5");if(!r.c[0])return new o(r);if(i<0)throw Error(Ms+"No square root");i=Math.sqrt(+xi(r,!0,!0)),i===0||i===1/0?(t=r.c.join(""),t.length+s&1||(t+="0"),i=Math.sqrt(t),s=((s+1)/2|0)-(s<0||s&1),e=new o((i==1/0?"5e":(i=i.toExponential()).slice(0,i.indexOf("e")+1))+s)):e=new o(i+""),s=e.e+(o.DP+=4);do n=e,e=a.times(n.plus(r.div(n)));while(n.c.slice(0,s).join("")!==e.c.slice(0,s).join(""));return Ai(e,(o.DP-=4)+e.e+1,o.RM)};Me.times=Me.mul=function(e){var t,n=this,r=n.constructor,o=n.c,i=(e=new r(e)).c,s=o.length,a=i.length,c=n.e,l=e.e;if(e.s=n.s==e.s?1:-1,!o[0]||!i[0])return e.c=[e.e=0],e;for(e.e=c+l,s<a&&(t=o,o=i,i=t,l=s,s=a,a=l),t=new Array(l=s+a);l--;)t[l]=0;for(c=a;c--;){for(a=0,l=s+c;l>c;)a=t[l]+i[c]*o[l-c-1]+a,t[l--]=a%10,a=a/10|0;t[l]=a}for(a?++e.e:t.shift(),c=t.length;!t[--c];)t.pop();return e.c=t,e};Me.toExponential=function(e,t){var n=this,r=n.c[0];if(e!==Nn){if(e!==~~e||e<0||e>Kr)throw Error(Sc);for(n=Ai(new n.constructor(n),++e,t);n.c.length<e;)n.c.push(0)}return xi(n,!0,!!r)};Me.toFixed=function(e,t){var n=this,r=n.c[0];if(e!==Nn){if(e!==~~e||e<0||e>Kr)throw Error(Sc);for(n=Ai(new n.constructor(n),e+n.e+1,t),e=e+n.e+1;n.c.length<e;)n.c.push(0)}return xi(n,!1,!!r)};Me[Symbol.for("nodejs.util.inspect.custom")]=Me.toJSON=Me.toString=function(){var e=this,t=e.constructor;return xi(e,e.e<=t.NE||e.e>=t.PE,!!e.c[0])};Me.toNumber=function(){var e=+xi(this,!0,!0);if(this.constructor.strict===!0&&!this.eq(e.toString()))throw Error(Ms+"Imprecise conversion");return e};Me.toPrecision=function(e,t){var n=this,r=n.constructor,o=n.c[0];if(e!==Nn){if(e!==~~e||e<1||e>Kr)throw Error(_i+"precision");for(n=Ai(new r(n),e,t);n.c.length<e;)n.c.push(0)}return xi(n,e<=n.e||n.e<=r.NE||n.e>=r.PE,!!o)};Me.valueOf=function(){var e=this,t=e.constructor;if(t.strict===!0)throw Error(Ms+"valueOf disallowed");return xi(e,e.e<=t.NE||e.e>=t.PE,!0)};var En=Ap();const Ji={bigNumber(e,t={safe:!1}){try{return e?new En(e):new En(0)}catch(n){if(t.safe)return new En(0);throw n}},formatNumber(e,t){const{decimals:n,round:r=8,safe:o=!0}=t;return Ji.bigNumber(e,{safe:o}).div(new En(10).pow(n)).round(r)},multiply(e,t){if(e===void 0||t===void 0)return new En(0);const n=new En(e),r=new En(t);return n.times(r)},toFixed(e,t=2){return e===void 0||e===""?new En(0).toFixed(t):new En(e).toFixed(t)},formatNumberToLocalString(e,t=2){return e===void 0||e===""?"0.00":typeof e=="number"?e.toLocaleString("en-US",{maximumFractionDigits:t,minimumFractionDigits:t,roundingMode:"floor"}):parseFloat(e).toLocaleString("en-US",{maximumFractionDigits:t,minimumFractionDigits:t,roundingMode:"floor"})},parseLocalStringToNumber(e){if(e===void 0||e==="")return 0;const t=e.replace(/,/gu,"");return new En(t).toNumber()}},Hm=[{type:"function",name:"transfer",stateMutability:"nonpayable",inputs:[{name:"_to",type:"address"},{name:"_value",type:"uint256"}],outputs:[{name:"",type:"bool"}]},{type:"function",name:"transferFrom",stateMutability:"nonpayable",inputs:[{name:"_from",type:"address"},{name:"_to",type:"address"},{name:"_value",type:"uint256"}],outputs:[{name:"",type:"bool"}]}],Vm=[{type:"function",name:"approve",stateMutability:"nonpayable",inputs:[{name:"spender",type:"address"},{name:"amount",type:"uint256"}],outputs:[{type:"bool"}]}],qm=[{type:"function",name:"transfer",stateMutability:"nonpayable",inputs:[{name:"recipient",type:"address"},{name:"amount",type:"uint256"}],outputs:[]},{type:"function",name:"transferFrom",stateMutability:"nonpayable",inputs:[{name:"sender",type:"address"},{name:"recipient",type:"address"},{name:"amount",type:"uint256"}],outputs:[{name:"",type:"bool"}]}],Km={getERC20Abi:e=>N.USDT_CONTRACT_ADDRESSES.includes(e)?qm:Hm,getSwapAbi:()=>Vm},Gm={URLS:{FAQ:"https://walletconnect.com/faq"}},Di={ConnectorExplorerIds:{[N.CONNECTOR_ID.COINBASE]:"fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa",[N.CONNECTOR_ID.COINBASE_SDK]:"fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa",[N.CONNECTOR_ID.BASE_ACCOUNT]:"fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa",[N.CONNECTOR_ID.SAFE]:"225affb176778569276e484e1b92637ad061b01e13a048b35a9d280c3b58970f",[N.CONNECTOR_ID.LEDGER]:"19177a98252e07ddfc9af2083ba8e07ef627cb6103467ffebb3f8f4205fd7927",[N.CONNECTOR_ID.OKX]:"971e689d0a5be527bac79629b4ee9b925e82208e5168b733496a09c0faed0709",[N.METMASK_CONNECTOR_NAME]:"c57ca95b47569778a828d19178114f4db188b89b763c899ba0be274e97267d96",[N.TRUST_CONNECTOR_NAME]:"4622a2b2d6af1c9844944291e5e7351a6aa24cd7b23099efac1b2fd875da31a0",[N.SOLFLARE_CONNECTOR_NAME]:"1ca0bdd4747578705b1939af023d120677c64fe6ca76add81fda36e350605e79",[N.PHANTOM_CONNECTOR_NAME]:"a797aa35c0fadbfc1a53e7f675162ed5226968b44a19ee3d24385c64d1d3c393",[N.COIN98_CONNECTOR_NAME]:"2a3c89040ac3b723a1972a33a125b1db11e258a6975d3a61252cd64e6ea5ea01",[N.MAGIC_EDEN_CONNECTOR_NAME]:"8b830a2b724a9c3fbab63af6f55ed29c9dfa8a55e732dc88c80a196a2ba136c6",[N.BACKPACK_CONNECTOR_NAME]:"2bd8c14e035c2d48f184aaa168559e86b0e3433228d3c4075900a221785019b0",[N.BITGET_CONNECTOR_NAME]:"38f5d18bd8522c244bdd70cb4a68e0e718865155811c043f052fb9f1c51de662",[N.FRONTIER_CONNECTOR_NAME]:"85db431492aa2e8672e93f4ea7acf10c88b97b867b0d373107af63dc4880f041",[N.XVERSE_CONNECTOR_NAME]:"2a87d74ae02e10bdd1f51f7ce6c4e1cc53cd5f2c0b6b5ad0d7b3007d2b13de7b",[N.LEATHER_CONNECTOR_NAME]:"483afe1df1df63daf313109971ff3ef8356ddf1cc4e45877d205eee0b7893a13",[N.OKX_CONNECTOR_NAME]:"971e689d0a5be527bac79629b4ee9b925e82208e5168b733496a09c0faed0709",[N.BINANCE_CONNECTOR_NAME]:"2fafea35bb471d22889ccb49c08d99dd0a18a37982602c33f696a5723934ba25"},ConnectorImageIds:{[N.CONNECTOR_ID.COINBASE]:"0c2840c3-5b04-4c44-9661-fbd4b49e1800",[N.CONNECTOR_ID.COINBASE_SDK]:"0c2840c3-5b04-4c44-9661-fbd4b49e1800",[N.CONNECTOR_ID.BASE_ACCOUNT]:"bba2c8be-7fd1-463e-42b1-796ecb0ad200",[N.CONNECTOR_ID.SAFE]:"461db637-8616-43ce-035a-d89b8a1d5800",[N.CONNECTOR_ID.LEDGER]:"54a1aa77-d202-4f8d-0fb2-5d2bb6db0300",[N.CONNECTOR_ID.WALLET_CONNECT]:"ef1a1fcf-7fe8-4d69-bd6d-fda1345b4400",[N.CONNECTOR_ID.INJECTED]:"07ba87ed-43aa-4adf-4540-9e6a2b9cae00"},ConnectorNamesMap:{[N.CONNECTOR_ID.INJECTED]:"Browser Wallet",[N.CONNECTOR_ID.WALLET_CONNECT]:"WalletConnect",[N.CONNECTOR_ID.COINBASE]:"Coinbase",[N.CONNECTOR_ID.COINBASE_SDK]:"Coinbase",[N.CONNECTOR_ID.BASE_ACCOUNT]:"Base Account",[N.CONNECTOR_ID.LEDGER]:"Ledger",[N.CONNECTOR_ID.SAFE]:"Safe"},ConnectorTypesMap:{[N.CONNECTOR_ID.INJECTED]:"INJECTED",[N.CONNECTOR_ID.WALLET_CONNECT]:"WALLET_CONNECT",[N.CONNECTOR_ID.EIP6963]:"ANNOUNCED",[N.CONNECTOR_ID.AUTH]:"AUTH"}},Jt={validateCaipAddress(e){if(e.split(":")?.length!==3)throw new Error("Invalid CAIP Address");return e},parseCaipAddress(e){const t=e.split(":");if(t.length!==3)throw new Error(`Invalid CAIP-10 address: ${e}`);const[n,r,o]=t;if(!n||!r||!o)throw new Error(`Invalid CAIP-10 address: ${e}`);return{chainNamespace:n,chainId:r,address:o}},parseCaipNetworkId(e){const t=e.split(":");if(t.length!==2)throw new Error(`Invalid CAIP-2 network id: ${e}`);const[n,r]=t;if(!n||!r)throw new Error(`Invalid CAIP-2 network id: ${e}`);return{chainNamespace:n,chainId:r}}},Yt={RPC_ERROR_CODE:{USER_REJECTED_REQUEST:4001,USER_REJECTED_METHODS:5002,USER_REJECTED:5e3},PROVIDER_RPC_ERROR_NAME:{PROVIDER_RPC:"ProviderRpcError",USER_REJECTED_REQUEST:"UserRejectedRequestError"},isRpcProviderError(e){try{if(typeof e=="object"&&e!==null){const t=e,n=typeof t.message=="string",r=typeof t.code=="number";return n&&r}return!1}catch{return!1}},isUserRejectedMessage(e){return e.toLowerCase().includes("user rejected")||e.toLowerCase().includes("user cancelled")||e.toLowerCase().includes("user canceled")},isUserRejectedRequestError(e){if(Yt.isRpcProviderError(e)){const t=e.code===Yt.RPC_ERROR_CODE.USER_REJECTED_REQUEST,n=e.code===Yt.RPC_ERROR_CODE.USER_REJECTED_METHODS;return t||n||Yt.isUserRejectedMessage(e.message)}return e instanceof Error?Yt.isUserRejectedMessage(e.message):!1}};let Zm=class extends Error{constructor(t,n){super(n.message,{cause:t}),this.name=Yt.PROVIDER_RPC_ERROR_NAME.PROVIDER_RPC,this.code=n.code}},Ym=class extends Zm{constructor(t){super(t,{code:Yt.RPC_ERROR_CODE.USER_REJECTED_REQUEST,message:"User rejected the request"}),this.name=Yt.PROVIDER_RPC_ERROR_NAME.USER_REJECTED_REQUEST}};const ce={WALLET_ID:"@appkit/wallet_id",WALLET_NAME:"@appkit/wallet_name",SOLANA_WALLET:"@appkit/solana_wallet",SOLANA_CAIP_CHAIN:"@appkit/solana_caip_chain",ACTIVE_CAIP_NETWORK_ID:"@appkit/active_caip_network_id",CONNECTED_SOCIAL:"@appkit/connected_social",CONNECTED_SOCIAL_USERNAME:"@appkit-wallet/SOCIAL_USERNAME",RECENT_WALLETS:"@appkit/recent_wallets",RECENT_WALLET:"@appkit/recent_wallet",DEEPLINK_CHOICE:"WALLETCONNECT_DEEPLINK_CHOICE",ACTIVE_NAMESPACE:"@appkit/active_namespace",CONNECTED_NAMESPACES:"@appkit/connected_namespaces",CONNECTION_STATUS:"@appkit/connection_status",SIWX_AUTH_TOKEN:"@appkit/siwx-auth-token",SIWX_NONCE_TOKEN:"@appkit/siwx-nonce-token",TELEGRAM_SOCIAL_PROVIDER:"@appkit/social_provider",NATIVE_BALANCE_CACHE:"@appkit/native_balance_cache",PORTFOLIO_CACHE:"@appkit/portfolio_cache",ENS_CACHE:"@appkit/ens_cache",IDENTITY_CACHE:"@appkit/identity_cache",PREFERRED_ACCOUNT_TYPES:"@appkit/preferred_account_types",CONNECTIONS:"@appkit/connections",DISCONNECTED_CONNECTOR_IDS:"@appkit/disconnected_connector_ids",HISTORY_TRANSACTIONS_CACHE:"@appkit/history_transactions_cache",TOKEN_PRICE_CACHE:"@appkit/token_price_cache",RECENT_EMAILS:"@appkit/recent_emails",LATEST_APPKIT_VERSION:"@appkit/latest_version",TON_WALLETS_CACHE:"@appkit/ton_wallets_cache"};function Vc(e){if(!e)throw new Error("Namespace is required for CONNECTED_CONNECTOR_ID");return`@appkit/${e}:connected_connector_id`}const se={setItem(e,t){Io()&&t!==void 0&&localStorage.setItem(e,t)},getItem(e){if(Io())return localStorage.getItem(e)||void 0},removeItem(e){Io()&&localStorage.removeItem(e)},clear(){Io()&&localStorage.clear()}};function Io(){return typeof window<"u"&&typeof localStorage<"u"}function Da(e,t){const n=e?.["--apkt-accent"]??e?.["--w3m-accent"];return t==="light"?{"--w3m-accent":n||"hsla(231, 100%, 70%, 1)","--w3m-background":"#fff"}:{"--w3m-accent":n||"hsla(230, 100%, 67%, 1)","--w3m-background":"#202020"}}var wu={};const qc=(typeof process<"u"&&typeof wu<"u"?wu.NEXT_PUBLIC_SECURE_SITE_ORIGIN:void 0)||"https://secure.walletconnect.org",nv=[{label:"Meld.io",name:"meld",feeRange:"1-2%",url:"https://meldcrypto.com",supportedChains:["eip155","solana"]}],rv="WXETMuFUQmqqybHuRkSgxv:25B8LJHSfpG6LVjR2ytU5Cwh7Z4Sch2ocoU",ke={FOUR_MINUTES_MS:24e4,TEN_SEC_MS:1e4,FIVE_SEC_MS:5e3,THREE_SEC_MS:3e3,ONE_SEC_MS:1e3,SECURE_SITE:qc,SECURE_SITE_DASHBOARD:`${qc}/dashboard`,SECURE_SITE_FAVICON:`${qc}/images/favicon.png`,SOLANA_NATIVE_TOKEN_ADDRESS:"So11111111111111111111111111111111111111111",RESTRICTED_TIMEZONES:["ASIA/SHANGHAI","ASIA/URUMQI","ASIA/CHONGQING","ASIA/HARBIN","ASIA/KASHGAR","ASIA/MACAU","ASIA/HONG_KONG","ASIA/MACAO","ASIA/BEIJING","ASIA/HARBIN"],SWAP_SUGGESTED_TOKENS:["ETH","UNI","1INCH","AAVE","SOL","ADA","AVAX","DOT","LINK","NITRO","GAIA","MILK","TRX","NEAR","GNO","WBTC","DAI","WETH","USDC","USDT","ARB","BAL","BICO","CRV","ENS","MATIC","OP"],SWAP_POPULAR_TOKENS:["ETH","UNI","1INCH","AAVE","SOL","ADA","AVAX","DOT","LINK","NITRO","GAIA","MILK","TRX","NEAR","GNO","WBTC","DAI","WETH","USDC","USDT","ARB","BAL","BICO","CRV","ENS","MATIC","OP","METAL","DAI","CHAMP","WOLF","SALE","BAL","BUSD","MUST","BTCpx","ROUTE","HEX","WELT","amDAI","VSQ","VISION","AURUM","pSP","SNX","VC","LINK","CHP","amUSDT","SPHERE","FOX","GIDDY","GFC","OMEN","OX_OLD","DE","WNT"],SUGGESTED_TOKENS_BY_CHAIN:{"eip155:42161":["USD₮0"]},BALANCE_SUPPORTED_CHAINS:[N.CHAIN.EVM,N.CHAIN.SOLANA],SEND_PARAMS_SUPPORTED_CHAINS:[N.CHAIN.EVM],SWAP_SUPPORTED_NETWORKS:["eip155:1","eip155:42161","eip155:10","eip155:324","eip155:8453","eip155:56","eip155:137","eip155:100","eip155:43114","eip155:250","eip155:8217","eip155:1313161554"],NAMES_SUPPORTED_CHAIN_NAMESPACES:[N.CHAIN.EVM],ONRAMP_SUPPORTED_CHAIN_NAMESPACES:[N.CHAIN.EVM,N.CHAIN.SOLANA],PAY_WITH_EXCHANGE_SUPPORTED_CHAIN_NAMESPACES:[N.CHAIN.EVM,N.CHAIN.SOLANA],ACTIVITY_ENABLED_CHAIN_NAMESPACES:[N.CHAIN.EVM,N.CHAIN.TON],NATIVE_TOKEN_ADDRESS:{eip155:"0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",solana:"So11111111111111111111111111111111111111111",polkadot:"0x",bip122:"0x",cosmos:"0x",sui:"0x",stacks:"0x",ton:"0x"},CONVERT_SLIPPAGE_TOLERANCE:1,CONNECT_LABELS:{MOBILE:"Open and continue in the wallet app",WEB:"Open and continue in the wallet app"},SEND_SUPPORTED_NAMESPACES:[N.CHAIN.EVM,N.CHAIN.SOLANA],DEFAULT_REMOTE_FEATURES:{swaps:["1inch"],onramp:["meld"],email:!0,socials:["google","x","discord","farcaster","github","apple","facebook"],activity:!0,reownBranding:!0,multiWallet:!1,emailCapture:!1,payWithExchange:!1,payments:!1,reownAuthentication:!1,headless:!1},DEFAULT_REMOTE_FEATURES_DISABLED:{email:!1,socials:!1,swaps:!1,onramp:!1,activity:!1,reownBranding:!1,emailCapture:!1,reownAuthentication:!1,headless:!1},DEFAULT_FEATURES:{receive:!0,send:!0,emailShowWallets:!0,connectorTypeOrder:["walletConnect","recent","injected","featured","custom","external","recommended"],analytics:!0,allWallets:!0,legalCheckbox:!1,smartSessions:!1,collapseWallets:!1,walletFeaturesOrder:["onramp","swaps","receive","send"],connectMethodsOrder:void 0,pay:!1,reownAuthentication:!1,headless:!1},DEFAULT_SOCIALS:["google","x","farcaster","discord","apple","github","facebook"],DEFAULT_ACCOUNT_TYPES:{bip122:"payment",eip155:"smartAccount",polkadot:"eoa",solana:"eoa",ton:"eoa"},ADAPTER_TYPES:{UNIVERSAL:"universal",SOLANA:"solana",WAGMI:"wagmi",ETHERS:"ethers",ETHERS5:"ethers5",BITCOIN:"bitcoin"},SIWX_DEFAULTS:{signOutOnDisconnect:!0},MANDATORY_WALLET_IDS_ON_MOBILE:[Di.ConnectorExplorerIds[N.CONNECTOR_ID.COINBASE],Di.ConnectorExplorerIds[N.CONNECTOR_ID.COINBASE_SDK],Di.ConnectorExplorerIds[N.CONNECTOR_ID.BASE_ACCOUNT],Di.ConnectorExplorerIds[N.SOLFLARE_CONNECTOR_NAME],Di.ConnectorExplorerIds[N.PHANTOM_CONNECTOR_NAME],Di.ConnectorExplorerIds[N.BINANCE_CONNECTOR_NAME]],DEFAULT_CONNECT_METHOD_ORDER:["email","social","wallet"]},G={cacheExpiry:{portfolio:3e4,nativeBalance:3e4,ens:3e5,identity:3e5,transactionsHistory:15e3,tokenPrice:15e3,latestAppKitVersion:6048e5,tonWallets:864e5},isCacheExpired(e,t){return Date.now()-e>t},getActiveNetworkProps(){const e=G.getActiveNamespace(),t=G.getActiveCaipNetworkId(),n=t?t.split(":")[1]:void 0,r=n?isNaN(Number(n))?n:Number(n):void 0;return{namespace:e,caipNetworkId:t,chainId:r}},setWalletConnectDeepLink({name:e,href:t}){try{se.setItem(ce.DEEPLINK_CHOICE,JSON.stringify({href:t,name:e}))}catch{console.info("Unable to set WalletConnect deep link")}},getWalletConnectDeepLink(){try{const e=se.getItem(ce.DEEPLINK_CHOICE);if(e)return JSON.parse(e)}catch{console.info("Unable to get WalletConnect deep link")}},deleteWalletConnectDeepLink(){try{se.removeItem(ce.DEEPLINK_CHOICE)}catch{console.info("Unable to delete WalletConnect deep link")}},setActiveNamespace(e){try{se.setItem(ce.ACTIVE_NAMESPACE,e)}catch{console.info("Unable to set active namespace")}},setActiveCaipNetworkId(e){try{se.setItem(ce.ACTIVE_CAIP_NETWORK_ID,e),G.setActiveNamespace(e.split(":")[0])}catch{console.info("Unable to set active caip network id")}},getActiveCaipNetworkId(){try{return se.getItem(ce.ACTIVE_CAIP_NETWORK_ID)}catch{console.info("Unable to get active caip network id");return}},deleteActiveCaipNetworkId(){try{se.removeItem(ce.ACTIVE_CAIP_NETWORK_ID)}catch{console.info("Unable to delete active caip network id")}},deleteConnectedConnectorId(e){try{const t=Vc(e);se.removeItem(t)}catch{console.info("Unable to delete connected connector id")}},setAppKitRecent(e){try{const t=G.getRecentWallets();t.find(r=>r.id===e.id)||(t.unshift(e),t.length>2&&t.pop(),se.setItem(ce.RECENT_WALLETS,JSON.stringify(t)),se.setItem(ce.RECENT_WALLET,JSON.stringify(e)))}catch{console.info("Unable to set AppKit recent")}},getRecentWallets(){try{const e=se.getItem(ce.RECENT_WALLETS);return e?JSON.parse(e):[]}catch{console.info("Unable to get AppKit recent")}return[]},getRecentWallet(){try{const e=se.getItem(ce.RECENT_WALLET);return e?JSON.parse(e):null}catch{console.info("Unable to get AppKit recent")}return null},deleteRecentWallet(){try{se.removeItem(ce.RECENT_WALLET)}catch{console.info("Unable to delete AppKit recent")}},setConnectedConnectorId(e,t){try{const n=Vc(e);se.setItem(n,t)}catch{console.info("Unable to set Connected Connector Id")}},getActiveNamespace(){try{return se.getItem(ce.ACTIVE_NAMESPACE)}catch{console.info("Unable to get active namespace")}},getConnectedConnectorId(e){if(e)try{const t=Vc(e);return se.getItem(t)}catch{console.info("Unable to get connected connector id in namespace",e)}},setConnectedSocialProvider(e){try{se.setItem(ce.CONNECTED_SOCIAL,e)}catch{console.info("Unable to set connected social provider")}},getConnectedSocialProvider(){try{return se.getItem(ce.CONNECTED_SOCIAL)}catch{console.info("Unable to get connected social provider")}},deleteConnectedSocialProvider(){try{se.removeItem(ce.CONNECTED_SOCIAL)}catch{console.info("Unable to delete connected social provider")}},getConnectedSocialUsername(){try{return se.getItem(ce.CONNECTED_SOCIAL_USERNAME)}catch{console.info("Unable to get connected social username")}},getStoredActiveCaipNetworkId(){return se.getItem(ce.ACTIVE_CAIP_NETWORK_ID)?.split(":")?.[1]},setConnectionStatus(e){try{se.setItem(ce.CONNECTION_STATUS,e)}catch{console.info("Unable to set connection status")}},getConnectionStatus(){try{return se.getItem(ce.CONNECTION_STATUS)}catch{return}},getConnectedNamespaces(){try{const e=se.getItem(ce.CONNECTED_NAMESPACES);return e?.length?e.split(","):[]}catch{return[]}},setConnectedNamespaces(e){try{const t=Array.from(new Set(e));se.setItem(ce.CONNECTED_NAMESPACES,t.join(","))}catch{console.info("Unable to set namespaces in storage")}},addConnectedNamespace(e){try{const t=G.getConnectedNamespaces();t.includes(e)||(t.push(e),G.setConnectedNamespaces(t))}catch{console.info("Unable to add connected namespace")}},removeConnectedNamespace(e){try{const t=G.getConnectedNamespaces(),n=t.indexOf(e);n>-1&&(t.splice(n,1),G.setConnectedNamespaces(t))}catch{console.info("Unable to remove connected namespace")}},getTelegramSocialProvider(){try{return se.getItem(ce.TELEGRAM_SOCIAL_PROVIDER)}catch{return console.info("Unable to get telegram social provider"),null}},setTelegramSocialProvider(e){try{se.setItem(ce.TELEGRAM_SOCIAL_PROVIDER,e)}catch{console.info("Unable to set telegram social provider")}},removeTelegramSocialProvider(){try{se.removeItem(ce.TELEGRAM_SOCIAL_PROVIDER)}catch{console.info("Unable to remove telegram social provider")}},getBalanceCache(){let e={};try{const t=se.getItem(ce.PORTFOLIO_CACHE);e=t?JSON.parse(t):{}}catch{console.info("Unable to get balance cache")}return e},removeAddressFromBalanceCache(e){try{const t=G.getBalanceCache();se.setItem(ce.PORTFOLIO_CACHE,JSON.stringify({...t,[e]:void 0}))}catch{console.info("Unable to remove address from balance cache",e)}},getBalanceCacheForCaipAddress(e){try{const n=G.getBalanceCache()[e];if(n&&!this.isCacheExpired(n.timestamp,this.cacheExpiry.portfolio))return n.balance;G.removeAddressFromBalanceCache(e)}catch{console.info("Unable to get balance cache for address",e)}},updateBalanceCache(e){try{const t=G.getBalanceCache();t[e.caipAddress]=e,se.setItem(ce.PORTFOLIO_CACHE,JSON.stringify(t))}catch{console.info("Unable to update balance cache",e)}},getNativeBalanceCache(){let e={};try{const t=se.getItem(ce.NATIVE_BALANCE_CACHE);e=t?JSON.parse(t):{}}catch{console.info("Unable to get balance cache")}return e},removeAddressFromNativeBalanceCache(e){try{const t=G.getBalanceCache();se.setItem(ce.NATIVE_BALANCE_CACHE,JSON.stringify({...t,[e]:void 0}))}catch{console.info("Unable to remove address from balance cache",e)}},getNativeBalanceCacheForCaipAddress(e){try{const n=G.getNativeBalanceCache()[e];if(n&&!this.isCacheExpired(n.timestamp,this.cacheExpiry.nativeBalance))return n;console.info("Discarding cache for address",e),G.removeAddressFromBalanceCache(e)}catch{console.info("Unable to get balance cache for address",e)}},updateNativeBalanceCache(e){try{const t=G.getNativeBalanceCache();t[e.caipAddress]=e,se.setItem(ce.NATIVE_BALANCE_CACHE,JSON.stringify(t))}catch{console.info("Unable to update balance cache",e)}},getEnsCache(){let e={};try{const t=se.getItem(ce.ENS_CACHE);e=t?JSON.parse(t):{}}catch{console.info("Unable to get ens name cache")}return e},getEnsFromCacheForAddress(e){try{const n=G.getEnsCache()[e];if(n&&!this.isCacheExpired(n.timestamp,this.cacheExpiry.ens))return n.ens;G.removeEnsFromCache(e)}catch{console.info("Unable to get ens name from cache",e)}},updateEnsCache(e){try{const t=G.getEnsCache();t[e.address]=e,se.setItem(ce.ENS_CACHE,JSON.stringify(t))}catch{console.info("Unable to update ens name cache",e)}},removeEnsFromCache(e){try{const t=G.getEnsCache();se.setItem(ce.ENS_CACHE,JSON.stringify({...t,[e]:void 0}))}catch{console.info("Unable to remove ens name from cache",e)}},getIdentityCache(){let e={};try{const t=se.getItem(ce.IDENTITY_CACHE);e=t?JSON.parse(t):{}}catch{console.info("Unable to get identity cache")}return e},getIdentityFromCacheForAddress(e){try{const n=G.getIdentityCache()[e];if(n&&!this.isCacheExpired(n.timestamp,this.cacheExpiry.identity))return n.identity;G.removeIdentityFromCache(e)}catch{console.info("Unable to get identity from cache",e)}},updateIdentityCache(e){try{const t=G.getIdentityCache();t[e.address]={identity:e.identity,timestamp:e.timestamp},se.setItem(ce.IDENTITY_CACHE,JSON.stringify(t))}catch{console.info("Unable to update identity cache",e)}},removeIdentityFromCache(e){try{const t=G.getIdentityCache();se.setItem(ce.IDENTITY_CACHE,JSON.stringify({...t,[e]:void 0}))}catch{console.info("Unable to remove identity from cache",e)}},getTonWalletsCache(){try{const e=se.getItem(ce.TON_WALLETS_CACHE),t=e?JSON.parse(e):void 0;if(t&&!this.isCacheExpired(t.timestamp,this.cacheExpiry.tonWallets))return t;G.removeTonWalletsCache()}catch{console.info("Unable to get ton wallets cache")}},updateTonWalletsCache(e){try{const t=G.getTonWalletsCache()||{timestamp:0,wallets:[]};t.timestamp=new Date().getTime(),t.wallets=e,se.setItem(ce.TON_WALLETS_CACHE,JSON.stringify(t))}catch{console.info("Unable to update ton wallets cache",e)}},removeTonWalletsCache(){try{se.removeItem(ce.TON_WALLETS_CACHE)}catch{console.info("Unable to remove ton wallets cache")}},clearAddressCache(){try{se.removeItem(ce.PORTFOLIO_CACHE),se.removeItem(ce.NATIVE_BALANCE_CACHE),se.removeItem(ce.ENS_CACHE),se.removeItem(ce.IDENTITY_CACHE),se.removeItem(ce.HISTORY_TRANSACTIONS_CACHE)}catch{console.info("Unable to clear address cache")}},setPreferredAccountTypes(e){try{se.setItem(ce.PREFERRED_ACCOUNT_TYPES,JSON.stringify(e))}catch{console.info("Unable to set preferred account types",e)}},getPreferredAccountTypes(){try{const e=se.getItem(ce.PREFERRED_ACCOUNT_TYPES);return e?JSON.parse(e):{}}catch{console.info("Unable to get preferred account types")}return{}},setConnections(e,t){try{const n=G.getConnections(),r=n[t]??[],o=new Map;for(const s of r)o.set(s.connectorId,{...s});for(const s of e){const a=o.get(s.connectorId),c=s.connectorId===N.CONNECTOR_ID.AUTH;if(a&&!c){const l=new Set(a.accounts.map(h=>h.address.toLowerCase())),d=s.accounts.filter(h=>!l.has(h.address.toLowerCase()));a.accounts.push(...d)}else o.set(s.connectorId,{...s})}const i={...n,[t]:Array.from(o.values())};se.setItem(ce.CONNECTIONS,JSON.stringify(i))}catch(n){console.error("Unable to sync connections to storage",n)}},getConnections(){try{const e=se.getItem(ce.CONNECTIONS);return e?JSON.parse(e):{}}catch(e){return console.error("Unable to get connections from storage",e),{}}},deleteAddressFromConnection({connectorId:e,address:t,namespace:n}){try{const r=G.getConnections(),o=r[n]??[],i=new Map(o.map(a=>[a.connectorId,a])),s=i.get(e);s&&(s.accounts.filter(c=>c.address.toLowerCase()!==t.toLowerCase()).length===0?i.delete(e):i.set(e,{...s,accounts:s.accounts.filter(c=>c.address.toLowerCase()!==t.toLowerCase())})),se.setItem(ce.CONNECTIONS,JSON.stringify({...r,[n]:Array.from(i.values())}))}catch{console.error(`Unable to remove address "${t}" from connector "${e}" in namespace "${n}"`)}},getDisconnectedConnectorIds(){try{const e=se.getItem(ce.DISCONNECTED_CONNECTOR_IDS);return e?JSON.parse(e):{}}catch{console.info("Unable to get disconnected connector ids")}return{}},addDisconnectedConnectorId(e,t){try{const n=G.getDisconnectedConnectorIds(),r=n[t]??[];r.push(e),se.setItem(ce.DISCONNECTED_CONNECTOR_IDS,JSON.stringify({...n,[t]:Array.from(new Set(r))}))}catch{console.error(`Unable to set disconnected connector id "${e}" for namespace "${t}"`)}},removeDisconnectedConnectorId(e,t){try{const n=G.getDisconnectedConnectorIds();let r=n[t]??[];r=r.filter(o=>o.toLowerCase()!==e.toLowerCase()),se.setItem(ce.DISCONNECTED_CONNECTOR_IDS,JSON.stringify({...n,[t]:Array.from(new Set(r))}))}catch{console.error(`Unable to remove disconnected connector id "${e}" for namespace "${t}"`)}},isConnectorDisconnected(e,t){try{return(G.getDisconnectedConnectorIds()[t]??[]).some(o=>o.toLowerCase()===e.toLowerCase())}catch{console.info(`Unable to get disconnected connector id "${e}" for namespace "${t}"`)}return!1},getTransactionsCache(){try{const e=se.getItem(ce.HISTORY_TRANSACTIONS_CACHE);return e?JSON.parse(e):{}}catch{console.info("Unable to get transactions cache")}return{}},getTransactionsCacheForAddress({address:e,chainId:t=""}){try{const r=G.getTransactionsCache()[e]?.[t];if(r&&!this.isCacheExpired(r.timestamp,this.cacheExpiry.transactionsHistory))return r.transactions;G.removeTransactionsCache({address:e,chainId:t})}catch{console.info("Unable to get transactions cache")}},updateTransactionsCache({address:e,chainId:t="",timestamp:n,transactions:r}){try{const o=G.getTransactionsCache();o[e]={...o[e],[t]:{timestamp:n,transactions:r}},se.setItem(ce.HISTORY_TRANSACTIONS_CACHE,JSON.stringify(o))}catch{console.info("Unable to update transactions cache",{address:e,chainId:t,timestamp:n,transactions:r})}},removeTransactionsCache({address:e,chainId:t}){try{const n=G.getTransactionsCache(),r=n?.[e]||{},{[t]:o,...i}=r;se.setItem(ce.HISTORY_TRANSACTIONS_CACHE,JSON.stringify({...n,[e]:i}))}catch{console.info("Unable to remove transactions cache",{address:e,chainId:t})}},getTokenPriceCache(){try{const e=se.getItem(ce.TOKEN_PRICE_CACHE);return e?JSON.parse(e):{}}catch{console.info("Unable to get token price cache")}return{}},getTokenPriceCacheForAddresses(e){try{const n=G.getTokenPriceCache()[e.join(",")];if(n&&!this.isCacheExpired(n.timestamp,this.cacheExpiry.tokenPrice))return n.tokenPrice;G.removeTokenPriceCache(e)}catch{console.info("Unable to get token price cache for addresses",e)}},updateTokenPriceCache(e){try{const t=G.getTokenPriceCache();t[e.addresses.join(",")]={timestamp:e.timestamp,tokenPrice:e.tokenPrice},se.setItem(ce.TOKEN_PRICE_CACHE,JSON.stringify(t))}catch{console.info("Unable to update token price cache",e)}},removeTokenPriceCache(e){try{const t=G.getTokenPriceCache();se.setItem(ce.TOKEN_PRICE_CACHE,JSON.stringify({...t,[e.join(",")]:void 0}))}catch{console.info("Unable to remove token price cache",e)}},getLatestAppKitVersion(){try{const e=this.getLatestAppKitVersionCache(),t=e?.version;return t&&!this.isCacheExpired(e.timestamp,this.cacheExpiry.latestAppKitVersion)?t:void 0}catch{console.info("Unable to get latest AppKit version")}},getLatestAppKitVersionCache(){try{const e=se.getItem(ce.LATEST_APPKIT_VERSION);return e?JSON.parse(e):{}}catch{console.info("Unable to get latest AppKit version cache")}return{}},updateLatestAppKitVersion(e){try{const t=G.getLatestAppKitVersionCache();t.timestamp=e.timestamp,t.version=e.version,se.setItem(ce.LATEST_APPKIT_VERSION,JSON.stringify(t))}catch{console.info("Unable to update latest AppKit version on local storage",e)}}},L={getWindow(){if(!(typeof window>"u"))return window},isMobile(){return this.isClient()?!!(window?.matchMedia&&typeof window.matchMedia=="function"&&window.matchMedia("(pointer:coarse)")?.matches||/Android|webOS|iPhone|iPad|iPod|BlackBerry|Opera Mini/u.test(navigator.userAgent)):!1},checkCaipNetwork(e,t=""){return e?.caipNetworkId.toLocaleLowerCase().includes(t.toLowerCase())},isAndroid(){if(!this.isMobile())return!1;const e=window?.navigator.userAgent.toLowerCase();return L.isMobile()&&e.includes("android")},isIos(){if(!this.isMobile())return!1;const e=window?.navigator.userAgent.toLowerCase();return e.includes("iphone")||e.includes("ipad")},isSafari(){return this.isClient()?(window?.navigator.userAgent.toLowerCase()).includes("safari"):!1},isClient(){return typeof window<"u"},isPairingExpired(e){return e?e-Date.now()<=ke.TEN_SEC_MS:!0},isAllowedRetry(e,t=ke.ONE_SEC_MS){return Date.now()-e>=t},copyToClopboard(e){navigator.clipboard.writeText(e)},isIframe(){try{return window?.self!==window?.top}catch{return!1}},isSafeApp(){if(L.isClient()&&window.self!==window.top)try{const e=window?.location?.ancestorOrigins?.[0],t="https://app.safe.global";if(e){const n=new URL(e),r=new URL(t);return n.hostname===r.hostname}}catch{return!1}return!1},getPairingExpiry(){return Date.now()+ke.FOUR_MINUTES_MS},getNetworkId(e){return e?.split(":")[1]},getPlainAddress(e){return e?.split(":")[2]},async wait(e){return new Promise(t=>{setTimeout(t,e)})},debounce(e,t=500){let n;return(...r)=>{function o(){e(...r)}n&&clearTimeout(n),n=setTimeout(o,t)}},isHttpUrl(e){return e.startsWith("http://")||e.startsWith("https://")},formatNativeUrl(e,t,n=null){if(L.isHttpUrl(e))return this.formatUniversalUrl(e,t);let r=e,o=n;r.includes("://")||(r=e.replaceAll("/","").replaceAll(":",""),r=`${r}://`),r.endsWith("/")||(r=`${r}/`),o&&!o?.endsWith("/")&&(o=`${o}/`),this.isTelegram()&&this.isAndroid()&&(t=encodeURIComponent(t));const i=encodeURIComponent(t);return{redirect:`${r}wc?uri=${i}`,redirectUniversalLink:o?`${o}wc?uri=${i}`:void 0,href:r}},formatUniversalUrl(e,t){if(!L.isHttpUrl(e))return this.formatNativeUrl(e,t);let n=e;n.endsWith("/")||(n=`${n}/`);const r=encodeURIComponent(t);return{redirect:`${n}wc?uri=${r}`,href:n}},getOpenTargetForPlatform(e){return e==="popupWindow"?e:this.isTelegram()?G.getTelegramSocialProvider()?"_top":"_blank":e},openHref(e,t,n){window?.open(e,this.getOpenTargetForPlatform(t),n||"noreferrer noopener")},returnOpenHref(e,t,n){return window?.open(e,this.getOpenTargetForPlatform(t),n||"noreferrer noopener")},isTelegram(){return typeof window<"u"&&(!!window.TelegramWebviewProxy||!!window.Telegram||!!window.TelegramWebviewProxyProto)},isPWA(){if(typeof window>"u")return!1;const e=window?.matchMedia&&typeof window.matchMedia=="function"?window.matchMedia("(display-mode: standalone)")?.matches:!1,t=window?.navigator?.standalone;return!!(e||t)},async preloadImage(e){const t=new Promise((n,r)=>{const o=new Image;o.onload=n,o.onerror=r,o.crossOrigin="anonymous",o.src=e});return Promise.race([t,L.wait(2e3)])},parseBalance(e,t){let n="0.000";if(typeof e=="string"){const c=Number(e);if(!isNaN(c)){const l=(Math.floor(c*1e3)/1e3).toFixed(3);l&&(n=l)}}const[r,o]=n.split("."),i=r||"0",s=o||"000";return{formattedText:`${i}.${s}${t?` ${t}`:""}`,value:i,decimals:s,symbol:t}},getApiUrl(){return N.W3M_API_URL},getBlockchainApiUrl(){return N.BLOCKCHAIN_API_RPC_URL},getAnalyticsUrl(){return N.PULSE_API_URL},getUUID(){return crypto?.randomUUID?crypto.randomUUID():"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/gu,e=>{const t=Math.random()*16|0;return(e==="x"?t:t&3|8).toString(16)})},parseError(e){return typeof e=="string"?e:typeof e?.issues?.[0]?.message=="string"?e.issues[0].message:e instanceof Error?e.message:"Unknown error"},sortRequestedNetworks(e,t=[]){const n={};return t&&e&&(e.forEach((r,o)=>{n[r]=o}),t.sort((r,o)=>{const i=n[r.id],s=n[o.id];return i!==void 0&&s!==void 0?i-s:i!==void 0?-1:s!==void 0?1:0})),t},calculateBalance(e){let t=0;for(const n of e)t+=n.value??0;return t},formatTokenBalance(e){const t=e.toFixed(2),[n,r]=t.split(".");return{dollars:n,pennies:r}},isAddress(e,t="eip155"){switch(t){case"eip155":if(/^(?:0x)?[0-9a-f]{40}$/iu.test(e)){if(/^(?:0x)?[0-9a-f]{40}$/iu.test(e)||/^(?:0x)?[0-9A-F]{40}$/iu.test(e))return!0}else return!1;return!1;case"solana":return/[1-9A-HJ-NP-Za-km-z]{32,44}$/iu.test(e);case"bip122":{const n=/^[1][a-km-zA-HJ-NP-Z1-9]{25,34}$/u.test(e),r=/^[3][a-km-zA-HJ-NP-Z1-9]{25,34}$/u.test(e),o=/^bc1[a-z0-9]{39,87}$/u.test(e),i=/^bc1p[a-z0-9]{58}$/u.test(e);return n||r||o||i}default:return!1}},uniqueBy(e,t){const n=new Set;return e.filter(r=>{const o=r[t];return n.has(o)?!1:(n.add(o),!0)})},generateSdkVersion(e,t,n){const o=e.length===0?ke.ADAPTER_TYPES.UNIVERSAL:e.map(i=>i.adapterType).join(",");return`${t}-${o}-${n}`},createAccount(e,t,n,r,o){return{namespace:e,address:t,type:n,publicKey:r,path:o}},isCaipAddress(e){if(typeof e!="string")return!1;const t=e.split(":"),n=t[0];return t.filter(Boolean).length===3&&n in N.CHAIN_NAME_MAP},getAccount(e){return e?typeof e=="string"?{address:e,chainId:void 0}:{address:e.address,chainId:e.chainId}:{address:void 0,chainId:void 0}},isMac(){const e=window?.navigator.userAgent.toLowerCase();return e.includes("macintosh")&&!e.includes("safari")},formatTelegramSocialLoginUrl(e){const t=`--${encodeURIComponent(window?.location.href)}`,n="state=";if(new URL(e).host==="auth.magic.link"){const o="provider_authorization_url=",i=e.substring(e.indexOf(o)+o.length),s=this.injectIntoUrl(decodeURIComponent(i),n,t);return e.replace(i,encodeURIComponent(s))}return this.injectIntoUrl(e,n,t)},injectIntoUrl(e,t,n){const r=e.indexOf(t);if(r===-1)throw new Error(`${t} parameter not found in the URL: ${e}`);const o=e.indexOf("&",r),i=t.length,s=o!==-1?o:e.length,a=e.substring(0,r+i),c=e.substring(r+i,s),l=e.substring(o),d=c+n;return a+d+l},isNumber(e){return typeof e!="number"&&typeof e!="string"?!1:!isNaN(Number(e))}};var Xi={};const Jm="https://secure.walletconnect.org/sdk",Xm=(typeof process<"u"&&typeof Xi<"u"?Xi.NEXT_PUBLIC_SECURE_SITE_SDK_URL:void 0)||Jm,Qm=(typeof process<"u"&&typeof Xi<"u"?Xi.NEXT_PUBLIC_DEFAULT_LOG_LEVEL:void 0)||"error",e0=(typeof process<"u"&&typeof Xi<"u"?Xi.NEXT_PUBLIC_SECURE_SITE_SDK_VERSION:void 0)||"4",oe={APP_EVENT_KEY:"@w3m-app/",FRAME_EVENT_KEY:"@w3m-frame/",RPC_METHOD_KEY:"RPC_",STORAGE_KEY:"@appkit-wallet/",SESSION_TOKEN_KEY:"SESSION_TOKEN_KEY",EMAIL_LOGIN_USED_KEY:"EMAIL_LOGIN_USED_KEY",LAST_USED_CHAIN_KEY:"LAST_USED_CHAIN_KEY",LAST_EMAIL_LOGIN_TIME:"LAST_EMAIL_LOGIN_TIME",EMAIL:"EMAIL",PREFERRED_ACCOUNT_TYPE:"PREFERRED_ACCOUNT_TYPE",SMART_ACCOUNT_ENABLED:"SMART_ACCOUNT_ENABLED",SMART_ACCOUNT_ENABLED_NETWORKS:"SMART_ACCOUNT_ENABLED_NETWORKS",SOCIAL_USERNAME:"SOCIAL_USERNAME",APP_SWITCH_NETWORK:"@w3m-app/SWITCH_NETWORK",APP_CONNECT_EMAIL:"@w3m-app/CONNECT_EMAIL",APP_CONNECT_DEVICE:"@w3m-app/CONNECT_DEVICE",APP_CONNECT_OTP:"@w3m-app/CONNECT_OTP",APP_CONNECT_SOCIAL:"@w3m-app/CONNECT_SOCIAL",APP_GET_SOCIAL_REDIRECT_URI:"@w3m-app/GET_SOCIAL_REDIRECT_URI",APP_GET_USER:"@w3m-app/GET_USER",APP_SIGN_OUT:"@w3m-app/SIGN_OUT",APP_IS_CONNECTED:"@w3m-app/IS_CONNECTED",APP_GET_CHAIN_ID:"@w3m-app/GET_CHAIN_ID",APP_RPC_REQUEST:"@w3m-app/RPC_REQUEST",APP_UPDATE_EMAIL:"@w3m-app/UPDATE_EMAIL",APP_UPDATE_EMAIL_PRIMARY_OTP:"@w3m-app/UPDATE_EMAIL_PRIMARY_OTP",APP_UPDATE_EMAIL_SECONDARY_OTP:"@w3m-app/UPDATE_EMAIL_SECONDARY_OTP",APP_AWAIT_UPDATE_EMAIL:"@w3m-app/AWAIT_UPDATE_EMAIL",APP_SYNC_THEME:"@w3m-app/SYNC_THEME",APP_SYNC_DAPP_DATA:"@w3m-app/SYNC_DAPP_DATA",APP_GET_SMART_ACCOUNT_ENABLED_NETWORKS:"@w3m-app/GET_SMART_ACCOUNT_ENABLED_NETWORKS",APP_INIT_SMART_ACCOUNT:"@w3m-app/INIT_SMART_ACCOUNT",APP_SET_PREFERRED_ACCOUNT:"@w3m-app/SET_PREFERRED_ACCOUNT",APP_CONNECT_FARCASTER:"@w3m-app/CONNECT_FARCASTER",APP_GET_FARCASTER_URI:"@w3m-app/GET_FARCASTER_URI",APP_RELOAD:"@w3m-app/RELOAD",APP_RPC_ABORT:"@w3m-app/RPC_ABORT",FRAME_SWITCH_NETWORK_ERROR:"@w3m-frame/SWITCH_NETWORK_ERROR",FRAME_SWITCH_NETWORK_SUCCESS:"@w3m-frame/SWITCH_NETWORK_SUCCESS",FRAME_CONNECT_EMAIL_ERROR:"@w3m-frame/CONNECT_EMAIL_ERROR",FRAME_CONNECT_EMAIL_SUCCESS:"@w3m-frame/CONNECT_EMAIL_SUCCESS",FRAME_CONNECT_DEVICE_ERROR:"@w3m-frame/CONNECT_DEVICE_ERROR",FRAME_CONNECT_DEVICE_SUCCESS:"@w3m-frame/CONNECT_DEVICE_SUCCESS",FRAME_CONNECT_OTP_SUCCESS:"@w3m-frame/CONNECT_OTP_SUCCESS",FRAME_CONNECT_OTP_ERROR:"@w3m-frame/CONNECT_OTP_ERROR",FRAME_CONNECT_SOCIAL_SUCCESS:"@w3m-frame/CONNECT_SOCIAL_SUCCESS",FRAME_CONNECT_SOCIAL_ERROR:"@w3m-frame/CONNECT_SOCIAL_ERROR",FRAME_CONNECT_FARCASTER_SUCCESS:"@w3m-frame/CONNECT_FARCASTER_SUCCESS",FRAME_CONNECT_FARCASTER_ERROR:"@w3m-frame/CONNECT_FARCASTER_ERROR",FRAME_GET_FARCASTER_URI_SUCCESS:"@w3m-frame/GET_FARCASTER_URI_SUCCESS",FRAME_GET_FARCASTER_URI_ERROR:"@w3m-frame/GET_FARCASTER_URI_ERROR",FRAME_GET_SOCIAL_REDIRECT_URI_SUCCESS:"@w3m-frame/GET_SOCIAL_REDIRECT_URI_SUCCESS",FRAME_GET_SOCIAL_REDIRECT_URI_ERROR:"@w3m-frame/GET_SOCIAL_REDIRECT_URI_ERROR",FRAME_GET_USER_SUCCESS:"@w3m-frame/GET_USER_SUCCESS",FRAME_GET_USER_ERROR:"@w3m-frame/GET_USER_ERROR",FRAME_SIGN_OUT_SUCCESS:"@w3m-frame/SIGN_OUT_SUCCESS",FRAME_SIGN_OUT_ERROR:"@w3m-frame/SIGN_OUT_ERROR",FRAME_IS_CONNECTED_SUCCESS:"@w3m-frame/IS_CONNECTED_SUCCESS",FRAME_IS_CONNECTED_ERROR:"@w3m-frame/IS_CONNECTED_ERROR",FRAME_GET_CHAIN_ID_SUCCESS:"@w3m-frame/GET_CHAIN_ID_SUCCESS",FRAME_GET_CHAIN_ID_ERROR:"@w3m-frame/GET_CHAIN_ID_ERROR",FRAME_RPC_REQUEST_SUCCESS:"@w3m-frame/RPC_REQUEST_SUCCESS",FRAME_RPC_REQUEST_ERROR:"@w3m-frame/RPC_REQUEST_ERROR",FRAME_SESSION_UPDATE:"@w3m-frame/SESSION_UPDATE",FRAME_UPDATE_EMAIL_SUCCESS:"@w3m-frame/UPDATE_EMAIL_SUCCESS",FRAME_UPDATE_EMAIL_ERROR:"@w3m-frame/UPDATE_EMAIL_ERROR",FRAME_UPDATE_EMAIL_PRIMARY_OTP_SUCCESS:"@w3m-frame/UPDATE_EMAIL_PRIMARY_OTP_SUCCESS",FRAME_UPDATE_EMAIL_PRIMARY_OTP_ERROR:"@w3m-frame/UPDATE_EMAIL_PRIMARY_OTP_ERROR",FRAME_UPDATE_EMAIL_SECONDARY_OTP_SUCCESS:"@w3m-frame/UPDATE_EMAIL_SECONDARY_OTP_SUCCESS",FRAME_UPDATE_EMAIL_SECONDARY_OTP_ERROR:"@w3m-frame/UPDATE_EMAIL_SECONDARY_OTP_ERROR",FRAME_SYNC_THEME_SUCCESS:"@w3m-frame/SYNC_THEME_SUCCESS",FRAME_SYNC_THEME_ERROR:"@w3m-frame/SYNC_THEME_ERROR",FRAME_SYNC_DAPP_DATA_SUCCESS:"@w3m-frame/SYNC_DAPP_DATA_SUCCESS",FRAME_SYNC_DAPP_DATA_ERROR:"@w3m-frame/SYNC_DAPP_DATA_ERROR",FRAME_GET_SMART_ACCOUNT_ENABLED_NETWORKS_SUCCESS:"@w3m-frame/GET_SMART_ACCOUNT_ENABLED_NETWORKS_SUCCESS",FRAME_GET_SMART_ACCOUNT_ENABLED_NETWORKS_ERROR:"@w3m-frame/GET_SMART_ACCOUNT_ENABLED_NETWORKS_ERROR",FRAME_INIT_SMART_ACCOUNT_SUCCESS:"@w3m-frame/INIT_SMART_ACCOUNT_SUCCESS",FRAME_INIT_SMART_ACCOUNT_ERROR:"@w3m-frame/INIT_SMART_ACCOUNT_ERROR",FRAME_SET_PREFERRED_ACCOUNT_SUCCESS:"@w3m-frame/SET_PREFERRED_ACCOUNT_SUCCESS",FRAME_SET_PREFERRED_ACCOUNT_ERROR:"@w3m-frame/SET_PREFERRED_ACCOUNT_ERROR",FRAME_READY:"@w3m-frame/READY",FRAME_RELOAD_SUCCESS:"@w3m-frame/RELOAD_SUCCESS",FRAME_RELOAD_ERROR:"@w3m-frame/RELOAD_ERROR",FRAME_RPC_ABORT_SUCCESS:"@w3m-frame/RPC_ABORT_SUCCESS",FRAME_RPC_ABORT_ERROR:"@w3m-frame/RPC_ABORT_ERROR",RPC_RESPONSE_TYPE_ERROR:"RPC_RESPONSE_ERROR",RPC_RESPONSE_TYPE_TX:"RPC_RESPONSE_TRANSACTION_HASH",RPC_RESPONSE_TYPE_OBJECT:"RPC_RESPONSE_OBJECT"},je={SAFE_RPC_METHODS:["eth_accounts","eth_blockNumber","eth_call","eth_chainId","eth_estimateGas","eth_feeHistory","eth_gasPrice","eth_getAccount","eth_getBalance","eth_getBlockByHash","eth_getBlockByNumber","eth_getBlockReceipts","eth_getBlockTransactionCountByHash","eth_getBlockTransactionCountByNumber","eth_getCode","eth_getFilterChanges","eth_getFilterLogs","eth_getLogs","eth_getProof","eth_getStorageAt","eth_getTransactionByBlockHashAndIndex","eth_getTransactionByBlockNumberAndIndex","eth_getTransactionByHash","eth_getTransactionCount","eth_getTransactionReceipt","eth_getUncleCountByBlockHash","eth_getUncleCountByBlockNumber","eth_maxPriorityFeePerGas","eth_newBlockFilter","eth_newFilter","eth_newPendingTransactionFilter","eth_sendRawTransaction","eth_syncing","eth_uninstallFilter","wallet_getCapabilities","wallet_getCallsStatus","eth_getUserOperationReceipt","eth_estimateUserOperationGas","eth_getUserOperationByHash","eth_supportedEntryPoints","wallet_getAssets"],NOT_SAFE_RPC_METHODS:["personal_sign","eth_signTypedData_v4","eth_sendTransaction","solana_signMessage","solana_signTransaction","solana_signAllTransactions","solana_signAndSendTransaction","wallet_sendCalls","wallet_grantPermissions","wallet_revokePermissions","eth_sendUserOperation"],GET_CHAIN_ID:"eth_chainId",RPC_METHOD_NOT_ALLOWED_MESSAGE:"Requested RPC call is not allowed",RPC_METHOD_NOT_ALLOWED_UI_MESSAGE:"Action not allowed",ACCOUNT_TYPES:{EOA:"eoa",SMART_ACCOUNT:"smartAccount"}},bu={transactionHash:/^0x(?:[A-Fa-f0-9]{64})$/u,signedMessage:/^0x(?:[a-fA-F0-9]{62,})$/u},tt={set(e,t){Sn.isClient&&localStorage.setItem(`${oe.STORAGE_KEY}${e}`,t)},get(e){return Sn.isClient?localStorage.getItem(`${oe.STORAGE_KEY}${e}`):null},delete(e,t){Sn.isClient&&(t?localStorage.removeItem(e):localStorage.removeItem(`${oe.STORAGE_KEY}${e}`))}},aa=30*1e3,Sn={checkIfAllowedToTriggerEmail(){const e=tt.get(oe.LAST_EMAIL_LOGIN_TIME);if(e){const t=Date.now()-Number(e);if(t<aa){const n=Math.ceil((aa-t)/1e3);throw new Error(`Please try again after ${n} seconds`)}}},getTimeToNextEmailLogin(){const e=tt.get(oe.LAST_EMAIL_LOGIN_TIME);if(e){const t=Date.now()-Number(e);if(t<aa)return Math.ceil((aa-t)/1e3)}return 0},checkIfRequestExists(e){return je.NOT_SAFE_RPC_METHODS.includes(e.method)||je.SAFE_RPC_METHODS.includes(e.method)},getResponseType(e){return typeof e=="string"&&(e?.match(bu.transactionHash)||e?.match(bu.signedMessage))?oe.RPC_RESPONSE_TYPE_TX:oe.RPC_RESPONSE_TYPE_OBJECT},checkIfRequestIsSafe(e){return je.SAFE_RPC_METHODS.includes(e.method)},isClient:typeof window<"u"};var Pe;(function(e){e.assertEqual=o=>o;function t(o){}e.assertIs=t;function n(o){throw new Error}e.assertNever=n,e.arrayToEnum=o=>{const i={};for(const s of o)i[s]=s;return i},e.getValidEnumValues=o=>{const i=e.objectKeys(o).filter(a=>typeof o[o[a]]!="number"),s={};for(const a of i)s[a]=o[a];return e.objectValues(s)},e.objectValues=o=>e.objectKeys(o).map(function(i){return o[i]}),e.objectKeys=typeof Object.keys=="function"?o=>Object.keys(o):o=>{const i=[];for(const s in o)Object.prototype.hasOwnProperty.call(o,s)&&i.push(s);return i},e.find=(o,i)=>{for(const s of o)if(i(s))return s},e.isInteger=typeof Number.isInteger=="function"?o=>Number.isInteger(o):o=>typeof o=="number"&&isFinite(o)&&Math.floor(o)===o;function r(o,i=" | "){return o.map(s=>typeof s=="string"?`'${s}'`:s).join(i)}e.joinValues=r,e.jsonStringifyReplacer=(o,i)=>typeof i=="bigint"?i.toString():i})(Pe||(Pe={}));var jl;(function(e){e.mergeShapes=(t,n)=>({...t,...n})})(jl||(jl={}));const ee=Pe.arrayToEnum(["string","nan","number","integer","float","boolean","date","bigint","symbol","function","undefined","null","array","object","unknown","promise","void","never","map","set"]),lr=e=>{switch(typeof e){case"undefined":return ee.undefined;case"string":return ee.string;case"number":return isNaN(e)?ee.nan:ee.number;case"boolean":return ee.boolean;case"function":return ee.function;case"bigint":return ee.bigint;case"symbol":return ee.symbol;case"object":return Array.isArray(e)?ee.array:e===null?ee.null:e.then&&typeof e.then=="function"&&e.catch&&typeof e.catch=="function"?ee.promise:typeof Map<"u"&&e instanceof Map?ee.map:typeof Set<"u"&&e instanceof Set?ee.set:typeof Date<"u"&&e instanceof Date?ee.date:ee.object;default:return ee.unknown}},K=Pe.arrayToEnum(["invalid_type","invalid_literal","custom","invalid_union","invalid_union_discriminator","invalid_enum_value","unrecognized_keys","invalid_arguments","invalid_return_type","invalid_date","invalid_string","too_small","too_big","invalid_intersection_types","not_multiple_of","not_finite"]),t0=e=>JSON.stringify(e,null,2).replace(/"([^"]+)":/g,"$1:");class pn extends Error{constructor(t){super(),this.issues=[],this.addIssue=r=>{this.issues=[...this.issues,r]},this.addIssues=(r=[])=>{this.issues=[...this.issues,...r]};const n=new.target.prototype;Object.setPrototypeOf?Object.setPrototypeOf(this,n):this.__proto__=n,this.name="ZodError",this.issues=t}get errors(){return this.issues}format(t){const n=t||function(i){return i.message},r={_errors:[]},o=i=>{for(const s of i.issues)if(s.code==="invalid_union")s.unionErrors.map(o);else if(s.code==="invalid_return_type")o(s.returnTypeError);else if(s.code==="invalid_arguments")o(s.argumentsError);else if(s.path.length===0)r._errors.push(n(s));else{let a=r,c=0;for(;c<s.path.length;){const l=s.path[c];c===s.path.length-1?(a[l]=a[l]||{_errors:[]},a[l]._errors.push(n(s))):a[l]=a[l]||{_errors:[]},a=a[l],c++}}};return o(this),r}toString(){return this.message}get message(){return JSON.stringify(this.issues,Pe.jsonStringifyReplacer,2)}get isEmpty(){return this.issues.length===0}flatten(t=n=>n.message){const n={},r=[];for(const o of this.issues)o.path.length>0?(n[o.path[0]]=n[o.path[0]]||[],n[o.path[0]].push(t(o))):r.push(t(o));return{formErrors:r,fieldErrors:n}}get formErrors(){return this.flatten()}}pn.create=e=>new pn(e);const jo=(e,t)=>{let n;switch(e.code){case K.invalid_type:e.received===ee.undefined?n="Required":n=`Expected ${e.expected}, received ${e.received}`;break;case K.invalid_literal:n=`Invalid literal value, expected ${JSON.stringify(e.expected,Pe.jsonStringifyReplacer)}`;break;case K.unrecognized_keys:n=`Unrecognized key(s) in object: ${Pe.joinValues(e.keys,", ")}`;break;case K.invalid_union:n="Invalid input";break;case K.invalid_union_discriminator:n=`Invalid discriminator value. Expected ${Pe.joinValues(e.options)}`;break;case K.invalid_enum_value:n=`Invalid enum value. Expected ${Pe.joinValues(e.options)}, received '${e.received}'`;break;case K.invalid_arguments:n="Invalid function arguments";break;case K.invalid_return_type:n="Invalid function return type";break;case K.invalid_date:n="Invalid date";break;case K.invalid_string:typeof e.validation=="object"?"includes"in e.validation?(n=`Invalid input: must include "${e.validation.includes}"`,typeof e.validation.position=="number"&&(n=`${n} at one or more positions greater than or equal to ${e.validation.position}`)):"startsWith"in e.validation?n=`Invalid input: must start with "${e.validation.startsWith}"`:"endsWith"in e.validation?n=`Invalid input: must end with "${e.validation.endsWith}"`:Pe.assertNever(e.validation):e.validation!=="regex"?n=`Invalid ${e.validation}`:n="Invalid";break;case K.too_small:e.type==="array"?n=`Array must contain ${e.exact?"exactly":e.inclusive?"at least":"more than"} ${e.minimum} element(s)`:e.type==="string"?n=`String must contain ${e.exact?"exactly":e.inclusive?"at least":"over"} ${e.minimum} character(s)`:e.type==="number"?n=`Number must be ${e.exact?"exactly equal to ":e.inclusive?"greater than or equal to ":"greater than "}${e.minimum}`:e.type==="date"?n=`Date must be ${e.exact?"exactly equal to ":e.inclusive?"greater than or equal to ":"greater than "}${new Date(Number(e.minimum))}`:n="Invalid input";break;case K.too_big:e.type==="array"?n=`Array must contain ${e.exact?"exactly":e.inclusive?"at most":"less than"} ${e.maximum} element(s)`:e.type==="string"?n=`String must contain ${e.exact?"exactly":e.inclusive?"at most":"under"} ${e.maximum} character(s)`:e.type==="number"?n=`Number must be ${e.exact?"exactly":e.inclusive?"less than or equal to":"less than"} ${e.maximum}`:e.type==="bigint"?n=`BigInt must be ${e.exact?"exactly":e.inclusive?"less than or equal to":"less than"} ${e.maximum}`:e.type==="date"?n=`Date must be ${e.exact?"exactly":e.inclusive?"smaller than or equal to":"smaller than"} ${new Date(Number(e.maximum))}`:n="Invalid input";break;case K.custom:n="Invalid input";break;case K.invalid_intersection_types:n="Intersection results could not be merged";break;case K.not_multiple_of:n=`Number must be a multiple of ${e.multipleOf}`;break;case K.not_finite:n="Number must be finite";break;default:n=t.defaultError,Pe.assertNever(e)}return{message:n}};let xp=jo;function n0(e){xp=e}function Ma(){return xp}const Ua=e=>{const{data:t,path:n,errorMaps:r,issueData:o}=e,i=[...n,...o.path||[]],s={...o,path:i};let a="";const c=r.filter(l=>!!l).slice().reverse();for(const l of c)a=l(s,{data:t,defaultError:a}).message;return{...o,path:i,message:o.message||a}},r0=[];function ie(e,t){const n=Ua({issueData:t,data:e.data,path:e.path,errorMaps:[e.common.contextualErrorMap,e.schemaErrorMap,Ma(),jo].filter(r=>!!r)});e.common.issues.push(n)}class ht{constructor(){this.value="valid"}dirty(){this.value==="valid"&&(this.value="dirty")}abort(){this.value!=="aborted"&&(this.value="aborted")}static mergeArray(t,n){const r=[];for(const o of n){if(o.status==="aborted")return Ee;o.status==="dirty"&&t.dirty(),r.push(o.value)}return{status:t.value,value:r}}static async mergeObjectAsync(t,n){const r=[];for(const o of n)r.push({key:await o.key,value:await o.value});return ht.mergeObjectSync(t,r)}static mergeObjectSync(t,n){const r={};for(const o of n){const{key:i,value:s}=o;if(i.status==="aborted"||s.status==="aborted")return Ee;i.status==="dirty"&&t.dirty(),s.status==="dirty"&&t.dirty(),i.value!=="__proto__"&&(typeof s.value<"u"||o.alwaysSet)&&(r[i.value]=s.value)}return{status:t.value,value:r}}}const Ee=Object.freeze({status:"aborted"}),Sp=e=>({status:"dirty",value:e}),Et=e=>({status:"valid",value:e}),Fl=e=>e.status==="aborted",zl=e=>e.status==="dirty",Fo=e=>e.status==="valid",Ba=e=>typeof Promise<"u"&&e instanceof Promise;var ge;(function(e){e.errToObj=t=>typeof t=="string"?{message:t}:t||{},e.toString=t=>typeof t=="string"?t:t?.message})(ge||(ge={}));class Rn{constructor(t,n,r,o){this._cachedPath=[],this.parent=t,this.data=n,this._path=r,this._key=o}get path(){return this._cachedPath.length||(this._key instanceof Array?this._cachedPath.push(...this._path,...this._key):this._cachedPath.push(...this._path,this._key)),this._cachedPath}}const yu=(e,t)=>{if(Fo(t))return{success:!0,data:t.value};if(!e.common.issues.length)throw new Error("Validation failed but no issues detected.");return{success:!1,get error(){if(this._error)return this._error;const n=new pn(e.common.issues);return this._error=n,this._error}}};function Ae(e){if(!e)return{};const{errorMap:t,invalid_type_error:n,required_error:r,description:o}=e;if(t&&(n||r))throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);return t?{errorMap:t,description:o}:{errorMap:(s,a)=>s.code!=="invalid_type"?{message:a.defaultError}:typeof a.data>"u"?{message:r??a.defaultError}:{message:n??a.defaultError},description:o}}class xe{constructor(t){this.spa=this.safeParseAsync,this._def=t,this.parse=this.parse.bind(this),this.safeParse=this.safeParse.bind(this),this.parseAsync=this.parseAsync.bind(this),this.safeParseAsync=this.safeParseAsync.bind(this),this.spa=this.spa.bind(this),this.refine=this.refine.bind(this),this.refinement=this.refinement.bind(this),this.superRefine=this.superRefine.bind(this),this.optional=this.optional.bind(this),this.nullable=this.nullable.bind(this),this.nullish=this.nullish.bind(this),this.array=this.array.bind(this),this.promise=this.promise.bind(this),this.or=this.or.bind(this),this.and=this.and.bind(this),this.transform=this.transform.bind(this),this.brand=this.brand.bind(this),this.default=this.default.bind(this),this.catch=this.catch.bind(this),this.describe=this.describe.bind(this),this.pipe=this.pipe.bind(this),this.readonly=this.readonly.bind(this),this.isNullable=this.isNullable.bind(this),this.isOptional=this.isOptional.bind(this)}get description(){return this._def.description}_getType(t){return lr(t.data)}_getOrReturnCtx(t,n){return n||{common:t.parent.common,data:t.data,parsedType:lr(t.data),schemaErrorMap:this._def.errorMap,path:t.path,parent:t.parent}}_processInputParams(t){return{status:new ht,ctx:{common:t.parent.common,data:t.data,parsedType:lr(t.data),schemaErrorMap:this._def.errorMap,path:t.path,parent:t.parent}}}_parseSync(t){const n=this._parse(t);if(Ba(n))throw new Error("Synchronous parse encountered promise.");return n}_parseAsync(t){const n=this._parse(t);return Promise.resolve(n)}parse(t,n){const r=this.safeParse(t,n);if(r.success)return r.data;throw r.error}safeParse(t,n){var r;const o={common:{issues:[],async:(r=n?.async)!==null&&r!==void 0?r:!1,contextualErrorMap:n?.errorMap},path:n?.path||[],schemaErrorMap:this._def.errorMap,parent:null,data:t,parsedType:lr(t)},i=this._parseSync({data:t,path:o.path,parent:o});return yu(o,i)}async parseAsync(t,n){const r=await this.safeParseAsync(t,n);if(r.success)return r.data;throw r.error}async safeParseAsync(t,n){const r={common:{issues:[],contextualErrorMap:n?.errorMap,async:!0},path:n?.path||[],schemaErrorMap:this._def.errorMap,parent:null,data:t,parsedType:lr(t)},o=this._parse({data:t,path:r.path,parent:r}),i=await(Ba(o)?o:Promise.resolve(o));return yu(r,i)}refine(t,n){const r=o=>typeof n=="string"||typeof n>"u"?{message:n}:typeof n=="function"?n(o):n;return this._refinement((o,i)=>{const s=t(o),a=()=>i.addIssue({code:K.custom,...r(o)});return typeof Promise<"u"&&s instanceof Promise?s.then(c=>c?!0:(a(),!1)):s?!0:(a(),!1)})}refinement(t,n){return this._refinement((r,o)=>t(r)?!0:(o.addIssue(typeof n=="function"?n(r,o):n),!1))}_refinement(t){return new mn({schema:this,typeName:be.ZodEffects,effect:{type:"refinement",refinement:t}})}superRefine(t){return this._refinement(t)}optional(){return Zn.create(this,this._def)}nullable(){return Yr.create(this,this._def)}nullish(){return this.nullable().optional()}array(){return fn.create(this,this._def)}promise(){return eo.create(this,this._def)}or(t){return qo.create([this,t],this._def)}and(t){return Ko.create(this,t,this._def)}transform(t){return new mn({...Ae(this._def),schema:this,typeName:be.ZodEffects,effect:{type:"transform",transform:t}})}default(t){const n=typeof t=="function"?t:()=>t;return new Xo({...Ae(this._def),innerType:this,defaultValue:n,typeName:be.ZodDefault})}brand(){return new $p({typeName:be.ZodBranded,type:this,...Ae(this._def)})}catch(t){const n=typeof t=="function"?t:()=>t;return new za({...Ae(this._def),innerType:this,catchValue:n,typeName:be.ZodCatch})}describe(t){const n=this.constructor;return new n({...this._def,description:t})}pipe(t){return Us.create(this,t)}readonly(){return Va.create(this)}isOptional(){return this.safeParse(void 0).success}isNullable(){return this.safeParse(null).success}}const i0=/^c[^\s-]{8,}$/i,o0=/^[a-z][a-z0-9]*$/,s0=/^[0-9A-HJKMNP-TV-Z]{26}$/,a0=/^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i,c0=/^(?!\.)(?!.*\.\.)([A-Z0-9_+-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i,l0="^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";let Kc;const d0=/^(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))$/,u0=/^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/,h0=e=>e.precision?e.offset?new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{${e.precision}}(([+-]\\d{2}(:?\\d{2})?)|Z)$`):new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{${e.precision}}Z$`):e.precision===0?e.offset?new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(([+-]\\d{2}(:?\\d{2})?)|Z)$"):new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z$"):e.offset?new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?(([+-]\\d{2}(:?\\d{2})?)|Z)$"):new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?Z$");function p0(e,t){return!!((t==="v4"||!t)&&d0.test(e)||(t==="v6"||!t)&&u0.test(e))}class hn extends xe{_parse(t){if(this._def.coerce&&(t.data=String(t.data)),this._getType(t)!==ee.string){const i=this._getOrReturnCtx(t);return ie(i,{code:K.invalid_type,expected:ee.string,received:i.parsedType}),Ee}const r=new ht;let o;for(const i of this._def.checks)if(i.kind==="min")t.data.length<i.value&&(o=this._getOrReturnCtx(t,o),ie(o,{code:K.too_small,minimum:i.value,type:"string",inclusive:!0,exact:!1,message:i.message}),r.dirty());else if(i.kind==="max")t.data.length>i.value&&(o=this._getOrReturnCtx(t,o),ie(o,{code:K.too_big,maximum:i.value,type:"string",inclusive:!0,exact:!1,message:i.message}),r.dirty());else if(i.kind==="length"){const s=t.data.length>i.value,a=t.data.length<i.value;(s||a)&&(o=this._getOrReturnCtx(t,o),s?ie(o,{code:K.too_big,maximum:i.value,type:"string",inclusive:!0,exact:!0,message:i.message}):a&&ie(o,{code:K.too_small,minimum:i.value,type:"string",inclusive:!0,exact:!0,message:i.message}),r.dirty())}else if(i.kind==="email")c0.test(t.data)||(o=this._getOrReturnCtx(t,o),ie(o,{validation:"email",code:K.invalid_string,message:i.message}),r.dirty());else if(i.kind==="emoji")Kc||(Kc=new RegExp(l0,"u")),Kc.test(t.data)||(o=this._getOrReturnCtx(t,o),ie(o,{validation:"emoji",code:K.invalid_string,message:i.message}),r.dirty());else if(i.kind==="uuid")a0.test(t.data)||(o=this._getOrReturnCtx(t,o),ie(o,{validation:"uuid",code:K.invalid_string,message:i.message}),r.dirty());else if(i.kind==="cuid")i0.test(t.data)||(o=this._getOrReturnCtx(t,o),ie(o,{validation:"cuid",code:K.invalid_string,message:i.message}),r.dirty());else if(i.kind==="cuid2")o0.test(t.data)||(o=this._getOrReturnCtx(t,o),ie(o,{validation:"cuid2",code:K.invalid_string,message:i.message}),r.dirty());else if(i.kind==="ulid")s0.test(t.data)||(o=this._getOrReturnCtx(t,o),ie(o,{validation:"ulid",code:K.invalid_string,message:i.message}),r.dirty());else if(i.kind==="url")try{new URL(t.data)}catch{o=this._getOrReturnCtx(t,o),ie(o,{validation:"url",code:K.invalid_string,message:i.message}),r.dirty()}else i.kind==="regex"?(i.regex.lastIndex=0,i.regex.test(t.data)||(o=this._getOrReturnCtx(t,o),ie(o,{validation:"regex",code:K.invalid_string,message:i.message}),r.dirty())):i.kind==="trim"?t.data=t.data.trim():i.kind==="includes"?t.data.includes(i.value,i.position)||(o=this._getOrReturnCtx(t,o),ie(o,{code:K.invalid_string,validation:{includes:i.value,position:i.position},message:i.message}),r.dirty()):i.kind==="toLowerCase"?t.data=t.data.toLowerCase():i.kind==="toUpperCase"?t.data=t.data.toUpperCase():i.kind==="startsWith"?t.data.startsWith(i.value)||(o=this._getOrReturnCtx(t,o),ie(o,{code:K.invalid_string,validation:{startsWith:i.value},message:i.message}),r.dirty()):i.kind==="endsWith"?t.data.endsWith(i.value)||(o=this._getOrReturnCtx(t,o),ie(o,{code:K.invalid_string,validation:{endsWith:i.value},message:i.message}),r.dirty()):i.kind==="datetime"?h0(i).test(t.data)||(o=this._getOrReturnCtx(t,o),ie(o,{code:K.invalid_string,validation:"datetime",message:i.message}),r.dirty()):i.kind==="ip"?p0(t.data,i.version)||(o=this._getOrReturnCtx(t,o),ie(o,{validation:"ip",code:K.invalid_string,message:i.message}),r.dirty()):Pe.assertNever(i);return{status:r.value,value:t.data}}_regex(t,n,r){return this.refinement(o=>t.test(o),{validation:n,code:K.invalid_string,...ge.errToObj(r)})}_addCheck(t){return new hn({...this._def,checks:[...this._def.checks,t]})}email(t){return this._addCheck({kind:"email",...ge.errToObj(t)})}url(t){return this._addCheck({kind:"url",...ge.errToObj(t)})}emoji(t){return this._addCheck({kind:"emoji",...ge.errToObj(t)})}uuid(t){return this._addCheck({kind:"uuid",...ge.errToObj(t)})}cuid(t){return this._addCheck({kind:"cuid",...ge.errToObj(t)})}cuid2(t){return this._addCheck({kind:"cuid2",...ge.errToObj(t)})}ulid(t){return this._addCheck({kind:"ulid",...ge.errToObj(t)})}ip(t){return this._addCheck({kind:"ip",...ge.errToObj(t)})}datetime(t){var n;return typeof t=="string"?this._addCheck({kind:"datetime",precision:null,offset:!1,message:t}):this._addCheck({kind:"datetime",precision:typeof t?.precision>"u"?null:t?.precision,offset:(n=t?.offset)!==null&&n!==void 0?n:!1,...ge.errToObj(t?.message)})}regex(t,n){return this._addCheck({kind:"regex",regex:t,...ge.errToObj(n)})}includes(t,n){return this._addCheck({kind:"includes",value:t,position:n?.position,...ge.errToObj(n?.message)})}startsWith(t,n){return this._addCheck({kind:"startsWith",value:t,...ge.errToObj(n)})}endsWith(t,n){return this._addCheck({kind:"endsWith",value:t,...ge.errToObj(n)})}min(t,n){return this._addCheck({kind:"min",value:t,...ge.errToObj(n)})}max(t,n){return this._addCheck({kind:"max",value:t,...ge.errToObj(n)})}length(t,n){return this._addCheck({kind:"length",value:t,...ge.errToObj(n)})}nonempty(t){return this.min(1,ge.errToObj(t))}trim(){return new hn({...this._def,checks:[...this._def.checks,{kind:"trim"}]})}toLowerCase(){return new hn({...this._def,checks:[...this._def.checks,{kind:"toLowerCase"}]})}toUpperCase(){return new hn({...this._def,checks:[...this._def.checks,{kind:"toUpperCase"}]})}get isDatetime(){return!!this._def.checks.find(t=>t.kind==="datetime")}get isEmail(){return!!this._def.checks.find(t=>t.kind==="email")}get isURL(){return!!this._def.checks.find(t=>t.kind==="url")}get isEmoji(){return!!this._def.checks.find(t=>t.kind==="emoji")}get isUUID(){return!!this._def.checks.find(t=>t.kind==="uuid")}get isCUID(){return!!this._def.checks.find(t=>t.kind==="cuid")}get isCUID2(){return!!this._def.checks.find(t=>t.kind==="cuid2")}get isULID(){return!!this._def.checks.find(t=>t.kind==="ulid")}get isIP(){return!!this._def.checks.find(t=>t.kind==="ip")}get minLength(){let t=null;for(const n of this._def.checks)n.kind==="min"&&(t===null||n.value>t)&&(t=n.value);return t}get maxLength(){let t=null;for(const n of this._def.checks)n.kind==="max"&&(t===null||n.value<t)&&(t=n.value);return t}}hn.create=e=>{var t;return new hn({checks:[],typeName:be.ZodString,coerce:(t=e?.coerce)!==null&&t!==void 0?t:!1,...Ae(e)})};function f0(e,t){const n=(e.toString().split(".")[1]||"").length,r=(t.toString().split(".")[1]||"").length,o=n>r?n:r,i=parseInt(e.toFixed(o).replace(".","")),s=parseInt(t.toFixed(o).replace(".",""));return i%s/Math.pow(10,o)}class gr extends xe{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte,this.step=this.multipleOf}_parse(t){if(this._def.coerce&&(t.data=Number(t.data)),this._getType(t)!==ee.number){const i=this._getOrReturnCtx(t);return ie(i,{code:K.invalid_type,expected:ee.number,received:i.parsedType}),Ee}let r;const o=new ht;for(const i of this._def.checks)i.kind==="int"?Pe.isInteger(t.data)||(r=this._getOrReturnCtx(t,r),ie(r,{code:K.invalid_type,expected:"integer",received:"float",message:i.message}),o.dirty()):i.kind==="min"?(i.inclusive?t.data<i.value:t.data<=i.value)&&(r=this._getOrReturnCtx(t,r),ie(r,{code:K.too_small,minimum:i.value,type:"number",inclusive:i.inclusive,exact:!1,message:i.message}),o.dirty()):i.kind==="max"?(i.inclusive?t.data>i.value:t.data>=i.value)&&(r=this._getOrReturnCtx(t,r),ie(r,{code:K.too_big,maximum:i.value,type:"number",inclusive:i.inclusive,exact:!1,message:i.message}),o.dirty()):i.kind==="multipleOf"?f0(t.data,i.value)!==0&&(r=this._getOrReturnCtx(t,r),ie(r,{code:K.not_multiple_of,multipleOf:i.value,message:i.message}),o.dirty()):i.kind==="finite"?Number.isFinite(t.data)||(r=this._getOrReturnCtx(t,r),ie(r,{code:K.not_finite,message:i.message}),o.dirty()):Pe.assertNever(i);return{status:o.value,value:t.data}}gte(t,n){return this.setLimit("min",t,!0,ge.toString(n))}gt(t,n){return this.setLimit("min",t,!1,ge.toString(n))}lte(t,n){return this.setLimit("max",t,!0,ge.toString(n))}lt(t,n){return this.setLimit("max",t,!1,ge.toString(n))}setLimit(t,n,r,o){return new gr({...this._def,checks:[...this._def.checks,{kind:t,value:n,inclusive:r,message:ge.toString(o)}]})}_addCheck(t){return new gr({...this._def,checks:[...this._def.checks,t]})}int(t){return this._addCheck({kind:"int",message:ge.toString(t)})}positive(t){return this._addCheck({kind:"min",value:0,inclusive:!1,message:ge.toString(t)})}negative(t){return this._addCheck({kind:"max",value:0,inclusive:!1,message:ge.toString(t)})}nonpositive(t){return this._addCheck({kind:"max",value:0,inclusive:!0,message:ge.toString(t)})}nonnegative(t){return this._addCheck({kind:"min",value:0,inclusive:!0,message:ge.toString(t)})}multipleOf(t,n){return this._addCheck({kind:"multipleOf",value:t,message:ge.toString(n)})}finite(t){return this._addCheck({kind:"finite",message:ge.toString(t)})}safe(t){return this._addCheck({kind:"min",inclusive:!0,value:Number.MIN_SAFE_INTEGER,message:ge.toString(t)})._addCheck({kind:"max",inclusive:!0,value:Number.MAX_SAFE_INTEGER,message:ge.toString(t)})}get minValue(){let t=null;for(const n of this._def.checks)n.kind==="min"&&(t===null||n.value>t)&&(t=n.value);return t}get maxValue(){let t=null;for(const n of this._def.checks)n.kind==="max"&&(t===null||n.value<t)&&(t=n.value);return t}get isInt(){return!!this._def.checks.find(t=>t.kind==="int"||t.kind==="multipleOf"&&Pe.isInteger(t.value))}get isFinite(){let t=null,n=null;for(const r of this._def.checks){if(r.kind==="finite"||r.kind==="int"||r.kind==="multipleOf")return!0;r.kind==="min"?(n===null||r.value>n)&&(n=r.value):r.kind==="max"&&(t===null||r.value<t)&&(t=r.value)}return Number.isFinite(n)&&Number.isFinite(t)}}gr.create=e=>new gr({checks:[],typeName:be.ZodNumber,coerce:e?.coerce||!1,...Ae(e)});class wr extends xe{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte}_parse(t){if(this._def.coerce&&(t.data=BigInt(t.data)),this._getType(t)!==ee.bigint){const i=this._getOrReturnCtx(t);return ie(i,{code:K.invalid_type,expected:ee.bigint,received:i.parsedType}),Ee}let r;const o=new ht;for(const i of this._def.checks)i.kind==="min"?(i.inclusive?t.data<i.value:t.data<=i.value)&&(r=this._getOrReturnCtx(t,r),ie(r,{code:K.too_small,type:"bigint",minimum:i.value,inclusive:i.inclusive,message:i.message}),o.dirty()):i.kind==="max"?(i.inclusive?t.data>i.value:t.data>=i.value)&&(r=this._getOrReturnCtx(t,r),ie(r,{code:K.too_big,type:"bigint",maximum:i.value,inclusive:i.inclusive,message:i.message}),o.dirty()):i.kind==="multipleOf"?t.data%i.value!==BigInt(0)&&(r=this._getOrReturnCtx(t,r),ie(r,{code:K.not_multiple_of,multipleOf:i.value,message:i.message}),o.dirty()):Pe.assertNever(i);return{status:o.value,value:t.data}}gte(t,n){return this.setLimit("min",t,!0,ge.toString(n))}gt(t,n){return this.setLimit("min",t,!1,ge.toString(n))}lte(t,n){return this.setLimit("max",t,!0,ge.toString(n))}lt(t,n){return this.setLimit("max",t,!1,ge.toString(n))}setLimit(t,n,r,o){return new wr({...this._def,checks:[...this._def.checks,{kind:t,value:n,inclusive:r,message:ge.toString(o)}]})}_addCheck(t){return new wr({...this._def,checks:[...this._def.checks,t]})}positive(t){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!1,message:ge.toString(t)})}negative(t){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!1,message:ge.toString(t)})}nonpositive(t){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!0,message:ge.toString(t)})}nonnegative(t){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!0,message:ge.toString(t)})}multipleOf(t,n){return this._addCheck({kind:"multipleOf",value:t,message:ge.toString(n)})}get minValue(){let t=null;for(const n of this._def.checks)n.kind==="min"&&(t===null||n.value>t)&&(t=n.value);return t}get maxValue(){let t=null;for(const n of this._def.checks)n.kind==="max"&&(t===null||n.value<t)&&(t=n.value);return t}}wr.create=e=>{var t;return new wr({checks:[],typeName:be.ZodBigInt,coerce:(t=e?.coerce)!==null&&t!==void 0?t:!1,...Ae(e)})};class zo extends xe{_parse(t){if(this._def.coerce&&(t.data=!!t.data),this._getType(t)!==ee.boolean){const r=this._getOrReturnCtx(t);return ie(r,{code:K.invalid_type,expected:ee.boolean,received:r.parsedType}),Ee}return Et(t.data)}}zo.create=e=>new zo({typeName:be.ZodBoolean,coerce:e?.coerce||!1,...Ae(e)});class Gr extends xe{_parse(t){if(this._def.coerce&&(t.data=new Date(t.data)),this._getType(t)!==ee.date){const i=this._getOrReturnCtx(t);return ie(i,{code:K.invalid_type,expected:ee.date,received:i.parsedType}),Ee}if(isNaN(t.data.getTime())){const i=this._getOrReturnCtx(t);return ie(i,{code:K.invalid_date}),Ee}const r=new ht;let o;for(const i of this._def.checks)i.kind==="min"?t.data.getTime()<i.value&&(o=this._getOrReturnCtx(t,o),ie(o,{code:K.too_small,message:i.message,inclusive:!0,exact:!1,minimum:i.value,type:"date"}),r.dirty()):i.kind==="max"?t.data.getTime()>i.value&&(o=this._getOrReturnCtx(t,o),ie(o,{code:K.too_big,message:i.message,inclusive:!0,exact:!1,maximum:i.value,type:"date"}),r.dirty()):Pe.assertNever(i);return{status:r.value,value:new Date(t.data.getTime())}}_addCheck(t){return new Gr({...this._def,checks:[...this._def.checks,t]})}min(t,n){return this._addCheck({kind:"min",value:t.getTime(),message:ge.toString(n)})}max(t,n){return this._addCheck({kind:"max",value:t.getTime(),message:ge.toString(n)})}get minDate(){let t=null;for(const n of this._def.checks)n.kind==="min"&&(t===null||n.value>t)&&(t=n.value);return t!=null?new Date(t):null}get maxDate(){let t=null;for(const n of this._def.checks)n.kind==="max"&&(t===null||n.value<t)&&(t=n.value);return t!=null?new Date(t):null}}Gr.create=e=>new Gr({checks:[],coerce:e?.coerce||!1,typeName:be.ZodDate,...Ae(e)});class Wa extends xe{_parse(t){if(this._getType(t)!==ee.symbol){const r=this._getOrReturnCtx(t);return ie(r,{code:K.invalid_type,expected:ee.symbol,received:r.parsedType}),Ee}return Et(t.data)}}Wa.create=e=>new Wa({typeName:be.ZodSymbol,...Ae(e)});class Ho extends xe{_parse(t){if(this._getType(t)!==ee.undefined){const r=this._getOrReturnCtx(t);return ie(r,{code:K.invalid_type,expected:ee.undefined,received:r.parsedType}),Ee}return Et(t.data)}}Ho.create=e=>new Ho({typeName:be.ZodUndefined,...Ae(e)});class Vo extends xe{_parse(t){if(this._getType(t)!==ee.null){const r=this._getOrReturnCtx(t);return ie(r,{code:K.invalid_type,expected:ee.null,received:r.parsedType}),Ee}return Et(t.data)}}Vo.create=e=>new Vo({typeName:be.ZodNull,...Ae(e)});class Qi extends xe{constructor(){super(...arguments),this._any=!0}_parse(t){return Et(t.data)}}Qi.create=e=>new Qi({typeName:be.ZodAny,...Ae(e)});class zr extends xe{constructor(){super(...arguments),this._unknown=!0}_parse(t){return Et(t.data)}}zr.create=e=>new zr({typeName:be.ZodUnknown,...Ae(e)});class Jn extends xe{_parse(t){const n=this._getOrReturnCtx(t);return ie(n,{code:K.invalid_type,expected:ee.never,received:n.parsedType}),Ee}}Jn.create=e=>new Jn({typeName:be.ZodNever,...Ae(e)});class ja extends xe{_parse(t){if(this._getType(t)!==ee.undefined){const r=this._getOrReturnCtx(t);return ie(r,{code:K.invalid_type,expected:ee.void,received:r.parsedType}),Ee}return Et(t.data)}}ja.create=e=>new ja({typeName:be.ZodVoid,...Ae(e)});class fn extends xe{_parse(t){const{ctx:n,status:r}=this._processInputParams(t),o=this._def;if(n.parsedType!==ee.array)return ie(n,{code:K.invalid_type,expected:ee.array,received:n.parsedType}),Ee;if(o.exactLength!==null){const s=n.data.length>o.exactLength.value,a=n.data.length<o.exactLength.value;(s||a)&&(ie(n,{code:s?K.too_big:K.too_small,minimum:a?o.exactLength.value:void 0,maximum:s?o.exactLength.value:void 0,type:"array",inclusive:!0,exact:!0,message:o.exactLength.message}),r.dirty())}if(o.minLength!==null&&n.data.length<o.minLength.value&&(ie(n,{code:K.too_small,minimum:o.minLength.value,type:"array",inclusive:!0,exact:!1,message:o.minLength.message}),r.dirty()),o.maxLength!==null&&n.data.length>o.maxLength.value&&(ie(n,{code:K.too_big,maximum:o.maxLength.value,type:"array",inclusive:!0,exact:!1,message:o.maxLength.message}),r.dirty()),n.common.async)return Promise.all([...n.data].map((s,a)=>o.type._parseAsync(new Rn(n,s,n.path,a)))).then(s=>ht.mergeArray(r,s));const i=[...n.data].map((s,a)=>o.type._parseSync(new Rn(n,s,n.path,a)));return ht.mergeArray(r,i)}get element(){return this._def.type}min(t,n){return new fn({...this._def,minLength:{value:t,message:ge.toString(n)}})}max(t,n){return new fn({...this._def,maxLength:{value:t,message:ge.toString(n)}})}length(t,n){return new fn({...this._def,exactLength:{value:t,message:ge.toString(n)}})}nonempty(t){return this.min(1,t)}}fn.create=(e,t)=>new fn({type:e,minLength:null,maxLength:null,exactLength:null,typeName:be.ZodArray,...Ae(t)});function Wi(e){if(e instanceof Ge){const t={};for(const n in e.shape){const r=e.shape[n];t[n]=Zn.create(Wi(r))}return new Ge({...e._def,shape:()=>t})}else return e instanceof fn?new fn({...e._def,type:Wi(e.element)}):e instanceof Zn?Zn.create(Wi(e.unwrap())):e instanceof Yr?Yr.create(Wi(e.unwrap())):e instanceof kn?kn.create(e.items.map(t=>Wi(t))):e}class Ge extends xe{constructor(){super(...arguments),this._cached=null,this.nonstrict=this.passthrough,this.augment=this.extend}_getCached(){if(this._cached!==null)return this._cached;const t=this._def.shape(),n=Pe.objectKeys(t);return this._cached={shape:t,keys:n}}_parse(t){if(this._getType(t)!==ee.object){const l=this._getOrReturnCtx(t);return ie(l,{code:K.invalid_type,expected:ee.object,received:l.parsedType}),Ee}const{status:r,ctx:o}=this._processInputParams(t),{shape:i,keys:s}=this._getCached(),a=[];if(!(this._def.catchall instanceof Jn&&this._def.unknownKeys==="strip"))for(const l in o.data)s.includes(l)||a.push(l);const c=[];for(const l of s){const d=i[l],h=o.data[l];c.push({key:{status:"valid",value:l},value:d._parse(new Rn(o,h,o.path,l)),alwaysSet:l in o.data})}if(this._def.catchall instanceof Jn){const l=this._def.unknownKeys;if(l==="passthrough")for(const d of a)c.push({key:{status:"valid",value:d},value:{status:"valid",value:o.data[d]}});else if(l==="strict")a.length>0&&(ie(o,{code:K.unrecognized_keys,keys:a}),r.dirty());else if(l!=="strip")throw new Error("Internal ZodObject error: invalid unknownKeys value.")}else{const l=this._def.catchall;for(const d of a){const h=o.data[d];c.push({key:{status:"valid",value:d},value:l._parse(new Rn(o,h,o.path,d)),alwaysSet:d in o.data})}}return o.common.async?Promise.resolve().then(async()=>{const l=[];for(const d of c){const h=await d.key;l.push({key:h,value:await d.value,alwaysSet:d.alwaysSet})}return l}).then(l=>ht.mergeObjectSync(r,l)):ht.mergeObjectSync(r,c)}get shape(){return this._def.shape()}strict(t){return ge.errToObj,new Ge({...this._def,unknownKeys:"strict",...t!==void 0?{errorMap:(n,r)=>{var o,i,s,a;const c=(s=(i=(o=this._def).errorMap)===null||i===void 0?void 0:i.call(o,n,r).message)!==null&&s!==void 0?s:r.defaultError;return n.code==="unrecognized_keys"?{message:(a=ge.errToObj(t).message)!==null&&a!==void 0?a:c}:{message:c}}}:{}})}strip(){return new Ge({...this._def,unknownKeys:"strip"})}passthrough(){return new Ge({...this._def,unknownKeys:"passthrough"})}extend(t){return new Ge({...this._def,shape:()=>({...this._def.shape(),...t})})}merge(t){return new Ge({unknownKeys:t._def.unknownKeys,catchall:t._def.catchall,shape:()=>({...this._def.shape(),...t._def.shape()}),typeName:be.ZodObject})}setKey(t,n){return this.augment({[t]:n})}catchall(t){return new Ge({...this._def,catchall:t})}pick(t){const n={};return Pe.objectKeys(t).forEach(r=>{t[r]&&this.shape[r]&&(n[r]=this.shape[r])}),new Ge({...this._def,shape:()=>n})}omit(t){const n={};return Pe.objectKeys(this.shape).forEach(r=>{t[r]||(n[r]=this.shape[r])}),new Ge({...this._def,shape:()=>n})}deepPartial(){return Wi(this)}partial(t){const n={};return Pe.objectKeys(this.shape).forEach(r=>{const o=this.shape[r];t&&!t[r]?n[r]=o:n[r]=o.optional()}),new Ge({...this._def,shape:()=>n})}required(t){const n={};return Pe.objectKeys(this.shape).forEach(r=>{if(t&&!t[r])n[r]=this.shape[r];else{let i=this.shape[r];for(;i instanceof Zn;)i=i._def.innerType;n[r]=i}}),new Ge({...this._def,shape:()=>n})}keyof(){return Tp(Pe.objectKeys(this.shape))}}Ge.create=(e,t)=>new Ge({shape:()=>e,unknownKeys:"strip",catchall:Jn.create(),typeName:be.ZodObject,...Ae(t)});Ge.strictCreate=(e,t)=>new Ge({shape:()=>e,unknownKeys:"strict",catchall:Jn.create(),typeName:be.ZodObject,...Ae(t)});Ge.lazycreate=(e,t)=>new Ge({shape:e,unknownKeys:"strip",catchall:Jn.create(),typeName:be.ZodObject,...Ae(t)});class qo extends xe{_parse(t){const{ctx:n}=this._processInputParams(t),r=this._def.options;function o(i){for(const a of i)if(a.result.status==="valid")return a.result;for(const a of i)if(a.result.status==="dirty")return n.common.issues.push(...a.ctx.common.issues),a.result;const s=i.map(a=>new pn(a.ctx.common.issues));return ie(n,{code:K.invalid_union,unionErrors:s}),Ee}if(n.common.async)return Promise.all(r.map(async i=>{const s={...n,common:{...n.common,issues:[]},parent:null};return{result:await i._parseAsync({data:n.data,path:n.path,parent:s}),ctx:s}})).then(o);{let i;const s=[];for(const c of r){const l={...n,common:{...n.common,issues:[]},parent:null},d=c._parseSync({data:n.data,path:n.path,parent:l});if(d.status==="valid")return d;d.status==="dirty"&&!i&&(i={result:d,ctx:l}),l.common.issues.length&&s.push(l.common.issues)}if(i)return n.common.issues.push(...i.ctx.common.issues),i.result;const a=s.map(c=>new pn(c));return ie(n,{code:K.invalid_union,unionErrors:a}),Ee}}get options(){return this._def.options}}qo.create=(e,t)=>new qo({options:e,typeName:be.ZodUnion,...Ae(t)});const Na=e=>e instanceof Zo?Na(e.schema):e instanceof mn?Na(e.innerType()):e instanceof Yo?[e.value]:e instanceof br?e.options:e instanceof Jo?Object.keys(e.enum):e instanceof Xo?Na(e._def.innerType):e instanceof Ho?[void 0]:e instanceof Vo?[null]:null;class Tc extends xe{_parse(t){const{ctx:n}=this._processInputParams(t);if(n.parsedType!==ee.object)return ie(n,{code:K.invalid_type,expected:ee.object,received:n.parsedType}),Ee;const r=this.discriminator,o=n.data[r],i=this.optionsMap.get(o);return i?n.common.async?i._parseAsync({data:n.data,path:n.path,parent:n}):i._parseSync({data:n.data,path:n.path,parent:n}):(ie(n,{code:K.invalid_union_discriminator,options:Array.from(this.optionsMap.keys()),path:[r]}),Ee)}get discriminator(){return this._def.discriminator}get options(){return this._def.options}get optionsMap(){return this._def.optionsMap}static create(t,n,r){const o=new Map;for(const i of n){const s=Na(i.shape[t]);if(!s)throw new Error(`A discriminator value for key \`${t}\` could not be extracted from all schema options`);for(const a of s){if(o.has(a))throw new Error(`Discriminator property ${String(t)} has duplicate value ${String(a)}`);o.set(a,i)}}return new Tc({typeName:be.ZodDiscriminatedUnion,discriminator:t,options:n,optionsMap:o,...Ae(r)})}}function Hl(e,t){const n=lr(e),r=lr(t);if(e===t)return{valid:!0,data:e};if(n===ee.object&&r===ee.object){const o=Pe.objectKeys(t),i=Pe.objectKeys(e).filter(a=>o.indexOf(a)!==-1),s={...e,...t};for(const a of i){const c=Hl(e[a],t[a]);if(!c.valid)return{valid:!1};s[a]=c.data}return{valid:!0,data:s}}else if(n===ee.array&&r===ee.array){if(e.length!==t.length)return{valid:!1};const o=[];for(let i=0;i<e.length;i++){const s=e[i],a=t[i],c=Hl(s,a);if(!c.valid)return{valid:!1};o.push(c.data)}return{valid:!0,data:o}}else return n===ee.date&&r===ee.date&&+e==+t?{valid:!0,data:e}:{valid:!1}}class Ko extends xe{_parse(t){const{status:n,ctx:r}=this._processInputParams(t),o=(i,s)=>{if(Fl(i)||Fl(s))return Ee;const a=Hl(i.value,s.value);return a.valid?((zl(i)||zl(s))&&n.dirty(),{status:n.value,value:a.data}):(ie(r,{code:K.invalid_intersection_types}),Ee)};return r.common.async?Promise.all([this._def.left._parseAsync({data:r.data,path:r.path,parent:r}),this._def.right._parseAsync({data:r.data,path:r.path,parent:r})]).then(([i,s])=>o(i,s)):o(this._def.left._parseSync({data:r.data,path:r.path,parent:r}),this._def.right._parseSync({data:r.data,path:r.path,parent:r}))}}Ko.create=(e,t,n)=>new Ko({left:e,right:t,typeName:be.ZodIntersection,...Ae(n)});class kn extends xe{_parse(t){const{status:n,ctx:r}=this._processInputParams(t);if(r.parsedType!==ee.array)return ie(r,{code:K.invalid_type,expected:ee.array,received:r.parsedType}),Ee;if(r.data.length<this._def.items.length)return ie(r,{code:K.too_small,minimum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),Ee;!this._def.rest&&r.data.length>this._def.items.length&&(ie(r,{code:K.too_big,maximum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),n.dirty());const i=[...r.data].map((s,a)=>{const c=this._def.items[a]||this._def.rest;return c?c._parse(new Rn(r,s,r.path,a)):null}).filter(s=>!!s);return r.common.async?Promise.all(i).then(s=>ht.mergeArray(n,s)):ht.mergeArray(n,i)}get items(){return this._def.items}rest(t){return new kn({...this._def,rest:t})}}kn.create=(e,t)=>{if(!Array.isArray(e))throw new Error("You must pass an array of schemas to z.tuple([ ... ])");return new kn({items:e,typeName:be.ZodTuple,rest:null,...Ae(t)})};class Go extends xe{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(t){const{status:n,ctx:r}=this._processInputParams(t);if(r.parsedType!==ee.object)return ie(r,{code:K.invalid_type,expected:ee.object,received:r.parsedType}),Ee;const o=[],i=this._def.keyType,s=this._def.valueType;for(const a in r.data)o.push({key:i._parse(new Rn(r,a,r.path,a)),value:s._parse(new Rn(r,r.data[a],r.path,a))});return r.common.async?ht.mergeObjectAsync(n,o):ht.mergeObjectSync(n,o)}get element(){return this._def.valueType}static create(t,n,r){return n instanceof xe?new Go({keyType:t,valueType:n,typeName:be.ZodRecord,...Ae(r)}):new Go({keyType:hn.create(),valueType:t,typeName:be.ZodRecord,...Ae(n)})}}class Fa extends xe{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(t){const{status:n,ctx:r}=this._processInputParams(t);if(r.parsedType!==ee.map)return ie(r,{code:K.invalid_type,expected:ee.map,received:r.parsedType}),Ee;const o=this._def.keyType,i=this._def.valueType,s=[...r.data.entries()].map(([a,c],l)=>({key:o._parse(new Rn(r,a,r.path,[l,"key"])),value:i._parse(new Rn(r,c,r.path,[l,"value"]))}));if(r.common.async){const a=new Map;return Promise.resolve().then(async()=>{for(const c of s){const l=await c.key,d=await c.value;if(l.status==="aborted"||d.status==="aborted")return Ee;(l.status==="dirty"||d.status==="dirty")&&n.dirty(),a.set(l.value,d.value)}return{status:n.value,value:a}})}else{const a=new Map;for(const c of s){const l=c.key,d=c.value;if(l.status==="aborted"||d.status==="aborted")return Ee;(l.status==="dirty"||d.status==="dirty")&&n.dirty(),a.set(l.value,d.value)}return{status:n.value,value:a}}}}Fa.create=(e,t,n)=>new Fa({valueType:t,keyType:e,typeName:be.ZodMap,...Ae(n)});class Zr extends xe{_parse(t){const{status:n,ctx:r}=this._processInputParams(t);if(r.parsedType!==ee.set)return ie(r,{code:K.invalid_type,expected:ee.set,received:r.parsedType}),Ee;const o=this._def;o.minSize!==null&&r.data.size<o.minSize.value&&(ie(r,{code:K.too_small,minimum:o.minSize.value,type:"set",inclusive:!0,exact:!1,message:o.minSize.message}),n.dirty()),o.maxSize!==null&&r.data.size>o.maxSize.value&&(ie(r,{code:K.too_big,maximum:o.maxSize.value,type:"set",inclusive:!0,exact:!1,message:o.maxSize.message}),n.dirty());const i=this._def.valueType;function s(c){const l=new Set;for(const d of c){if(d.status==="aborted")return Ee;d.status==="dirty"&&n.dirty(),l.add(d.value)}return{status:n.value,value:l}}const a=[...r.data.values()].map((c,l)=>i._parse(new Rn(r,c,r.path,l)));return r.common.async?Promise.all(a).then(c=>s(c)):s(a)}min(t,n){return new Zr({...this._def,minSize:{value:t,message:ge.toString(n)}})}max(t,n){return new Zr({...this._def,maxSize:{value:t,message:ge.toString(n)}})}size(t,n){return this.min(t,n).max(t,n)}nonempty(t){return this.min(1,t)}}Zr.create=(e,t)=>new Zr({valueType:e,minSize:null,maxSize:null,typeName:be.ZodSet,...Ae(t)});class qi extends xe{constructor(){super(...arguments),this.validate=this.implement}_parse(t){const{ctx:n}=this._processInputParams(t);if(n.parsedType!==ee.function)return ie(n,{code:K.invalid_type,expected:ee.function,received:n.parsedType}),Ee;function r(a,c){return Ua({data:a,path:n.path,errorMaps:[n.common.contextualErrorMap,n.schemaErrorMap,Ma(),jo].filter(l=>!!l),issueData:{code:K.invalid_arguments,argumentsError:c}})}function o(a,c){return Ua({data:a,path:n.path,errorMaps:[n.common.contextualErrorMap,n.schemaErrorMap,Ma(),jo].filter(l=>!!l),issueData:{code:K.invalid_return_type,returnTypeError:c}})}const i={errorMap:n.common.contextualErrorMap},s=n.data;if(this._def.returns instanceof eo){const a=this;return Et(async function(...c){const l=new pn([]),d=await a._def.args.parseAsync(c,i).catch(w=>{throw l.addIssue(r(c,w)),l}),h=await Reflect.apply(s,this,d);return await a._def.returns._def.type.parseAsync(h,i).catch(w=>{throw l.addIssue(o(h,w)),l})})}else{const a=this;return Et(function(...c){const l=a._def.args.safeParse(c,i);if(!l.success)throw new pn([r(c,l.error)]);const d=Reflect.apply(s,this,l.data),h=a._def.returns.safeParse(d,i);if(!h.success)throw new pn([o(d,h.error)]);return h.data})}}parameters(){return this._def.args}returnType(){return this._def.returns}args(...t){return new qi({...this._def,args:kn.create(t).rest(zr.create())})}returns(t){return new qi({...this._def,returns:t})}implement(t){return this.parse(t)}strictImplement(t){return this.parse(t)}static create(t,n,r){return new qi({args:t||kn.create([]).rest(zr.create()),returns:n||zr.create(),typeName:be.ZodFunction,...Ae(r)})}}class Zo extends xe{get schema(){return this._def.getter()}_parse(t){const{ctx:n}=this._processInputParams(t);return this._def.getter()._parse({data:n.data,path:n.path,parent:n})}}Zo.create=(e,t)=>new Zo({getter:e,typeName:be.ZodLazy,...Ae(t)});class Yo extends xe{_parse(t){if(t.data!==this._def.value){const n=this._getOrReturnCtx(t);return ie(n,{received:n.data,code:K.invalid_literal,expected:this._def.value}),Ee}return{status:"valid",value:t.data}}get value(){return this._def.value}}Yo.create=(e,t)=>new Yo({value:e,typeName:be.ZodLiteral,...Ae(t)});function Tp(e,t){return new br({values:e,typeName:be.ZodEnum,...Ae(t)})}class br extends xe{_parse(t){if(typeof t.data!="string"){const n=this._getOrReturnCtx(t),r=this._def.values;return ie(n,{expected:Pe.joinValues(r),received:n.parsedType,code:K.invalid_type}),Ee}if(this._def.values.indexOf(t.data)===-1){const n=this._getOrReturnCtx(t),r=this._def.values;return ie(n,{received:n.data,code:K.invalid_enum_value,options:r}),Ee}return Et(t.data)}get options(){return this._def.values}get enum(){const t={};for(const n of this._def.values)t[n]=n;return t}get Values(){const t={};for(const n of this._def.values)t[n]=n;return t}get Enum(){const t={};for(const n of this._def.values)t[n]=n;return t}extract(t){return br.create(t)}exclude(t){return br.create(this.options.filter(n=>!t.includes(n)))}}br.create=Tp;class Jo extends xe{_parse(t){const n=Pe.getValidEnumValues(this._def.values),r=this._getOrReturnCtx(t);if(r.parsedType!==ee.string&&r.parsedType!==ee.number){const o=Pe.objectValues(n);return ie(r,{expected:Pe.joinValues(o),received:r.parsedType,code:K.invalid_type}),Ee}if(n.indexOf(t.data)===-1){const o=Pe.objectValues(n);return ie(r,{received:r.data,code:K.invalid_enum_value,options:o}),Ee}return Et(t.data)}get enum(){return this._def.values}}Jo.create=(e,t)=>new Jo({values:e,typeName:be.ZodNativeEnum,...Ae(t)});class eo extends xe{unwrap(){return this._def.type}_parse(t){const{ctx:n}=this._processInputParams(t);if(n.parsedType!==ee.promise&&n.common.async===!1)return ie(n,{code:K.invalid_type,expected:ee.promise,received:n.parsedType}),Ee;const r=n.parsedType===ee.promise?n.data:Promise.resolve(n.data);return Et(r.then(o=>this._def.type.parseAsync(o,{path:n.path,errorMap:n.common.contextualErrorMap})))}}eo.create=(e,t)=>new eo({type:e,typeName:be.ZodPromise,...Ae(t)});class mn extends xe{innerType(){return this._def.schema}sourceType(){return this._def.schema._def.typeName===be.ZodEffects?this._def.schema.sourceType():this._def.schema}_parse(t){const{status:n,ctx:r}=this._processInputParams(t),o=this._def.effect||null,i={addIssue:s=>{ie(r,s),s.fatal?n.abort():n.dirty()},get path(){return r.path}};if(i.addIssue=i.addIssue.bind(i),o.type==="preprocess"){const s=o.transform(r.data,i);return r.common.issues.length?{status:"dirty",value:r.data}:r.common.async?Promise.resolve(s).then(a=>this._def.schema._parseAsync({data:a,path:r.path,parent:r})):this._def.schema._parseSync({data:s,path:r.path,parent:r})}if(o.type==="refinement"){const s=a=>{const c=o.refinement(a,i);if(r.common.async)return Promise.resolve(c);if(c instanceof Promise)throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");return a};if(r.common.async===!1){const a=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});return a.status==="aborted"?Ee:(a.status==="dirty"&&n.dirty(),s(a.value),{status:n.value,value:a.value})}else return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(a=>a.status==="aborted"?Ee:(a.status==="dirty"&&n.dirty(),s(a.value).then(()=>({status:n.value,value:a.value}))))}if(o.type==="transform")if(r.common.async===!1){const s=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});if(!Fo(s))return s;const a=o.transform(s.value,i);if(a instanceof Promise)throw new Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");return{status:n.value,value:a}}else return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(s=>Fo(s)?Promise.resolve(o.transform(s.value,i)).then(a=>({status:n.value,value:a})):s);Pe.assertNever(o)}}mn.create=(e,t,n)=>new mn({schema:e,typeName:be.ZodEffects,effect:t,...Ae(n)});mn.createWithPreprocess=(e,t,n)=>new mn({schema:t,effect:{type:"preprocess",transform:e},typeName:be.ZodEffects,...Ae(n)});class Zn extends xe{_parse(t){return this._getType(t)===ee.undefined?Et(void 0):this._def.innerType._parse(t)}unwrap(){return this._def.innerType}}Zn.create=(e,t)=>new Zn({innerType:e,typeName:be.ZodOptional,...Ae(t)});class Yr extends xe{_parse(t){return this._getType(t)===ee.null?Et(null):this._def.innerType._parse(t)}unwrap(){return this._def.innerType}}Yr.create=(e,t)=>new Yr({innerType:e,typeName:be.ZodNullable,...Ae(t)});class Xo extends xe{_parse(t){const{ctx:n}=this._processInputParams(t);let r=n.data;return n.parsedType===ee.undefined&&(r=this._def.defaultValue()),this._def.innerType._parse({data:r,path:n.path,parent:n})}removeDefault(){return this._def.innerType}}Xo.create=(e,t)=>new Xo({innerType:e,typeName:be.ZodDefault,defaultValue:typeof t.default=="function"?t.default:()=>t.default,...Ae(t)});class za extends xe{_parse(t){const{ctx:n}=this._processInputParams(t),r={...n,common:{...n.common,issues:[]}},o=this._def.innerType._parse({data:r.data,path:r.path,parent:{...r}});return Ba(o)?o.then(i=>({status:"valid",value:i.status==="valid"?i.value:this._def.catchValue({get error(){return new pn(r.common.issues)},input:r.data})})):{status:"valid",value:o.status==="valid"?o.value:this._def.catchValue({get error(){return new pn(r.common.issues)},input:r.data})}}removeCatch(){return this._def.innerType}}za.create=(e,t)=>new za({innerType:e,typeName:be.ZodCatch,catchValue:typeof t.catch=="function"?t.catch:()=>t.catch,...Ae(t)});class Ha extends xe{_parse(t){if(this._getType(t)!==ee.nan){const r=this._getOrReturnCtx(t);return ie(r,{code:K.invalid_type,expected:ee.nan,received:r.parsedType}),Ee}return{status:"valid",value:t.data}}}Ha.create=e=>new Ha({typeName:be.ZodNaN,...Ae(e)});const m0=Symbol("zod_brand");class $p extends xe{_parse(t){const{ctx:n}=this._processInputParams(t),r=n.data;return this._def.type._parse({data:r,path:n.path,parent:n})}unwrap(){return this._def.type}}class Us extends xe{_parse(t){const{status:n,ctx:r}=this._processInputParams(t);if(r.common.async)return(async()=>{const i=await this._def.in._parseAsync({data:r.data,path:r.path,parent:r});return i.status==="aborted"?Ee:i.status==="dirty"?(n.dirty(),Sp(i.value)):this._def.out._parseAsync({data:i.value,path:r.path,parent:r})})();{const o=this._def.in._parseSync({data:r.data,path:r.path,parent:r});return o.status==="aborted"?Ee:o.status==="dirty"?(n.dirty(),{status:"dirty",value:o.value}):this._def.out._parseSync({data:o.value,path:r.path,parent:r})}}static create(t,n){return new Us({in:t,out:n,typeName:be.ZodPipeline})}}class Va extends xe{_parse(t){const n=this._def.innerType._parse(t);return Fo(n)&&(n.value=Object.freeze(n.value)),n}}Va.create=(e,t)=>new Va({innerType:e,typeName:be.ZodReadonly,...Ae(t)});const Np=(e,t={},n)=>e?Qi.create().superRefine((r,o)=>{var i,s;if(!e(r)){const a=typeof t=="function"?t(r):typeof t=="string"?{message:t}:t,c=(s=(i=a.fatal)!==null&&i!==void 0?i:n)!==null&&s!==void 0?s:!0,l=typeof a=="string"?{message:a}:a;o.addIssue({code:"custom",...l,fatal:c})}}):Qi.create(),g0={object:Ge.lazycreate};var be;(function(e){e.ZodString="ZodString",e.ZodNumber="ZodNumber",e.ZodNaN="ZodNaN",e.ZodBigInt="ZodBigInt",e.ZodBoolean="ZodBoolean",e.ZodDate="ZodDate",e.ZodSymbol="ZodSymbol",e.ZodUndefined="ZodUndefined",e.ZodNull="ZodNull",e.ZodAny="ZodAny",e.ZodUnknown="ZodUnknown",e.ZodNever="ZodNever",e.ZodVoid="ZodVoid",e.ZodArray="ZodArray",e.ZodObject="ZodObject",e.ZodUnion="ZodUnion",e.ZodDiscriminatedUnion="ZodDiscriminatedUnion",e.ZodIntersection="ZodIntersection",e.ZodTuple="ZodTuple",e.ZodRecord="ZodRecord",e.ZodMap="ZodMap",e.ZodSet="ZodSet",e.ZodFunction="ZodFunction",e.ZodLazy="ZodLazy",e.ZodLiteral="ZodLiteral",e.ZodEnum="ZodEnum",e.ZodEffects="ZodEffects",e.ZodNativeEnum="ZodNativeEnum",e.ZodOptional="ZodOptional",e.ZodNullable="ZodNullable",e.ZodDefault="ZodDefault",e.ZodCatch="ZodCatch",e.ZodPromise="ZodPromise",e.ZodBranded="ZodBranded",e.ZodPipeline="ZodPipeline",e.ZodReadonly="ZodReadonly"})(be||(be={}));const w0=(e,t={message:`Input not instance of ${e.name}`})=>Np(n=>n instanceof e,t),Rp=hn.create,kp=gr.create,b0=Ha.create,y0=wr.create,Ip=zo.create,C0=Gr.create,v0=Wa.create,E0=Ho.create,_0=Vo.create,A0=Qi.create,x0=zr.create,S0=Jn.create,T0=ja.create,$0=fn.create,N0=Ge.create,R0=Ge.strictCreate,k0=qo.create,I0=Tc.create,O0=Ko.create,P0=kn.create,L0=Go.create,D0=Fa.create,M0=Zr.create,U0=qi.create,B0=Zo.create,W0=Yo.create,j0=br.create,F0=Jo.create,z0=eo.create,Cu=mn.create,H0=Zn.create,V0=Yr.create,q0=mn.createWithPreprocess,K0=Us.create,G0=()=>Rp().optional(),Z0=()=>kp().optional(),Y0=()=>Ip().optional(),J0={string:(e=>hn.create({...e,coerce:!0})),number:(e=>gr.create({...e,coerce:!0})),boolean:(e=>zo.create({...e,coerce:!0})),bigint:(e=>wr.create({...e,coerce:!0})),date:(e=>Gr.create({...e,coerce:!0}))},X0=Ee;var u=Object.freeze({__proto__:null,defaultErrorMap:jo,setErrorMap:n0,getErrorMap:Ma,makeIssue:Ua,EMPTY_PATH:r0,addIssueToContext:ie,ParseStatus:ht,INVALID:Ee,DIRTY:Sp,OK:Et,isAborted:Fl,isDirty:zl,isValid:Fo,isAsync:Ba,get util(){return Pe},get objectUtil(){return jl},ZodParsedType:ee,getParsedType:lr,ZodType:xe,ZodString:hn,ZodNumber:gr,ZodBigInt:wr,ZodBoolean:zo,ZodDate:Gr,ZodSymbol:Wa,ZodUndefined:Ho,ZodNull:Vo,ZodAny:Qi,ZodUnknown:zr,ZodNever:Jn,ZodVoid:ja,ZodArray:fn,ZodObject:Ge,ZodUnion:qo,ZodDiscriminatedUnion:Tc,ZodIntersection:Ko,ZodTuple:kn,ZodRecord:Go,ZodMap:Fa,ZodSet:Zr,ZodFunction:qi,ZodLazy:Zo,ZodLiteral:Yo,ZodEnum:br,ZodNativeEnum:Jo,ZodPromise:eo,ZodEffects:mn,ZodTransformer:mn,ZodOptional:Zn,ZodNullable:Yr,ZodDefault:Xo,ZodCatch:za,ZodNaN:Ha,BRAND:m0,ZodBranded:$p,ZodPipeline:Us,ZodReadonly:Va,custom:Np,Schema:xe,ZodSchema:xe,late:g0,get ZodFirstPartyTypeKind(){return be},coerce:J0,any:A0,array:$0,bigint:y0,boolean:Ip,date:C0,discriminatedUnion:I0,effect:Cu,enum:j0,function:U0,instanceof:w0,intersection:O0,lazy:B0,literal:W0,map:D0,nan:b0,nativeEnum:F0,never:S0,null:_0,nullable:V0,number:kp,object:N0,oboolean:Y0,onumber:Z0,optional:H0,ostring:G0,pipeline:K0,preprocess:q0,promise:z0,record:L0,set:M0,strictObject:R0,string:Rp,symbol:v0,transformer:Cu,tuple:P0,undefined:E0,union:k0,unknown:x0,void:T0,NEVER:X0,ZodIssueCode:K,quotelessJson:t0,ZodError:pn});const Ze=u.object({message:u.string()});function te(e){return u.literal(oe[e])}const $c=u.object({serializedMessage:u.string().optional(),accountAddress:u.string(),chainId:u.string(),notBefore:u.string().optional(),domain:u.string(),uri:u.string(),version:u.string(),nonce:u.string(),statement:u.string().optional(),resources:u.array(u.string()).optional(),requestId:u.string().optional(),issuedAt:u.string().optional(),expirationTime:u.string().optional()});u.object({accessList:u.array(u.string()),blockHash:u.string().nullable(),blockNumber:u.string().nullable(),chainId:u.string().or(u.number()),from:u.string(),gas:u.string(),hash:u.string(),input:u.string().nullable(),maxFeePerGas:u.string(),maxPriorityFeePerGas:u.string(),nonce:u.string(),r:u.string(),s:u.string(),to:u.string(),transactionIndex:u.string().nullable(),type:u.string(),v:u.string(),value:u.string()});const Q0=u.object({chainId:u.string().or(u.number()),rpcUrl:u.optional(u.string())}),eg=u.object({email:u.string().email()}),tg=u.object({otp:u.string()}),ng=u.object({uri:u.string(),preferredAccountType:u.optional(u.string()),chainId:u.optional(u.string().or(u.number())),siwxMessage:u.optional($c),rpcUrl:u.optional(u.string())}),rg=u.object({chainId:u.optional(u.string().or(u.number())),preferredAccountType:u.optional(u.string()),socialUri:u.optional(u.string()),siwxMessage:u.optional($c),rpcUrl:u.optional(u.string())}),ig=u.object({provider:u.enum(["google","github","apple","facebook","x","discord"])}),og=u.object({email:u.string().email()}),sg=u.object({otp:u.string()}),ag=u.object({otp:u.string()}),cg=u.object({themeMode:u.optional(u.enum(["light","dark"])),themeVariables:u.optional(u.record(u.string(),u.string().or(u.number()))),w3mThemeVariables:u.optional(u.record(u.string(),u.string()))}),lg=u.object({metadata:u.object({name:u.string(),description:u.string(),url:u.string(),icons:u.array(u.string())}).optional(),sdkVersion:u.string().optional(),sdkType:u.string().optional(),projectId:u.string()}),dg=u.object({type:u.string()}),ug=u.object({action:u.enum(["VERIFY_DEVICE","VERIFY_OTP","CONNECT"])}),hg=u.object({url:u.string()}),pg=u.object({userName:u.string()}),fg=u.object({email:u.string().optional().nullable(),address:u.string(),chainId:u.string().or(u.number()),accounts:u.array(u.object({address:u.string(),type:u.enum([je.ACCOUNT_TYPES.EOA,je.ACCOUNT_TYPES.SMART_ACCOUNT])})).optional(),userName:u.string().optional().nullable(),preferredAccountType:u.optional(u.string()),signature:u.string().optional(),message:u.string().optional(),siwxMessage:u.optional($c)}),mg=u.object({action:u.enum(["VERIFY_PRIMARY_OTP","VERIFY_SECONDARY_OTP"])}),gg=u.object({email:u.string().email().optional().nullable(),address:u.string(),chainId:u.string().or(u.number()),smartAccountDeployed:u.optional(u.boolean()),accounts:u.array(u.object({address:u.string(),type:u.enum([je.ACCOUNT_TYPES.EOA,je.ACCOUNT_TYPES.SMART_ACCOUNT])})).optional(),preferredAccountType:u.optional(u.string()),signature:u.string().optional(),message:u.string().optional(),siwxMessage:u.optional($c)}),wg=u.object({uri:u.string()}),bg=u.object({isConnected:u.boolean()}),yg=u.object({chainId:u.string().or(u.number())}),Cg=u.object({chainId:u.string().or(u.number())}),vg=u.object({newEmail:u.string().email()}),Eg=u.object({smartAccountEnabledNetworks:u.array(u.number())});u.object({address:u.string(),isDeployed:u.boolean()});const _g=u.object({version:u.string().optional()}),Ag=u.object({type:u.string(),address:u.string()}),xg=u.any(),Sg=u.object({method:u.literal("eth_accounts")}),Tg=u.object({method:u.literal("eth_blockNumber")}),$g=u.object({method:u.literal("eth_call"),params:u.array(u.any())}),Ng=u.object({method:u.literal("eth_chainId")}),Rg=u.object({method:u.literal("eth_estimateGas"),params:u.array(u.any())}),kg=u.object({method:u.literal("eth_feeHistory"),params:u.array(u.any())}),Ig=u.object({method:u.literal("eth_gasPrice")}),Og=u.object({method:u.literal("eth_getAccount"),params:u.array(u.any())}),Pg=u.object({method:u.literal("eth_getBalance"),params:u.array(u.any())}),Lg=u.object({method:u.literal("eth_getBlockByHash"),params:u.array(u.any())}),Dg=u.object({method:u.literal("eth_getBlockByNumber"),params:u.array(u.any())}),Mg=u.object({method:u.literal("eth_getBlockReceipts"),params:u.array(u.any())}),Ug=u.object({method:u.literal("eth_getBlockTransactionCountByHash"),params:u.array(u.any())}),Bg=u.object({method:u.literal("eth_getBlockTransactionCountByNumber"),params:u.array(u.any())}),Wg=u.object({method:u.literal("eth_getCode"),params:u.array(u.any())}),jg=u.object({method:u.literal("eth_getFilterChanges"),params:u.array(u.any())}),Fg=u.object({method:u.literal("eth_getFilterLogs"),params:u.array(u.any())}),zg=u.object({method:u.literal("eth_getLogs"),params:u.array(u.any())}),Hg=u.object({method:u.literal("eth_getProof"),params:u.array(u.any())}),Vg=u.object({method:u.literal("eth_getStorageAt"),params:u.array(u.any())}),qg=u.object({method:u.literal("eth_getTransactionByBlockHashAndIndex"),params:u.array(u.any())}),Kg=u.object({method:u.literal("eth_getTransactionByBlockNumberAndIndex"),params:u.array(u.any())}),Gg=u.object({method:u.literal("eth_getTransactionByHash"),params:u.array(u.any())}),Zg=u.object({method:u.literal("eth_getTransactionCount"),params:u.array(u.any())}),Yg=u.object({method:u.literal("eth_getTransactionReceipt"),params:u.array(u.any())}),Jg=u.object({method:u.literal("eth_getUncleCountByBlockHash"),params:u.array(u.any())}),Xg=u.object({method:u.literal("eth_getUncleCountByBlockNumber"),params:u.array(u.any())}),Qg=u.object({method:u.literal("eth_maxPriorityFeePerGas")}),e1=u.object({method:u.literal("eth_newBlockFilter")}),t1=u.object({method:u.literal("eth_newFilter"),params:u.array(u.any())}),n1=u.object({method:u.literal("eth_newPendingTransactionFilter")}),r1=u.object({method:u.literal("eth_sendRawTransaction"),params:u.array(u.any())}),i1=u.object({method:u.literal("eth_syncing"),params:u.array(u.any())}),o1=u.object({method:u.literal("eth_uninstallFilter"),params:u.array(u.any())}),vu=u.object({method:u.literal("personal_sign"),params:u.array(u.any())}),s1=u.object({method:u.literal("eth_signTypedData_v4"),params:u.array(u.any())}),a1=u.object({method:u.literal("eth_sendTransaction"),params:u.array(u.any())}),c1=u.object({method:u.literal("solana_signMessage"),params:u.object({message:u.string(),pubkey:u.string()})}),l1=u.object({method:u.literal("solana_signTransaction"),params:u.object({transaction:u.string()})}),d1=u.object({method:u.literal("solana_signAllTransactions"),params:u.object({transactions:u.array(u.string())})}),u1=u.object({method:u.literal("solana_signAndSendTransaction"),params:u.object({transaction:u.string(),options:u.object({skipPreflight:u.boolean().optional(),preflightCommitment:u.enum(["processed","confirmed","finalized","recent","single","singleGossip","root","max"]).optional(),maxRetries:u.number().optional(),minContextSlot:u.number().optional()}).optional()})}),h1=u.object({method:u.literal("wallet_sendCalls"),params:u.array(u.object({chainId:u.string().or(u.number()).optional(),from:u.string().optional(),version:u.string().optional(),capabilities:u.any().optional(),calls:u.array(u.object({to:u.string().startsWith("0x"),data:u.string().startsWith("0x").optional(),value:u.string().optional()}))}))}),p1=u.object({method:u.literal("wallet_getCallsStatus"),params:u.array(u.string())}),f1=u.object({method:u.literal("wallet_getCapabilities"),params:u.array(u.string().or(u.number()).optional()).optional()}),m1=u.object({method:u.literal("wallet_grantPermissions"),params:u.array(u.any())}),g1=u.object({method:u.literal("wallet_revokePermissions"),params:u.any()}),w1=u.object({method:u.literal("wallet_getAssets"),params:u.any()}),Eu=u.object({token:u.string()}),ne=u.object({id:u.string().optional()}),Gc={appEvent:ne.extend({type:te("APP_SWITCH_NETWORK"),payload:Q0}).or(ne.extend({type:te("APP_CONNECT_EMAIL"),payload:eg})).or(ne.extend({type:te("APP_CONNECT_DEVICE")})).or(ne.extend({type:te("APP_CONNECT_OTP"),payload:tg})).or(ne.extend({type:te("APP_CONNECT_SOCIAL"),payload:ng})).or(ne.extend({type:te("APP_GET_FARCASTER_URI")})).or(ne.extend({type:te("APP_CONNECT_FARCASTER")})).or(ne.extend({type:te("APP_GET_USER"),payload:u.optional(rg)})).or(ne.extend({type:te("APP_GET_SOCIAL_REDIRECT_URI"),payload:ig})).or(ne.extend({type:te("APP_SIGN_OUT")})).or(ne.extend({type:te("APP_IS_CONNECTED"),payload:u.optional(Eu)})).or(ne.extend({type:te("APP_GET_CHAIN_ID")})).or(ne.extend({type:te("APP_GET_SMART_ACCOUNT_ENABLED_NETWORKS")})).or(ne.extend({type:te("APP_INIT_SMART_ACCOUNT")})).or(ne.extend({type:te("APP_SET_PREFERRED_ACCOUNT"),payload:dg})).or(ne.extend({type:te("APP_RPC_REQUEST"),payload:vu.or(w1).or(Sg).or(Tg).or($g).or(Ng).or(Rg).or(kg).or(Ig).or(Og).or(Pg).or(Lg).or(Dg).or(Mg).or(Ug).or(Bg).or(Wg).or(jg).or(Fg).or(zg).or(Hg).or(Vg).or(qg).or(Kg).or(Gg).or(Zg).or(Yg).or(Jg).or(Xg).or(Qg).or(e1).or(t1).or(n1).or(r1).or(i1).or(o1).or(vu).or(s1).or(a1).or(c1).or(l1).or(d1).or(u1).or(p1).or(h1).or(f1).or(m1).or(g1).and(u.object({chainId:u.string().or(u.number()).optional(),chainNamespace:u.enum(["eip155","solana","polkadot","bip122","cosmos"]).optional(),rpcUrl:u.string().optional()}))})).or(ne.extend({type:te("APP_UPDATE_EMAIL"),payload:og})).or(ne.extend({type:te("APP_UPDATE_EMAIL_PRIMARY_OTP"),payload:sg})).or(ne.extend({type:te("APP_UPDATE_EMAIL_SECONDARY_OTP"),payload:ag})).or(ne.extend({type:te("APP_SYNC_THEME"),payload:cg})).or(ne.extend({type:te("APP_SYNC_DAPP_DATA"),payload:lg})).or(ne.extend({type:te("APP_RELOAD")})).or(ne.extend({type:te("APP_RPC_ABORT")})),frameEvent:ne.extend({type:te("FRAME_SWITCH_NETWORK_ERROR"),payload:Ze}).or(ne.extend({type:te("FRAME_SWITCH_NETWORK_SUCCESS"),payload:Cg})).or(ne.extend({type:te("FRAME_CONNECT_EMAIL_SUCCESS"),payload:ug})).or(ne.extend({type:te("FRAME_CONNECT_EMAIL_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_GET_FARCASTER_URI_SUCCESS"),payload:hg})).or(ne.extend({type:te("FRAME_GET_FARCASTER_URI_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_CONNECT_FARCASTER_SUCCESS"),payload:pg})).or(ne.extend({type:te("FRAME_CONNECT_FARCASTER_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_CONNECT_OTP_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_CONNECT_OTP_SUCCESS")})).or(ne.extend({type:te("FRAME_CONNECT_DEVICE_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_CONNECT_DEVICE_SUCCESS")})).or(ne.extend({type:te("FRAME_CONNECT_SOCIAL_SUCCESS"),payload:fg})).or(ne.extend({type:te("FRAME_CONNECT_SOCIAL_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_GET_USER_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_GET_USER_SUCCESS"),payload:gg})).or(ne.extend({type:te("FRAME_GET_SOCIAL_REDIRECT_URI_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_GET_SOCIAL_REDIRECT_URI_SUCCESS"),payload:wg})).or(ne.extend({type:te("FRAME_SIGN_OUT_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_SIGN_OUT_SUCCESS")})).or(ne.extend({type:te("FRAME_IS_CONNECTED_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_IS_CONNECTED_SUCCESS"),payload:bg})).or(ne.extend({type:te("FRAME_GET_CHAIN_ID_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_GET_CHAIN_ID_SUCCESS"),payload:yg})).or(ne.extend({type:te("FRAME_RPC_REQUEST_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_RPC_REQUEST_SUCCESS"),payload:xg})).or(ne.extend({type:te("FRAME_SESSION_UPDATE"),payload:Eu})).or(ne.extend({type:te("FRAME_UPDATE_EMAIL_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_UPDATE_EMAIL_SUCCESS"),payload:mg})).or(ne.extend({type:te("FRAME_UPDATE_EMAIL_PRIMARY_OTP_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_UPDATE_EMAIL_PRIMARY_OTP_SUCCESS")})).or(ne.extend({type:te("FRAME_UPDATE_EMAIL_SECONDARY_OTP_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_UPDATE_EMAIL_SECONDARY_OTP_SUCCESS"),payload:vg})).or(ne.extend({type:te("FRAME_SYNC_THEME_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_SYNC_THEME_SUCCESS")})).or(ne.extend({type:te("FRAME_SYNC_DAPP_DATA_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_SYNC_DAPP_DATA_SUCCESS")})).or(ne.extend({type:te("FRAME_GET_SMART_ACCOUNT_ENABLED_NETWORKS_SUCCESS"),payload:Eg})).or(ne.extend({type:te("FRAME_GET_SMART_ACCOUNT_ENABLED_NETWORKS_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_INIT_SMART_ACCOUNT_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_SET_PREFERRED_ACCOUNT_SUCCESS"),payload:Ag})).or(ne.extend({type:te("FRAME_SET_PREFERRED_ACCOUNT_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_READY"),payload:_g})).or(ne.extend({type:te("FRAME_RELOAD_ERROR"),payload:Ze})).or(ne.extend({type:te("FRAME_RELOAD_SUCCESS")}))};function Zc(e,t={}){return typeof t?.type=="string"&&t?.type?.includes(e)}function b1({projectId:e,chainId:t,enableLogger:n,rpcUrl:r=N.BLOCKCHAIN_API_RPC_URL,enableCloudAuthAccount:o=!1}){const i=new URL(Xm);i.searchParams.set("projectId",e),i.searchParams.set("chainId",String(t)),i.searchParams.set("version",e0),i.searchParams.set("enableLogger",String(n)),i.searchParams.set("rpcUrl",r);const s=tt.get("dapp_smart_account_version");return s&&(s==="v6"||s==="v7")&&(console.warn(">> AppKit - Forcing smart account version",s),i.searchParams.set("smartAccountVersion",s)),o&&i.searchParams.set("enableCloudAuthAccount","true"),i.toString()}class y1{constructor({projectId:t,isAppClient:n=!1,chainId:r="eip155:1",enableLogger:o=!0,enableCloudAuthAccount:i=!1,rpcUrl:s=N.BLOCKCHAIN_API_RPC_URL}){if(this.iframe=null,this.iframeIsReady=!1,this.initFrame=()=>{const a=document.getElementById("w3m-iframe");this.iframe&&!a&&document.body.appendChild(this.iframe)},this.events={registerFrameEventHandler:(a,c,l)=>{function d({data:h}){if(!Zc(oe.FRAME_EVENT_KEY,h))return;const f=Gc.frameEvent.safeParse(h);if(!f.success){console.warn("W3mFrame: invalid frame event",f.error.message);return}f.data?.id===a&&(c(f.data),window.removeEventListener("message",d))}Sn.isClient&&(window.addEventListener("message",d),l.addEventListener("abort",()=>{window.removeEventListener("message",d)}))},onFrameEvent:a=>{Sn.isClient&&window.addEventListener("message",({data:c})=>{if(!Zc(oe.FRAME_EVENT_KEY,c))return;const l=Gc.frameEvent.safeParse(c);l.success?a(l.data):console.warn("W3mFrame: invalid frame event",l.error.message)})},onAppEvent:a=>{Sn.isClient&&window.addEventListener("message",({data:c})=>{if(!Zc(oe.APP_EVENT_KEY,c))return;const l=Gc.appEvent.safeParse(c);l.success||console.warn("W3mFrame: invalid app event",l.error.message),a(c)})},postAppEvent:a=>{if(Sn.isClient){if(!this.iframe?.contentWindow)throw new Error("W3mFrame: iframe is not set");this.iframe.contentWindow.postMessage(a,"*")}},postFrameEvent:a=>{if(Sn.isClient){if(!parent)throw new Error("W3mFrame: parent is not set");parent.postMessage(a,"*")}}},this.projectId=t,this.frameLoadPromise=new Promise((a,c)=>{this.frameLoadPromiseResolver={resolve:a,reject:c}}),this.rpcUrl=s,n&&(this.frameLoadPromise=new Promise((a,c)=>{this.frameLoadPromiseResolver={resolve:a,reject:c}}),Sn.isClient)){const a=document.createElement("iframe");a.id="w3m-iframe",a.src=b1({projectId:t,chainId:r,enableLogger:o,rpcUrl:this.rpcUrl,enableCloudAuthAccount:i}),a.name="w3m-secure-iframe",a.style.position="fixed",a.style.zIndex="999999",a.style.display="none",a.style.border="none",a.style.animationDelay="0s, 50ms",a.style.borderBottomLeftRadius="clamp(0px, var(--apkt-borderRadius-8), 44px)",a.style.borderBottomRightRadius="clamp(0px, var(--apkt-borderRadius-8), 44px)",this.iframe=a,this.iframe.onerror=()=>{this.frameLoadPromiseResolver?.reject("Unable to load email login dependency")},this.events.onFrameEvent(c=>{c.type==="@w3m-frame/READY"&&(this.iframeIsReady=!0,this.frameLoadPromiseResolver?.resolve(void 0))})}}get networks(){const t=["eip155:1","eip155:5","eip155:11155111","eip155:10","eip155:420","eip155:42161","eip155:421613","eip155:137","eip155:80001","eip155:42220","eip155:1313161554","eip155:1313161555","eip155:56","eip155:97","eip155:43114","eip155:43113","eip155:324","eip155:280","eip155:100","eip155:8453","eip155:84531","eip155:84532","eip155:7777777","eip155:999","solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp","solana:4uhcVJyU9pJkvQyS88uRDiswHXSCkY3z","solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1"].map(n=>({[n]:{rpcUrl:`${this.rpcUrl}/v1/?chainId=${n}&projectId=${this.projectId}`,chainId:n}}));return Object.assign({},...t)}}var Tn={exports:{}};function C1(e){try{return JSON.stringify(e)}catch{return'"[Circular]"'}}var v1=E1;function E1(e,t,n){var r=n&&n.stringify||C1,o=1;if(typeof e=="object"&&e!==null){var i=t.length+o;if(i===1)return e;var s=new Array(i);s[0]=r(e);for(var a=1;a<i;a++)s[a]=r(t[a]);return s.join(" ")}if(typeof e!="string")return e;var c=t.length;if(c===0)return e;for(var l="",d=1-o,h=-1,f=e&&e.length||0,w=0;w<f;){if(e.charCodeAt(w)===37&&w+1<f){switch(h=h>-1?h:0,e.charCodeAt(w+1)){case 100:case 102:if(d>=c||t[d]==null)break;h<w&&(l+=e.slice(h,w)),l+=Number(t[d]),h=w+2,w++;break;case 105:if(d>=c||t[d]==null)break;h<w&&(l+=e.slice(h,w)),l+=Math.floor(Number(t[d])),h=w+2,w++;break;case 79:case 111:case 106:if(d>=c||t[d]===void 0)break;h<w&&(l+=e.slice(h,w));var v=typeof t[d];if(v==="string"){l+="'"+t[d]+"'",h=w+2,w++;break}if(v==="function"){l+=t[d].name||"<anonymous>",h=w+2,w++;break}l+=r(t[d]),h=w+2,w++;break;case 115:if(d>=c)break;h<w&&(l+=e.slice(h,w)),l+=String(t[d]),h=w+2,w++;break;case 37:h<w&&(l+=e.slice(h,w)),l+="%",h=w+2,w++,d--;break}++d}++w}return h===-1?e:(h<f&&(l+=e.slice(h)),l)}const _u=v1;Tn.exports=Yn;const Qo=M1().console||{},_1={mapHttpRequest:ca,mapHttpResponse:ca,wrapRequestSerializer:Yc,wrapResponseSerializer:Yc,wrapErrorSerializer:Yc,req:ca,res:ca,err:xu,errWithCause:xu};function pr(e,t){return e==="silent"?1/0:t.levels.values[e]}const xd=Symbol("pino.logFuncs"),Vl=Symbol("pino.hierarchy"),A1={error:"log",fatal:"error",warn:"error",info:"log",debug:"log",trace:"log"};function Au(e,t){const n={logger:t,parent:e[Vl]};t[Vl]=n}function x1(e,t,n){const r={};t.forEach(o=>{r[o]=n[o]?n[o]:Qo[o]||Qo[A1[o]||"log"]||Ki}),e[xd]=r}function S1(e,t){return Array.isArray(e)?e.filter(function(n){return n!=="!stdSerializers.err"}):e===!0?Object.keys(t):!1}function Yn(e){e=e||{},e.browser=e.browser||{};const t=e.browser.transmit;if(t&&typeof t.send!="function")throw Error("pino: transmit option must have a send function");const n=e.browser.write||Qo;e.browser.write&&(e.browser.asObject=!0);const r=e.serializers||{},o=S1(e.browser.serialize,r);let i=e.browser.serialize;Array.isArray(e.browser.serialize)&&e.browser.serialize.indexOf("!stdSerializers.err")>-1&&(i=!1);const s=Object.keys(e.customLevels||{}),a=["error","fatal","warn","info","debug","trace"].concat(s);typeof n=="function"&&a.forEach(function(y){n[y]=n}),(e.enabled===!1||e.browser.disabled)&&(e.level="silent");const c=e.level||"info",l=Object.create(n);l.log||(l.log=Ki),x1(l,a,n),Au({},l),Object.defineProperty(l,"levelVal",{get:h}),Object.defineProperty(l,"level",{get:f,set:w});const d={transmit:t,serialize:o,asObject:e.browser.asObject,asObjectBindingsOnly:e.browser.asObjectBindingsOnly,formatters:e.browser.formatters,levels:a,timestamp:P1(e),messageKey:e.messageKey||"msg",onChild:e.onChild||Ki};l.levels=T1(e),l.level=c,l.isLevelEnabled=function(y){return this.levels.values[y]?this.levels.values[y]>=this.levels.values[this.level]:!1},l.setMaxListeners=l.getMaxListeners=l.emit=l.addListener=l.on=l.prependListener=l.once=l.prependOnceListener=l.removeListener=l.removeAllListeners=l.listeners=l.listenerCount=l.eventNames=l.write=l.flush=Ki,l.serializers=r,l._serialize=o,l._stdErrSerialize=i,l.child=function(...y){return v.call(this,d,...y)},t&&(l._logEvent=ql());function h(){return pr(this.level,this)}function f(){return this._level}function w(y){if(y!=="silent"&&!this.levels.values[y])throw Error("unknown level "+y);this._level=y,Ir(this,d,l,"error"),Ir(this,d,l,"fatal"),Ir(this,d,l,"warn"),Ir(this,d,l,"info"),Ir(this,d,l,"debug"),Ir(this,d,l,"trace"),s.forEach($=>{Ir(this,d,l,$)})}function v(y,$,I){if(!$)throw new Error("missing bindings for child Pino");I=I||{},o&&$.serializers&&(I.serializers=$.serializers);const k=I.serializers;if(o&&k){var D=Object.assign({},r,k),C=e.browser.serialize===!0?Object.keys(D):o;delete $.serializers,Sd([$],C,D,this._stdErrSerialize)}function A(P){this._childLevel=(P._childLevel|0)+1,this.bindings=$,D&&(this.serializers=D,this._serialize=C),t&&(this._logEvent=ql([].concat(P._logEvent.bindings,$)))}A.prototype=this;const _=new A(this);return Au(this,_),_.child=function(...P){return v.call(this,y,...P)},_.level=I.level||this.level,y.onChild(_),_}return l}function T1(e){const t=e.customLevels||{},n=Object.assign({},Yn.levels.values,t),r=Object.assign({},Yn.levels.labels,$1(t));return{values:n,labels:r}}function $1(e){const t={};return Object.keys(e).forEach(function(n){t[e[n]]=n}),t}Yn.levels={values:{fatal:60,error:50,warn:40,info:30,debug:20,trace:10},labels:{10:"trace",20:"debug",30:"info",40:"warn",50:"error",60:"fatal"}},Yn.stdSerializers=_1,Yn.stdTimeFunctions=Object.assign({},{nullTime:Op,epochTime:Pp,unixTime:L1,isoTime:D1});function N1(e){const t=[];e.bindings&&t.push(e.bindings);let n=e[Vl];for(;n.parent;)n=n.parent,n.logger.bindings&&t.push(n.logger.bindings);return t.reverse()}function Ir(e,t,n,r){if(Object.defineProperty(e,r,{value:pr(e.level,n)>pr(r,n)?Ki:n[xd][r],writable:!0,enumerable:!0,configurable:!0}),e[r]===Ki){if(!t.transmit)return;const i=t.transmit.level||e.level,s=pr(i,n);if(pr(r,n)<s)return}e[r]=k1(e,t,n,r);const o=N1(e);o.length!==0&&(e[r]=R1(o,e[r]))}function R1(e,t){return function(){return t.apply(this,[...e,...arguments])}}function k1(e,t,n,r){return(function(o){return function(){const i=t.timestamp(),s=new Array(arguments.length),a=Object.getPrototypeOf&&Object.getPrototypeOf(this)===Qo?Qo:this;for(var c=0;c<s.length;c++)s[c]=arguments[c];var l=!1;if(t.serialize&&(Sd(s,this._serialize,this.serializers,this._stdErrSerialize),l=!0),t.asObject||t.formatters?o.call(a,...I1(this,r,s,i,t)):o.apply(a,s),t.transmit){const d=t.transmit.level||e._level,h=pr(d,n),f=pr(r,n);if(f<h)return;O1(this,{ts:i,methodLevel:r,methodValue:f,transmitValue:n.levels.values[t.transmit.level||e._level],send:t.transmit.send,val:pr(e._level,n)},s,l)}}})(e[xd][r])}function I1(e,t,n,r,o){const{level:i,log:s=h=>h}=o.formatters||{},a=n.slice();let c=a[0];const l={};let d=(e._childLevel|0)+1;if(d<1&&(d=1),r&&(l.time=r),i){const h=i(t,e.levels.values[t]);Object.assign(l,h)}else l.level=e.levels.values[t];if(o.asObjectBindingsOnly){if(c!==null&&typeof c=="object")for(;d--&&typeof a[0]=="object";)Object.assign(l,a.shift());return[s(l),...a]}else{if(c!==null&&typeof c=="object"){for(;d--&&typeof a[0]=="object";)Object.assign(l,a.shift());c=a.length?_u(a.shift(),a):void 0}else typeof c=="string"&&(c=_u(a.shift(),a));return c!==void 0&&(l[o.messageKey]=c),[s(l)]}}function Sd(e,t,n,r){for(const o in e)if(r&&e[o]instanceof Error)e[o]=Yn.stdSerializers.err(e[o]);else if(typeof e[o]=="object"&&!Array.isArray(e[o])&&t)for(const i in e[o])t.indexOf(i)>-1&&i in n&&(e[o][i]=n[i](e[o][i]))}function O1(e,t,n,r=!1){const o=t.send,i=t.ts,s=t.methodLevel,a=t.methodValue,c=t.val,l=e._logEvent.bindings;r||Sd(n,e._serialize||Object.keys(e.serializers),e.serializers,e._stdErrSerialize===void 0?!0:e._stdErrSerialize),e._logEvent.ts=i,e._logEvent.messages=n.filter(function(d){return l.indexOf(d)===-1}),e._logEvent.level.label=s,e._logEvent.level.value=a,o(s,e._logEvent,c),e._logEvent=ql(l)}function ql(e){return{ts:0,messages:[],bindings:e||[],level:{label:"",value:0}}}function xu(e){const t={type:e.constructor.name,msg:e.message,stack:e.stack};for(const n in e)t[n]===void 0&&(t[n]=e[n]);return t}function P1(e){return typeof e.timestamp=="function"?e.timestamp:e.timestamp===!1?Op:Pp}function ca(){return{}}function Yc(e){return e}function Ki(){}function Op(){return!1}function Pp(){return Date.now()}function L1(){return Math.round(Date.now()/1e3)}function D1(){return new Date(Date.now()).toISOString()}function M1(){function e(t){return typeof t<"u"&&t}try{return typeof globalThis<"u"||Object.defineProperty(Object.prototype,"globalThis",{get:function(){return delete Object.prototype.globalThis,this.globalThis=this},configurable:!0}),globalThis}catch{return e(self)||e(window)||e(this)||{}}}Tn.exports.default=Yn;Tn.exports.pino=Yn;const U1={level:"info"},Nc="custom_context",Td=1e3*1024;var B1=Object.defineProperty,W1=(e,t,n)=>t in e?B1(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,dr=(e,t,n)=>W1(e,typeof t!="symbol"?t+"":t,n);class j1{constructor(t){dr(this,"nodeValue"),dr(this,"sizeInBytes"),dr(this,"next"),this.nodeValue=t,this.sizeInBytes=new TextEncoder().encode(this.nodeValue).length,this.next=null}get value(){return this.nodeValue}get size(){return this.sizeInBytes}}class Su{constructor(t){dr(this,"lengthInNodes"),dr(this,"sizeInBytes"),dr(this,"head"),dr(this,"tail"),dr(this,"maxSizeInBytes"),this.head=null,this.tail=null,this.lengthInNodes=0,this.maxSizeInBytes=t,this.sizeInBytes=0}append(t){const n=new j1(t);if(n.size>this.maxSizeInBytes)throw new Error(`[LinkedList] Value too big to insert into list: ${t} with size ${n.size}`);for(;this.size+n.size>this.maxSizeInBytes;)this.shift();this.head?(this.tail&&(this.tail.next=n),this.tail=n):(this.head=n,this.tail=n),this.lengthInNodes++,this.sizeInBytes+=n.size}shift(){if(!this.head)return;const t=this.head;this.head=this.head.next,this.head||(this.tail=null),this.lengthInNodes--,this.sizeInBytes-=t.size}toArray(){const t=[];let n=this.head;for(;n!==null;)t.push(n.value),n=n.next;return t}get length(){return this.lengthInNodes}get size(){return this.sizeInBytes}toOrderedArray(){return Array.from(this)}[Symbol.iterator](){let t=this.head;return{next:()=>{if(!t)return{done:!0,value:null};const n=t.value;return t=t.next,{done:!1,value:n}}}}}const F1=e=>JSON.stringify(e,(t,n)=>typeof n=="bigint"?n.toString()+"n":n);function Tu(e){return typeof e=="string"?e:F1(e)||""}var z1=Object.defineProperty,H1=(e,t,n)=>t in e?z1(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,la=(e,t,n)=>H1(e,typeof t!="symbol"?t+"":t,n);class Lp{constructor(t,n=Td){la(this,"logs"),la(this,"level"),la(this,"levelValue"),la(this,"MAX_LOG_SIZE_IN_BYTES"),this.level=t??"error",this.levelValue=Tn.exports.levels.values[this.level],this.MAX_LOG_SIZE_IN_BYTES=n,this.logs=new Su(this.MAX_LOG_SIZE_IN_BYTES)}forwardToConsole(t,n){n===Tn.exports.levels.values.error?console.error(t):n===Tn.exports.levels.values.warn?console.warn(t):n===Tn.exports.levels.values.debug?console.debug(t):n===Tn.exports.levels.values.trace?console.trace(t):console.log(t)}appendToLogs(t){this.logs.append(Tu({timestamp:new Date().toISOString(),log:t}));const n=typeof t=="string"?JSON.parse(t).level:t.level;n>=this.levelValue&&this.forwardToConsole(t,n)}getLogs(){return this.logs}clearLogs(){this.logs=new Su(this.MAX_LOG_SIZE_IN_BYTES)}getLogArray(){return Array.from(this.logs)}logsToBlob(t){const n=this.getLogArray();return n.push(Tu({extraMetadata:t})),new Blob(n,{type:"application/json"})}}var V1=Object.defineProperty,q1=(e,t,n)=>t in e?V1(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,K1=(e,t,n)=>q1(e,t+"",n);let G1=class{constructor(t,n=Td){K1(this,"baseChunkLogger"),this.baseChunkLogger=new Lp(t,n)}write(t){this.baseChunkLogger.appendToLogs(t)}getLogs(){return this.baseChunkLogger.getLogs()}clearLogs(){this.baseChunkLogger.clearLogs()}getLogArray(){return this.baseChunkLogger.getLogArray()}logsToBlob(t){return this.baseChunkLogger.logsToBlob(t)}downloadLogsBlobInBrowser(t){const n=URL.createObjectURL(this.logsToBlob(t)),r=document.createElement("a");r.href=n,r.download=`walletconnect-logs-${new Date().toISOString()}.txt`,document.body.appendChild(r),r.click(),document.body.removeChild(r),URL.revokeObjectURL(n)}};var Z1=Object.defineProperty,Y1=(e,t,n)=>t in e?Z1(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,J1=(e,t,n)=>Y1(e,t+"",n);class X1{constructor(t,n=Td){J1(this,"baseChunkLogger"),this.baseChunkLogger=new Lp(t,n)}write(t){this.baseChunkLogger.appendToLogs(t)}getLogs(){return this.baseChunkLogger.getLogs()}clearLogs(){this.baseChunkLogger.clearLogs()}getLogArray(){return this.baseChunkLogger.getLogArray()}logsToBlob(t){return this.baseChunkLogger.logsToBlob(t)}}var Q1=Object.defineProperty,ew=Object.defineProperties,tw=Object.getOwnPropertyDescriptors,$u=Object.getOwnPropertySymbols,nw=Object.prototype.hasOwnProperty,rw=Object.prototype.propertyIsEnumerable,Nu=(e,t,n)=>t in e?Q1(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,qa=(e,t)=>{for(var n in t||(t={}))nw.call(t,n)&&Nu(e,n,t[n]);if($u)for(var n of $u(t))rw.call(t,n)&&Nu(e,n,t[n]);return e},Ka=(e,t)=>ew(e,tw(t));function iw(e){return Ka(qa({},e),{level:e?.level||U1.level})}function ow(e,t,n=Nc){return e[n]=t,e}function sw(e,t=Nc){return e[t]||""}function aw(e,t,n=Nc){const r=sw(e,n);return r.trim()?`${r}/${t}`:t}function cw(e,t,n=Nc){const r=aw(e,t,n),o=e.child({context:r});return ow(o,r,n)}function lw(e){var t,n;const r=new G1((t=e.opts)==null?void 0:t.level,e.maxSizeInBytes);return{logger:Tn.exports(Ka(qa({},e.opts),{level:"trace",browser:Ka(qa({},(n=e.opts)==null?void 0:n.browser),{write:o=>r.write(o)})})),chunkLoggerController:r}}function dw(e){var t;const n=new X1((t=e.opts)==null?void 0:t.level,e.maxSizeInBytes);return{logger:Tn.exports(Ka(qa({},e.opts),{level:"trace"}),n),chunkLoggerController:n}}function uw(e){return typeof e.loggerOverride<"u"&&typeof e.loggerOverride!="string"?{logger:e.loggerOverride,chunkLoggerController:null}:typeof window<"u"?lw(e):dw(e)}class hw{constructor(t){const n=iw({level:Qm}),{logger:r,chunkLoggerController:o}=uw({opts:n});this.logger=cw(r,this.constructor.name),this.chunkLoggerController=o,typeof window<"u"&&this.chunkLoggerController?.downloadLogsBlobInBrowser&&(window.downloadAppKitLogsBlob||(window.downloadAppKitLogsBlob={}),window.downloadAppKitLogsBlob.sdk=()=>{this.chunkLoggerController?.downloadLogsBlobInBrowser&&this.chunkLoggerController.downloadLogsBlobInBrowser({projectId:t})})}}class pw{constructor({projectId:t,chainId:n,enableLogger:r=!0,onTimeout:o,abortController:i,getActiveCaipNetwork:s,getCaipNetworks:a,enableCloudAuthAccount:c,metadata:l,sdkVersion:d,sdkType:h}){this.openRpcRequests=new Map,this.isInitialized=!1,r&&(this.w3mLogger=new hw(t)),this.abortController=i,this.getActiveCaipNetwork=s,this.getCaipNetworks=a;const f=this.getRpcUrl(n);this.projectId=t,this.sdkVersion=d,this.sdkType=h,this.metadata=l,this.w3mFrame=new y1({projectId:t,isAppClient:!0,chainId:n,enableLogger:r,rpcUrl:f,enableCloudAuthAccount:c}),this.onTimeout=o,this.getLoginEmailUsed()&&this.createFrame()}async createFrame(){this.w3mFrame.initFrame(),this.initPromise=new Promise(t=>{this.w3mFrame.events.onFrameEvent(n=>{n.type===oe.FRAME_READY&&setTimeout(()=>{t()},500)})}),await this.initPromise,await this.syncDappData({metadata:this.metadata,projectId:this.projectId,sdkVersion:this.sdkVersion,sdkType:this.sdkType}),await this.getSmartAccountEnabledNetworks(),this.isInitialized=!0,this.initPromise=void 0}async init(){if(!this.isInitialized){if(this.initPromise){await this.initPromise;return}await this.createFrame()}}getLoginEmailUsed(){return!!tt.get(oe.EMAIL_LOGIN_USED_KEY)}getEmail(){return tt.get(oe.EMAIL)}getUsername(){return tt.get(oe.SOCIAL_USERNAME)}async reload(){try{await this.appEvent({type:oe.APP_RELOAD})}catch(t){throw this.w3mLogger?.logger.error({error:t},"Error reloading iframe"),t}}async connectEmail(t){try{Sn.checkIfAllowedToTriggerEmail(),await this.init();const n=await this.appEvent({type:oe.APP_CONNECT_EMAIL,payload:t});return this.setNewLastEmailLoginTime(),n}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error connecting email"),n}}async connectDevice(){try{return this.appEvent({type:oe.APP_CONNECT_DEVICE})}catch(t){throw this.w3mLogger?.logger.error({error:t},"Error connecting device"),t}}async connectOtp(t){try{return this.appEvent({type:oe.APP_CONNECT_OTP,payload:t})}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error connecting otp"),n}}async isConnected(){try{if(!this.getLoginEmailUsed())return{isConnected:!1};const t=await this.appEvent({type:oe.APP_IS_CONNECTED});return t?.isConnected||this.deleteAuthLoginCache(),t}catch(t){throw this.deleteAuthLoginCache(),this.w3mLogger?.logger.error({error:t},"Error checking connection"),t}}async getChainId(){try{const t=await this.appEvent({type:oe.APP_GET_CHAIN_ID});return this.setLastUsedChainId(t.chainId),t}catch(t){throw this.w3mLogger?.logger.error({error:t},"Error getting chain id"),t}}async getSocialRedirectUri(t){try{return await this.init(),this.appEvent({type:oe.APP_GET_SOCIAL_REDIRECT_URI,payload:t})}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error getting social redirect uri"),n}}async updateEmail(t){try{const n=await this.appEvent({type:oe.APP_UPDATE_EMAIL,payload:t});return this.setNewLastEmailLoginTime(),n}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error updating email"),n}}async updateEmailPrimaryOtp(t){try{return this.appEvent({type:oe.APP_UPDATE_EMAIL_PRIMARY_OTP,payload:t})}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error updating email primary otp"),n}}async updateEmailSecondaryOtp(t){try{const n=await this.appEvent({type:oe.APP_UPDATE_EMAIL_SECONDARY_OTP,payload:t});return this.setLoginSuccess(n.newEmail),n}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error updating email secondary otp"),n}}async syncTheme(t){try{return this.appEvent({type:oe.APP_SYNC_THEME,payload:t})}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error syncing theme"),n}}async syncDappData(t){try{return this.appEvent({type:oe.APP_SYNC_DAPP_DATA,payload:t})}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error syncing dapp data"),n}}async getSmartAccountEnabledNetworks(){try{const t=await this.appEvent({type:oe.APP_GET_SMART_ACCOUNT_ENABLED_NETWORKS});return this.persistSmartAccountEnabledNetworks(t.smartAccountEnabledNetworks),t}catch(t){throw this.persistSmartAccountEnabledNetworks([]),this.w3mLogger?.logger.error({error:t},"Error getting smart account enabled networks"),t}}async setPreferredAccount(t){try{return this.appEvent({type:oe.APP_SET_PREFERRED_ACCOUNT,payload:{type:t}})}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error setting preferred account"),n}}async connect(t){if(t?.socialUri)try{await this.init();const n=this.getRpcUrl(t.chainId),r=await this.appEvent({type:oe.APP_CONNECT_SOCIAL,payload:{uri:t.socialUri,preferredAccountType:t.preferredAccountType,chainId:t.chainId,siwxMessage:t.siwxMessage,rpcUrl:n}});return r.userName&&this.setSocialLoginSuccess(r.userName),this.setLoginSuccess(r.email),this.setLastUsedChainId(r.chainId),this.user=r,r}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error connecting social"),n}else try{const n=t?.chainId||this.getLastUsedChainId()||1,r=await this.getUser({chainId:n,preferredAccountType:t?.preferredAccountType,siwxMessage:t?.siwxMessage,rpcUrl:this.getRpcUrl(n)});return this.setLoginSuccess(r.email),this.setLastUsedChainId(r.chainId),this.user=r,r}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error connecting"),n}}async getUser(t){try{await this.init();const n=t?.chainId||this.getLastUsedChainId()||1,r=await this.appEvent({type:oe.APP_GET_USER,payload:{...t,chainId:n,rpcUrl:this.getRpcUrl(n)}});return this.user=r,r}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error connecting"),n}}async connectSocial({uri:t,chainId:n,preferredAccountType:r}){try{await this.init();const o=this.getRpcUrl(n),i=await this.appEvent({type:oe.APP_CONNECT_SOCIAL,payload:{uri:t,chainId:n,rpcUrl:o,preferredAccountType:r}});return i.userName&&this.setSocialLoginSuccess(i.userName),i}catch(o){throw this.w3mLogger?.logger.error({error:o},"Error connecting social"),o}}async getFarcasterUri(){try{return await this.init(),await this.appEvent({type:oe.APP_GET_FARCASTER_URI})}catch(t){throw this.w3mLogger?.logger.error({error:t},"Error getting farcaster uri"),t}}async connectFarcaster(){try{const t=await this.appEvent({type:oe.APP_CONNECT_FARCASTER});return t.userName&&this.setSocialLoginSuccess(t.userName),t}catch(t){throw this.w3mLogger?.logger.error({error:t},"Error connecting farcaster"),t}}async switchNetwork({chainId:t}){try{const n=this.getRpcUrl(t),r=await this.appEvent({type:oe.APP_SWITCH_NETWORK,payload:{chainId:t,rpcUrl:n}});return this.setLastUsedChainId(r.chainId),r}catch(n){throw this.w3mLogger?.logger.error({error:n},"Error switching network"),n}}async disconnect(){try{return this.deleteAuthLoginCache(),await new Promise(async n=>{const r=setTimeout(()=>{n()},3e3);await this.appEvent({type:oe.APP_SIGN_OUT}),clearTimeout(r),n()})}catch(t){throw this.w3mLogger?.logger.error({error:t},"Error disconnecting"),t}}async request(t){const n=t;try{if(je.GET_CHAIN_ID===t.method)return this.getLastUsedChainId();const r=t.chainNamespace||"eip155",o=this.getActiveCaipNetwork(r)?.id;n.chainNamespace=r,n.chainId=o,n.rpcUrl=this.getRpcUrl(o),this.rpcRequestHandler?.(t);const i=await this.appEvent({type:oe.APP_RPC_REQUEST,payload:n});return this.rpcSuccessHandler?.(i,n),i}catch(r){throw this.rpcErrorHandler?.(r,n),this.w3mLogger?.logger.error({error:r},"Error requesting"),r}}onRpcRequest(t){this.rpcRequestHandler=t}onRpcSuccess(t){this.rpcSuccessHandler=t}onRpcError(t){this.rpcErrorHandler=t}onIsConnected(t){this.w3mFrame.events.onFrameEvent(n=>{n.type===oe.FRAME_IS_CONNECTED_SUCCESS&&n.payload.isConnected&&t()})}onNotConnected(t){this.w3mFrame.events.onFrameEvent(n=>{n.type===oe.FRAME_IS_CONNECTED_ERROR&&t(),n.type===oe.FRAME_IS_CONNECTED_SUCCESS&&!n.payload.isConnected&&t()})}onConnect(t){this.w3mFrame.events.onFrameEvent(n=>{n.type===oe.FRAME_GET_USER_SUCCESS&&t(n.payload)})}onSocialConnected(t){this.w3mFrame.events.onFrameEvent(n=>{n.type===oe.FRAME_CONNECT_SOCIAL_SUCCESS&&t(n.payload)})}async getCapabilities(){try{return await this.request({method:"wallet_getCapabilities"})||{}}catch{return{}}}onSetPreferredAccount(t){this.w3mFrame.events.onFrameEvent(n=>{n.type===oe.FRAME_SET_PREFERRED_ACCOUNT_SUCCESS?t(n.payload):n.type===oe.FRAME_SET_PREFERRED_ACCOUNT_ERROR&&t({type:je.ACCOUNT_TYPES.EOA})})}getAvailableChainIds(){return Object.keys(this.w3mFrame.networks)}async rejectRpcRequests(){try{await Promise.all(Array.from(this.openRpcRequests.values()).map(async({abortController:t,method:n})=>{je.SAFE_RPC_METHODS.includes(n)||t.abort(),await this.appEvent({type:oe.APP_RPC_ABORT})})),this.openRpcRequests.clear()}catch(t){this.w3mLogger?.logger.error({error:t},"Error aborting RPC request")}}async appEvent(t){let n,r;function o(c){return c.replace("@w3m-app/","")}const i=[oe.APP_SYNC_DAPP_DATA,oe.APP_SYNC_THEME,oe.APP_SET_PREFERRED_ACCOUNT],s=o(t.type);return!this.w3mFrame.iframeIsReady&&!i.includes(t.type)&&(r=setTimeout(()=>{this.onTimeout?.("iframe_load_failed"),this.abortController.abort()},2e4)),await this.w3mFrame.frameLoadPromise,clearTimeout(r),[oe.APP_CONNECT_EMAIL,oe.APP_CONNECT_DEVICE,oe.APP_CONNECT_OTP,oe.APP_CONNECT_SOCIAL,oe.APP_GET_SOCIAL_REDIRECT_URI].map(o).includes(s)&&(n=setTimeout(()=>{this.onTimeout?.("iframe_request_timeout"),this.abortController.abort()},12e4)),new Promise((c,l)=>{const d=Math.random().toString(36).substring(7);this.w3mLogger?.logger.info?.({event:t,id:d},"Sending app event"),this.w3mFrame.events.postAppEvent({...t,id:d});const h=new AbortController;if(s==="RPC_REQUEST"){const w=t;this.openRpcRequests.set(d,{...w.payload,abortController:h})}h.signal.addEventListener("abort",()=>{s==="RPC_REQUEST"?l(new Error("Request was aborted")):s!=="GET_FARCASTER_URI"&&l(new Error("Something went wrong"))});const f=(w,v)=>{w.id===d&&(v?.logger.info?.({framEvent:w,id:d},"Received frame response"),this.openRpcRequests.delete(w.id),w.type===`@w3m-frame/${s}_SUCCESS`?(n&&clearTimeout(n),r&&clearTimeout(r),"payload"in w&&c(w.payload),c(void 0)):w.type===`@w3m-frame/${s}_ERROR`&&(n&&clearTimeout(n),r&&clearTimeout(r),"payload"in w&&l(new Error(w.payload?.message||"An error occurred")),l(new Error("An error occurred"))))};this.w3mFrame.events.registerFrameEventHandler(d,w=>f(w,this.w3mLogger),this.abortController.signal)})}setNewLastEmailLoginTime(){tt.set(oe.LAST_EMAIL_LOGIN_TIME,Date.now().toString())}setSocialLoginSuccess(t){tt.set(oe.SOCIAL_USERNAME,t)}setLoginSuccess(t){t&&tt.set(oe.EMAIL,t),tt.set(oe.EMAIL_LOGIN_USED_KEY,"true"),tt.delete(oe.LAST_EMAIL_LOGIN_TIME)}deleteAuthLoginCache(){tt.delete(oe.EMAIL_LOGIN_USED_KEY),tt.delete(oe.EMAIL),tt.delete(oe.LAST_USED_CHAIN_KEY),tt.delete(oe.SOCIAL_USERNAME)}setLastUsedChainId(t){t&&tt.set(oe.LAST_USED_CHAIN_KEY,String(t))}getLastUsedChainId(){const t=tt.get(oe.LAST_USED_CHAIN_KEY)??void 0,n=Number(t);return isNaN(n)?t:n}persistSmartAccountEnabledNetworks(t){tt.set(oe.SMART_ACCOUNT_ENABLED_NETWORKS,t.join(","))}getRpcUrl(t){let n=t===void 0?void 0:"eip155";typeof t=="string"&&(t.includes(":")?n=Jt.parseCaipNetworkId(t)?.chainNamespace:Number.isInteger(Number(t))?n="eip155":n="solana");const r=this.getCaipNetworks(n);return(t?r.find(i=>String(i.id)===String(t)||i.caipNetworkId===t):r[0])?.rpcUrls.default.http?.[0]}}function Dp(e,{strict:t=!0}={}){return!e||typeof e!="string"?!1:t?/^0x[0-9a-fA-F]*$/.test(e):e.startsWith("0x")}function Ru(e){return Dp(e,{strict:!1})?Math.ceil((e.length-2)/2):e.length}const Mp="2.43.3";let Jc={getDocsUrl:({docsBaseUrl:e,docsPath:t="",docsSlug:n})=>t?`${e??"https://viem.sh"}${t}${n?`#${n}`:""}`:void 0,version:`viem@${Mp}`};class Ue extends Error{constructor(t,n={}){const r=n.cause instanceof Ue?n.cause.details:n.cause?.message?n.cause.message:n.details,o=n.cause instanceof Ue&&n.cause.docsPath||n.docsPath,i=Jc.getDocsUrl?.({...n,docsPath:o}),s=[t||"An error occurred.","",...n.metaMessages?[...n.metaMessages,""]:[],...i?[`Docs: ${i}`]:[],...r?[`Details: ${r}`]:[],...Jc.version?[`Version: ${Jc.version}`]:[]].join(`
`);super(s,n.cause?{cause:n.cause}:void 0),Object.defineProperty(this,"details",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"docsPath",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"metaMessages",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"shortMessage",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"version",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"BaseError"}),this.details=r,this.docsPath=o,this.metaMessages=n.metaMessages,this.name=n.name??this.name,this.shortMessage=t,this.version=Mp}walk(t){return Up(this,t)}}function Up(e,t){return t?.(e)?e:e&&typeof e=="object"&&"cause"in e&&e.cause!==void 0?Up(e.cause,t):t?null:e}class ov extends Ue{constructor({offset:t,position:n,size:r}){super(`Slice ${n==="start"?"starting":"ending"} at offset "${t}" is out-of-bounds (size: ${r}).`,{name:"SliceOffsetOutOfBoundsError"})}}class Bp extends Ue{constructor({size:t,targetSize:n,type:r}){super(`${r.charAt(0).toUpperCase()}${r.slice(1).toLowerCase()} size (${t}) exceeds padding size (${n}).`,{name:"SizeExceedsPaddingSizeError"})}}class sv extends Ue{constructor({size:t,targetSize:n,type:r}){super(`${r.charAt(0).toUpperCase()}${r.slice(1).toLowerCase()} is expected to be ${n} ${r} long, but is ${t} ${r} long.`,{name:"InvalidBytesLengthError"})}}function mo(e,{dir:t,size:n=32}={}){return typeof e=="string"?fw(e,{dir:t,size:n}):mw(e,{dir:t,size:n})}function fw(e,{dir:t,size:n=32}={}){if(n===null)return e;const r=e.replace("0x","");if(r.length>n*2)throw new Bp({size:Math.ceil(r.length/2),targetSize:n,type:"hex"});return`0x${r[t==="right"?"padEnd":"padStart"](n*2,"0")}`}function mw(e,{dir:t,size:n=32}={}){if(n===null)return e;if(e.length>n)throw new Bp({size:e.length,targetSize:n,type:"bytes"});const r=new Uint8Array(n);for(let o=0;o<n;o++){const i=t==="right";r[i?o:n-o-1]=e[i?o:e.length-o-1]}return r}class gw extends Ue{constructor({max:t,min:n,signed:r,size:o,value:i}){super(`Number "${i}" is not in safe ${o?`${o*8}-bit ${r?"signed":"unsigned"} `:""}integer range ${t?`(${n} to ${t})`:`(above ${n})`}`,{name:"IntegerOutOfRangeError"})}}class av extends Ue{constructor(t){super(`Bytes value "${t}" is not a valid boolean. The bytes array must contain a single byte of either a 0 or 1 value.`,{name:"InvalidBytesBooleanError"})}}class ww extends Ue{constructor(t){super(`Hex value "${t}" is not a valid boolean. The hex value must be "0x0" (false) or "0x1" (true).`,{name:"InvalidHexBooleanError"})}}class bw extends Ue{constructor({givenSize:t,maxSize:n}){super(`Size cannot exceed ${n} bytes. Given size: ${t} bytes.`,{name:"SizeOverflowError"})}}function Ra(e,{dir:t="left"}={}){let n=typeof e=="string"?e.replace("0x",""):e,r=0;for(let o=0;o<n.length-1&&n[t==="left"?o:n.length-o-1].toString()==="0";o++)r++;return n=t==="left"?n.slice(r):n.slice(0,n.length-r),typeof e=="string"?(n.length===1&&t==="right"&&(n=`${n}0`),`0x${n.length%2===1?`0${n}`:n}`):n}function xr(e,{size:t}){if(Ru(e)>t)throw new bw({givenSize:Ru(e),maxSize:t})}function yw(e,t={}){const{signed:n}=t;t.size&&xr(e,{size:t.size});const r=BigInt(e);if(!n)return r;const o=(e.length-2)/2,i=(1n<<BigInt(o)*8n-1n)-1n;return r<=i?r:r-BigInt(`0x${"f".padStart(o*2,"f")}`)-1n}function cv(e,t={}){let n=e;if(t.size&&(xr(n,{size:t.size}),n=Ra(n)),Ra(n)==="0x00")return!1;if(Ra(n)==="0x01")return!0;throw new ww(n)}function lv(e,t={}){return Number(yw(e,t))}function dv(e,t={}){let n=$d(e);return t.size&&(xr(n,{size:t.size}),n=Ra(n,{dir:"right"})),new TextDecoder().decode(n)}const Cw=Array.from({length:256},(e,t)=>t.toString(16).padStart(2,"0"));function uv(e,t={}){return typeof e=="number"||typeof e=="bigint"?jp(e,t):typeof e=="string"?Fp(e,t):typeof e=="boolean"?vw(e,t):Wp(e,t)}function vw(e,t={}){const n=`0x${Number(e)}`;return typeof t.size=="number"?(xr(n,{size:t.size}),mo(n,{size:t.size})):n}function Wp(e,t={}){let n="";for(let o=0;o<e.length;o++)n+=Cw[e[o]];const r=`0x${n}`;return typeof t.size=="number"?(xr(r,{size:t.size}),mo(r,{dir:"right",size:t.size})):r}function jp(e,t={}){const{signed:n,size:r}=t,o=BigInt(e);let i;r?n?i=(1n<<BigInt(r)*8n-1n)-1n:i=2n**(BigInt(r)*8n)-1n:typeof e=="number"&&(i=BigInt(Number.MAX_SAFE_INTEGER));const s=typeof i=="bigint"&&n?-i-1n:0;if(i&&o>i||o<s){const c=typeof e=="bigint"?"n":"";throw new gw({max:i?`${i}${c}`:void 0,min:`${s}${c}`,signed:n,size:r,value:`${e}${c}`})}const a=`0x${(n&&o<0?(1n<<BigInt(r*8))+BigInt(o):o).toString(16)}`;return r?mo(a,{size:r}):a}const Ew=new TextEncoder;function Fp(e,t={}){const n=Ew.encode(e);return Wp(n,t)}const _w=new TextEncoder;function hv(e,t={}){return typeof e=="number"||typeof e=="bigint"?xw(e,t):typeof e=="boolean"?Aw(e,t):Dp(e)?$d(e,t):Sw(e,t)}function Aw(e,t={}){const n=new Uint8Array(1);return n[0]=Number(e),typeof t.size=="number"?(xr(n,{size:t.size}),mo(n,{size:t.size})):n}const jn={zero:48,nine:57,A:65,F:70,a:97,f:102};function ku(e){if(e>=jn.zero&&e<=jn.nine)return e-jn.zero;if(e>=jn.A&&e<=jn.F)return e-(jn.A-10);if(e>=jn.a&&e<=jn.f)return e-(jn.a-10)}function $d(e,t={}){let n=e;t.size&&(xr(n,{size:t.size}),n=mo(n,{dir:"right",size:t.size}));let r=n.slice(2);r.length%2&&(r=`0${r}`);const o=r.length/2,i=new Uint8Array(o);for(let s=0,a=0;s<o;s++){const c=ku(r.charCodeAt(a++)),l=ku(r.charCodeAt(a++));if(c===void 0||l===void 0)throw new Ue(`Invalid byte sequence ("${r[a-2]}${r[a-1]}" in "${r}").`);i[s]=c*16+l}return i}function xw(e,t){const n=jp(e,t);return $d(n)}function Sw(e,t={}){const n=_w.encode(e);return typeof t.size=="number"?(xr(n,{size:t.size}),mo(n,{dir:"right",size:t.size})):n}class Tw extends Map{constructor(t){super(),Object.defineProperty(this,"maxSize",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.maxSize=t}get(t){const n=super.get(t);return super.has(t)&&n!==void 0&&(this.delete(t),super.set(t,n)),n}set(t,n){if(super.set(t,n),this.maxSize&&this.size>this.maxSize){const r=this.keys().next().value;r&&this.delete(r)}return this}}const Hr=(e,t,n)=>JSON.stringify(e,(r,o)=>typeof o=="bigint"?o.toString():o,n),pv={gwei:9,wei:18},$w={ether:-9,wei:9};function Nd(e,t){let n=e.toString();const r=n.startsWith("-");r&&(n=n.slice(1)),n=n.padStart(t,"0");let[o,i]=[n.slice(0,n.length-t),n.slice(n.length-t)];return i=i.replace(/(0+)$/,""),`${r?"-":""}${o||"0"}${i?`.${i}`:""}`}function Ga(e,t="wei"){return Nd(e,$w[t])}const fv=e=>e,Rd=e=>e;class Po extends Ue{constructor({body:t,cause:n,details:r,headers:o,status:i,url:s}){super("HTTP request failed.",{cause:n,details:r,metaMessages:[i&&`Status: ${i}`,`URL: ${Rd(s)}`,t&&`Request body: ${Hr(t)}`].filter(Boolean),name:"HttpRequestError"}),Object.defineProperty(this,"body",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"headers",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"status",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"url",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.body=t,this.headers=o,this.status=i,this.url=s}}class zp extends Ue{constructor({body:t,error:n,url:r}){super("RPC Request failed.",{cause:n,details:n.message,metaMessages:[`URL: ${Rd(r)}`,`Request body: ${Hr(t)}`],name:"RpcRequestError"}),Object.defineProperty(this,"code",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"data",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"url",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.code=n.code,this.data=n.data,this.url=r}}class Iu extends Ue{constructor({body:t,url:n}){super("The request took too long to respond.",{details:"The request timed out.",metaMessages:[`URL: ${Rd(n)}`,`Request body: ${Hr(t)}`],name:"TimeoutError"}),Object.defineProperty(this,"url",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.url=n}}const Nw=-1;class Pt extends Ue{constructor(t,{code:n,docsPath:r,metaMessages:o,name:i,shortMessage:s}){super(s,{cause:t,docsPath:r,metaMessages:o||t?.metaMessages,name:i||"RpcError"}),Object.defineProperty(this,"code",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.name=i||t.name,this.code=t instanceof zp?t.code:n??Nw}}class Ht extends Pt{constructor(t,n){super(t,n),Object.defineProperty(this,"data",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.data=n.data}}class es extends Pt{constructor(t){super(t,{code:es.code,name:"ParseRpcError",shortMessage:"Invalid JSON was received by the server. An error occurred on the server while parsing the JSON text."})}}Object.defineProperty(es,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32700});class ts extends Pt{constructor(t){super(t,{code:ts.code,name:"InvalidRequestRpcError",shortMessage:"JSON is not a valid request object."})}}Object.defineProperty(ts,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32600});class ns extends Pt{constructor(t,{method:n}={}){super(t,{code:ns.code,name:"MethodNotFoundRpcError",shortMessage:`The method${n?` "${n}"`:""} does not exist / is not available.`})}}Object.defineProperty(ns,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32601});class rs extends Pt{constructor(t){super(t,{code:rs.code,name:"InvalidParamsRpcError",shortMessage:["Invalid parameters were provided to the RPC method.","Double check you have provided the correct parameters."].join(`
`)})}}Object.defineProperty(rs,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32602});class to extends Pt{constructor(t){super(t,{code:to.code,name:"InternalRpcError",shortMessage:"An internal error was received."})}}Object.defineProperty(to,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32603});class is extends Pt{constructor(t){super(t,{code:is.code,name:"InvalidInputRpcError",shortMessage:["Missing or invalid parameters.","Double check you have provided the correct parameters."].join(`
`)})}}Object.defineProperty(is,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32e3});class os extends Pt{constructor(t){super(t,{code:os.code,name:"ResourceNotFoundRpcError",shortMessage:"Requested resource not found."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ResourceNotFoundRpcError"})}}Object.defineProperty(os,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32001});class ss extends Pt{constructor(t){super(t,{code:ss.code,name:"ResourceUnavailableRpcError",shortMessage:"Requested resource not available."})}}Object.defineProperty(ss,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32002});class no extends Pt{constructor(t){super(t,{code:no.code,name:"TransactionRejectedRpcError",shortMessage:"Transaction creation failed."})}}Object.defineProperty(no,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32003});class Br extends Pt{constructor(t,{method:n}={}){super(t,{code:Br.code,name:"MethodNotSupportedRpcError",shortMessage:`Method${n?` "${n}"`:""} is not supported.`})}}Object.defineProperty(Br,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32004});class ro extends Pt{constructor(t){super(t,{code:ro.code,name:"LimitExceededRpcError",shortMessage:"Request exceeds defined limit."})}}Object.defineProperty(ro,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32005});class as extends Pt{constructor(t){super(t,{code:as.code,name:"JsonRpcVersionUnsupportedError",shortMessage:"Version of JSON-RPC protocol is not supported."})}}Object.defineProperty(as,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32006});class Vr extends Ht{constructor(t){super(t,{code:Vr.code,name:"UserRejectedRequestError",shortMessage:"User rejected the request."})}}Object.defineProperty(Vr,"code",{enumerable:!0,configurable:!0,writable:!0,value:4001});class cs extends Ht{constructor(t){super(t,{code:cs.code,name:"UnauthorizedProviderError",shortMessage:"The requested method and/or account has not been authorized by the user."})}}Object.defineProperty(cs,"code",{enumerable:!0,configurable:!0,writable:!0,value:4100});class ls extends Ht{constructor(t,{method:n}={}){super(t,{code:ls.code,name:"UnsupportedProviderMethodError",shortMessage:`The Provider does not support the requested method${n?` " ${n}"`:""}.`})}}Object.defineProperty(ls,"code",{enumerable:!0,configurable:!0,writable:!0,value:4200});class ds extends Ht{constructor(t){super(t,{code:ds.code,name:"ProviderDisconnectedError",shortMessage:"The Provider is disconnected from all chains."})}}Object.defineProperty(ds,"code",{enumerable:!0,configurable:!0,writable:!0,value:4900});class us extends Ht{constructor(t){super(t,{code:us.code,name:"ChainDisconnectedError",shortMessage:"The Provider is not connected to the requested chain."})}}Object.defineProperty(us,"code",{enumerable:!0,configurable:!0,writable:!0,value:4901});class hs extends Ht{constructor(t){super(t,{code:hs.code,name:"SwitchChainError",shortMessage:"An error occurred when attempting to switch chain."})}}Object.defineProperty(hs,"code",{enumerable:!0,configurable:!0,writable:!0,value:4902});class ps extends Ht{constructor(t){super(t,{code:ps.code,name:"UnsupportedNonOptionalCapabilityError",shortMessage:"This Wallet does not support a capability that was not marked as optional."})}}Object.defineProperty(ps,"code",{enumerable:!0,configurable:!0,writable:!0,value:5700});class fs extends Ht{constructor(t){super(t,{code:fs.code,name:"UnsupportedChainIdError",shortMessage:"This Wallet does not support the requested chain ID."})}}Object.defineProperty(fs,"code",{enumerable:!0,configurable:!0,writable:!0,value:5710});class ms extends Ht{constructor(t){super(t,{code:ms.code,name:"DuplicateIdError",shortMessage:"There is already a bundle submitted with this ID."})}}Object.defineProperty(ms,"code",{enumerable:!0,configurable:!0,writable:!0,value:5720});class gs extends Ht{constructor(t){super(t,{code:gs.code,name:"UnknownBundleIdError",shortMessage:"This bundle id is unknown / has not been submitted"})}}Object.defineProperty(gs,"code",{enumerable:!0,configurable:!0,writable:!0,value:5730});class ws extends Ht{constructor(t){super(t,{code:ws.code,name:"BundleTooLargeError",shortMessage:"The call bundle is too large for the Wallet to process."})}}Object.defineProperty(ws,"code",{enumerable:!0,configurable:!0,writable:!0,value:5740});class bs extends Ht{constructor(t){super(t,{code:bs.code,name:"AtomicReadyWalletRejectedUpgradeError",shortMessage:"The Wallet can support atomicity after an upgrade, but the user rejected the upgrade."})}}Object.defineProperty(bs,"code",{enumerable:!0,configurable:!0,writable:!0,value:5750});class ys extends Ht{constructor(t){super(t,{code:ys.code,name:"AtomicityNotSupportedError",shortMessage:"The wallet does not support atomic execution but the request requires it."})}}Object.defineProperty(ys,"code",{enumerable:!0,configurable:!0,writable:!0,value:5760});class Rw extends Pt{constructor(t){super(t,{name:"UnknownRpcError",shortMessage:"An unknown RPC error occurred."})}}const kw="modulepreload",Iw=function(e){return"/"+e},Ou={},me=function(t,n,r){let o=Promise.resolve();if(n&&n.length>0){let s=function(l){return Promise.all(l.map(d=>Promise.resolve(d).then(h=>({status:"fulfilled",value:h}),h=>({status:"rejected",reason:h}))))};document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),c=a?.nonce||a?.getAttribute("nonce");o=s(n.map(l=>{if(l=Iw(l),l in Ou)return;Ou[l]=!0;const d=l.endsWith(".css"),h=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${h}`))return;const f=document.createElement("link");if(f.rel=d?"stylesheet":kw,d||(f.as="script"),f.crossOrigin="",f.href=l,c&&f.setAttribute("nonce",c),document.head.appendChild(f),d)return new Promise((w,v)=>{f.addEventListener("load",w),f.addEventListener("error",()=>v(new Error(`Unable to preload CSS for ${l}`)))})}))}function i(s){const a=new Event("vite:preloadError",{cancelable:!0});if(a.payload=s,window.dispatchEvent(a),!a.defaultPrevented)throw s}return o.then(s=>{for(const a of s||[])a.status==="rejected"&&i(a.reason);return t().catch(i)})};class kd extends Ue{constructor({cause:t,message:n}={}){const r=n?.replace("execution reverted: ","")?.replace("execution reverted","");super(`Execution reverted ${r?`with reason: ${r}`:"for an unknown reason"}.`,{cause:t,name:"ExecutionRevertedError"})}}Object.defineProperty(kd,"code",{enumerable:!0,configurable:!0,writable:!0,value:3});Object.defineProperty(kd,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/execution reverted|gas required exceeds allowance/});class Ow extends Ue{constructor({cause:t,maxFeePerGas:n}={}){super(`The fee cap (\`maxFeePerGas\`${n?` = ${Ga(n)} gwei`:""}) cannot be higher than the maximum allowed value (2^256-1).`,{cause:t,name:"FeeCapTooHighError"})}}Object.defineProperty(Ow,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/max fee per gas higher than 2\^256-1|fee cap higher than 2\^256-1/});class Pw extends Ue{constructor({cause:t,maxFeePerGas:n}={}){super(`The fee cap (\`maxFeePerGas\`${n?` = ${Ga(n)}`:""} gwei) cannot be lower than the block base fee.`,{cause:t,name:"FeeCapTooLowError"})}}Object.defineProperty(Pw,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/max fee per gas less than block base fee|fee cap less than block base fee|transaction is outdated/});class Lw extends Ue{constructor({cause:t,nonce:n}={}){super(`Nonce provided for the transaction ${n?`(${n}) `:""}is higher than the next one expected.`,{cause:t,name:"NonceTooHighError"})}}Object.defineProperty(Lw,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/nonce too high/});class Dw extends Ue{constructor({cause:t,nonce:n}={}){super([`Nonce provided for the transaction ${n?`(${n}) `:""}is lower than the current nonce of the account.`,"Try increasing the nonce or find the latest nonce with `getTransactionCount`."].join(`
`),{cause:t,name:"NonceTooLowError"})}}Object.defineProperty(Dw,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/nonce too low|transaction already imported|already known/});class Mw extends Ue{constructor({cause:t,nonce:n}={}){super(`Nonce provided for the transaction ${n?`(${n}) `:""}exceeds the maximum allowed nonce.`,{cause:t,name:"NonceMaxValueError"})}}Object.defineProperty(Mw,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/nonce has max value/});class Uw extends Ue{constructor({cause:t}={}){super(["The total cost (gas * gas fee + value) of executing this transaction exceeds the balance of the account."].join(`
`),{cause:t,metaMessages:["This error could arise when the account does not have enough funds to:"," - pay for the total gas fee,"," - pay for the value to send."," ","The cost of the transaction is calculated as `gas * gas fee + value`, where:"," - `gas` is the amount of gas needed for transaction to execute,"," - `gas fee` is the gas fee,"," - `value` is the amount of ether to send to the recipient."],name:"InsufficientFundsError"})}}Object.defineProperty(Uw,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/insufficient funds|exceeds transaction sender account balance/});class Bw extends Ue{constructor({cause:t,gas:n}={}){super(`The amount of gas ${n?`(${n}) `:""}provided for the transaction exceeds the limit allowed for the block.`,{cause:t,name:"IntrinsicGasTooHighError"})}}Object.defineProperty(Bw,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/intrinsic gas too high|gas limit reached/});class Ww extends Ue{constructor({cause:t,gas:n}={}){super(`The amount of gas ${n?`(${n}) `:""}provided for the transaction is too low.`,{cause:t,name:"IntrinsicGasTooLowError"})}}Object.defineProperty(Ww,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/intrinsic gas too low/});class jw extends Ue{constructor({cause:t}){super("The transaction type is not supported for this chain.",{cause:t,name:"TransactionTypeNotSupportedError"})}}Object.defineProperty(jw,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/transaction type not valid/});class Fw extends Ue{constructor({cause:t,maxPriorityFeePerGas:n,maxFeePerGas:r}={}){super([`The provided tip (\`maxPriorityFeePerGas\`${n?` = ${Ga(n)} gwei`:""}) cannot be higher than the fee cap (\`maxFeePerGas\`${r?` = ${Ga(r)} gwei`:""}).`].join(`
`),{cause:t,name:"TipAboveFeeCapError"})}}Object.defineProperty(Fw,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/max priority fee per gas higher than max fee per gas|tip higher than fee cap/});class mv extends Ue{constructor({cause:t}){super(`An error occurred while executing: ${t?.shortMessage}`,{cause:t,name:"UnknownNodeError"})}}const gv=[{inputs:[{components:[{name:"target",type:"address"},{name:"allowFailure",type:"bool"},{name:"callData",type:"bytes"}],name:"calls",type:"tuple[]"}],name:"aggregate3",outputs:[{components:[{name:"success",type:"bool"},{name:"returnData",type:"bytes"}],name:"returnData",type:"tuple[]"}],stateMutability:"view",type:"function"},{inputs:[],name:"getCurrentBlockTimestamp",outputs:[{internalType:"uint256",name:"timestamp",type:"uint256"}],stateMutability:"view",type:"function"}],wv=[{name:"query",type:"function",stateMutability:"view",inputs:[{type:"tuple[]",name:"queries",components:[{type:"address",name:"sender"},{type:"string[]",name:"urls"},{type:"bytes",name:"data"}]}],outputs:[{type:"bool[]",name:"failures"},{type:"bytes[]",name:"responses"}]},{name:"HttpError",type:"error",inputs:[{type:"uint16",name:"status"},{type:"string",name:"message"}]}],Hp=[{inputs:[{name:"dns",type:"bytes"}],name:"DNSDecodingFailed",type:"error"},{inputs:[{name:"ens",type:"string"}],name:"DNSEncodingFailed",type:"error"},{inputs:[],name:"EmptyAddress",type:"error"},{inputs:[{name:"status",type:"uint16"},{name:"message",type:"string"}],name:"HttpError",type:"error"},{inputs:[],name:"InvalidBatchGatewayResponse",type:"error"},{inputs:[{name:"errorData",type:"bytes"}],name:"ResolverError",type:"error"},{inputs:[{name:"name",type:"bytes"},{name:"resolver",type:"address"}],name:"ResolverNotContract",type:"error"},{inputs:[{name:"name",type:"bytes"}],name:"ResolverNotFound",type:"error"},{inputs:[{name:"primary",type:"string"},{name:"primaryAddress",type:"bytes"}],name:"ReverseAddressMismatch",type:"error"},{inputs:[{internalType:"bytes4",name:"selector",type:"bytes4"}],name:"UnsupportedResolverProfile",type:"error"}],bv=[...Hp,{name:"resolveWithGateways",type:"function",stateMutability:"view",inputs:[{name:"name",type:"bytes"},{name:"data",type:"bytes"},{name:"gateways",type:"string[]"}],outputs:[{name:"",type:"bytes"},{name:"address",type:"address"}]}],yv=[...Hp,{name:"reverseWithGateways",type:"function",stateMutability:"view",inputs:[{type:"bytes",name:"reverseName"},{type:"uint256",name:"coinType"},{type:"string[]",name:"gateways"}],outputs:[{type:"string",name:"resolvedName"},{type:"address",name:"resolver"},{type:"address",name:"reverseResolver"}]}],Cv=[{name:"text",type:"function",stateMutability:"view",inputs:[{name:"name",type:"bytes32"},{name:"key",type:"string"}],outputs:[{name:"",type:"string"}]}],vv=[{name:"addr",type:"function",stateMutability:"view",inputs:[{name:"name",type:"bytes32"}],outputs:[{name:"",type:"address"}]},{name:"addr",type:"function",stateMutability:"view",inputs:[{name:"name",type:"bytes32"},{name:"coinType",type:"uint256"}],outputs:[{name:"",type:"bytes"}]}],Ev=[{name:"isValidSignature",type:"function",stateMutability:"view",inputs:[{name:"hash",type:"bytes32"},{name:"signature",type:"bytes"}],outputs:[{name:"",type:"bytes4"}]}],_v=[{inputs:[{name:"_signer",type:"address"},{name:"_hash",type:"bytes32"},{name:"_signature",type:"bytes"}],stateMutability:"nonpayable",type:"constructor"},{inputs:[{name:"_signer",type:"address"},{name:"_hash",type:"bytes32"},{name:"_signature",type:"bytes"}],outputs:[{type:"bool"}],stateMutability:"nonpayable",type:"function",name:"isValidSig"}],da=[{type:"event",name:"Approval",inputs:[{indexed:!0,name:"owner",type:"address"},{indexed:!0,name:"spender",type:"address"},{indexed:!1,name:"value",type:"uint256"}]},{type:"event",name:"Transfer",inputs:[{indexed:!0,name:"from",type:"address"},{indexed:!0,name:"to",type:"address"},{indexed:!1,name:"value",type:"uint256"}]},{type:"function",name:"allowance",stateMutability:"view",inputs:[{name:"owner",type:"address"},{name:"spender",type:"address"}],outputs:[{type:"uint256"}]},{type:"function",name:"approve",stateMutability:"nonpayable",inputs:[{name:"spender",type:"address"},{name:"amount",type:"uint256"}],outputs:[{type:"bool"}]},{type:"function",name:"balanceOf",stateMutability:"view",inputs:[{name:"account",type:"address"}],outputs:[{type:"uint256"}]},{type:"function",name:"decimals",stateMutability:"view",inputs:[],outputs:[{type:"uint8"}]},{type:"function",name:"name",stateMutability:"view",inputs:[],outputs:[{type:"string"}]},{type:"function",name:"symbol",stateMutability:"view",inputs:[],outputs:[{type:"string"}]},{type:"function",name:"totalSupply",stateMutability:"view",inputs:[],outputs:[{type:"uint256"}]},{type:"function",name:"transfer",stateMutability:"nonpayable",inputs:[{name:"recipient",type:"address"},{name:"amount",type:"uint256"}],outputs:[{type:"bool"}]},{type:"function",name:"transferFrom",stateMutability:"nonpayable",inputs:[{name:"sender",type:"address"},{name:"recipient",type:"address"},{name:"amount",type:"uint256"}],outputs:[{type:"bool"}]}];function zw(){let e=()=>{},t=()=>{};return{promise:new Promise((r,o)=>{e=r,t=o}),resolve:e,reject:t}}const Xc=new Map;function Hw({fn:e,id:t,shouldSplitBatch:n,wait:r=0,sort:o}){const i=async()=>{const d=c();s();const h=d.map(({args:f})=>f);h.length!==0&&e(h).then(f=>{o&&Array.isArray(f)&&f.sort(o);for(let w=0;w<d.length;w++){const{resolve:v}=d[w];v?.([f[w],f])}}).catch(f=>{for(let w=0;w<d.length;w++){const{reject:v}=d[w];v?.(f)}})},s=()=>Xc.delete(t),a=()=>c().map(({args:d})=>d),c=()=>Xc.get(t)||[],l=d=>Xc.set(t,[...c(),d]);return{flush:s,async schedule(d){const{promise:h,resolve:f,reject:w}=zw();return n?.([...a(),d])&&i(),c().length>0?(l({args:d,resolve:f,reject:w}),h):(l({args:d,resolve:f,reject:w}),setTimeout(i,r),h)}}}async function Vp(e){return new Promise(t=>setTimeout(t,e))}function Vw(e,{delay:t=100,retryCount:n=2,shouldRetry:r=()=>!0}={}){return new Promise((o,i)=>{const s=async({count:a=0}={})=>{const c=async({error:l})=>{const d=typeof t=="function"?t({count:a,error:l}):t;d&&await Vp(d),s({count:a+1})};try{const l=await e();o(l)}catch(l){if(a<n&&await r({count:a,error:l}))return c({error:l});i(l)}};s()})}const Kl=256;let ua=Kl,ha;function qw(e=11){if(!ha||ua+e>Kl*2){ha="",ua=0;for(let t=0;t<Kl;t++)ha+=(256+Math.random()*256|0).toString(16).substring(1)}return ha.substring(ua,ua+++e)}const pa=new Tw(8192);function Kw(e,{enabled:t=!0,id:n}){if(!t||!n)return e();if(pa.get(n))return pa.get(n);const r=e().finally(()=>pa.delete(n));return pa.set(n,r),r}function Gw(e,t={}){return async(n,r={})=>{const{dedupe:o=!1,methods:i,retryDelay:s=150,retryCount:a=3,uid:c}={...t,...r},{method:l}=n;if(i?.exclude?.includes(l))throw new Br(new Error("method not supported"),{method:l});if(i?.include&&!i.include.includes(l))throw new Br(new Error("method not supported"),{method:l});const d=o?Fp(`${c}.${Hr(n)}`):void 0;return Kw(()=>Vw(async()=>{try{return await e(n)}catch(h){const f=h;switch(f.code){case es.code:throw new es(f);case ts.code:throw new ts(f);case ns.code:throw new ns(f,{method:n.method});case rs.code:throw new rs(f);case to.code:throw new to(f);case is.code:throw new is(f);case os.code:throw new os(f);case ss.code:throw new ss(f);case no.code:throw new no(f);case Br.code:throw new Br(f,{method:n.method});case ro.code:throw new ro(f);case as.code:throw new as(f);case Vr.code:throw new Vr(f);case cs.code:throw new cs(f);case ls.code:throw new ls(f);case ds.code:throw new ds(f);case us.code:throw new us(f);case hs.code:throw new hs(f);case ps.code:throw new ps(f);case fs.code:throw new fs(f);case ms.code:throw new ms(f);case gs.code:throw new gs(f);case ws.code:throw new ws(f);case bs.code:throw new bs(f);case ys.code:throw new ys(f);case 5e3:throw new Vr(f);default:throw h instanceof Ue?h:new Rw(f)}}},{delay:({count:h,error:f})=>{if(f&&f instanceof Po){const w=f?.headers?.get("Retry-After");if(w?.match(/\d/))return Number.parseInt(w,10)*1e3}return~~(1<<h)*s},retryCount:a,shouldRetry:({error:h})=>Zw(h)}),{enabled:o,id:d})}}function Zw(e){return"code"in e&&typeof e.code=="number"?e.code===-1||e.code===ro.code||e.code===to.code:e instanceof Po&&e.status?e.status===403||e.status===408||e.status===413||e.status===429||e.status===500||e.status===502||e.status===503||e.status===504:!0}function Yw(e,{errorInstance:t=new Error("timed out"),timeout:n,signal:r}){return new Promise((o,i)=>{(async()=>{let s;try{const a=new AbortController;n>0&&(s=setTimeout(()=>{r&&a.abort()},n)),o(await e({signal:a?.signal||null}))}catch(a){a?.name==="AbortError"&&i(t),i(a)}finally{clearTimeout(s)}})()})}function Jw(){return{current:0,take(){return this.current++},reset(){this.current=0}}}const Pu=Jw();function Xw(e,t={}){return{async request(n){const{body:r,fetchFn:o=t.fetchFn??fetch,onRequest:i=t.onRequest,onResponse:s=t.onResponse,timeout:a=t.timeout??1e4}=n,c={...t.fetchOptions??{},...n.fetchOptions??{}},{headers:l,method:d,signal:h}=c;try{const f=await Yw(async({signal:v})=>{const y={...c,body:Array.isArray(r)?Hr(r.map(D=>({jsonrpc:"2.0",id:D.id??Pu.take(),...D}))):Hr({jsonrpc:"2.0",id:r.id??Pu.take(),...r}),headers:{"Content-Type":"application/json",...l},method:d||"POST",signal:h||(a>0?v:null)},$=new Request(e,y),I=await i?.($,y)??{...y,url:e};return await o(I.url??e,I)},{errorInstance:new Iu({body:r,url:e}),timeout:a,signal:!0});s&&await s(f);let w;if(f.headers.get("Content-Type")?.startsWith("application/json"))w=await f.json();else{w=await f.text();try{w=JSON.parse(w||"{}")}catch(v){if(f.ok)throw v;w={error:w}}}if(!f.ok)throw new Po({body:r,details:Hr(w.error)||f.statusText,headers:f.headers,status:f.status,url:e});return w}catch(f){throw f instanceof Po||f instanceof Iu?f:new Po({body:r,cause:f,url:e})}}}}function qp({key:e,methods:t,name:n,request:r,retryCount:o=3,retryDelay:i=150,timeout:s,type:a},c){const l=qw();return{config:{key:e,methods:t,name:n,request:r,retryCount:o,retryDelay:i,timeout:s,type:a},request:Gw(r,{methods:t,retryCount:o,retryDelay:i,uid:l}),value:c}}function Lu(e,t={}){const{key:n="fallback",name:r="Fallback",rank:o=!1,shouldThrow:i=Qw,retryCount:s,retryDelay:a}=t;return(({chain:c,pollingInterval:l=4e3,timeout:d,...h})=>{let f=e,w=()=>{};const v=qp({key:n,name:r,async request({method:y,params:$}){let I;const k=async(D=0)=>{const C=f[D]({...h,chain:c,retryCount:0,timeout:d});try{const A=await C.request({method:y,params:$});return w({method:y,params:$,response:A,transport:C,status:"success"}),A}catch(A){if(w({error:A,method:y,params:$,transport:C,status:"error"}),i(A)||D===f.length-1||(I??=f.slice(D+1).some(_=>{const{include:P,exclude:B}=_({chain:c}).config.methods||{};return P?P.includes(y):B?!B.includes(y):!0}),!I))throw A;return k(D+1)}};return k()},retryCount:s,retryDelay:a,type:"fallback"},{onResponse:y=>w=y,transports:f.map(y=>y({chain:c,retryCount:0}))});if(o){const y=typeof o=="object"?o:{};e2({chain:c,interval:y.interval??l,onTransports:$=>f=$,ping:y.ping,sampleCount:y.sampleCount,timeout:y.timeout,transports:f,weights:y.weights})}return v})}function Qw(e){return!!("code"in e&&typeof e.code=="number"&&(e.code===no.code||e.code===Vr.code||kd.nodeMessage.test(e.message)||e.code===5e3))}function e2({chain:e,interval:t=4e3,onTransports:n,ping:r,sampleCount:o=10,timeout:i=1e3,transports:s,weights:a={}}){const{stability:c=.7,latency:l=.3}=a,d=[],h=async()=>{const f=await Promise.all(s.map(async y=>{const $=y({chain:e,retryCount:0,timeout:i}),I=Date.now();let k,D;try{await(r?r({transport:$}):$.request({method:"net_listening"})),D=1}catch{D=0}finally{k=Date.now()}return{latency:k-I,success:D}}));d.push(f),d.length>o&&d.shift();const w=Math.max(...d.map(y=>Math.max(...y.map(({latency:$})=>$)))),v=s.map((y,$)=>{const I=d.map(_=>_[$].latency),D=1-I.reduce((_,P)=>_+P,0)/I.length/w,C=d.map(_=>_[$].success),A=C.reduce((_,P)=>_+P,0)/C.length;return A===0?[0,$]:[l*D+c*A,$]}).sort((y,$)=>$[0]-y[0]);n(v.map(([,y])=>s[y])),await Vp(t),h()};h()}class t2 extends Ue{constructor(){super("No URL was provided to the Transport. Please provide a valid RPC URL to the Transport.",{docsPath:"/docs/clients/intro",name:"UrlRequiredError"})}}function fa(e,t={}){const{batch:n,fetchFn:r,fetchOptions:o,key:i="http",methods:s,name:a="HTTP JSON-RPC",onFetchRequest:c,onFetchResponse:l,retryDelay:d,raw:h}=t;return({chain:f,retryCount:w,timeout:v})=>{const{batchSize:y=1e3,wait:$=0}=typeof n=="object"?n:{},I=t.retryCount??w,k=v??t.timeout??1e4,D=e||f?.rpcUrls.default.http[0];if(!D)throw new t2;const C=Xw(D,{fetchFn:r,fetchOptions:o,onRequest:c,onResponse:l,timeout:k});return qp({key:i,methods:s,name:a,async request({method:A,params:_}){const P={method:A,params:_},{schedule:B}=Hw({id:D,wait:$,shouldSplitBatch(Y){return Y.length>y},fn:Y=>C.request({body:Y}),sort:(Y,ue)=>Y.id-ue.id}),j=async Y=>n?B(Y):[await C.request({body:Y})],[{error:W,result:z}]=await j(P);if(h)return{error:W,result:z};if(W)throw new zp({body:P,error:W,url:D});return z},retryCount:I,retryDelay:d,timeout:k,type:"http"},{fetchOptions:o,url:D})}}async function xo(...e){const t=await fetch(...e);if(!t.ok)throw new Error(`HTTP status code: ${t.status}`,{cause:t});return t}class Bs{constructor({baseUrl:t,clientId:n}){this.baseUrl=t,this.clientId=n}async get({headers:t,signal:n,cache:r,...o}){const i=this.createUrl(o);return(await xo(i,{method:"GET",headers:t,signal:n,cache:r})).json()}async getBlob({headers:t,signal:n,...r}){const o=this.createUrl(r);return(await xo(o,{method:"GET",headers:t,signal:n})).blob()}async post({body:t,headers:n,signal:r,...o}){const i=this.createUrl(o);return(await xo(i,{method:"POST",headers:n,body:t?JSON.stringify(t):void 0,signal:r})).json()}async put({body:t,headers:n,signal:r,...o}){const i=this.createUrl(o);return(await xo(i,{method:"PUT",headers:n,body:t?JSON.stringify(t):void 0,signal:r})).json()}async delete({body:t,headers:n,signal:r,...o}){const i=this.createUrl(o);return(await xo(i,{method:"DELETE",headers:n,body:t?JSON.stringify(t):void 0,signal:r})).json()}createUrl({path:t,params:n}){const r=new URL(t,this.baseUrl);return n&&Object.entries(n).forEach(([o,i])=>{i&&r.searchParams.append(o,i)}),this.clientId&&r.searchParams.append("clientId",this.clientId),r}sendBeacon({body:t,...n}){const r=this.createUrl(n);return navigator.sendBeacon(r.toString(),t?JSON.stringify(t):void 0)}}const Gl={getFeatureValue(e,t){const n=t?.[e];return n===void 0?ke.DEFAULT_FEATURES[e]:n},filterSocialsByPlatform(e){if(!e||!e.length)return e;let t=e;return L.isTelegram()&&(L.isIos()&&(t=t.filter(n=>n!=="google")),L.isMac()&&(t=t.filter(n=>n!=="x")),L.isAndroid()&&(t=t.filter(n=>!["facebook","x"].includes(n)))),L.isMobile()&&(t=t.filter(n=>n!=="facebook")),t},isSocialsEnabled(){return Array.isArray(R.state.features?.socials)&&R.state.features?.socials.length>0||Array.isArray(R.state.remoteFeatures?.socials)&&R.state.remoteFeatures?.socials.length>0},isEmailEnabled(){return!!(R.state.features?.email||R.state.remoteFeatures?.email)}},le=ze({features:ke.DEFAULT_FEATURES,projectId:"",sdkType:"appkit",sdkVersion:"html-wagmi-undefined",defaultAccountTypes:ke.DEFAULT_ACCOUNT_TYPES,enableNetworkSwitch:!0,experimental_preferUniversalLinks:!1,remoteFeatures:{},enableMobileFullScreen:!1,coinbasePreference:"all"}),R={state:le,subscribeKey(e,t){return st(le,e,t)},setOptions(e){Object.assign(le,e)},setRemoteFeatures(e){if(!e)return;const t={...le.remoteFeatures,...e};le.remoteFeatures=t,le.remoteFeatures?.socials&&(le.remoteFeatures.socials=Gl.filterSocialsByPlatform(le.remoteFeatures.socials)),le.features?.pay&&(le.remoteFeatures.email=!1,le.remoteFeatures.socials=!1)},setFeatures(e){if(!e)return;le.features||(le.features=ke.DEFAULT_FEATURES);const t={...le.features,...e};le.features=t,le.features?.pay&&le.remoteFeatures&&(le.remoteFeatures.email=!1,le.remoteFeatures.socials=!1)},setProjectId(e){le.projectId=e},setCustomRpcUrls(e){le.customRpcUrls=e},setAllWallets(e){le.allWallets=e},setIncludeWalletIds(e){le.includeWalletIds=e},setExcludeWalletIds(e){le.excludeWalletIds=e},setFeaturedWalletIds(e){le.featuredWalletIds=e},setTokens(e){le.tokens=e},setTermsConditionsUrl(e){le.termsConditionsUrl=e},setPrivacyPolicyUrl(e){le.privacyPolicyUrl=e},setCustomWallets(e){le.customWallets=e},setIsSiweEnabled(e){le.isSiweEnabled=e},setIsUniversalProvider(e){le.isUniversalProvider=e},setSdkVersion(e){le.sdkVersion=e},setMetadata(e){le.metadata=e},setDisableAppend(e){le.disableAppend=e},setEIP6963Enabled(e){le.enableEIP6963=e},setDebug(e){le.debug=e},setEnableWalletGuide(e){le.enableWalletGuide=e},setEnableAuthLogger(e){le.enableAuthLogger=e},setEnableWallets(e){le.enableWallets=e},setPreferUniversalLinks(e){le.experimental_preferUniversalLinks=e},setSIWX(e){if(e)for(const[t,n]of Object.entries(ke.SIWX_DEFAULTS))e[t]??=n;le.siwx=e},setConnectMethodsOrder(e){le.features={...le.features,connectMethodsOrder:e}},setWalletFeaturesOrder(e){le.features={...le.features,walletFeaturesOrder:e}},setSocialsOrder(e){le.remoteFeatures={...le.remoteFeatures,socials:e}},setCollapseWallets(e){le.features={...le.features,collapseWallets:e}},setEnableEmbedded(e){le.enableEmbedded=e},setAllowUnsupportedChain(e){le.allowUnsupportedChain=e},setManualWCControl(e){le.manualWCControl=e},setEnableNetworkSwitch(e){le.enableNetworkSwitch=e},setEnableMobileFullScreen(e){le.enableMobileFullScreen=L.isMobile()&&e},setEnableReconnect(e){le.enableReconnect=e},setCoinbasePreference(e){le.coinbasePreference=e},setDefaultAccountTypes(e={}){Object.entries(e).forEach(([t,n])=>{n&&(le.defaultAccountTypes[t]=n)})},setUniversalProviderConfigOverride(e){le.universalProviderConfigOverride=e},getUniversalProviderConfigOverride(){return le.universalProviderConfigOverride},getSnapshot(){return Wo(le)}},Mr=Object.freeze({message:"",variant:"success",svg:void 0,open:!1,autoClose:!0}),et=ze({...Mr}),n2={state:et,subscribeKey(e,t){return st(et,e,t)},showLoading(e,t={}){this._showMessage({message:e,variant:"loading",...t})},showSuccess(e){this._showMessage({message:e,variant:"success"})},showSvg(e,t){this._showMessage({message:e,svg:t})},showError(e){const t=L.parseError(e);this._showMessage({message:t,variant:"error"})},hide(){et.message=Mr.message,et.variant=Mr.variant,et.svg=Mr.svg,et.open=Mr.open,et.autoClose=Mr.autoClose},_showMessage({message:e,svg:t,variant:n="success",autoClose:r=Mr.autoClose}){et.open?(et.open=!1,setTimeout(()=>{et.message=e,et.variant=n,et.svg=t,et.open=!0,et.autoClose=r},150)):(et.message=e,et.variant=n,et.svg=t,et.open=!0,et.autoClose=r)}},Te=n2,r2={purchaseCurrencies:[{id:"2b92315d-eab7-5bef-84fa-089a131333f5",name:"USD Coin",symbol:"USDC",networks:[{name:"ethereum-mainnet",display_name:"Ethereum",chain_id:"1",contract_address:"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"},{name:"polygon-mainnet",display_name:"Polygon",chain_id:"137",contract_address:"0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"}]},{id:"2b92315d-eab7-5bef-84fa-089a131333f5",name:"Ether",symbol:"ETH",networks:[{name:"ethereum-mainnet",display_name:"Ethereum",chain_id:"1",contract_address:"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"},{name:"polygon-mainnet",display_name:"Polygon",chain_id:"137",contract_address:"0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"}]}],paymentCurrencies:[{id:"USD",payment_method_limits:[{id:"card",min:"10.00",max:"7500.00"},{id:"ach_bank_account",min:"10.00",max:"25000.00"}]},{id:"EUR",payment_method_limits:[{id:"card",min:"10.00",max:"7500.00"},{id:"ach_bank_account",min:"10.00",max:"25000.00"}]}]},Kp=L.getBlockchainApiUrl(),yt=ze({clientId:null,api:new Bs({baseUrl:Kp,clientId:null}),supportedChains:{http:[],ws:[]}}),_e={state:yt,async get(e){const{st:t,sv:n}=_e.getSdkProperties(),r=R.state.projectId,o={...e.params||{},st:t,sv:n,projectId:r};return yt.api.get({...e,params:o})},getSdkProperties(){const{sdkType:e,sdkVersion:t}=R.state;return{st:e||"unknown",sv:t||"unknown"}},async isNetworkSupported(e){if(!e)return!1;try{yt.supportedChains.http.length||await _e.getSupportedNetworks()}catch{return!1}return yt.supportedChains.http.includes(e)},async getSupportedNetworks(){try{const e=await _e.get({path:"v1/supported-chains"});return yt.supportedChains=e,e}catch{return yt.supportedChains}},async fetchIdentity({address:e}){const t=G.getIdentityFromCacheForAddress(e);if(t)return t;const n=await _e.get({path:`/v1/identity/${e}`,params:{sender:p.state.activeCaipAddress?L.getPlainAddress(p.state.activeCaipAddress):void 0}});return G.updateIdentityCache({address:e,identity:n,timestamp:Date.now()}),n},async fetchTransactions({account:e,cursor:t,signal:n,cache:r,chainId:o}){if(!await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId))return{data:[],next:void 0};const s=G.getTransactionsCacheForAddress({address:e,chainId:o});if(s)return s;const a=await _e.get({path:`/v1/account/${e}/history`,params:{cursor:t,chainId:o},signal:n,cache:r});return G.updateTransactionsCache({address:e,chainId:o,timestamp:Date.now(),transactions:a}),a},async fetchSwapQuote({amount:e,userAddress:t,from:n,to:r,gasPrice:o}){return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?_e.get({path:"/v1/convert/quotes",headers:{"Content-Type":"application/json"},params:{amount:e,userAddress:t,from:n,to:r,gasPrice:o}}):{quotes:[]}},async fetchSwapTokens({chainId:e}){return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?_e.get({path:"/v1/convert/tokens",params:{chainId:e}}):{tokens:[]}},async getAddressBalance({caipNetworkId:e,address:t}){return yt.api.post({path:`/v1?chainId=${e}&projectId=${R.state.projectId}`,body:{id:"1",jsonrpc:"2.0",method:"getAddressBalance",params:{address:t}}}).then(n=>n.result)},async fetchTokenPrice({addresses:e,caipNetworkId:t=p.state.activeCaipNetwork?.caipNetworkId}){if(!await _e.isNetworkSupported(t))return{fungibles:[]};const r=G.getTokenPriceCacheForAddresses(e);if(r)return r;const o=await yt.api.post({path:"/v1/fungible/price",body:{currency:"usd",addresses:e,projectId:R.state.projectId},headers:{"Content-Type":"application/json"}});return G.updateTokenPriceCache({addresses:e,timestamp:Date.now(),tokenPrice:o}),o},async fetchSwapAllowance({tokenAddress:e,userAddress:t}){return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?_e.get({path:"/v1/convert/allowance",params:{tokenAddress:e,userAddress:t},headers:{"Content-Type":"application/json"}}):{allowance:"0"}},async fetchGasPrice({chainId:e}){const{st:t,sv:n}=_e.getSdkProperties();if(!await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId))throw new Error("Network not supported for Gas Price");return _e.get({path:"/v1/convert/gas-price",headers:{"Content-Type":"application/json"},params:{chainId:e,st:t,sv:n}})},async generateSwapCalldata({amount:e,from:t,to:n,userAddress:r,disableEstimate:o}){if(!await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId))throw new Error("Network not supported for Swaps");return yt.api.post({path:"/v1/convert/build-transaction",headers:{"Content-Type":"application/json"},body:{amount:e,eip155:{slippage:ke.CONVERT_SLIPPAGE_TOLERANCE},projectId:R.state.projectId,from:t,to:n,userAddress:r,disableEstimate:o}})},async generateApproveCalldata({from:e,to:t,userAddress:n}){const{st:r,sv:o}=_e.getSdkProperties();if(!await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId))throw new Error("Network not supported for Swaps");return _e.get({path:"/v1/convert/build-approve",headers:{"Content-Type":"application/json"},params:{userAddress:n,from:e,to:t,st:r,sv:o}})},async getBalance(e,t,n){const{st:r,sv:o}=_e.getSdkProperties();if(!await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId))return Te.showError("Token Balance Unavailable"),{balances:[]};const s=`${t}:${e}`,a=G.getBalanceCacheForCaipAddress(s);if(a)return a;const c=await _e.get({path:`/v1/account/${e}/balance`,params:{currency:"usd",chainId:t,forceUpdate:n,st:r,sv:o}});return G.updateBalanceCache({caipAddress:s,balance:c,timestamp:Date.now()}),c},async lookupEnsName(e){return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?_e.get({path:`/v1/profile/account/${e}`,params:{apiVersion:"2"}}):{addresses:{},attributes:[]}},async reverseLookupEnsName({address:e}){if(!await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId))return[];const n=p.getAccountData()?.address;return _e.get({path:`/v1/profile/reverse/${e}`,params:{sender:n,apiVersion:"2"}})},async getEnsNameSuggestions(e){return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?_e.get({path:`/v1/profile/suggestions/${e}`,params:{zone:"reown.id"}}):{suggestions:[]}},async registerEnsName({coinType:e,address:t,message:n,signature:r}){return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?yt.api.post({path:"/v1/profile/account",body:{coin_type:e,address:t,message:n,signature:r},headers:{"Content-Type":"application/json"}}):{success:!1}},async generateOnRampURL({destinationWallets:e,partnerUserId:t,defaultNetwork:n,purchaseAmount:r,paymentAmount:o}){return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?(await yt.api.post({path:"/v1/generators/onrampurl",params:{projectId:R.state.projectId},body:{destinationWallets:e,defaultNetwork:n,partnerUserId:t,defaultExperience:"buy",presetCryptoAmount:r,presetFiatAmount:o}})).url:""},async getOnrampOptions(){if(!await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId))return{paymentCurrencies:[],purchaseCurrencies:[]};try{return await _e.get({path:"/v1/onramp/options"})}catch{return r2}},async getOnrampQuote({purchaseCurrency:e,paymentCurrency:t,amount:n,network:r}){try{return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?await yt.api.post({path:"/v1/onramp/quote",params:{projectId:R.state.projectId},body:{purchaseCurrency:e,paymentCurrency:t,amount:n,network:r}}):null}catch{return{networkFee:{amount:n,currency:t.id},paymentSubtotal:{amount:n,currency:t.id},paymentTotal:{amount:n,currency:t.id},purchaseAmount:{amount:n,currency:t.id},quoteId:"mocked-quote-id"}}},async getSmartSessions(e){return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?_e.get({path:`/v1/sessions/${e}`}):[]},async revokeSmartSession(e,t,n){return await _e.isNetworkSupported(p.state.activeCaipNetwork?.caipNetworkId)?yt.api.post({path:`/v1/sessions/${e}/revoke`,params:{projectId:R.state.projectId},body:{pci:t,signature:n}}):{success:!1}},setClientId(e){yt.clientId=e,yt.api=new Bs({baseUrl:Kp,clientId:e})}},i2=Object.freeze({enabled:!0,events:[]}),o2=new Bs({baseUrl:L.getAnalyticsUrl(),clientId:null}),s2=5,a2=60*1e3,ar=ze({...i2}),c2={state:ar,subscribeKey(e,t){return st(ar,e,t)},async sendError(e,t){if(!ar.enabled)return;const n=Date.now();if(ar.events.filter(i=>{const s=new Date(i.properties.timestamp||"").getTime();return n-s<a2}).length>=s2)return;const o={type:"error",event:t,properties:{errorType:e.name,errorMessage:e.message,stackTrace:e.stack,timestamp:new Date().toISOString()}};ar.events.push(o);try{if(typeof window>"u")return;const{projectId:i,sdkType:s,sdkVersion:a}=R.state;await o2.post({path:"/e",params:{projectId:i,st:s,sv:a||"html-wagmi-4.2.2"},body:{eventId:L.getUUID(),url:window.location.href,domain:window.location.hostname,timestamp:new Date().toISOString(),props:{type:"error",event:t,errorType:e.name,errorMessage:e.message,stackTrace:e.stack}}})}catch{}},enable(){ar.enabled=!0},disable(){ar.enabled=!1},clearEvents(){ar.events=[]}};class In extends Error{constructor(t,n,r){super(t),this.originalName="AppKitError",this.name="AppKitError",this.category=n,this.originalError=r,r&&r instanceof Error&&(this.originalName=r.name),Object.setPrototypeOf(this,In.prototype);let o=!1;if(r instanceof Error&&typeof r.stack=="string"&&r.stack){const i=r.stack,s=i.indexOf(`
`);if(s>-1){const a=i.substring(s+1);this.stack=`${this.name}: ${this.message}
${a}`,o=!0}}o||(Error.captureStackTrace?Error.captureStackTrace(this,In):this.stack||(this.stack=`${this.name}: ${this.message}`))}}function Du(e,t){let n="";try{e instanceof Error?n=e.message:typeof e=="string"?n=e:typeof e=="object"&&e!==null?Object.keys(e).length===0?n="Unknown error":n=e?.message||JSON.stringify(e):n=String(e)}catch(o){n="Unknown error",console.error("Error parsing error message",o)}const r=e instanceof In?e:new In(n,t,e);throw c2.sendError(r,r.category),r}function gn(e,t="INTERNAL_SDK_ERROR"){const n={};return Object.keys(e).forEach(r=>{const o=e[r];if(typeof o=="function"){let i=o;o.constructor.name==="AsyncFunction"?i=async(...s)=>{try{return await o(...s)}catch(a){return Du(a,t)}}:i=(...s)=>{try{return o(...s)}catch(a){return Du(a,t)}},n[r]=i}else n[r]=o}),n}const Bt=ze({walletImages:{},networkImages:{},chainImages:{},connectorImages:{},tokenImages:{},currencyImages:{}}),l2={state:Bt,subscribeNetworkImages(e){return ot(Bt.networkImages,()=>e(Bt.networkImages))},subscribeKey(e,t){return st(Bt,e,t)},subscribe(e){return ot(Bt,()=>e(Bt))},setWalletImage(e,t){Bt.walletImages[e]=t},setNetworkImage(e,t){Bt.networkImages[e]=t},setChainImage(e,t){Bt.chainImages[e]=t},setConnectorImage(e,t){Bt.connectorImages={...Bt.connectorImages,[e]:t}},setTokenImage(e,t){Bt.tokenImages[e]=t},setCurrencyImage(e,t){Bt.currencyImages[e]=t}},rt=gn(l2),Mu={eip155:"ba0ba0cd-17c6-4806-ad93-f9d174f17900",solana:"a1b58899-f671-4276-6a5e-56ca5bd59700",polkadot:"",bip122:"0b4838db-0161-4ffe-022d-532bf03dba00",cosmos:"",sui:"",stacks:"",ton:"20f673c0-095e-49b2-07cf-eb5049dcf600"},Mi=ze({networkImagePromises:{},tokenImagePromises:{}}),De={async fetchWalletImage(e){if(e)return await q._fetchWalletImage(e),this.getWalletImageById(e)},async fetchNetworkImage(e){if(!e)return;const t=this.getNetworkImageById(e);return t||(Mi.networkImagePromises[e]||(Mi.networkImagePromises[e]=q._fetchNetworkImage(e)),await Mi.networkImagePromises[e],this.getNetworkImageById(e))},async fetchTokenImage(e){if(e)return Mi.tokenImagePromises[e]||(Mi.tokenImagePromises[e]=q._fetchTokenImage(e)),await Mi.tokenImagePromises[e],this.getTokenImage(e)},getWalletImageById(e){if(e)return rt.state.walletImages[e]},getWalletImage(e){if(e?.image_url)return e?.image_url;if(e?.image_id)return rt.state.walletImages[e.image_id]},getNetworkImage(e){if(e?.assets?.imageUrl)return e?.assets?.imageUrl;if(e?.assets?.imageId)return rt.state.networkImages[e.assets.imageId]},getNetworkImageById(e){if(e)return rt.state.networkImages[e]},getConnectorImage(e){if(e?.imageUrl)return e.imageUrl;if(e?.info?.icon)return e.info.icon;if(e?.imageId)return rt.state.connectorImages[e.imageId]},getChainImage(e){return rt.state.networkImages[Mu[e]]},getTokenImage(e){if(e)return rt.state.tokenImages[e]},getWalletImageUrl(e){if(!e)return"";const{projectId:t,sdkType:n,sdkVersion:r}=R.state,o=new URL(`${N.W3M_API_URL}/getWalletImage/${e}`);return o.searchParams.set("projectId",t),o.searchParams.set("st",n),o.searchParams.set("sv",r),o.toString()},getAssetImageUrl(e){if(!e)return"";const{projectId:t,sdkType:n,sdkVersion:r}=R.state,o=new URL(`${N.W3M_API_URL}/public/getAssetImage/${e}`);return o.searchParams.set("projectId",t),o.searchParams.set("st",n),o.searchParams.set("sv",r),o.toString()},getChainNamespaceImageUrl(e){return this.getAssetImageUrl(Mu[e])},async getImageByToken(e,t){if(e==="native"){const r=N.NATIVE_IMAGE_IDS_BY_NAMESPACE[t]??null;return r?De.fetchNetworkImage(r):void 0}const[,n]=Object.entries(N.TOKEN_SYMBOLS_BY_ADDRESS).find(([r])=>r.toLowerCase()===e.toLowerCase())??[];if(n)return De.fetchTokenImage(n)}},Gt={PHANTOM:{id:"a797aa35c0fadbfc1a53e7f675162ed5226968b44a19ee3d24385c64d1d3c393",url:"https://phantom.app"},SOLFLARE:{id:"1ca0bdd4747578705b1939af023d120677c64fe6ca76add81fda36e350605e79",url:"https://solflare.com"},COINBASE:{id:"fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa",url:"https://go.cb-w.com"},BINANCE:{id:"2fafea35bb471d22889ccb49c08d99dd0a18a37982602c33f696a5723934ba25",appId:"yFK5FCqYprrXDiVFbhyRx7",deeplink:"bnc://app.binance.com/mp/app",url:"https://app.binance.com/en/download"}},d2={handleMobileDeeplinkRedirect(e,t){const n=window.location.href,r=encodeURIComponent(n);if(e===Gt.PHANTOM.id&&!("phantom"in window)){const o=n.startsWith("https")?"https":"http",i=n.split("/")[2],s=encodeURIComponent(`${o}://${i}`);window.location.href=`${Gt.PHANTOM.url}/ul/browse/${r}?ref=${s}`}if(e===Gt.SOLFLARE.id&&!("solflare"in window)&&(window.location.href=`${Gt.SOLFLARE.url}/ul/v1/browse/${r}?ref=${r}`),t===N.CHAIN.SOLANA&&e===Gt.COINBASE.id&&!("coinbaseSolana"in window)&&(window.location.href=`${Gt.COINBASE.url}/dapp?cb_url=${r}`),t===N.CHAIN.BITCOIN&&e===Gt.BINANCE.id&&!("binancew3w"in window)){const o=p.state.activeCaipNetwork,i=window.btoa("/pages/browser/index"),s=window.btoa(`url=${r}&defaultChainId=${o?.id??1}`),a=new URL(Gt.BINANCE.deeplink);a.searchParams.set("appId",Gt.BINANCE.appId),a.searchParams.set("startPagePath",i),a.searchParams.set("startPageQuery",s);const c=new URL(Gt.BINANCE.url);c.searchParams.set("_dp",window.btoa(a.toString())),window.location.href=c.toString()}}},u2=L.getAnalyticsUrl(),h2=new Bs({baseUrl:u2,clientId:null}),p2=["MODAL_CREATED"],f2=45,Uu=1e3*10,Ye=ze({timestamp:Date.now(),lastFlush:Date.now(),reportedErrors:{},data:{type:"track",event:"MODAL_CREATED"},pendingEvents:[],subscribedToVisibilityChange:!1,walletImpressions:[]}),X={state:Ye,subscribe(e){return ot(Ye,()=>e(Ye))},getSdkProperties(){const{projectId:e,sdkType:t,sdkVersion:n}=R.state;return{projectId:e,st:t,sv:n||"html-wagmi-4.2.2"}},shouldFlushEvents(){const e=JSON.stringify(Ye.pendingEvents).length/1024>f2,t=Ye.lastFlush+Uu<Date.now();return e||t},_setPendingEvent(e){try{let t=p.getAccountData()?.address;if("address"in e.data&&e.data.address&&(t=e.data.address),p2.includes(e.data.event)||typeof window>"u")return;const n=p.getActiveCaipNetwork()?.caipNetworkId;this.state.pendingEvents.push({eventId:L.getUUID(),url:window.location.href,domain:window.location.hostname,timestamp:e.timestamp,props:{...e.data,address:t,properties:{..."properties"in e.data?e.data.properties:{},caipNetworkId:n}}}),Ye.reportedErrors.FORBIDDEN=!1,X.shouldFlushEvents()&&X._submitPendingEvents()}catch(t){console.warn("_setPendingEvent",t)}},sendEvent(e){Ye.timestamp=Date.now(),Ye.data=e;const t=["INITIALIZE","CONNECT_SUCCESS","SOCIAL_LOGIN_SUCCESS"];(R.state.features?.analytics||t.includes(e.event))&&X._setPendingEvent(Ye),this.subscribeToFlushTriggers()},sendWalletImpressionEvent(e){Ye.walletImpressions.push(e)},_transformPendingEventsForBatch(e){try{return e.filter(t=>t.props.event!=="WALLET_IMPRESSION_V2")}catch{return e}},_submitPendingEvents(){if(Ye.lastFlush=Date.now(),!(Ye.pendingEvents.length===0&&Ye.walletImpressions.length===0))try{const e=X._transformPendingEventsForBatch(Ye.pendingEvents);Ye.walletImpressions.length&&e.push({eventId:L.getUUID(),url:window.location.href,domain:window.location.hostname,timestamp:Date.now(),props:{type:"track",event:"WALLET_IMPRESSION_V2",items:[...Ye.walletImpressions]}}),h2.sendBeacon({path:"/batch",params:X.getSdkProperties(),body:e}),Ye.reportedErrors.FORBIDDEN=!1,Ye.pendingEvents=[],Ye.walletImpressions=[]}catch{Ye.reportedErrors.FORBIDDEN=!0}},subscribeToFlushTriggers(){Ye.subscribedToVisibilityChange||typeof document>"u"||(Ye.subscribedToVisibilityChange=!0,document?.addEventListener?.("visibilitychange",()=>{document.visibilityState==="hidden"&&X._submitPendingEvents()}),document?.addEventListener?.("freeze",()=>{X._submitPendingEvents()}),window?.addEventListener?.("pagehide",()=>{X._submitPendingEvents()}),setInterval(()=>{X._submitPendingEvents()},Uu))}},m2=L.getApiUrl(),Ct=new Bs({baseUrl:m2,clientId:null}),g2=40,Bu=4,w2=20,Ce=ze({promises:{},page:1,count:0,featured:[],allFeatured:[],recommended:[],allRecommended:[],wallets:[],filteredWallets:[],search:[],isAnalyticsEnabled:!1,excludedWallets:[],isFetchingRecommendedWallets:!1,explorerWallets:[],explorerFilteredWallets:[],plan:{tier:"none",hasExceededUsageLimit:!1,limits:{isAboveRpcLimit:!1,isAboveMauLimit:!1}}}),q={state:Ce,subscribeKey(e,t){return st(Ce,e,t)},_getSdkProperties(){const{projectId:e,sdkType:t,sdkVersion:n}=R.state;return{projectId:e,st:t||"appkit",sv:n||"html-wagmi-4.2.2"}},_filterOutExtensions(e){return R.state.isUniversalProvider?e.filter(t=>!!(t.mobile_link||t.desktop_link||t.webapp_link)):e},async _fetchWalletImage(e){const t=`${Ct.baseUrl}/getWalletImage/${e}`,n=await Ct.getBlob({path:t,params:q._getSdkProperties()});rt.setWalletImage(e,URL.createObjectURL(n))},async _fetchNetworkImage(e){const t=`${Ct.baseUrl}/public/getAssetImage/${e}`,n=await Ct.getBlob({path:t,params:q._getSdkProperties()});rt.setNetworkImage(e,URL.createObjectURL(n))},async _fetchConnectorImage(e){const t=`${Ct.baseUrl}/public/getAssetImage/${e}`,n=await Ct.getBlob({path:t,params:q._getSdkProperties()});rt.setConnectorImage(e,URL.createObjectURL(n))},async _fetchCurrencyImage(e){const t=`${Ct.baseUrl}/public/getCurrencyImage/${e}`,n=await Ct.getBlob({path:t,params:q._getSdkProperties()});rt.setCurrencyImage(e,URL.createObjectURL(n))},async _fetchTokenImage(e){const t=`${Ct.baseUrl}/public/getTokenImage/${e}`,n=await Ct.getBlob({path:t,params:q._getSdkProperties()});rt.setTokenImage(e,URL.createObjectURL(n))},_filterWalletsByPlatform(e){const t=e.length,n=L.isMobile()?e?.filter(o=>o.mobile_link||o.webapp_link?!0:Object.values(Gt).map(s=>s.id).includes(o.id)):e,r=t-n.length;return{filteredWallets:n,mobileFilteredOutWalletsLength:r}},async fetchProjectConfig(){return(await Ct.get({path:"/appkit/v1/config",params:q._getSdkProperties()})).features},async fetchUsage(){try{const e=await Ct.get({path:"/appkit/v1/project-limits",params:q._getSdkProperties()}),{tier:t,isAboveMauLimit:n,isAboveRpcLimit:r}=e.planLimits,o=t==="starter",i=n||r;q.state.plan={tier:t,hasExceededUsageLimit:o&&i,limits:{isAboveRpcLimit:r,isAboveMauLimit:n}}}catch(e){console.warn("Failed to fetch usage",e)}},async fetchAllowedOrigins(){try{const{allowedOrigins:e}=await Ct.get({path:"/projects/v1/origins",params:q._getSdkProperties()});return e}catch(e){if(e instanceof Error&&e.cause instanceof Response){const t=e.cause.status;if(t===N.HTTP_STATUS_CODES.TOO_MANY_REQUESTS)throw new Error("RATE_LIMITED",{cause:e});if(t>=N.HTTP_STATUS_CODES.SERVER_ERROR&&t<600)throw new Error("SERVER_ERROR",{cause:e});return[]}return[]}},async fetchNetworkImages(){const t=p.getAllRequestedCaipNetworks()?.map(({assets:n})=>n?.imageId).filter(Boolean).filter(n=>!De.getNetworkImageById(n));t&&await Promise.allSettled(t.map(n=>q._fetchNetworkImage(n)))},async fetchConnectorImages(){const{connectors:e}=O.state,t=e.map(({imageId:n})=>n).filter(Boolean);await Promise.allSettled(t.map(n=>q._fetchConnectorImage(n)))},async fetchCurrencyImages(e=[]){await Promise.allSettled(e.map(t=>q._fetchCurrencyImage(t)))},async fetchTokenImages(e=[]){await Promise.allSettled(e.map(t=>q._fetchTokenImage(t)))},async fetchWallets(e){const t=e.exclude??[];q._getSdkProperties().sv.startsWith("html-core-")&&t.push(...Object.values(Gt).map(s=>s.id));const r=await Ct.get({path:"/getWallets",params:{...q._getSdkProperties(),...e,page:String(e.page),entries:String(e.entries),include:e.include?.join(","),exclude:t.join(",")}}),{filteredWallets:o,mobileFilteredOutWalletsLength:i}=q._filterWalletsByPlatform(r?.data);return{data:o||[],count:r?.count,mobileFilteredOutWalletsLength:i}},async prefetchWalletRanks(){const e=O.state.connectors;if(!e?.length)return;const t={page:1,entries:20,badge:"certified"};if(t.names=e.map(o=>o.name).join(","),p.state.activeChain===N.CHAIN.EVM){const o=[...e.flatMap(i=>i.connectors?.map(s=>s.info?.rdns)||[]),...e.map(i=>i.info?.rdns)].filter(i=>typeof i=="string"&&i.length>0);o.length&&(t.rdns=o.join(","))}const{data:n}=await q.fetchWallets(t);Ce.explorerWallets=n,O.extendConnectorsWithExplorerWallets(n);const r=p.getRequestedCaipNetworkIds().join(",");Ce.explorerFilteredWallets=n.filter(o=>o.chains?.some(i=>r.includes(i)))},async fetchFeaturedWallets(){const{featuredWalletIds:e}=R.state;if(e?.length){const t={...q._getSdkProperties(),page:1,entries:e?.length??Bu,include:e},{data:n}=await q.fetchWallets(t),r=[...n].sort((i,s)=>e.indexOf(i.id)-e.indexOf(s.id)),o=r.map(i=>i.image_id).filter(Boolean);await Promise.allSettled(o.map(i=>q._fetchWalletImage(i))),Ce.featured=r,Ce.allFeatured=r}},async fetchRecommendedWallets(){try{Ce.isFetchingRecommendedWallets=!0;const{includeWalletIds:e,excludeWalletIds:t,featuredWalletIds:n}=R.state,r=[...t??[],...n??[]].filter(Boolean),o=p.getRequestedCaipNetworkIds().join(","),i={page:1,entries:Bu,include:e,exclude:r,chains:o},{data:s,count:a}=await q.fetchWallets(i),c=G.getRecentWallets(),l=s.map(h=>h.image_id).filter(Boolean),d=c.map(h=>h.image_id).filter(Boolean);await Promise.allSettled([...l,...d].map(h=>q._fetchWalletImage(h))),Ce.recommended=s,Ce.allRecommended=s,Ce.count=a??0}catch{}finally{Ce.isFetchingRecommendedWallets=!1}},async fetchWalletsByPage({page:e}){const{includeWalletIds:t,excludeWalletIds:n,featuredWalletIds:r}=R.state,o=p.getRequestedCaipNetworkIds().join(","),i=[...Ce.recommended.map(({id:h})=>h),...n??[],...r??[]].filter(Boolean),s={page:e,entries:g2,include:t,exclude:i,chains:o},{data:a,count:c,mobileFilteredOutWalletsLength:l}=await q.fetchWallets(s);Ce.mobileFilteredOutWalletsLength=l+(Ce.mobileFilteredOutWalletsLength??0);const d=a.slice(0,w2).map(h=>h.image_id).filter(Boolean);await Promise.allSettled(d.map(h=>q._fetchWalletImage(h))),Ce.wallets=L.uniqueBy([...Ce.wallets,...q._filterOutExtensions(a)],"id").filter(h=>h.chains?.some(f=>o.includes(f))),Ce.count=c>Ce.count?c:Ce.count,Ce.page=e},async initializeExcludedWallets({ids:e}){const t={page:1,entries:e.length,include:e},{data:n}=await q.fetchWallets(t);n&&n.forEach(r=>{Ce.excludedWallets.push({rdns:r.rdns,name:r.name})})},async searchWallet({search:e,badge:t}){const{includeWalletIds:n,excludeWalletIds:r}=R.state,o=p.getRequestedCaipNetworkIds().join(",");Ce.search=[];const i={page:1,entries:100,search:e?.trim(),badge_type:t,include:n,exclude:r,chains:o},{data:s}=await q.fetchWallets(i);X.sendEvent({type:"track",event:"SEARCH_WALLET",properties:{badge:t??"",search:e??""}});const a=s.map(c=>c.image_id).filter(Boolean);await Promise.allSettled([...a.map(c=>q._fetchWalletImage(c)),L.wait(300)]),Ce.search=q._filterOutExtensions(s)},initPromise(e,t){const n=Ce.promises[e];return n||(Ce.promises[e]=t())},prefetch({fetchConnectorImages:e=!0,fetchFeaturedWallets:t=!0,fetchRecommendedWallets:n=!0,fetchNetworkImages:r=!0,fetchWalletRanks:o=!0}={}){const i=[e&&q.initPromise("connectorImages",q.fetchConnectorImages),t&&q.initPromise("featuredWallets",q.fetchFeaturedWallets),n&&q.initPromise("recommendedWallets",q.fetchRecommendedWallets),r&&q.initPromise("networkImages",q.fetchNetworkImages),o&&q.initPromise("walletRanks",q.prefetchWalletRanks)].filter(Boolean);return Promise.allSettled(i)},prefetchAnalyticsConfig(){R.state.features?.analytics&&q.fetchAnalyticsConfig()},async fetchAnalyticsConfig(){try{const{isAnalyticsEnabled:e}=await Ct.get({path:"/getAnalyticsConfig",params:q._getSdkProperties()});R.setFeatures({analytics:e})}catch{R.setFeatures({analytics:!1})}},filterByNamespaces(e){if(!e?.length){Ce.featured=Ce.allFeatured,Ce.recommended=Ce.allRecommended;return}const t=p.getRequestedCaipNetworkIds().join(",");Ce.featured=Ce.allFeatured.filter(n=>n.chains?.some(r=>t.includes(r))),Ce.recommended=Ce.allRecommended.filter(n=>n.chains?.some(r=>t.includes(r))),Ce.filteredWallets=Ce.wallets.filter(n=>n.chains?.some(r=>t.includes(r)))},clearFilterByNamespaces(){Ce.filteredWallets=[]},setFilterByNamespace(e){if(!e){Ce.featured=Ce.allFeatured,Ce.recommended=Ce.allRecommended;return}const t=p.getRequestedCaipNetworkIds().join(",");Ce.featured=Ce.allFeatured.filter(n=>n.chains?.some(r=>t.includes(r))),Ce.recommended=Ce.allRecommended.filter(n=>n.chains?.some(r=>t.includes(r))),Ce.filteredWallets=Ce.wallets.filter(n=>n.chains?.some(r=>t.includes(r)))}},Xt={filterOutDuplicatesByRDNS(e){const t=R.state.enableEIP6963?O.state.connectors:[],n=G.getRecentWallets(),r=t.map(a=>a.info?.rdns).filter(Boolean),o=n.map(a=>a.rdns).filter(Boolean),i=r.concat(o);if(i.includes("io.metamask.mobile")&&L.isMobile()){const a=i.indexOf("io.metamask.mobile");i[a]="io.metamask"}return e.filter(a=>!(a?.rdns&&i.includes(String(a.rdns))||!a?.rdns&&t.some(l=>l.name===a.name)))},filterOutDuplicatesByIds(e){const t=O.state.connectors.filter(a=>a.type==="ANNOUNCED"||a.type==="INJECTED"||a.type==="MULTI_CHAIN"),n=G.getRecentWallets(),r=t.map(a=>a.explorerId||a.explorerWallet?.id||a.id),o=n.map(a=>a.id),i=r.concat(o);return e.filter(a=>!i.includes(a?.id))},filterOutDuplicateWallets(e){const t=this.filterOutDuplicatesByRDNS(e);return this.filterOutDuplicatesByIds(t)},markWalletsAsInstalled(e){const{connectors:t}=O.state,{featuredWalletIds:n}=R.state,r=t.filter(s=>s.type==="ANNOUNCED").reduce((s,a)=>(a.info?.rdns&&(s[a.info.rdns]=!0),s),{});return e.map(s=>({...s,installed:!!s.rdns&&!!r[s.rdns??""]})).sort((s,a)=>{const c=Number(a.installed)-Number(s.installed);if(c!==0)return c;if(n?.length){const l=n.indexOf(s.id),d=n.indexOf(a.id);if(l!==-1&&d!==-1)return l-d;if(l!==-1)return-1;if(d!==-1)return 1}return 0})},getConnectOrderMethod(e,t){const n=e?.connectMethodsOrder||R.state.features?.connectMethodsOrder,r=t||O.state.connectors;if(n)return n;const{injected:o,announced:i}=dt.getConnectorsByType(r,q.state.recommended,q.state.featured),s=o.filter(dt.showConnector),a=i.filter(dt.showConnector);return s.length||a.length?["wallet","email","social"]:ke.DEFAULT_CONNECT_METHOD_ORDER},isExcluded(e){const t=!!e.rdns&&q.state.excludedWallets.some(r=>r.rdns===e.rdns),n=!!e.name&&q.state.excludedWallets.some(r=>vp.isLowerCaseMatch(r.name,e.name));return t||n},markWalletsWithDisplayIndex(e){return e.map((t,n)=>({...t,display_index:n}))},filterWalletsByWcSupport(e){return U.state.wcBasic?e.filter(t=>t.supports_wc):L.isMobile()?e.filter(t=>t.supports_wc||ke.MANDATORY_WALLET_IDS_ON_MOBILE.includes(t.id)):e},getWalletConnectWallets(e){const t=[...q.state.featured,...q.state.recommended];q.state.filteredWallets?.length>0?t.push(...q.state.filteredWallets):t.push(...e);const n=L.uniqueBy(t,"id"),r=Xt.markWalletsAsInstalled(n),o=Xt.filterWalletsByWcSupport(r);return Xt.markWalletsWithDisplayIndex(o)}},dt={getConnectorsByType(e,t,n){const{customWallets:r}=R.state,o=G.getRecentWallets(),i=Xt.filterOutDuplicateWallets(t),s=Xt.filterOutDuplicateWallets(n),a=e.filter(h=>h.type==="MULTI_CHAIN"),c=e.filter(h=>h.type==="ANNOUNCED"),l=e.filter(h=>h.type==="INJECTED"),d=e.filter(h=>h.type==="EXTERNAL");return{custom:r,recent:o,external:d,multiChain:a,announced:c,injected:l,recommended:i,featured:s}},showConnector(e){const t=e.info?.rdns,n=!!t&&q.state.excludedWallets.some(o=>!!o.rdns&&o.rdns===t),r=!!e.name&&q.state.excludedWallets.some(o=>vp.isLowerCaseMatch(o.name,e.name));return!(e.type==="INJECTED"&&(e.name==="Browser Wallet"&&(!L.isMobile()||L.isMobile()&&!t&&!U.checkInstalled())||n||r)||(e.type==="ANNOUNCED"||e.type==="EXTERNAL")&&(n||r))},getIsConnectedWithWC(){return Array.from(p.state.chains.values()).some(n=>O.getConnectorId(n.namespace)===N.CONNECTOR_ID.WALLET_CONNECT)},getConnectorTypeOrder({recommended:e,featured:t,custom:n,recent:r,announced:o,injected:i,multiChain:s,external:a,overriddenConnectors:c=R.state.features?.connectorTypeOrder??[]}){const d=[{type:"walletConnect",isEnabled:!0},{type:"recent",isEnabled:r.length>0},{type:"injected",isEnabled:[...i,...o,...s].length>0},{type:"featured",isEnabled:t.length>0},{type:"custom",isEnabled:n&&n.length>0},{type:"external",isEnabled:a.length>0},{type:"recommended",isEnabled:e.length>0}].filter(v=>v.isEnabled),h=new Set(d.map(v=>v.type)),f=c.filter(v=>h.has(v)).map(v=>({type:v,isEnabled:!0})),w=d.filter(({type:v})=>!f.some(({type:$})=>$===v));return Array.from(new Set([...f,...w].map(({type:v})=>v)))},sortConnectorsByExplorerWallet(e){return[...e].sort((t,n)=>t.explorerWallet&&n.explorerWallet?(t.explorerWallet.order??0)-(n.explorerWallet.order??0):t.explorerWallet?-1:n.explorerWallet?1:0)},getPriority(e){return e.id===N.CONNECTOR_ID.BASE_ACCOUNT?0:e.id===N.CONNECTOR_ID.COINBASE||e.id===N.CONNECTOR_ID.COINBASE_SDK?1:2},sortConnectorsByPriority(e){return[...e].sort((t,n)=>dt.getPriority(t)-dt.getPriority(n))},getAuthName({email:e,socialUsername:t,socialProvider:n}){return t?n&&n==="discord"&&t.endsWith("0")?t.slice(0,-1):t:e.length>30?`${e.slice(0,-3)}...`:e},async fetchProviderData(e){try{if(e.name==="Browser Wallet"&&!L.isMobile())return{accounts:[],chainId:void 0};if(e.id===N.CONNECTOR_ID.AUTH)return{accounts:[],chainId:void 0};const[t,n]=await Promise.all([e.provider?.request({method:"eth_accounts"}),e.provider?.request({method:"eth_chainId"}).then(r=>Number(r))]);return{accounts:t,chainId:n}}catch(t){return console.warn(`Failed to fetch provider data for ${e.name}`,t),{accounts:[],chainId:void 0}}},getFilteredCustomWallets(e){const t=G.getRecentWallets(),n=O.state.connectors.map(s=>s.info?.rdns).filter(Boolean),r=t.map(s=>s.rdns).filter(Boolean),o=n.concat(r);if(o.includes("io.metamask.mobile")&&L.isMobile()){const s=o.indexOf("io.metamask.mobile");o[s]="io.metamask"}return e.filter(s=>!o.includes(String(s?.rdns)))},hasWalletConnector(e){return O.state.connectors.some(t=>t.id===e.id||t.name===e.name)},isWalletCompatibleWithCurrentChain(e){const t=p.state.activeChain;return t&&e.chains?e.chains.some(n=>{const r=n.split(":")[0];return t===r}):!0},getFilteredRecentWallets(){return G.getRecentWallets().filter(n=>!Xt.isExcluded(n)).filter(n=>!this.hasWalletConnector(n)).filter(n=>this.isWalletCompatibleWithCurrentChain(n))},getCappedRecommendedWallets(e){const{connectors:t}=O.state,{customWallets:n,featuredWalletIds:r}=R.state,o=t.find(k=>k.id==="walletConnect"),i=t.filter(k=>k.type==="INJECTED"||k.type==="ANNOUNCED"||k.type==="MULTI_CHAIN");if(!o&&!i.length&&!n?.length)return[];const s=Gl.isEmailEnabled(),a=Gl.isSocialsEnabled(),c=i.filter(k=>k.name!=="Browser Wallet"&&k.name!=="WalletConnect"),l=r?.length||0,d=n?.length||0,h=c.length||0,f=s?1:0,w=a?1:0,v=l+d+h+f+w,$=Math.max(0,4-v);return $<=0?[]:Xt.filterOutDuplicateWallets(e).slice(0,$)},processConnectorsByType(e,t=!0){const n=dt.sortConnectorsByExplorerWallet([...e]);return t?n.filter(dt.showConnector):n},connectorList(){const e=dt.getConnectorsByType(O.state.connectors,q.state.recommended,q.state.featured),t=this.processConnectorsByType(e.announced.filter(w=>w.id!=="walletConnect")),n=this.processConnectorsByType(e.injected),r=this.processConnectorsByType(e.multiChain.filter(w=>w.name!=="WalletConnect"),!1),o=e.custom,i=e.recent,s=this.processConnectorsByType(e.external.filter(w=>w.id!==N.CONNECTOR_ID.COINBASE_SDK&&w.id!==N.CONNECTOR_ID.BASE_ACCOUNT)),a=e.recommended,c=e.featured,l=dt.getConnectorTypeOrder({custom:o,recent:i,announced:t,injected:n,multiChain:r,recommended:a,featured:c,external:s}),d=O.state.connectors.find(w=>w.id==="walletConnect"),h=L.isMobile(),f=[];for(const w of l)switch(w){case"walletConnect":{!h&&d&&f.push({kind:"connector",subtype:"walletConnect",connector:d});break}case"recent":{dt.getFilteredRecentWallets().forEach(y=>f.push({kind:"wallet",subtype:"recent",wallet:y}));break}case"injected":{r.forEach(v=>f.push({kind:"connector",subtype:"multiChain",connector:v})),t.forEach(v=>f.push({kind:"connector",subtype:"announced",connector:v})),n.forEach(v=>f.push({kind:"connector",subtype:"injected",connector:v}));break}case"featured":{c.forEach(v=>f.push({kind:"wallet",subtype:"featured",wallet:v}));break}case"custom":{dt.getFilteredCustomWallets(o??[]).forEach(y=>f.push({kind:"wallet",subtype:"custom",wallet:y}));break}case"external":{s.forEach(v=>f.push({kind:"connector",subtype:"external",connector:v}));break}case"recommended":{dt.getCappedRecommendedWallets(a).forEach(y=>f.push({kind:"wallet",subtype:"recommended",wallet:y}));break}default:console.warn(`Unknown connector type: ${w}`)}return f},hasInjectedConnectors(){return O.state.connectors.filter(e=>(e.type==="INJECTED"||e.type==="ANNOUNCED"||e.type==="MULTI_CHAIN")&&e.name!=="Browser Wallet"&&e.name!=="WalletConnect").length}},b2=["ConnectingExternal","ConnectingMultiChain","ConnectingSocial","ConnectingFarcaster"],Le=ze({view:"Connect",history:["Connect"],transactionStack:[]}),y2={state:Le,subscribeKey(e,t){return st(Le,e,t)},pushTransactionStack(e){Le.transactionStack.push(e)},popTransactionStack(e){const t=Le.transactionStack.pop();if(!t)return;const{onSuccess:n,onError:r,onCancel:o}=t;switch(e){case"success":n?.();break;case"error":r?.(),S.goBack();break;case"cancel":o?.(),S.goBack();break}},push(e,t){let n=e,r=t;q.state.plan.hasExceededUsageLimit&&b2.includes(e)&&(n="UsageExceeded",r=void 0),n!==Le.view&&(Le.view=n,Le.history.push(n),Le.data=r)},reset(e,t){Le.view=e,Le.history=[e],Le.data=t},replace(e,t){Le.history.at(-1)===e||(Le.view=e,Le.history[Le.history.length-1]=e,Le.data=t)},goBack(){const e=p.state.activeCaipAddress,t=S.state.view==="ConnectingFarcaster",n=!e&&t;if(Le.history.length>1){Le.history.pop();const[r]=Le.history.slice(-1);r&&(e&&r==="Connect"?Le.view="Account":Le.view=r)}else ye.close();Le.data?.wallet&&(Le.data.wallet=void 0),Le.data?.redirectView&&(Le.data.redirectView=void 0),setTimeout(()=>{if(n){p.setAccountProp("farcasterUrl",void 0,p.state.activeChain);const r=O.getAuthConnector();r?.provider?.reload();const o=Wo(R.state);r?.provider?.syncDappData?.({metadata:o.metadata,sdkVersion:o.sdkVersion,projectId:o.projectId,sdkType:o.sdkType})}},100)},goBackToIndex(e){if(Le.history.length>1){Le.history=Le.history.slice(0,e+1);const[t]=Le.history.slice(-1);t&&(Le.view=t)}},goBackOrCloseModal(){S.state.history.length>1?S.goBack():ye.close()}},S=gn(y2),Fn=ze({themeMode:"dark",themeVariables:{},w3mThemeVariables:void 0}),Zl={state:Fn,subscribe(e){return ot(Fn,()=>e(Fn))},setThemeMode(e){Fn.themeMode=e;try{const t=O.getAuthConnector();if(t){const n=Zl.getSnapshot().themeVariables;t.provider.syncTheme({themeMode:e,themeVariables:n,w3mThemeVariables:Da(n,e)})}}catch{console.info("Unable to sync theme to auth connector")}},setThemeVariables(e){Fn.themeVariables={...Fn.themeVariables,...e};try{const t=O.getAuthConnector();if(t){const n=Zl.getSnapshot().themeVariables;t.provider.syncTheme({themeVariables:n,w3mThemeVariables:Da(Fn.themeVariables,Fn.themeMode)})}}catch{console.info("Unable to sync theme to auth connector")}},getSnapshot(){return Wo(Fn)}},fr=gn(Zl),Gp=Object.fromEntries(Ep.map(e=>[e,void 0])),C2=Object.fromEntries(Ep.map(e=>[e,!0])),Ie=ze({allConnectors:[],connectors:[],activeConnector:void 0,filterByNamespace:void 0,activeConnectorIds:Gp,filterByNamespaceMap:C2}),v2={state:Ie,subscribe(e){return ot(Ie,()=>{e(Ie)})},subscribeKey(e,t){return st(Ie,e,t)},initialize(e){e.forEach(t=>{const n=G.getConnectedConnectorId(t);n&&O.setConnectorId(n,t)})},setActiveConnector(e){e&&(Ie.activeConnector=Yi(e))},setConnectors(e){e.filter(o=>!Ie.allConnectors.some(i=>i.id===o.id&&O.getConnectorName(i.name)===O.getConnectorName(o.name)&&i.chain===o.chain)).forEach(o=>{o.type!=="MULTI_CHAIN"&&Ie.allConnectors.push(Yi(o))});const n=O.getEnabledNamespaces(),r=O.getEnabledConnectors(n);Ie.connectors=O.mergeMultiChainConnectors(r)},filterByNamespaces(e){Object.keys(Ie.filterByNamespaceMap).forEach(t=>{Ie.filterByNamespaceMap[t]=!1}),e.forEach(t=>{Ie.filterByNamespaceMap[t]=!0}),O.updateConnectorsForEnabledNamespaces()},filterByNamespace(e,t){Ie.filterByNamespaceMap[e]=t,O.updateConnectorsForEnabledNamespaces()},updateConnectorsForEnabledNamespaces(){const e=O.getEnabledNamespaces(),t=O.getEnabledConnectors(e),n=O.areAllNamespacesEnabled();Ie.connectors=O.mergeMultiChainConnectors(t),n?q.clearFilterByNamespaces():q.filterByNamespaces(e)},getEnabledNamespaces(){return Object.entries(Ie.filterByNamespaceMap).filter(([e,t])=>t).map(([e])=>e)},getEnabledConnectors(e){return Ie.allConnectors.filter(t=>e.includes(t.chain))},areAllNamespacesEnabled(){return Object.values(Ie.filterByNamespaceMap).every(e=>e)},mergeMultiChainConnectors(e){const t=O.generateConnectorMapByName(e),n=[];return t.forEach(r=>{const o=r[0],i=o?.id===N.CONNECTOR_ID.AUTH;r.length>1&&o?n.push({name:o.name,imageUrl:o.imageUrl,imageId:o.imageId,connectors:[...r],type:i?"AUTH":"MULTI_CHAIN",chain:"eip155",id:o?.id||""}):o&&n.push(o)}),n},generateConnectorMapByName(e){const t=new Map;return e.forEach(n=>{const{name:r}=n,o=O.getConnectorName(r);if(!o)return;const i=t.get(o)||[];i.find(a=>a.chain===n.chain)||i.push(n),t.set(o,i)}),t},getConnectorName(e){return e&&({"Trust Wallet":"Trust"}[e]||e)},getUniqueConnectorsByName(e){const t=[];return e.forEach(n=>{t.find(r=>r.chain===n.chain)||t.push(n)}),t},addConnector(e){if(e.id===N.CONNECTOR_ID.AUTH){const t=e,n=Wo(R.state),r=fr.getSnapshot().themeMode,o=fr.getSnapshot().themeVariables;t?.provider?.syncDappData?.({metadata:n.metadata,sdkVersion:n.sdkVersion,projectId:n.projectId,sdkType:n.sdkType}),t?.provider?.syncTheme({themeMode:r,themeVariables:o,w3mThemeVariables:Da(o,r)}),O.setConnectors([e])}else O.setConnectors([e])},getAuthConnector(e){const t=e||p.state.activeChain,n=Ie.connectors.find(r=>r.id===N.CONNECTOR_ID.AUTH);if(n)return n?.connectors?.length?n.connectors.find(o=>o.chain===t):n},getAnnouncedConnectorRdns(){return Ie.connectors.filter(e=>e.type==="ANNOUNCED").map(e=>e.info?.rdns)},getConnectorById(e){return dt.sortConnectorsByPriority(Ie.allConnectors).find(n=>n.id===e)},getConnector({id:e,namespace:t}){const n=t||p.state.activeChain,r=Ie.allConnectors.filter(s=>s.chain===n);return dt.sortConnectorsByPriority(r).find(s=>s.id===e||s.explorerId===e)},syncIfAuthConnector(e){if(e.id!=="AUTH")return;const t=e,n=Wo(R.state),r=fr.getSnapshot().themeMode,o=fr.getSnapshot().themeVariables;t?.provider?.syncDappData?.({metadata:n.metadata,sdkVersion:n.sdkVersion,sdkType:n.sdkType,projectId:n.projectId}),t.provider.syncTheme({themeMode:r,themeVariables:o,w3mThemeVariables:Da(o,r)})},getConnectorsByNamespace(e){const t=Ie.allConnectors.filter(n=>n.chain===e);return O.mergeMultiChainConnectors(t)},canSwitchToSmartAccount(e){return p.checkIfSmartAccountEnabled()&&ut(e)===je.ACCOUNT_TYPES.EOA},selectWalletConnector(e){const t=S.state.data?.redirectView,n=p.state.activeChain,r=n?O.getConnector({id:e.id,namespace:n}):void 0;d2.handleMobileDeeplinkRedirect(r?.explorerId||e.id,p.state.activeChain),r?S.push("ConnectingExternal",{connector:r,wallet:e,redirectView:t}):S.push("ConnectingWalletConnect",{wallet:e,redirectView:t})},getConnectors(e){return e?O.getConnectorsByNamespace(e):O.mergeMultiChainConnectors(Ie.allConnectors)},setFilterByNamespace(e){Ie.filterByNamespace=e,Ie.connectors=O.getConnectors(e),q.setFilterByNamespace(e)},setConnectorId(e,t){e&&(Ie.activeConnectorIds={...Ie.activeConnectorIds,[t]:e},G.setConnectedConnectorId(t,e))},removeConnectorId(e){Ie.activeConnectorIds={...Ie.activeConnectorIds,[e]:void 0},G.deleteConnectedConnectorId(e)},getConnectorId(e){if(e)return Ie.activeConnectorIds[e]},isConnected(e){return e?!!Ie.activeConnectorIds[e]:Object.values(Ie.activeConnectorIds).some(t=>!!t)},resetConnectorIds(){Ie.activeConnectorIds={...Gp}},extendConnectorsWithExplorerWallets(e){Ie.allConnectors.forEach(r=>{const o=e.find(i=>i.id===r.id||i.rdns&&i.rdns===r.info?.rdns);o&&(r.explorerWallet=o)});const t=O.getEnabledNamespaces(),n=O.getEnabledConnectors(t);Ie.connectors=O.mergeMultiChainConnectors(n)},async connect(e={}){const{namespace:t}=e;return O.setFilterByNamespace(t),S.push("Connect",{addWalletForNamespace:t}),new Promise((n,r)=>{if(t){const o=p.subscribeChainProp("accountState",s=>{s?.caipAddress&&(n({caipAddress:s?.caipAddress}),o())},t),i=ye.subscribeKey("open",s=>{s||(r(new Error("Modal closed")),i())})}else{const o=p.subscribeKey("activeCaipAddress",s=>{s&&(n({caipAddress:s}),o())}),i=ye.subscribeKey("open",s=>{s||(r(new Error("Modal closed")),i())})}})}},O=gn(v2),E2=1e3,So={checkNamespaceConnectorId(e,t){return O.getConnectorId(e)===t},isSocialProvider(e){return ke.DEFAULT_REMOTE_FEATURES.socials.includes(e)},connectWalletConnect({walletConnect:e,connector:t,closeModalOnConnect:n=!0,redirectViewOnModalClose:r="Connect",onOpen:o,onConnect:i}){return new Promise((s,a)=>{if(e&&O.setActiveConnector(t),o?.(L.isMobile()&&e),r){const l=ye.subscribeKey("open",d=>{d||(S.state.view!==r&&S.replace(r),l(),a(new Error("Modal closed")))})}const c=p.subscribeKey("activeCaipAddress",l=>{l&&(i?.(),n&&ye.close(),c(),s(Jt.parseCaipAddress(l)))})})},connectExternal(e){return new Promise((t,n)=>{const r=p.subscribeKey("activeCaipAddress",o=>{o&&(ye.close(),r(),t(Jt.parseCaipAddress(o)))});U.connectExternal(e,e.chain).catch(()=>{r(),n(new Error("Connection rejected"))})})},connectSocial({social:e,namespace:t,closeModalOnConnect:n=!0,onOpenFarcaster:r,onConnect:o}){let i,s=!1,a=null;const c=t||p.state.activeChain,l=p.subscribeKey("activeCaipAddress",d=>{d&&(n&&ye.close(),l())});return new Promise((d,h)=>{async function f(v){if(v.data?.resultUri)if(v.origin===N.SECURE_SITE_SDK_ORIGIN){window.removeEventListener("message",f,!1);try{const y=O.getAuthConnector(c);if(y&&!s){i&&i.close(),s=!0;const $=v.data.resultUri;X.sendEvent({type:"track",event:"SOCIAL_LOGIN_REQUEST_USER_DATA",properties:{provider:e}}),G.setConnectedSocialProvider(e),await U.connectExternal({id:y.id,type:y.type,socialUri:$},y.chain);const I=p.state.activeCaipAddress;if(!I){h(new Error("Failed to connect"));return}d(Jt.parseCaipAddress(I)),X.sendEvent({type:"track",event:"SOCIAL_LOGIN_SUCCESS",properties:{provider:e}})}}catch(y){X.sendEvent({type:"track",event:"SOCIAL_LOGIN_ERROR",properties:{provider:e,message:L.parseError(y)}}),h(new Error("Failed to connect"))}}else X.sendEvent({type:"track",event:"SOCIAL_LOGIN_ERROR",properties:{provider:e,message:"Untrusted Origin"}})}async function w(){if(X.sendEvent({type:"track",event:"SOCIAL_LOGIN_STARTED",properties:{provider:e}}),e==="farcaster"){r?.();const v=ye.subscribeKey("open",$=>{!$&&e==="farcaster"&&(h(new Error("Popup closed")),o?.(),v())}),y=O.getAuthConnector();if(y&&!p.getAccountData(c)?.farcasterUrl)try{const{url:I}=await y.provider.getFarcasterUri();p.setAccountProp("farcasterUrl",I,c)}catch{h(new Error("Failed to connect to farcaster"))}}else{const v=O.getAuthConnector();a=L.returnOpenHref(`${N.SECURE_SITE_SDK_ORIGIN}/loading`,"popupWindow","width=600,height=800,scrollbars=yes");try{if(v){const{uri:y}=await v.provider.getSocialRedirectUri({provider:e});if(a&&y){a.location.href=y,i=a;const $=setInterval(()=>{i?.closed&&!s&&(h(new Error("Popup closed")),clearInterval($))},1e3);window.addEventListener("message",f,!1)}else a?.close(),h(new Error("Failed to initiate social connection"))}}catch{h(new Error("Failed to initiate social connection")),a?.close()}}}w()})},connectEmail({closeModalOnConnect:e=!0,redirectViewOnModalClose:t="Connect",onOpen:n,onConnect:r}){return new Promise((o,i)=>{if(n?.(),t){const a=ye.subscribeKey("open",c=>{c||(S.state.view!==t&&S.replace(t),a(),i(new Error("Modal closed")))})}const s=p.subscribeKey("activeCaipAddress",a=>{a&&(r?.(),e&&ye.close(),s(),o(Jt.parseCaipAddress(a)))})})},async updateEmail(){const e=G.getConnectedConnectorId(p.state.activeChain),t=O.getAuthConnector();if(!t)throw new Error("No auth connector found");if(e!==N.CONNECTOR_ID.AUTH)throw new Error("Not connected to email or social");const n=t.provider.getEmail()??"";return await ye.open({view:"UpdateEmailWallet",data:{email:n,redirectView:void 0}}),new Promise((r,o)=>{const i=setInterval(()=>{const a=t.provider.getEmail()??"";a!==n&&(ye.close(),clearInterval(i),s(),r({email:a}))},E2),s=ye.subscribeKey("open",a=>{a||(S.state.view!=="Connect"&&S.push("Connect"),clearInterval(i),s(),o(new Error("Modal closed")))})})},canSwitchToSmartAccount(e){return p.checkIfSmartAccountEnabled()&&ut(e)===je.ACCOUNT_TYPES.EOA}};function Za(){const e=p.state.activeCaipNetwork?.chainNamespace||"eip155",t=p.state.activeCaipNetwork?.id||1,n=ke.NATIVE_TOKEN_ADDRESS[e];return`${e}:${t}:${n}`}function Av(e){return ke.NATIVE_TOKEN_ADDRESS[e]}function ut(e){return p.getAccountData(e)?.preferredAccountType}function ma(e){return e?p.state.chains.get(e)?.networkState?.caipNetwork:p.state.activeCaipNetwork}const dn={getConnectionStatus(e,t){const n=O.state.activeConnectorIds[t],r=U.getConnections(t);return!!n&&e.connectorId===n?"connected":r.some(s=>s.connectorId.toLowerCase()===e.connectorId.toLowerCase())?"active":"disconnected"},excludeConnectorAddressFromConnections({connections:e,connectorId:t,addresses:n}){return e.map(r=>{if((t?r.connectorId.toLowerCase()===t.toLowerCase():!1)&&n){const i=r.accounts.filter(s=>!n.some(c=>c.toLowerCase()===s.address.toLowerCase()));return{...r,accounts:i}}return r})},excludeExistingConnections(e,t){const n=new Set(e);return t.filter(r=>!n.has(r.connectorId))},getConnectionsByConnectorId(e,t){return e.filter(n=>n.connectorId.toLowerCase()===t.toLowerCase())},getConnectionsData(e){const t=!!R.state.remoteFeatures?.multiWallet,n=O.state.activeConnectorIds[e],r=U.getConnections(e),i=(U.state.recentConnections.get(e)??[]).filter(a=>O.getConnectorById(a.connectorId)),s=dn.excludeExistingConnections([...r.map(a=>a.connectorId),...n?[n]:[]],i);return t?{connections:r,recentConnections:s}:{connections:r.filter(a=>a.connectorId.toLowerCase()===n?.toLowerCase()),recentConnections:[]}},onConnectMobile(e){const t=U.state.wcUri;if(e?.mobile_link&&t)try{U.setWcError(!1);const{mobile_link:n,link_mode:r,name:o}=e,{redirect:i,redirectUniversalLink:s,href:a}=L.formatNativeUrl(n,t,r),c=i,l=s,d=L.isIframe()?"_top":"_self";U.setWcLinking({name:o,href:a}),U.setRecentWallet(e),R.state.experimental_preferUniversalLinks&&l?L.openHref(l,d):L.openHref(c,d)}catch(n){X.sendEvent({type:"track",event:"CONNECT_PROXY_ERROR",properties:{message:n instanceof Error?n.message:"Error parsing the deep link",uri:t,mobile_link:e.mobile_link,name:e.name}}),U.setWcError(!0)}}},Ui=ze({loading:!1,open:!1,selectedNetworkId:void 0,activeChain:void 0,initialized:!1,connectingWallet:void 0}),Gn={state:Ui,subscribe(e){return ot(Ui,()=>e(Ui))},subscribeOpen(e){return st(Ui,"open",e)},set(e){Object.assign(Ui,{...Ui,...e})}},qe=ze({transactions:[],transactionsByYear:{},lastNetworkInView:void 0,loading:!1,empty:!1,next:void 0}),_2={state:qe,subscribe(e){return ot(qe,()=>e(qe))},setLastNetworkInView(e){qe.lastNetworkInView=e},async fetchTransactions(e){if(!e)throw new Error("Transactions can't be fetched without an accountAddress");qe.loading=!0;try{const t=await _e.fetchTransactions({account:e,cursor:qe.next,chainId:p.state.activeCaipNetwork?.caipNetworkId}),n=vt.filterSpamTransactions(t.data),r=vt.filterByConnectedChain(n),o=[...qe.transactions,...r];qe.loading=!1,qe.transactions=o,qe.transactionsByYear=vt.groupTransactionsByYearAndMonth(qe.transactionsByYear,r),qe.empty=o.length===0,qe.next=t.next?t.next:void 0}catch{const n=p.state.activeChain;X.sendEvent({type:"track",event:"ERROR_FETCH_TRANSACTIONS",properties:{address:e,projectId:R.state.projectId,cursor:qe.next,isSmartAccount:ut(n)===je.ACCOUNT_TYPES.SMART_ACCOUNT}}),Te.showError("Failed to fetch transactions"),qe.loading=!1,qe.empty=!0,qe.next=void 0}},groupTransactionsByYearAndMonth(e={},t=[]){const n=e;return t.forEach(r=>{const o=new Date(r.metadata.minedAt).getFullYear(),i=new Date(r.metadata.minedAt).getMonth(),s=n[o]??{},c=(s[i]??[]).filter(l=>l.id!==r.id);n[o]={...s,[i]:[...c,r].sort((l,d)=>new Date(d.metadata.minedAt).getTime()-new Date(l.metadata.minedAt).getTime())}}),n},filterSpamTransactions(e){return e.filter(t=>!t.transfers?.every(r=>r.nft_info?.flags.is_spam===!0))},filterByConnectedChain(e){const t=p.state.activeCaipNetwork?.caipNetworkId;return e.filter(r=>r.metadata.chain===t)},clearCursor(){qe.next=void 0},resetTransactions(){qe.transactions=[],qe.transactionsByYear={},qe.lastNetworkInView=void 0,qe.loading=!1,qe.empty=!1,qe.next=void 0}},vt=gn(_2,"API_ERROR"),$e=ze({connections:new Map,recentConnections:new Map,isSwitchingConnection:!1,wcError:!1,wcFetchingUri:!1,buffering:!1,status:"disconnected"});let Or;const A2={state:$e,subscribe(e){return ot($e,()=>e($e))},subscribeKey(e,t){return st($e,e,t)},_getClient(){return $e._client},setClient(e){$e._client=Yi(e)},initialize(e){const t=e.filter(n=>!!n.namespace).map(n=>n.namespace);U.syncStorageConnections(t)},syncStorageConnections(e){const t=G.getConnections(),n=e??Array.from(p.state.chains.keys());for(const r of n){const o=t[r]??[],i=new Map($e.recentConnections);i.set(r,o),$e.recentConnections=i}},getConnections(e){return e?$e.connections.get(e)??[]:[]},hasAnyConnection(e){const t=U.state.connections;return Array.from(t.values()).flatMap(n=>n).some(({connectorId:n})=>n===e)},async connectWalletConnect({cache:e="auto"}={}){$e.wcFetchingUri=!0;const t=L.isTelegram()||L.isSafari()&&L.isIos();if(e==="always"||e==="auto"&&t){if(Or){await Or,Or=void 0;return}if(!L.isPairingExpired($e?.wcPairingExpiry)){const n=$e.wcUri;$e.wcUri=n;return}Or=U._getClient()?.connectWalletConnect?.().catch(()=>{}),U.state.status="connecting",await Or,Or=void 0,$e.wcPairingExpiry=void 0,U.state.status="connected"}else await U._getClient()?.connectWalletConnect?.()},async connectExternal(e,t,n=!0){const r=await U._getClient()?.connectExternal?.(e);n&&p.setActiveNamespace(t);const o=O.state.allConnectors.find(s=>s.id===e?.id),i=e.type==="AUTH"?"email":"browser";return X.sendEvent({type:"track",event:"CONNECT_SUCCESS",properties:{method:i,name:o?.name||"Unknown",view:S.state.view,walletRank:o?.explorerWallet?.order}}),r},async reconnectExternal(e){await U._getClient()?.reconnectExternal?.(e);const t=e.chain||p.state.activeChain;t&&O.setConnectorId(e.id,t)},async setPreferredAccountType(e,t){if(!t)return;ye.setLoading(!0,p.state.activeChain);const n=O.getAuthConnector();n&&(p.setAccountProp("preferredAccountType",e,t),await n.provider.setPreferredAccount(e),G.setPreferredAccountTypes(Object.entries(p.state.chains).reduce((r,[o,i])=>{const s=o,a=ut(s);return a!==void 0&&(r[s]=a),r},{})),await U.reconnectExternal(n),ye.setLoading(!1,p.state.activeChain),X.sendEvent({type:"track",event:"SET_PREFERRED_ACCOUNT_TYPE",properties:{accountType:e,network:p.state.activeCaipNetwork?.caipNetworkId||""}}))},async signMessage(e){return U._getClient()?.signMessage(e)},parseUnits(e,t){return U._getClient()?.parseUnits(e,t)},formatUnits(e,t){return U._getClient()?.formatUnits(e,t)},updateBalance(e){return U._getClient()?.updateBalance(e)},async sendTransaction(e){return U._getClient()?.sendTransaction(e)},async getCapabilities(e){return U._getClient()?.getCapabilities(e)},async grantPermissions(e){return U._getClient()?.grantPermissions(e)},async walletGetAssets(e){return U._getClient()?.walletGetAssets(e)??{}},async estimateGas(e){return U._getClient()?.estimateGas(e)},async writeContract(e){return U._getClient()?.writeContract(e)},async writeSolanaTransaction(e){return U._getClient()?.writeSolanaTransaction(e)},async getEnsAddress(e){return U._getClient()?.getEnsAddress(e)},async getEnsAvatar(e){return U._getClient()?.getEnsAvatar(e)},checkInstalled(e){return U._getClient()?.checkInstalled?.(e)||!1},resetWcConnection(){$e.wcUri=void 0,$e.wcPairingExpiry=void 0,$e.wcLinking=void 0,$e.recentWallet=void 0,$e.wcFetchingUri=!1,$e.status="disconnected",vt.resetTransactions(),G.deleteWalletConnectDeepLink(),G.deleteRecentWallet(),Gn.set({connectingWallet:void 0})},resetUri(){$e.wcUri=void 0,$e.wcPairingExpiry=void 0,Or=void 0,$e.wcFetchingUri=!1,Gn.set({connectingWallet:void 0})},finalizeWcConnection(e){const{wcLinking:t,recentWallet:n}=U.state;t&&G.setWalletConnectDeepLink(t),n&&G.setAppKitRecent(n),e&&X.sendEvent({type:"track",event:"CONNECT_SUCCESS",address:e,properties:{method:t?"mobile":"qrcode",name:S.state.data?.wallet?.name||"Unknown",view:S.state.view,walletRank:n?.order}})},setWcBasic(e){$e.wcBasic=e},setUri(e){$e.wcUri=e,$e.wcFetchingUri=!1,$e.wcPairingExpiry=L.getPairingExpiry()},setWcLinking(e){$e.wcLinking=e},setWcError(e){$e.wcError=e,$e.wcFetchingUri=!1,$e.buffering=!1},setRecentWallet(e){$e.recentWallet=e},setBuffering(e){$e.buffering=e},setStatus(e){$e.status=e},setIsSwitchingConnection(e){$e.isSwitchingConnection=e},async disconnect({id:e,namespace:t,initialDisconnect:n}={}){try{await U._getClient()?.disconnect({id:e,chainNamespace:t,initialDisconnect:n})}catch(r){throw new In("Failed to disconnect","INTERNAL_SDK_ERROR",r)}},async disconnectConnector({id:e,namespace:t}){try{await U._getClient()?.disconnectConnector({id:e,namespace:t})}catch(n){throw new In("Failed to disconnect connector","INTERNAL_SDK_ERROR",n)}},setConnections(e,t){const n=new Map($e.connections);n.set(t,e),$e.connections=n},async handleAuthAccountSwitch({address:e,namespace:t}){const r=p.getAccountData(t)?.user?.accounts?.find(i=>i.type==="smartAccount"),o=r&&r.address.toLowerCase()===e.toLowerCase()&&So.canSwitchToSmartAccount(t)?"smartAccount":"eoa";await U.setPreferredAccountType(o,t)},async handleActiveConnection({connection:e,namespace:t,address:n}){const r=O.getConnectorById(e.connectorId),o=e.connectorId===N.CONNECTOR_ID.AUTH;if(!r)throw new Error(`No connector found for connection: ${e.connectorId}`);if(o)n&&await U.handleAuthAccountSwitch({address:n,namespace:t});else return(await U.connectExternal({id:r.id,type:r.type,provider:r.provider,address:n,chain:t},t))?.address;return n},async handleDisconnectedConnection({connection:e,namespace:t,address:n,closeModalOnConnect:r}){const o=O.getConnectorById(e.connectorId),i=e.auth?.name?.toLowerCase(),s=e.connectorId===N.CONNECTOR_ID.AUTH,a=e.connectorId===N.CONNECTOR_ID.WALLET_CONNECT;if(!o)throw new Error(`No connector found for connection: ${e.connectorId}`);let c;if(s)if(i&&So.isSocialProvider(i)){const{address:l}=await So.connectSocial({social:i,closeModalOnConnect:r,onOpenFarcaster(){ye.open({view:"ConnectingFarcaster"})},onConnect(){S.replace("ProfileWallets")}});c=l}else{const{address:l}=await So.connectEmail({closeModalOnConnect:r,onOpen(){ye.open({view:"EmailLogin"})},onConnect(){S.replace("ProfileWallets")}});c=l}else if(a){const{address:l}=await So.connectWalletConnect({walletConnect:!0,connector:o,closeModalOnConnect:r,onOpen(d){const h=d?"AllWallets":"ConnectingWalletConnect";ye.state.open?S.push(h):ye.open({view:h})},onConnect(){S.replace("ProfileWallets")}});c=l}else{const l=await U.connectExternal({id:o.id,type:o.type,provider:o.provider,chain:t},t);l&&(c=l.address)}return s&&n&&await U.handleAuthAccountSwitch({address:n,namespace:t}),c},async switchConnection({connection:e,address:t,namespace:n,closeModalOnConnect:r,onChange:o}){let i;const s=p.getAccountData(n)?.caipAddress;if(s){const{address:c}=Jt.parseCaipAddress(s);i=c}const a=dn.getConnectionStatus(e,n);switch(a){case"connected":case"active":{const c=await U.handleActiveConnection({connection:e,namespace:n,address:t});if(i&&c){const l=c.toLowerCase()!==i.toLowerCase();o?.({address:c,namespace:n,hasSwitchedAccount:l,hasSwitchedWallet:a==="active"})}break}case"disconnected":{const c=await U.handleDisconnectedConnection({connection:e,namespace:n,address:t,closeModalOnConnect:r});c&&o?.({address:c,namespace:n,hasSwitchedAccount:!0,hasSwitchedWallet:!0});break}default:throw new Error(`Invalid connection status: ${a}`)}}},U=gn(A2),Qc={createBalance(e,t){const n={name:e.metadata.name||"",symbol:e.metadata.symbol||"",decimals:e.metadata.decimals||0,value:e.metadata.value||0,price:e.metadata.price||0,iconUrl:e.metadata.iconUrl||""};return{name:n.name,symbol:n.symbol,chainId:t,address:e.address==="native"?void 0:this.convertAddressToCAIP10Address(e.address,t),value:n.value,price:n.price,quantity:{decimals:n.decimals.toString(),numeric:this.convertHexToBalance({hex:e.balance,decimals:n.decimals})},iconUrl:n.iconUrl}},convertHexToBalance({hex:e,decimals:t}){return Nd(BigInt(e),t)},convertAddressToCAIP10Address(e,t){return`${t}:${e}`},createCAIP2ChainId(e,t){return`${t}:${parseInt(e,16)}`},getChainIdHexFromCAIP2ChainId(e){const t=e.split(":");if(t.length<2||!t[1])return"0x0";const n=t[1],r=parseInt(n,10);return isNaN(r)?"0x0":`0x${r.toString(16)}`},isWalletGetAssetsResponse(e){return typeof e!="object"||e===null?!1:Object.values(e).every(t=>Array.isArray(t)&&t.every(n=>this.isValidAsset(n)))},isValidAsset(e){return typeof e=="object"&&e!==null&&typeof e.address=="string"&&typeof e.balance=="string"&&(e.type==="ERC20"||e.type==="NATIVE")&&typeof e.metadata=="object"&&e.metadata!==null&&typeof e.metadata.name=="string"&&typeof e.metadata.symbol=="string"&&typeof e.metadata.decimals=="number"&&typeof e.metadata.price=="number"&&typeof e.metadata.iconUrl=="string"}};let el;async function Wu(){if(!el){const{createPublicClient:e,http:t,defineChain:n}=await me(async()=>{const{createPublicClient:r,http:o,defineChain:i}=await import("./index.CzvxWjdH.js").then(s=>s.i);return{createPublicClient:r,http:o,defineChain:i}},__vite__mapDeps([0,1,2,3]));el={createPublicClient:e,http:t,defineChain:n}}return el}const Yl={getBlockchainApiRpcUrl(e,t){const n=new URL("https://rpc.walletconnect.org/v1/");return n.searchParams.set("chainId",e),n.searchParams.set("projectId",t),n.toString()},async getViemChain(e){const{defineChain:t}=await Wu(),{chainId:n}=Jt.parseCaipNetworkId(e.caipNetworkId);return t({...e,id:Number(n)})},async createViemPublicClient(e){const{createPublicClient:t,http:n}=await Wu(),r=R.state.projectId,o=await Yl.getViemChain(e);if(!o)throw new Error(`Chain ${e.caipNetworkId} not found in viem/chains`);return t({chain:o,transport:n(Yl.getBlockchainApiRpcUrl(e.caipNetworkId,r))})}},Id={async getMyTokensWithBalance(e={forceUpdate:void 0,caipNetwork:p.state.activeCaipNetwork,address:p.getAccountData()?.address}){const{forceUpdate:t,caipNetwork:n,address:r}=e,o=O.getConnectorId("eip155")===N.CONNECTOR_ID.AUTH;if(!r)return[];const i=n?`${n.caipNetworkId}:${r}`:r,s=G.getBalanceCacheForCaipAddress(i);if(s)return s.balances;if(n&&n.chainNamespace===N.CHAIN.EVM&&o){const c=await this.getEIP155Balances(r,n);if(c)return this.filterLowQualityTokens(c)}const a=await _e.getBalance(r,n?.caipNetworkId,t);return this.filterLowQualityTokens(a.balances)},async getEIP155Balances(e,t){try{const n=Qc.getChainIdHexFromCAIP2ChainId(t.caipNetworkId);if(!(await U.getCapabilities(e))?.[n]?.assetDiscovery?.supported)return null;const o=await U.walletGetAssets({account:e,chainFilter:[n]});if(!Qc.isWalletGetAssetsResponse(o))return null;const s=(o[n]||[]).map(a=>Qc.createBalance(a,t.caipNetworkId));return G.updateBalanceCache({caipAddress:`${t.caipNetworkId}:${e}`,balance:{balances:s},timestamp:Date.now()}),s}catch{return null}},filterLowQualityTokens(e){return e.filter(t=>t.quantity.decimals!=="0")},async fetchERC20Balance({caipAddress:e,assetAddress:t,caipNetwork:n}){const r=await Yl.createViemPublicClient(n),{address:o}=Jt.parseCaipAddress(e),[{result:i},{result:s},{result:a},{result:c}]=await r.multicall({contracts:[{address:t,functionName:"name",args:[],abi:da},{address:t,functionName:"symbol",args:[],abi:da},{address:t,functionName:"balanceOf",args:[o],abi:da},{address:t,functionName:"decimals",args:[],abi:da}]});return{name:i,symbol:s,decimals:c,balance:a&&c?Nd(a,c):"0"}}},tl={adapters:{}},x2={state:tl,initialize(e){tl.adapters={...e}},get(e){return tl.adapters[e]}},Ya={eip155:void 0,solana:void 0,polkadot:void 0,bip122:void 0,cosmos:void 0,sui:void 0,stacks:void 0,ton:void 0},Tt=ze({providers:{...Ya},providerIds:{...Ya}}),S2={state:Tt,subscribeKey(e,t){return st(Tt,e,t)},subscribe(e){return ot(Tt,()=>{e(Tt)})},subscribeProviders(e){return ot(Tt.providers,()=>e(Tt.providers))},setProvider(e,t){e&&t&&(Tt.providers[e]=Yi(t))},getProvider(e){if(e)return Tt.providers[e]},setProviderId(e,t){t&&(Tt.providerIds[e]=t)},getProviderId(e){if(e)return Tt.providerIds[e]},reset(){Tt.providers={...Ya},Tt.providerIds={...Ya}},resetChain(e){Tt.providers[e]=void 0,Tt.providerIds[e]=void 0}},T2={async getTokenList(e){return(await _e.fetchSwapTokens({chainId:e}))?.tokens?.map(r=>({...r,eip2612:!1,quantity:{decimals:"0",numeric:"0"},price:0,value:0}))||[]},async fetchGasPrice(){const e=p.state.activeCaipNetwork;if(!e)return null;try{switch(e.chainNamespace){case"solana":const t=(await U?.estimateGas({chainNamespace:"solana"}))?.toString();return{standard:t,fast:t,instant:t};case"eip155":default:return await _e.fetchGasPrice({chainId:e.caipNetworkId})}}catch{return null}},async fetchSwapAllowance({tokenAddress:e,userAddress:t,sourceTokenAmount:n,sourceTokenDecimals:r}){const o=await _e.fetchSwapAllowance({tokenAddress:e,userAddress:t});if(o?.allowance&&n&&r){const i=U.parseUnits(n,r)||0;return BigInt(o.allowance)>=i}return!1},async getMyTokensWithBalance(e){const t=await Id.getMyTokensWithBalance({forceUpdate:e,caipNetwork:p.state.activeCaipNetwork,address:p.getAccountData()?.address});return p.setAccountProp("tokenBalance",t,p.state.activeChain),this.mapBalancesToSwapTokens(t)},mapBalancesToSwapTokens(e){return e?.map(t=>({...t,address:t?.address?t.address:Za(),decimals:parseInt(t.quantity.decimals,10),logoUri:t.iconUrl,eip2612:!1}))||[]},async handleSwapError(e){try{const t=e?.cause;return t?.json&&(await t.json())?.reasons?.[0]?.description?.includes("insufficient liquidity")?"Insufficient liquidity":void 0}catch{return}}},Oe=ze({tokenBalances:[],loading:!1}),$2={state:Oe,subscribe(e){return ot(Oe,()=>e(Oe))},subscribeKey(e,t){return st(Oe,e,t)},setToken(e){e&&(Oe.token=Yi(e))},setTokenAmount(e){Oe.sendTokenAmount=e},setReceiverAddress(e){Oe.receiverAddress=e},setReceiverProfileImageUrl(e){Oe.receiverProfileImageUrl=e},setReceiverProfileName(e){Oe.receiverProfileName=e},setNetworkBalanceInUsd(e){Oe.networkBalanceInUSD=e},setLoading(e){Oe.loading=e},getSdkEventProperties(e){return{message:L.parseError(e),isSmartAccount:ut(p.state.activeChain)===je.ACCOUNT_TYPES.SMART_ACCOUNT,token:Oe.token?.symbol||"",amount:Oe.sendTokenAmount??0,network:p.state.activeCaipNetwork?.caipNetworkId||""}},async sendToken(){try{switch(Se.setLoading(!0),p.state.activeCaipNetwork?.chainNamespace){case"eip155":await Se.sendEvmToken();return;case"solana":await Se.sendSolanaToken();return;default:throw new Error("Unsupported chain")}}catch(e){throw Yt.isUserRejectedRequestError(e)?new Ym(e):e}finally{Se.setLoading(!1)}},async sendEvmToken(){const e=p.state.activeChain;if(!e)throw new Error("SendController:sendEvmToken - activeChainNamespace is required");const t=ut(e);if(!Se.state.sendTokenAmount||!Se.state.receiverAddress)throw new Error("An amount and receiver address are required");if(!Se.state.token)throw new Error("A token is required");if(Se.state.token?.address){X.sendEvent({type:"track",event:"SEND_INITIATED",properties:{isSmartAccount:t===je.ACCOUNT_TYPES.SMART_ACCOUNT,token:Se.state.token.address,amount:Se.state.sendTokenAmount,network:p.state.activeCaipNetwork?.caipNetworkId||""}});const{hash:n}=await Se.sendERC20Token({receiverAddress:Se.state.receiverAddress,tokenAddress:Se.state.token.address,sendTokenAmount:Se.state.sendTokenAmount,decimals:Se.state.token.quantity.decimals});n&&(Oe.hash=n)}else{X.sendEvent({type:"track",event:"SEND_INITIATED",properties:{isSmartAccount:t===je.ACCOUNT_TYPES.SMART_ACCOUNT,token:Se.state.token.symbol||"",amount:Se.state.sendTokenAmount,network:p.state.activeCaipNetwork?.caipNetworkId||""}});const{hash:n}=await Se.sendNativeToken({receiverAddress:Se.state.receiverAddress,sendTokenAmount:Se.state.sendTokenAmount,decimals:Se.state.token.quantity.decimals});n&&(Oe.hash=n)}},async fetchTokenBalance(e){Oe.loading=!0;const t=p.state.activeChain,n=p.state.activeCaipNetwork?.caipNetworkId,r=p.state.activeCaipNetwork?.chainNamespace,o=p.getAccountData(t)?.caipAddress??p.state.activeCaipAddress,i=o?L.getPlainAddress(o):void 0;if(Oe.lastRetry&&!L.isAllowedRetry(Oe.lastRetry,30*ke.ONE_SEC_MS))return Oe.loading=!1,[];try{if(i&&n&&r){const s=await Id.getMyTokensWithBalance();return Oe.tokenBalances=s,Oe.lastRetry=void 0,s}}catch(s){Oe.lastRetry=Date.now(),e?.(s),Te.showError("Token Balance Unavailable")}finally{Oe.loading=!1}return[]},fetchNetworkBalance(){if(Oe.tokenBalances.length===0)return;const e=T2.mapBalancesToSwapTokens(Oe.tokenBalances);if(!e)return;const t=e.find(n=>n.address===Za());t&&(Oe.networkBalanceInUSD=t?Ji.multiply(t.quantity.numeric,t.price).toString():"0")},async sendNativeToken(e){S.pushTransactionStack({});const t=e.receiverAddress,n=p.getAccountData()?.address,r=U.parseUnits(e.sendTokenAmount.toString(),Number(e.decimals)),i=await U.sendTransaction({chainNamespace:N.CHAIN.EVM,to:t,address:n,data:"0x",value:r??BigInt(0)});return X.sendEvent({type:"track",event:"SEND_SUCCESS",properties:{isSmartAccount:ut("eip155")===je.ACCOUNT_TYPES.SMART_ACCOUNT,token:Se.state.token?.symbol||"",amount:e.sendTokenAmount,network:p.state.activeCaipNetwork?.caipNetworkId||"",hash:i||""}}),U._getClient()?.updateBalance("eip155"),Se.resetSend(),{hash:i}},async sendERC20Token(e){S.pushTransactionStack({onSuccess(){S.replace("Account")}});const t=U.parseUnits(e.sendTokenAmount.toString(),Number(e.decimals)),n=p.getAccountData()?.address;if(n&&e.sendTokenAmount&&e.receiverAddress&&e.tokenAddress){const r=L.getPlainAddress(e.tokenAddress);if(!r)throw new Error("SendController:sendERC20Token - tokenAddress is required");const o=await U.writeContract({fromAddress:n,tokenAddress:r,args:[e.receiverAddress,t??BigInt(0)],method:"transfer",abi:Km.getERC20Abi(r),chainNamespace:N.CHAIN.EVM});return X.sendEvent({type:"track",event:"SEND_SUCCESS",properties:{isSmartAccount:ut("eip155")===je.ACCOUNT_TYPES.SMART_ACCOUNT,token:Se.state.token?.symbol||"",amount:e.sendTokenAmount,network:p.state.activeCaipNetwork?.caipNetworkId||"",hash:o||""}}),Se.resetSend(),{hash:o}}return{hash:void 0}},async sendSolanaToken(){if(!Se.state.sendTokenAmount||!Se.state.receiverAddress)throw new Error("An amount and receiver address are required");S.pushTransactionStack({onSuccess(){S.replace("Account")}});let e;Se.state.token&&Se.state.token.address!==ke.SOLANA_NATIVE_TOKEN_ADDRESS&&(L.isCaipAddress(Se.state.token.address)?e=L.getPlainAddress(Se.state.token.address):e=Se.state.token.address);const t=await U.sendTransaction({chainNamespace:"solana",tokenMint:e,to:Se.state.receiverAddress,value:Se.state.sendTokenAmount});t&&(Oe.hash=t),U._getClient()?.updateBalance("solana"),X.sendEvent({type:"track",event:"SEND_SUCCESS",properties:{isSmartAccount:!1,token:Se.state.token?.symbol||"",amount:Se.state.sendTokenAmount,network:p.state.activeCaipNetwork?.caipNetworkId||"",hash:t||""}}),Se.resetSend()},resetSend(){Oe.token=void 0,Oe.sendTokenAmount=void 0,Oe.receiverAddress=void 0,Oe.receiverProfileImageUrl=void 0,Oe.receiverProfileName=void 0,Oe.loading=!1,Oe.tokenBalances=[]}},Se=gn($2),nl={currentTab:0,tokenBalance:[],smartAccountDeployed:!1,addressLabels:new Map,user:void 0,preferredAccountType:void 0},ga={caipNetwork:void 0,supportsAllNetworks:!0,smartAccountEnabledNetworks:[]},J=ze({chains:wm(),activeCaipAddress:void 0,activeChain:void 0,activeCaipNetwork:void 0,noAdapters:!1,universalAdapter:{connectionControllerClient:void 0},isSwitchingNamespace:!1}),Zp={state:J,subscribe(e){return ot(J,()=>{e(J)})},subscribeKey(e,t){return st(J,e,t)},subscribeAccountStateProp(e,t,n){const r=n||J.activeChain;return r?st(J.chains.get(r)?.accountState||{},e,t):()=>{}},subscribeChainProp(e,t,n){let r;return ot(J.chains,()=>{const o=n||J.activeChain;if(o){const i=J.chains.get(o)?.[e];r!==i&&(r=i,t(i))}})},initialize(e,t,n){const{chainId:r,namespace:o}=G.getActiveNetworkProps(),i=t?.find(d=>d.id.toString()===r?.toString()),a=e.find(d=>d?.namespace===o)||e?.[0],c=e.map(d=>d.namespace).filter(d=>d!==void 0),l=R.state.enableEmbedded?new Set([...c]):new Set([...t?.map(d=>d.chainNamespace)??[]]);(e?.length===0||!a)&&(J.noAdapters=!0),J.noAdapters||(J.activeChain=a?.namespace,J.activeCaipNetwork=i,p.setChainNetworkData(a?.namespace,{caipNetwork:i}),J.activeChain&&Gn.set({activeChain:a?.namespace})),l.forEach(d=>{const h=t?.filter(v=>v.chainNamespace===d),f=G.getPreferredAccountTypes()||{},w={...R.state.defaultAccountTypes,...f};p.state.chains.set(d,{namespace:d,networkState:ze({...ga,caipNetwork:h?.[0]}),accountState:ze({...nl,preferredAccountType:w[d]}),caipNetworks:h??[],...n}),p.setRequestedCaipNetworks(h??[],d)})},removeAdapter(e){if(J.activeChain===e){const t=Array.from(J.chains.entries()).find(([n])=>n!==e);if(t){const n=t[1]?.caipNetworks?.[0];n&&p.setActiveCaipNetwork(n)}}J.chains.delete(e)},addAdapter(e,{connectionControllerClient:t},n){if(!e.namespace)throw new Error("ChainController:addAdapter - adapter must have a namespace");J.chains.set(e.namespace,{namespace:e.namespace,networkState:{...ga,caipNetwork:n[0]},accountState:{...nl},caipNetworks:n,connectionControllerClient:t}),p.setRequestedCaipNetworks(n?.filter(r=>r.chainNamespace===e.namespace)??[],e.namespace)},addNetwork(e){const t=J.chains.get(e.chainNamespace);if(t){const n=[...t.caipNetworks||[]];t.caipNetworks?.find(r=>r.id===e.id)||n.push(e),J.chains.set(e.chainNamespace,{...t,caipNetworks:n}),p.setRequestedCaipNetworks(n,e.chainNamespace),O.filterByNamespace(e.chainNamespace,!0)}},removeNetwork(e,t){const n=J.chains.get(e);if(n){const r=J.activeCaipNetwork?.id===t,o=[...n.caipNetworks?.filter(i=>i.id!==t)||[]];r&&n?.caipNetworks?.[0]&&p.setActiveCaipNetwork(n.caipNetworks[0]),J.chains.set(e,{...n,caipNetworks:o}),p.setRequestedCaipNetworks(o||[],e),o.length===0&&O.filterByNamespace(e,!1)}},setAdapterNetworkState(e,t){const n=J.chains.get(e);n&&(n.networkState={...n.networkState||ga,...t},J.chains.set(e,n))},setChainAccountData(e,t,n=!0){if(!e)throw new Error("Chain is required to update chain account data");const r=J.chains.get(e);if(r){const o={...r.accountState||nl,...t};J.chains.set(e,{...r,accountState:o}),(J.chains.size===1||J.activeChain===e)&&t.caipAddress&&(J.activeCaipAddress=t.caipAddress)}},setChainNetworkData(e,t){if(!e)return;const n=J.chains.get(e);if(n){const r={...n.networkState||ga,...t};J.chains.set(e,{...n,networkState:r})}},setAccountProp(e,t,n,r=!0){p.setChainAccountData(n,{[e]:t},r)},setActiveNamespace(e){J.activeChain=e;const t=e?J.chains.get(e):void 0,n=t?.networkState?.caipNetwork;n?.id&&e&&(J.activeCaipAddress=t?.accountState?.caipAddress,J.activeCaipNetwork=n,p.setChainNetworkData(e,{caipNetwork:n}),G.setActiveCaipNetworkId(n?.caipNetworkId),Gn.set({activeChain:e,selectedNetworkId:n?.caipNetworkId}))},setActiveCaipNetwork(e){if(!e)return;const t=J.activeChain===e.chainNamespace;t||p.setIsSwitchingNamespace(!0);const n=J.chains.get(e.chainNamespace);J.activeChain=e.chainNamespace,J.activeCaipNetwork=e,p.setChainNetworkData(e.chainNamespace,{caipNetwork:e});let r=n?.accountState?.address;if(r)J.activeCaipAddress=`${e.chainNamespace}:${e.id}:${r}`;else if(t&&J.activeCaipAddress){const{address:i}=Jt.parseCaipAddress(J.activeCaipAddress);r=i,J.activeCaipAddress=`${e.caipNetworkId}:${r}`}else J.activeCaipAddress=void 0;p.setChainAccountData(e.chainNamespace,{address:r,caipAddress:J.activeCaipAddress}),Se.resetSend(),Gn.set({activeChain:J.activeChain,selectedNetworkId:J.activeCaipNetwork?.caipNetworkId}),G.setActiveCaipNetworkId(e.caipNetworkId),!p.checkIfSupportedNetwork(e.chainNamespace)&&R.state.enableNetworkSwitch&&!R.state.allowUnsupportedChain&&!U.state.wcBasic&&p.showUnsupportedChainUI()},addCaipNetwork(e){if(!e)return;const t=J.chains.get(e.chainNamespace);t&&t?.caipNetworks?.push(e)},async switchActiveNamespace(e){if(!e)return;const t=e!==p.state.activeChain,n=p.getNetworkData(e)?.caipNetwork,r=p.getCaipNetworkByNamespace(e,n?.id);t&&r&&await p.switchActiveNetwork(r)},async switchActiveNetwork(e,{throwOnFailure:t=!1}={}){const n=p.state.activeChain;if(!n)throw new Error("ChainController:switchActiveNetwork - namespace is required");const r=S2.getProviderId(J.activeChain)==="AUTH",o=p.getAccountData(n)?.address,i=N.AUTH_CONNECTOR_SUPPORTED_CHAINS.includes(e.chainNamespace);try{if(o&&e.chainNamespace===n||r&&i){const s=x2.get(e.chainNamespace);if(!s)throw new Error("Adapter not found");await s.switchNetwork({caipNetwork:e})}p.setActiveCaipNetwork(e)}catch(s){if(t)throw s}X.sendEvent({type:"track",event:"SWITCH_NETWORK",properties:{network:e.caipNetworkId}})},getConnectionControllerClient(e){const t=e||J.activeChain;if(!t)throw new Error("Chain is required to get connection controller client");const n=J.chains.get(t);if(!n?.connectionControllerClient)throw new Error("ConnectionController client not set");return n.connectionControllerClient},getNetworkProp(e,t){const n=J.chains.get(t)?.networkState;if(n)return n[e]},getRequestedCaipNetworks(e){const t=J.chains.get(e),{approvedCaipNetworkIds:n=[],requestedCaipNetworks:r=[]}=t?.networkState||{};return L.sortRequestedNetworks(n,r).filter(s=>s?.id)},getAllRequestedCaipNetworks(){const e=[];return J.chains.forEach(t=>{if(!t.namespace)throw new Error("ChainController:getAllRequestedCaipNetworks - chainAdapter must have a namespace");const n=p.getRequestedCaipNetworks(t.namespace);e.push(...n)}),e},setRequestedCaipNetworks(e,t){p.setAdapterNetworkState(t,{requestedCaipNetworks:e});const r=p.getAllRequestedCaipNetworks().map(i=>i.chainNamespace),o=Array.from(new Set(r));O.filterByNamespaces(o)},getAllApprovedCaipNetworkIds(){const e=[];return J.chains.forEach(t=>{if(!t.namespace)throw new Error("ChainController:getAllApprovedCaipNetworkIds - chainAdapter must have a namespace");const n=p.getApprovedCaipNetworkIds(t.namespace);e.push(...n)}),e},getActiveCaipNetwork(e){return e?J.chains.get(e)?.networkState?.caipNetwork:J.activeCaipNetwork},getActiveCaipAddress(){return J.activeCaipAddress},getApprovedCaipNetworkIds(e){return J.chains.get(e)?.networkState?.approvedCaipNetworkIds||[]},setApprovedCaipNetworksData(e,t){p.setAdapterNetworkState(e,t)},checkIfSupportedNetwork(e,t){const n=t||J.activeCaipNetwork?.caipNetworkId,r=p.getRequestedCaipNetworks(e);return r.length?r?.some(o=>o.caipNetworkId===n):!0},checkIfSupportedChainId(e){return J.activeChain?p.getRequestedCaipNetworks(J.activeChain)?.some(n=>n.id===e):!0},checkIfSmartAccountEnabled(){const e=Lm.caipNetworkIdToNumber(J.activeCaipNetwork?.caipNetworkId);return!J.activeChain||!e?!1:!!(tt.get(oe.SMART_ACCOUNT_ENABLED_NETWORKS)?.split(",")||[])?.includes(e.toString())},showUnsupportedChainUI(){ye.open({view:"UnsupportedChain"})},checkIfNamesSupported(){const e=J.activeCaipNetwork;return!!(e?.chainNamespace&&ke.NAMES_SUPPORTED_CHAIN_NAMESPACES.includes(e.chainNamespace))},resetNetwork(e){p.setAdapterNetworkState(e,{approvedCaipNetworkIds:void 0,supportsAllNetworks:!0})},resetAccount(e){const t=e;if(!t)throw new Error("Chain is required to set account prop");const n=p.state.chains.get(t)?.accountState?.preferredAccountType,r=R.state.defaultAccountTypes[t];J.activeCaipAddress=void 0,p.setChainAccountData(t,{smartAccountDeployed:!1,currentTab:0,caipAddress:void 0,address:void 0,balance:void 0,balanceSymbol:void 0,profileName:void 0,profileImage:void 0,addressExplorerUrl:void 0,tokenBalance:[],connectedWalletInfo:void 0,preferredAccountType:r||n,socialProvider:void 0,socialWindow:void 0,farcasterUrl:void 0,user:void 0,status:"disconnected"}),O.removeConnectorId(t)},setIsSwitchingNamespace(e){J.isSwitchingNamespace=e},getFirstCaipNetworkSupportsAuthConnector(){const e=[];let t;if(J.chains.forEach(n=>{N.AUTH_CONNECTOR_SUPPORTED_CHAINS.find(r=>r===n.namespace)&&n.namespace&&e.push(n.namespace)}),e.length>0){const n=e[0];return t=n?J.chains.get(n)?.caipNetworks?.[0]:void 0,t}},getAccountData(e){const t=e||J.activeChain;if(t)return p.state.chains.get(t)?.accountState},getNetworkData(e){const t=e||J.activeChain;if(t)return p.state.chains.get(t)?.networkState},getCaipNetworkByNamespace(e,t){if(!e)return;const n=p.state.chains.get(e),r=n?.caipNetworks?.find(o=>o.id.toString()===t?.toString());return r||n?.networkState?.caipNetwork||n?.caipNetworks?.[0]},getRequestedCaipNetworkIds(){const e=O.state.filterByNamespace;return(e?[J.chains.get(e)]:Array.from(J.chains.values())).flatMap(n=>n?.caipNetworks||[]).map(n=>n.caipNetworkId)},getCaipNetworks(e){return e?p.getRequestedCaipNetworks(e):p.getAllRequestedCaipNetworks()},getCaipNetworkById(e,t){return Zp.getCaipNetworks(t).find(n=>n.id.toString()===e.toString()||n.caipNetworkId.toString()===e.toString())},setLastConnectedSIWECaipNetwork(e){J.lastConnectedSIWECaipNetwork=e},getLastConnectedSIWECaipNetwork(){return J.lastConnectedSIWECaipNetwork},async fetchTokenBalance(e){const t=p.getAccountData();if(!t)return[];const n=p.state.activeCaipNetwork?.caipNetworkId,r=p.state.activeCaipNetwork?.chainNamespace,o=p.state.activeCaipAddress,i=o?L.getPlainAddress(o):void 0;if(p.setAccountProp("balanceLoading",!0,r),t.lastRetry&&!L.isAllowedRetry(t.lastRetry,30*ke.ONE_SEC_MS))return p.setAccountProp("balanceLoading",!1,r),[];try{if(i&&n&&r){const s=await Id.getMyTokensWithBalance();return p.setAccountProp("tokenBalance",s,r),p.setAccountProp("lastRetry",void 0,r),p.setAccountProp("balanceLoading",!1,r),s}}catch(s){p.setAccountProp("lastRetry",Date.now(),r),e?.(s),Te.showError("Token Balance Unavailable")}finally{p.setAccountProp("balanceLoading",!1,r)}return[]},isCaipNetworkDisabled(e){const t=e.chainNamespace,n=!!p.getAccountData(t)?.caipAddress,r=p.getAllApprovedCaipNetworkIds(),o=p.getNetworkProp("supportsAllNetworks",t)!==!1,i=O.getConnectorId(t),s=O.getAuthConnector(),a=i===N.CONNECTOR_ID.AUTH&&s;return!n||o||a?!1:!r?.includes(e.caipNetworkId)}},p=gn(Zp),Yp={onSwitchNetwork({network:e,ignoreSwitchConfirmation:t=!1}){const n=p.state.activeCaipNetwork,r=p.state.activeChain,o=S.state.data;if(e.id===n?.id)return;const s=!!p.getAccountData(r)?.address,a=!!p.getAccountData(e.chainNamespace)?.address,c=e.chainNamespace!==r,d=O.getConnectorId(r)===N.CONNECTOR_ID.AUTH,h=N.AUTH_CONNECTOR_SUPPORTED_CHAINS.find(f=>f===e.chainNamespace);t||d&&h?S.push("SwitchNetwork",{...o,network:e}):s&&c&&!a?S.push("SwitchActiveChain",{switchToChain:e.chainNamespace,navigateTo:"Connect",navigateWithReplace:!0,network:e}):S.push("SwitchNetwork",{...o,network:e})}},$t=ze({loading:!1,loadingNamespaceMap:new Map,open:!1,shake:!1,namespace:void 0}),N2={state:$t,subscribe(e){return ot($t,()=>e($t))},subscribeKey(e,t){return st($t,e,t)},async open(e){const t=e?.namespace,n=p.state.activeChain,r=t&&t!==n,o=p.getAccountData(e?.namespace)?.caipAddress,i=p.state.noAdapters;if(U.state.wcBasic?q.prefetch({fetchNetworkImages:!1,fetchConnectorImages:!1,fetchWalletRanks:!1}):await q.prefetch(),O.setFilterByNamespace(e?.namespace),ye.setLoading(!0,t),t&&r){const s=p.getNetworkData(t)?.caipNetwork||p.getRequestedCaipNetworks(t)[0];s&&(i?(await p.switchActiveNetwork(s),S.push("ConnectingWalletConnectBasic")):Yp.onSwitchNetwork({network:s,ignoreSwitchConfirmation:!0}))}else R.state.manualWCControl||i&&!o?L.isMobile()?S.reset("AllWallets"):S.reset("ConnectingWalletConnectBasic"):e?.view?S.reset(e.view,e.data):o?S.reset("Account"):S.reset("Connect");$t.open=!0,Gn.set({open:!0}),X.sendEvent({type:"track",event:"MODAL_OPEN",properties:{connected:!!o}})},close(){const e=R.state.enableEmbedded,t=!!p.state.activeCaipAddress;$t.open&&X.sendEvent({type:"track",event:"MODAL_CLOSE",properties:{connected:t}}),$t.open=!1,S.reset("Connect"),ye.clearLoading(),e?t?S.replace("Account"):S.push("Connect"):Gn.set({open:!1}),U.resetUri()},setLoading(e,t){t&&$t.loadingNamespaceMap.set(t,e),$t.loading=e,Gn.set({loading:e})},clearLoading(){$t.loadingNamespaceMap.clear(),$t.loading=!1,Gn.set({loading:!1})},shake(){$t.shake||($t.shake=!0,setTimeout(()=>{$t.shake=!1},500))}},ye=gn(N2);var wa={exports:{}},ju;function R2(){if(ju)return wa.exports;ju=1;var e=typeof Reflect=="object"?Reflect:null,t=e&&typeof e.apply=="function"?e.apply:function(A,_,P){return Function.prototype.apply.call(A,_,P)},n;e&&typeof e.ownKeys=="function"?n=e.ownKeys:Object.getOwnPropertySymbols?n=function(A){return Object.getOwnPropertyNames(A).concat(Object.getOwnPropertySymbols(A))}:n=function(A){return Object.getOwnPropertyNames(A)};function r(C){console&&console.warn&&console.warn(C)}var o=Number.isNaN||function(A){return A!==A};function i(){i.init.call(this)}wa.exports=i,wa.exports.once=I,i.EventEmitter=i,i.prototype._events=void 0,i.prototype._eventsCount=0,i.prototype._maxListeners=void 0;var s=10;function a(C){if(typeof C!="function")throw new TypeError('The "listener" argument must be of type Function. Received type '+typeof C)}Object.defineProperty(i,"defaultMaxListeners",{enumerable:!0,get:function(){return s},set:function(C){if(typeof C!="number"||C<0||o(C))throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received '+C+".");s=C}}),i.init=function(){(this._events===void 0||this._events===Object.getPrototypeOf(this)._events)&&(this._events=Object.create(null),this._eventsCount=0),this._maxListeners=this._maxListeners||void 0},i.prototype.setMaxListeners=function(A){if(typeof A!="number"||A<0||o(A))throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received '+A+".");return this._maxListeners=A,this};function c(C){return C._maxListeners===void 0?i.defaultMaxListeners:C._maxListeners}i.prototype.getMaxListeners=function(){return c(this)},i.prototype.emit=function(A){for(var _=[],P=1;P<arguments.length;P++)_.push(arguments[P]);var B=A==="error",j=this._events;if(j!==void 0)B=B&&j.error===void 0;else if(!B)return!1;if(B){var W;if(_.length>0&&(W=_[0]),W instanceof Error)throw W;var z=new Error("Unhandled error."+(W?" ("+W.message+")":""));throw z.context=W,z}var Y=j[A];if(Y===void 0)return!1;if(typeof Y=="function")t(Y,this,_);else for(var ue=Y.length,V=v(Y,ue),P=0;P<ue;++P)t(V[P],this,_);return!0};function l(C,A,_,P){var B,j,W;if(a(_),j=C._events,j===void 0?(j=C._events=Object.create(null),C._eventsCount=0):(j.newListener!==void 0&&(C.emit("newListener",A,_.listener?_.listener:_),j=C._events),W=j[A]),W===void 0)W=j[A]=_,++C._eventsCount;else if(typeof W=="function"?W=j[A]=P?[_,W]:[W,_]:P?W.unshift(_):W.push(_),B=c(C),B>0&&W.length>B&&!W.warned){W.warned=!0;var z=new Error("Possible EventEmitter memory leak detected. "+W.length+" "+String(A)+" listeners added. Use emitter.setMaxListeners() to increase limit");z.name="MaxListenersExceededWarning",z.emitter=C,z.type=A,z.count=W.length,r(z)}return C}i.prototype.addListener=function(A,_){return l(this,A,_,!1)},i.prototype.on=i.prototype.addListener,i.prototype.prependListener=function(A,_){return l(this,A,_,!0)};function d(){if(!this.fired)return this.target.removeListener(this.type,this.wrapFn),this.fired=!0,arguments.length===0?this.listener.call(this.target):this.listener.apply(this.target,arguments)}function h(C,A,_){var P={fired:!1,wrapFn:void 0,target:C,type:A,listener:_},B=d.bind(P);return B.listener=_,P.wrapFn=B,B}i.prototype.once=function(A,_){return a(_),this.on(A,h(this,A,_)),this},i.prototype.prependOnceListener=function(A,_){return a(_),this.prependListener(A,h(this,A,_)),this},i.prototype.removeListener=function(A,_){var P,B,j,W,z;if(a(_),B=this._events,B===void 0)return this;if(P=B[A],P===void 0)return this;if(P===_||P.listener===_)--this._eventsCount===0?this._events=Object.create(null):(delete B[A],B.removeListener&&this.emit("removeListener",A,P.listener||_));else if(typeof P!="function"){for(j=-1,W=P.length-1;W>=0;W--)if(P[W]===_||P[W].listener===_){z=P[W].listener,j=W;break}if(j<0)return this;j===0?P.shift():y(P,j),P.length===1&&(B[A]=P[0]),B.removeListener!==void 0&&this.emit("removeListener",A,z||_)}return this},i.prototype.off=i.prototype.removeListener,i.prototype.removeAllListeners=function(A){var _,P,B;if(P=this._events,P===void 0)return this;if(P.removeListener===void 0)return arguments.length===0?(this._events=Object.create(null),this._eventsCount=0):P[A]!==void 0&&(--this._eventsCount===0?this._events=Object.create(null):delete P[A]),this;if(arguments.length===0){var j=Object.keys(P),W;for(B=0;B<j.length;++B)W=j[B],W!=="removeListener"&&this.removeAllListeners(W);return this.removeAllListeners("removeListener"),this._events=Object.create(null),this._eventsCount=0,this}if(_=P[A],typeof _=="function")this.removeListener(A,_);else if(_!==void 0)for(B=_.length-1;B>=0;B--)this.removeListener(A,_[B]);return this};function f(C,A,_){var P=C._events;if(P===void 0)return[];var B=P[A];return B===void 0?[]:typeof B=="function"?_?[B.listener||B]:[B]:_?$(B):v(B,B.length)}i.prototype.listeners=function(A){return f(this,A,!0)},i.prototype.rawListeners=function(A){return f(this,A,!1)},i.listenerCount=function(C,A){return typeof C.listenerCount=="function"?C.listenerCount(A):w.call(C,A)},i.prototype.listenerCount=w;function w(C){var A=this._events;if(A!==void 0){var _=A[C];if(typeof _=="function")return 1;if(_!==void 0)return _.length}return 0}i.prototype.eventNames=function(){return this._eventsCount>0?n(this._events):[]};function v(C,A){for(var _=new Array(A),P=0;P<A;++P)_[P]=C[P];return _}function y(C,A){for(;A+1<C.length;A++)C[A]=C[A+1];C.pop()}function $(C){for(var A=new Array(C.length),_=0;_<A.length;++_)A[_]=C[_].listener||C[_];return A}function I(C,A){return new Promise(function(_,P){function B(W){C.removeListener(A,j),P(W)}function j(){typeof C.removeListener=="function"&&C.removeListener("error",B),_([].slice.call(arguments))}D(C,A,j,{once:!0}),A!=="error"&&k(C,B,{once:!0})})}function k(C,A,_){typeof C.on=="function"&&D(C,"error",A,_)}function D(C,A,_,P){if(typeof C.on=="function")P.once?C.once(A,_):C.on(A,_);else if(typeof C.addEventListener=="function")C.addEventListener(A,function B(j){P.once&&C.removeEventListener(A,B),_(j)});else throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type '+typeof C)}return wa.exports}var k2=R2();const xv=Ei(k2);var rl={};/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */var Jl=function(e,t){return Jl=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(n,r){n.__proto__=r}||function(n,r){for(var o in r)r.hasOwnProperty(o)&&(n[o]=r[o])},Jl(e,t)};function I2(e,t){Jl(e,t);function n(){this.constructor=e}e.prototype=t===null?Object.create(t):(n.prototype=t.prototype,new n)}var Xl=function(){return Xl=Object.assign||function(t){for(var n,r=1,o=arguments.length;r<o;r++){n=arguments[r];for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(t[i]=n[i])}return t},Xl.apply(this,arguments)};function O2(e,t){var n={};for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&t.indexOf(r)<0&&(n[r]=e[r]);if(e!=null&&typeof Object.getOwnPropertySymbols=="function")for(var o=0,r=Object.getOwnPropertySymbols(e);o<r.length;o++)t.indexOf(r[o])<0&&Object.prototype.propertyIsEnumerable.call(e,r[o])&&(n[r[o]]=e[r[o]]);return n}function P2(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i}function L2(e,t){return function(n,r){t(n,r,e)}}function D2(e,t){if(typeof Reflect=="object"&&typeof Reflect.metadata=="function")return Reflect.metadata(e,t)}function M2(e,t,n,r){function o(i){return i instanceof n?i:new n(function(s){s(i)})}return new(n||(n=Promise))(function(i,s){function a(d){try{l(r.next(d))}catch(h){s(h)}}function c(d){try{l(r.throw(d))}catch(h){s(h)}}function l(d){d.done?i(d.value):o(d.value).then(a,c)}l((r=r.apply(e,t||[])).next())})}function U2(e,t){var n={label:0,sent:function(){if(i[0]&1)throw i[1];return i[1]},trys:[],ops:[]},r,o,i,s;return s={next:a(0),throw:a(1),return:a(2)},typeof Symbol=="function"&&(s[Symbol.iterator]=function(){return this}),s;function a(l){return function(d){return c([l,d])}}function c(l){if(r)throw new TypeError("Generator is already executing.");for(;n;)try{if(r=1,o&&(i=l[0]&2?o.return:l[0]?o.throw||((i=o.return)&&i.call(o),0):o.next)&&!(i=i.call(o,l[1])).done)return i;switch(o=0,i&&(l=[l[0]&2,i.value]),l[0]){case 0:case 1:i=l;break;case 4:return n.label++,{value:l[1],done:!1};case 5:n.label++,o=l[1],l=[0];continue;case 7:l=n.ops.pop(),n.trys.pop();continue;default:if(i=n.trys,!(i=i.length>0&&i[i.length-1])&&(l[0]===6||l[0]===2)){n=0;continue}if(l[0]===3&&(!i||l[1]>i[0]&&l[1]<i[3])){n.label=l[1];break}if(l[0]===6&&n.label<i[1]){n.label=i[1],i=l;break}if(i&&n.label<i[2]){n.label=i[2],n.ops.push(l);break}i[2]&&n.ops.pop(),n.trys.pop();continue}l=t.call(e,n)}catch(d){l=[6,d],o=0}finally{r=i=0}if(l[0]&5)throw l[1];return{value:l[0]?l[1]:void 0,done:!0}}}function B2(e,t,n,r){r===void 0&&(r=n),e[r]=t[n]}function W2(e,t){for(var n in e)n!=="default"&&!t.hasOwnProperty(n)&&(t[n]=e[n])}function Ql(e){var t=typeof Symbol=="function"&&Symbol.iterator,n=t&&e[t],r=0;if(n)return n.call(e);if(e&&typeof e.length=="number")return{next:function(){return e&&r>=e.length&&(e=void 0),{value:e&&e[r++],done:!e}}};throw new TypeError(t?"Object is not iterable.":"Symbol.iterator is not defined.")}function Jp(e,t){var n=typeof Symbol=="function"&&e[Symbol.iterator];if(!n)return e;var r=n.call(e),o,i=[],s;try{for(;(t===void 0||t-- >0)&&!(o=r.next()).done;)i.push(o.value)}catch(a){s={error:a}}finally{try{o&&!o.done&&(n=r.return)&&n.call(r)}finally{if(s)throw s.error}}return i}function j2(){for(var e=[],t=0;t<arguments.length;t++)e=e.concat(Jp(arguments[t]));return e}function F2(){for(var e=0,t=0,n=arguments.length;t<n;t++)e+=arguments[t].length;for(var r=Array(e),o=0,t=0;t<n;t++)for(var i=arguments[t],s=0,a=i.length;s<a;s++,o++)r[o]=i[s];return r}function Cs(e){return this instanceof Cs?(this.v=e,this):new Cs(e)}function z2(e,t,n){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var r=n.apply(e,t||[]),o,i=[];return o={},s("next"),s("throw"),s("return"),o[Symbol.asyncIterator]=function(){return this},o;function s(f){r[f]&&(o[f]=function(w){return new Promise(function(v,y){i.push([f,w,v,y])>1||a(f,w)})})}function a(f,w){try{c(r[f](w))}catch(v){h(i[0][3],v)}}function c(f){f.value instanceof Cs?Promise.resolve(f.value.v).then(l,d):h(i[0][2],f)}function l(f){a("next",f)}function d(f){a("throw",f)}function h(f,w){f(w),i.shift(),i.length&&a(i[0][0],i[0][1])}}function H2(e){var t,n;return t={},r("next"),r("throw",function(o){throw o}),r("return"),t[Symbol.iterator]=function(){return this},t;function r(o,i){t[o]=e[o]?function(s){return(n=!n)?{value:Cs(e[o](s)),done:o==="return"}:i?i(s):s}:i}}function V2(e){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var t=e[Symbol.asyncIterator],n;return t?t.call(e):(e=typeof Ql=="function"?Ql(e):e[Symbol.iterator](),n={},r("next"),r("throw"),r("return"),n[Symbol.asyncIterator]=function(){return this},n);function r(i){n[i]=e[i]&&function(s){return new Promise(function(a,c){s=e[i](s),o(a,c,s.done,s.value)})}}function o(i,s,a,c){Promise.resolve(c).then(function(l){i({value:l,done:a})},s)}}function q2(e,t){return Object.defineProperty?Object.defineProperty(e,"raw",{value:t}):e.raw=t,e}function K2(e){if(e&&e.__esModule)return e;var t={};if(e!=null)for(var n in e)Object.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t.default=e,t}function G2(e){return e&&e.__esModule?e:{default:e}}function Z2(e,t){if(!t.has(e))throw new TypeError("attempted to get private field on non-instance");return t.get(e)}function Y2(e,t,n){if(!t.has(e))throw new TypeError("attempted to set private field on non-instance");return t.set(e,n),n}const J2=Object.freeze(Object.defineProperty({__proto__:null,get __assign(){return Xl},__asyncDelegator:H2,__asyncGenerator:z2,__asyncValues:V2,__await:Cs,__awaiter:M2,__classPrivateFieldGet:Z2,__classPrivateFieldSet:Y2,__createBinding:B2,__decorate:P2,__exportStar:W2,__extends:I2,__generator:U2,__importDefault:G2,__importStar:K2,__makeTemplateObject:q2,__metadata:D2,__param:L2,__read:Jp,__rest:O2,__spread:j2,__spreadArrays:F2,__values:Ql},Symbol.toStringTag,{value:"Module"})),X2=Xf(J2);var zn={},Fu;function Q2(){if(Fu)return zn;Fu=1,Object.defineProperty(zn,"__esModule",{value:!0}),zn.isBrowserCryptoAvailable=zn.getSubtleCrypto=zn.getBrowerCrypto=void 0;function e(){return(xn===null||xn===void 0?void 0:xn.crypto)||(xn===null||xn===void 0?void 0:xn.msCrypto)||{}}zn.getBrowerCrypto=e;function t(){const r=e();return r.subtle||r.webkitSubtle}zn.getSubtleCrypto=t;function n(){return!!e()&&!!t()}return zn.isBrowserCryptoAvailable=n,zn}var Hn={},zu;function e3(){if(zu)return Hn;zu=1,Object.defineProperty(Hn,"__esModule",{value:!0}),Hn.isBrowser=Hn.isNode=Hn.isReactNative=void 0;function e(){return typeof document>"u"&&typeof navigator<"u"&&navigator.product==="ReactNative"}Hn.isReactNative=e;function t(){return typeof process<"u"&&typeof process.versions<"u"&&typeof process.versions.node<"u"}Hn.isNode=t;function n(){return!e()&&!t()}return Hn.isBrowser=n,Hn}var Hu;function t3(){return Hu||(Hu=1,(function(e){Object.defineProperty(e,"__esModule",{value:!0});const t=X2;t.__exportStar(Q2(),e),t.__exportStar(e3(),e)})(rl)),rl}var Sv=t3(),ba={exports:{}},Vu;function n3(){return Vu||(Vu=1,(function(e,t){var n=typeof globalThis<"u"&&globalThis||typeof self<"u"&&self||typeof xn<"u"&&xn,r=(function(){function i(){this.fetch=!1,this.DOMException=n.DOMException}return i.prototype=n,new i})();(function(i){(function(s){var a=typeof i<"u"&&i||typeof self<"u"&&self||typeof xn<"u"&&xn||{},c={searchParams:"URLSearchParams"in a,iterable:"Symbol"in a&&"iterator"in Symbol,blob:"FileReader"in a&&"Blob"in a&&(function(){try{return new Blob,!0}catch{return!1}})(),formData:"FormData"in a,arrayBuffer:"ArrayBuffer"in a};function l(b){return b&&DataView.prototype.isPrototypeOf(b)}if(c.arrayBuffer)var d=["[object Int8Array]","[object Uint8Array]","[object Uint8ClampedArray]","[object Int16Array]","[object Uint16Array]","[object Int32Array]","[object Uint32Array]","[object Float32Array]","[object Float64Array]"],h=ArrayBuffer.isView||function(b){return b&&d.indexOf(Object.prototype.toString.call(b))>-1};function f(b){if(typeof b!="string"&&(b=String(b)),/[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(b)||b==="")throw new TypeError('Invalid character in header field name: "'+b+'"');return b.toLowerCase()}function w(b){return typeof b!="string"&&(b=String(b)),b}function v(b){var E={next:function(){var H=b.shift();return{done:H===void 0,value:H}}};return c.iterable&&(E[Symbol.iterator]=function(){return E}),E}function y(b){this.map={},b instanceof y?b.forEach(function(E,H){this.append(H,E)},this):Array.isArray(b)?b.forEach(function(E){if(E.length!=2)throw new TypeError("Headers constructor: expected name/value pair to be length 2, found"+E.length);this.append(E[0],E[1])},this):b&&Object.getOwnPropertyNames(b).forEach(function(E){this.append(E,b[E])},this)}y.prototype.append=function(b,E){b=f(b),E=w(E);var H=this.map[b];this.map[b]=H?H+", "+E:E},y.prototype.delete=function(b){delete this.map[f(b)]},y.prototype.get=function(b){return b=f(b),this.has(b)?this.map[b]:null},y.prototype.has=function(b){return this.map.hasOwnProperty(f(b))},y.prototype.set=function(b,E){this.map[f(b)]=w(E)},y.prototype.forEach=function(b,E){for(var H in this.map)this.map.hasOwnProperty(H)&&b.call(E,this.map[H],H,this)},y.prototype.keys=function(){var b=[];return this.forEach(function(E,H){b.push(H)}),v(b)},y.prototype.values=function(){var b=[];return this.forEach(function(E){b.push(E)}),v(b)},y.prototype.entries=function(){var b=[];return this.forEach(function(E,H){b.push([H,E])}),v(b)},c.iterable&&(y.prototype[Symbol.iterator]=y.prototype.entries);function $(b){if(!b._noBody){if(b.bodyUsed)return Promise.reject(new TypeError("Already read"));b.bodyUsed=!0}}function I(b){return new Promise(function(E,H){b.onload=function(){E(b.result)},b.onerror=function(){H(b.error)}})}function k(b){var E=new FileReader,H=I(E);return E.readAsArrayBuffer(b),H}function D(b){var E=new FileReader,H=I(E),F=/charset=([A-Za-z0-9_-]+)/.exec(b.type),re=F?F[1]:"utf-8";return E.readAsText(b,re),H}function C(b){for(var E=new Uint8Array(b),H=new Array(E.length),F=0;F<E.length;F++)H[F]=String.fromCharCode(E[F]);return H.join("")}function A(b){if(b.slice)return b.slice(0);var E=new Uint8Array(b.byteLength);return E.set(new Uint8Array(b)),E.buffer}function _(){return this.bodyUsed=!1,this._initBody=function(b){this.bodyUsed=this.bodyUsed,this._bodyInit=b,b?typeof b=="string"?this._bodyText=b:c.blob&&Blob.prototype.isPrototypeOf(b)?this._bodyBlob=b:c.formData&&FormData.prototype.isPrototypeOf(b)?this._bodyFormData=b:c.searchParams&&URLSearchParams.prototype.isPrototypeOf(b)?this._bodyText=b.toString():c.arrayBuffer&&c.blob&&l(b)?(this._bodyArrayBuffer=A(b.buffer),this._bodyInit=new Blob([this._bodyArrayBuffer])):c.arrayBuffer&&(ArrayBuffer.prototype.isPrototypeOf(b)||h(b))?this._bodyArrayBuffer=A(b):this._bodyText=b=Object.prototype.toString.call(b):(this._noBody=!0,this._bodyText=""),this.headers.get("content-type")||(typeof b=="string"?this.headers.set("content-type","text/plain;charset=UTF-8"):this._bodyBlob&&this._bodyBlob.type?this.headers.set("content-type",this._bodyBlob.type):c.searchParams&&URLSearchParams.prototype.isPrototypeOf(b)&&this.headers.set("content-type","application/x-www-form-urlencoded;charset=UTF-8"))},c.blob&&(this.blob=function(){var b=$(this);if(b)return b;if(this._bodyBlob)return Promise.resolve(this._bodyBlob);if(this._bodyArrayBuffer)return Promise.resolve(new Blob([this._bodyArrayBuffer]));if(this._bodyFormData)throw new Error("could not read FormData body as blob");return Promise.resolve(new Blob([this._bodyText]))}),this.arrayBuffer=function(){if(this._bodyArrayBuffer){var b=$(this);return b||(ArrayBuffer.isView(this._bodyArrayBuffer)?Promise.resolve(this._bodyArrayBuffer.buffer.slice(this._bodyArrayBuffer.byteOffset,this._bodyArrayBuffer.byteOffset+this._bodyArrayBuffer.byteLength)):Promise.resolve(this._bodyArrayBuffer))}else{if(c.blob)return this.blob().then(k);throw new Error("could not read as ArrayBuffer")}},this.text=function(){var b=$(this);if(b)return b;if(this._bodyBlob)return D(this._bodyBlob);if(this._bodyArrayBuffer)return Promise.resolve(C(this._bodyArrayBuffer));if(this._bodyFormData)throw new Error("could not read FormData body as text");return Promise.resolve(this._bodyText)},c.formData&&(this.formData=function(){return this.text().then(W)}),this.json=function(){return this.text().then(JSON.parse)},this}var P=["CONNECT","DELETE","GET","HEAD","OPTIONS","PATCH","POST","PUT","TRACE"];function B(b){var E=b.toUpperCase();return P.indexOf(E)>-1?E:b}function j(b,E){if(!(this instanceof j))throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');E=E||{};var H=E.body;if(b instanceof j){if(b.bodyUsed)throw new TypeError("Already read");this.url=b.url,this.credentials=b.credentials,E.headers||(this.headers=new y(b.headers)),this.method=b.method,this.mode=b.mode,this.signal=b.signal,!H&&b._bodyInit!=null&&(H=b._bodyInit,b.bodyUsed=!0)}else this.url=String(b);if(this.credentials=E.credentials||this.credentials||"same-origin",(E.headers||!this.headers)&&(this.headers=new y(E.headers)),this.method=B(E.method||this.method||"GET"),this.mode=E.mode||this.mode||null,this.signal=E.signal||this.signal||(function(){if("AbortController"in a){var Z=new AbortController;return Z.signal}})(),this.referrer=null,(this.method==="GET"||this.method==="HEAD")&&H)throw new TypeError("Body not allowed for GET or HEAD requests");if(this._initBody(H),(this.method==="GET"||this.method==="HEAD")&&(E.cache==="no-store"||E.cache==="no-cache")){var F=/([?&])_=[^&]*/;if(F.test(this.url))this.url=this.url.replace(F,"$1_="+new Date().getTime());else{var re=/\?/;this.url+=(re.test(this.url)?"&":"?")+"_="+new Date().getTime()}}}j.prototype.clone=function(){return new j(this,{body:this._bodyInit})};function W(b){var E=new FormData;return b.trim().split("&").forEach(function(H){if(H){var F=H.split("="),re=F.shift().replace(/\+/g," "),Z=F.join("=").replace(/\+/g," ");E.append(decodeURIComponent(re),decodeURIComponent(Z))}}),E}function z(b){var E=new y,H=b.replace(/\r?\n[\t ]+/g," ");return H.split("\r").map(function(F){return F.indexOf(`
`)===0?F.substr(1,F.length):F}).forEach(function(F){var re=F.split(":"),Z=re.shift().trim();if(Z){var Ne=re.join(":").trim();try{E.append(Z,Ne)}catch(We){console.warn("Response "+We.message)}}}),E}_.call(j.prototype);function Y(b,E){if(!(this instanceof Y))throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');if(E||(E={}),this.type="default",this.status=E.status===void 0?200:E.status,this.status<200||this.status>599)throw new RangeError("Failed to construct 'Response': The status provided (0) is outside the range [200, 599].");this.ok=this.status>=200&&this.status<300,this.statusText=E.statusText===void 0?"":""+E.statusText,this.headers=new y(E.headers),this.url=E.url||"",this._initBody(b)}_.call(Y.prototype),Y.prototype.clone=function(){return new Y(this._bodyInit,{status:this.status,statusText:this.statusText,headers:new y(this.headers),url:this.url})},Y.error=function(){var b=new Y(null,{status:200,statusText:""});return b.ok=!1,b.status=0,b.type="error",b};var ue=[301,302,303,307,308];Y.redirect=function(b,E){if(ue.indexOf(E)===-1)throw new RangeError("Invalid status code");return new Y(null,{status:E,headers:{location:b}})},s.DOMException=a.DOMException;try{new s.DOMException}catch{s.DOMException=function(E,H){this.message=E,this.name=H;var F=Error(E);this.stack=F.stack},s.DOMException.prototype=Object.create(Error.prototype),s.DOMException.prototype.constructor=s.DOMException}function V(b,E){return new Promise(function(H,F){var re=new j(b,E);if(re.signal&&re.signal.aborted)return F(new s.DOMException("Aborted","AbortError"));var Z=new XMLHttpRequest;function Ne(){Z.abort()}Z.onload=function(){var Re={statusText:Z.statusText,headers:z(Z.getAllResponseHeaders()||"")};re.url.indexOf("file://")===0&&(Z.status<200||Z.status>599)?Re.status=200:Re.status=Z.status,Re.url="responseURL"in Z?Z.responseURL:Re.headers.get("X-Request-URL");var Ve="response"in Z?Z.response:Z.responseText;setTimeout(function(){H(new Y(Ve,Re))},0)},Z.onerror=function(){setTimeout(function(){F(new TypeError("Network request failed"))},0)},Z.ontimeout=function(){setTimeout(function(){F(new TypeError("Network request timed out"))},0)},Z.onabort=function(){setTimeout(function(){F(new s.DOMException("Aborted","AbortError"))},0)};function We(Re){try{return Re===""&&a.location.href?a.location.href:Re}catch{return Re}}if(Z.open(re.method,We(re.url),!0),re.credentials==="include"?Z.withCredentials=!0:re.credentials==="omit"&&(Z.withCredentials=!1),"responseType"in Z&&(c.blob?Z.responseType="blob":c.arrayBuffer&&(Z.responseType="arraybuffer")),E&&typeof E.headers=="object"&&!(E.headers instanceof y||a.Headers&&E.headers instanceof a.Headers)){var He=[];Object.getOwnPropertyNames(E.headers).forEach(function(Re){He.push(f(Re)),Z.setRequestHeader(Re,w(E.headers[Re]))}),re.headers.forEach(function(Re,Ve){He.indexOf(Ve)===-1&&Z.setRequestHeader(Ve,Re)})}else re.headers.forEach(function(Re,Ve){Z.setRequestHeader(Ve,Re)});re.signal&&(re.signal.addEventListener("abort",Ne),Z.onreadystatechange=function(){Z.readyState===4&&re.signal.removeEventListener("abort",Ne)}),Z.send(typeof re._bodyInit>"u"?null:re._bodyInit)})}return V.polyfill=!0,a.fetch||(a.fetch=V,a.Headers=y,a.Request=j,a.Response=Y),s.Headers=y,s.Request=j,s.Response=Y,s.fetch=V,Object.defineProperty(s,"__esModule",{value:!0}),s})({})})(r),r.fetch.ponyfill=!0,delete r.fetch.polyfill;var o=n.fetch?n:r;t=o.fetch,t.default=o.fetch,t.fetch=o.fetch,t.Headers=o.Headers,t.Request=o.Request,t.Response=o.Response,e.exports=t})(ba,ba.exports)),ba.exports}var r3=n3();const Tv=Ei(r3);let Pr=null;const An={getSIWX(){return R.state.siwx},async initializeIfEnabled(e=p.getActiveCaipAddress()){const t=R.state.siwx;if(!(t&&e))return;const[n,r,o]=e.split(":");if(p.checkIfSupportedNetwork(n,`${n}:${r}`))try{if(R.state.remoteFeatures?.emailCapture){const s=p.getAccountData(n)?.user;await ye.open({view:"DataCapture",data:{email:s?.email??void 0}});return}if(Pr&&await Pr,(await t.getSessions(`${n}:${r}`,o)).length)return;await ye.open({view:"SIWXSignMessage"})}catch(i){console.error("SIWXUtil:initializeIfEnabled",i),X.sendEvent({type:"track",event:"SIWX_AUTH_ERROR",properties:this.getSIWXEventProperties(i)}),await U._getClient()?.disconnect().catch(console.error),S.reset("Connect"),Te.showError("A problem occurred while trying initialize authentication")}},async isAuthenticated(e=p.getActiveCaipAddress()){if(!R.state.siwx||!e)return!0;const{chainNamespace:n,chainId:r,address:o}=Jt.parseCaipAddress(e),i=`${n}:${r}`;return(await An.getSessions({address:o,caipNetworkId:i})).length>0},async requestSignMessage(){const e=R.state.siwx,t=L.getPlainAddress(p.getActiveCaipAddress()),n=ma();if(!e)throw new Error("SIWX is not enabled");if(!t)throw new Error("No ActiveCaipAddress found");if(!n)throw new Error("No ActiveCaipNetwork or client found");try{const r=await e.createMessage({chainId:n.caipNetworkId,accountAddress:t}),o=r.toString();let i="";e.signMessage?i=await e.signMessage({message:o,chainId:n.caipNetworkId,accountAddress:t}):(O.getConnectorId(n.chainNamespace)===N.CONNECTOR_ID.AUTH&&S.pushTransactionStack({}),i=await U.signMessage(o)||""),await e.addSession({data:r,message:o,signature:i}),p.setLastConnectedSIWECaipNetwork(n),ye.close(),X.sendEvent({type:"track",event:"SIWX_AUTH_SUCCESS",properties:this.getSIWXEventProperties()})}catch(r){(!ye.state.open||S.state.view==="ApproveTransaction")&&await ye.open({view:"SIWXSignMessage"}),Te.showError("Error signing message"),X.sendEvent({type:"track",event:"SIWX_AUTH_ERROR",properties:this.getSIWXEventProperties(r)}),console.error("SWIXUtil:requestSignMessage",r)}},async cancelSignMessage(){try{const e=this.getSIWX();if(e?.getRequired?.()){const n=p.getLastConnectedSIWECaipNetwork();if(n){const r=await e?.getSessions(n?.caipNetworkId,L.getPlainAddress(p.getActiveCaipAddress())||"");r&&r.length>0?await p.switchActiveNetwork(n):await U.disconnect()}else await U.disconnect()}else ye.close();ye.close(),X.sendEvent({event:"CLICK_CANCEL_SIWX",type:"track",properties:this.getSIWXEventProperties()})}catch(e){console.error("SIWXUtil:cancelSignMessage",e)}},async getAllSessions(){const e=this.getSIWX(),t=p.getAllRequestedCaipNetworks(),n=[];return await Promise.all(t.map(async r=>{const o=await e?.getSessions(r.caipNetworkId,L.getPlainAddress(p.getActiveCaipAddress())||"");o&&n.push(...o)})),n},async getSessions(e){const t=R.state.siwx;let n=e?.address;if(!n){const o=p.getActiveCaipAddress();n=L.getPlainAddress(o)}let r=e?.caipNetworkId;return r||(r=p.getActiveCaipNetwork()?.caipNetworkId),t&&n&&r?t.getSessions(r,n):[]},async isSIWXCloseDisabled(){const e=this.getSIWX();if(e){const t=S.state.view==="ApproveTransaction",n=S.state.view==="SIWXSignMessage";if(t||n)return e.getRequired?.()&&(await this.getSessions()).length===0}return!1},async authConnectorAuthenticate({authConnector:e,chainId:t,socialUri:n,preferredAccountType:r,chainNamespace:o}){const i=An.getSIWX(),s=ma();if(!i||!o.includes(N.CHAIN.EVM)||R.state.remoteFeatures?.emailCapture){const h=await e.connect({chainId:t,socialUri:n,preferredAccountType:r});return{address:h.address,chainId:h.chainId,accounts:h.accounts}}const a=`${o}:${t}`,c=await i.createMessage({chainId:a,accountAddress:"<<AccountAddress>>"}),l={accountAddress:c.accountAddress,chainId:c.chainId,domain:c.domain,uri:c.uri,version:c.version,nonce:c.nonce,notBefore:c.notBefore,statement:c.statement,resources:c.resources,requestId:c.requestId,issuedAt:c.issuedAt,expirationTime:c.expirationTime,serializedMessage:c.toString()},d=await e.connect({chainId:t,socialUri:n,siwxMessage:l,preferredAccountType:r});return l.accountAddress=d.address,l.serializedMessage=d.message||"",d.signature&&d.message&&await An.addEmbeddedWalletSession(l,d.message,d.signature),p.setLastConnectedSIWECaipNetwork(s),{address:d.address,chainId:d.chainId,accounts:d.accounts}},async addEmbeddedWalletSession(e,t,n){if(Pr)return Pr;const r=An.getSIWX();return r?(Pr=r.addSession({data:e,message:t,signature:n}).finally(()=>{Pr=null}),Pr):Promise.resolve()},async universalProviderAuthenticate({universalProvider:e,chains:t,methods:n}){const r=An.getSIWX(),o=ma(),i=new Set(t.map(l=>l.split(":")[0]));if(!r||i.size!==1||!i.has("eip155"))return!1;const s=await r.createMessage({chainId:ma()?.caipNetworkId||"",accountAddress:""}),a=await e.authenticate({nonce:s.nonce,domain:s.domain,uri:s.uri,exp:s.expirationTime,iat:s.issuedAt,nbf:s.notBefore,requestId:s.requestId,version:s.version,resources:s.resources,statement:s.statement,chainId:s.chainId,methods:n,chains:[s.chainId,...t.filter(l=>l!==s.chainId)]});Te.showLoading("Authenticating...",{autoClose:!1});const c={...a.session.peer.metadata,name:a.session.peer.metadata.name,icon:a.session.peer.metadata.icons?.[0],type:"WALLET_CONNECT"};if(p.setAccountProp("connectedWalletInfo",c,Array.from(i)[0]),a?.auths?.length){const l=a.auths.map(d=>{const h=e.client.formatAuthMessage({request:d.p,iss:d.p.iss});return{data:{...d.p,accountAddress:d.p.iss.split(":").slice(-1).join(""),chainId:d.p.iss.split(":").slice(2,4).join(":"),uri:d.p.aud??"",version:d.p.version||s.version,expirationTime:d.p.exp,issuedAt:d.p.iat,notBefore:d.p.nbf},message:h,signature:d.s.s,cacao:d}});try{await r.setSessions(l),o&&p.setLastConnectedSIWECaipNetwork(o),X.sendEvent({type:"track",event:"SIWX_AUTH_SUCCESS",properties:An.getSIWXEventProperties()})}catch(d){throw console.error("SIWX:universalProviderAuth - failed to set sessions",d),X.sendEvent({type:"track",event:"SIWX_AUTH_ERROR",properties:An.getSIWXEventProperties(d)}),await e.disconnect().catch(console.error),d}finally{Te.hide()}}return!0},getSIWXEventProperties(e){const t=p.state.activeChain;if(!t)throw new Error("SIWXUtil:getSIWXEventProperties - namespace is required");return{network:p.state.activeCaipNetwork?.caipNetworkId||"",isSmartAccount:ut(t)===je.ACCOUNT_TYPES.SMART_ACCOUNT,message:e?L.parseError(e):void 0}},async clearSessions(){const e=this.getSIWX();e&&await e.setSessions([])}},an=ze({message:"",variant:"info",open:!1}),i3={state:an,subscribeKey(e,t){return st(an,e,t)},open(e,t){const{debug:n}=R.state,{code:r,displayMessage:o,debugMessage:i}=e;o&&n&&(an.message=o,an.variant=t,an.open=!0)},warn(e,t,n){an.open=!0,an.message=e,an.variant="warning",t&&console.warn(t,n)},close(){an.open=!1,an.message="",an.variant="info"}},Xp=gn(i3),cn=ze({message:"",open:!1,triggerRect:{width:0,height:0,top:0,left:0},variant:"shade"}),o3={state:cn,subscribe(e){return ot(cn,()=>e(cn))},subscribeKey(e,t){return st(cn,e,t)},showTooltip({message:e,triggerRect:t,variant:n}){cn.open=!0,cn.message=e,cn.triggerRect=t,cn.variant=n},hide(){cn.open=!1,cn.message="",cn.triggerRect={width:0,height:0,top:0,left:0}}},Zt=gn(o3),To=ze({isLegalCheckboxChecked:!1}),qr={state:To,subscribe(e){return ot(To,()=>e(To))},subscribeKey(e,t){return st(To,e,t)},setIsLegalCheckboxChecked(e){To.isLegalCheckboxChecked=e}},s3={eip155:{native:{assetNamespace:"slip44",assetReference:"60"},defaultTokenNamespace:"erc20"},solana:{native:{assetNamespace:"slip44",assetReference:"501"},defaultTokenNamespace:"token"}};class a3 extends Error{}function c3(){const{sdkType:e,sdkVersion:t,projectId:n}=R.getSnapshot(),r=new URL("https://rpc.walletconnect.org/v1/json-rpc");return r.searchParams.set("projectId",n),r.searchParams.set("st",e),r.searchParams.set("sv",t),r.searchParams.set("source","fund-wallet"),r.toString()}async function Od(e,t){const n=c3(),{projectId:r}=R.getSnapshot(),o={jsonrpc:"2.0",id:1,method:e,params:{...t||{},projectId:r}},s=await(await fetch(n,{method:"POST",body:JSON.stringify(o),headers:{"Content-Type":"application/json"}})).json();if(s.error)throw new a3(s.error.message);return s}async function l3(e){return(await Od("reown_getExchanges",e)).result}async function d3(e){return(await Od("reown_getExchangePayUrl",e)).result}async function u3(e){return(await Od("reown_getExchangeBuyStatus",e)).result}function qu(e,t){const{chainNamespace:n,chainId:r}=Jt.parseCaipNetworkId(e),o=s3[n];if(!o)throw new Error(`Unsupported chain namespace for CAIP-19 formatting: ${n}`);let i=o.native.assetNamespace,s=o.native.assetReference;return t!=="native"&&(i=o.defaultTokenNamespace,s=t),`${`${n}:${r}`}/${i}:${s}`}const h3={network:"eip155:1",asset:"native",metadata:{name:"Ethereum",symbol:"ETH",decimals:18}},p3={network:"eip155:8453",asset:"native",metadata:{name:"Ethereum",symbol:"ETH",decimals:18}},f3={network:"eip155:8453",asset:"0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},$v={asset:"0x036CbD53842c5426634e7929541eC2318f3dCF7e"},m3={network:"eip155:84532",asset:"native",metadata:{name:"Ethereum",symbol:"ETH",decimals:18}},g3={network:"eip155:1",asset:"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},w3={network:"eip155:42161",asset:"0xaf88d065e77c8cC2239327C5EDb3A432268e5831",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},b3={network:"eip155:137",asset:"0x2791bca1f2de4661ed88a30c99a7a9449aa84174",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},y3={network:"solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",asset:"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},C3={network:"eip155:1",asset:"0xdAC17F958D2ee523a2206206994597C13D831ec7",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},v3={network:"eip155:10",asset:"0x94b008aA00579c1307B0EF2c499aD98a8ce58e58",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},E3={network:"eip155:42161",asset:"0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},_3={network:"eip155:137",asset:"0xc2132d05d31c914a87c6611c10748aeb04b58e8f",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},A3={network:"solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",asset:"Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},x3={network:"solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",asset:"native",metadata:{name:"Solana",symbol:"SOL",decimals:9}},S3={ethereumETH:h3,baseETH:p3,baseUSDC:f3,baseSepoliaETH:m3,ethereumUSDC:g3,arbitrumUSDC:w3,polygonUSDC:b3,solanaUSDC:y3,ethereumUSDT:C3,optimismUSDT:v3,arbitrumUSDT:E3,polygonUSDT:_3,solanaUSDT:A3,solanaSOL:x3};function T3(e){return Object.values(S3).filter(t=>t.network===e)}const $3=0,Qp={paymentAsset:null,amount:null,tokenAmount:0,priceLoading:!1,error:null,exchanges:[],isLoading:!1,currentPayment:void 0,isPaymentInProgress:!1,paymentId:"",assets:[]},fe=ze(Qp),nt={state:fe,subscribe(e){return ot(fe,()=>e(fe))},subscribeKey(e,t){return st(fe,e,t)},resetState(){Object.assign(fe,{...Qp})},async getAssetsForNetwork(e){const t=T3(e),n=await nt.getAssetsImageAndPrice(t),r=t.map(o=>{const i=o.asset==="native"?Za():`${o.network}:${o.asset}`,s=n.find(a=>a.fungibles?.[0]?.address?.toLowerCase()===i.toLowerCase());return{...o,price:s?.fungibles?.[0]?.price||1,metadata:{...o.metadata,iconUrl:s?.fungibles?.[0]?.iconUrl}}});return fe.assets=r,r},async getAssetsImageAndPrice(e){const t=e.map(r=>r.asset==="native"?Za():`${r.network}:${r.asset}`);return await Promise.all(t.map(r=>_e.fetchTokenPrice({addresses:[r]})))},getTokenAmount(){if(!fe?.paymentAsset?.price)throw new Error("Cannot get token price");const e=Ji.bigNumber(fe.amount??0).round(8),t=Ji.bigNumber(fe.paymentAsset.price).round(8);return e.div(t).round(8).toNumber()},setAmount(e){fe.amount=e,fe.paymentAsset?.price&&(fe.tokenAmount=nt.getTokenAmount())},setPaymentAsset(e){fe.paymentAsset=e},isPayWithExchangeEnabled(){return R.state.remoteFeatures?.payWithExchange},isPayWithExchangeSupported(){return nt.isPayWithExchangeEnabled()&&p.state.activeCaipNetwork&&ke.PAY_WITH_EXCHANGE_SUPPORTED_CHAIN_NAMESPACES.includes(p.state.activeCaipNetwork.chainNamespace)},async fetchExchanges(){try{const e=nt.isPayWithExchangeSupported();if(!fe.paymentAsset||!e){fe.exchanges=[],fe.isLoading=!1;return}fe.isLoading=!0;const t=await l3({page:$3,asset:qu(fe.paymentAsset.network,fe.paymentAsset.asset),amount:fe.amount?.toString()??"0"});fe.exchanges=t.exchanges.slice(0,2)}catch{throw Te.showError("Unable to get exchanges"),new Error("Unable to get exchanges")}finally{fe.isLoading=!1}},async getPayUrl(e,t){try{const n=Number(t.amount),r=await d3({exchangeId:e,asset:qu(t.network,t.asset),amount:n.toString(),recipient:`${t.network}:${t.recipient}`});return X.sendEvent({type:"track",event:"PAY_EXCHANGE_SELECTED",properties:{exchange:{id:e},configuration:{network:t.network,asset:t.asset,recipient:t.recipient,amount:n},currentPayment:{type:"exchange",exchangeId:e},source:"fund-from-exchange",headless:!1}}),r}catch(n){throw n instanceof Error&&n.message.includes("is not supported")?new Error("Asset not supported"):new Error(n.message)}},async handlePayWithExchange(e){try{const t=p.getAccountData()?.address;if(!t)throw new Error("No account connected");if(!fe.paymentAsset)throw new Error("No payment asset selected");const n=L.returnOpenHref("","popupWindow","scrollbar=yes,width=480,height=720");if(!n)throw new Error("Could not create popup window");fe.isPaymentInProgress=!0,fe.paymentId=crypto.randomUUID(),fe.currentPayment={type:"exchange",exchangeId:e};const{network:r,asset:o}=fe.paymentAsset,i={network:r,asset:o,amount:fe.tokenAmount,recipient:t},s=await nt.getPayUrl(e,i);if(!s){try{n.close()}catch(a){console.error("Unable to close popup window",a)}throw new Error("Unable to initiate payment")}fe.currentPayment.sessionId=s.sessionId,fe.currentPayment.status="IN_PROGRESS",fe.currentPayment.exchangeId=e,n.location.href=s.url}catch{fe.error="Unable to initiate payment",Te.showError(fe.error)}},async waitUntilComplete({exchangeId:e,sessionId:t,paymentId:n,retries:r=20}){const o=await nt.getBuyStatus(e,t,n);if(o.status==="SUCCESS"||o.status==="FAILED")return o;if(r===0)throw new Error("Unable to get deposit status");return await new Promise(i=>{setTimeout(i,5e3)}),nt.waitUntilComplete({exchangeId:e,sessionId:t,paymentId:n,retries:r-1})},async getBuyStatus(e,t,n){try{if(!fe.currentPayment)throw new Error("No current payment");const r=await u3({sessionId:t,exchangeId:e});if(fe.currentPayment.status=r.status,r.status==="SUCCESS"||r.status==="FAILED"){const o=p.getAccountData()?.address;fe.currentPayment.result=r.txHash,fe.isPaymentInProgress=!1,X.sendEvent({type:"track",event:r.status==="SUCCESS"?"PAY_SUCCESS":"PAY_ERROR",properties:{message:r.status==="FAILED"?L.parseError(fe.error):void 0,source:"fund-from-exchange",paymentId:n,configuration:{network:fe.paymentAsset?.network||"",asset:fe.paymentAsset?.asset||"",recipient:o||"",amount:fe.amount??0},currentPayment:{type:"exchange",exchangeId:fe.currentPayment?.exchangeId,sessionId:fe.currentPayment?.sessionId,result:r.txHash}}})}return r}catch{return{status:"UNKNOWN",txHash:""}}},reset(){fe.currentPayment=void 0,fe.isPaymentInProgress=!1,fe.paymentId="",fe.paymentAsset=null,fe.amount=0,fe.tokenAmount=0,fe.priceLoading=!1,fe.error=null,fe.exchanges=[],fe.isLoading=!1}};function N3(){try{return L.returnOpenHref(`${N.SECURE_SITE_SDK_ORIGIN}/loading`,"popupWindow","width=600,height=800,scrollbars=yes")}catch{throw new Error("Could not open social popup")}}async function R3(){S.push("ConnectingFarcaster");const e=O.getAuthConnector();if(e&&!p.getAccountData()?.farcasterUrl)try{const{url:n}=await e.provider.getFarcasterUri();p.setAccountProp("farcasterUrl",n,p.state.activeChain)}catch(n){S.goBack(),Te.showError(n)}}async function k3(e){S.push("ConnectingSocial");const t=O.getAuthConnector();let n=null;try{const r=setTimeout(()=>{throw new Error("Social login timed out. Please try again.")},45e3);if(t&&e){if(L.isTelegram()||(n=N3()),n)p.setAccountProp("socialWindow",Yi(n),p.state.activeChain);else if(!L.isTelegram())throw new Error("Could not create social popup");const{uri:o}=await t.provider.getSocialRedirectUri({provider:e});if(!o)throw n?.close(),new Error("Could not fetch the social redirect uri");if(n&&(n.location.href=o),L.isTelegram()){G.setTelegramSocialProvider(e);const i=L.formatTelegramSocialLoginUrl(o);L.openHref(i,"_top")}clearTimeout(r)}}catch(r){n?.close();const o=L.parseError(r);Te.showError(o),X.sendEvent({type:"track",event:"SOCIAL_LOGIN_ERROR",properties:{provider:e,message:o}})}}async function I3(e){p.setAccountProp("socialProvider",e,p.state.activeChain),X.sendEvent({type:"track",event:"SOCIAL_LOGIN_STARTED",properties:{provider:e}}),e==="farcaster"?await R3():await k3(e)}const ef={METMASK_CONNECTOR_NAME:"MetaMask",TRUST_CONNECTOR_NAME:"Trust Wallet",SOLFLARE_CONNECTOR_NAME:"Solflare",PHANTOM_CONNECTOR_NAME:"Phantom",COIN98_CONNECTOR_NAME:"Coin98",MAGIC_EDEN_CONNECTOR_NAME:"Magic Eden",BACKPACK_CONNECTOR_NAME:"Backpack",BITGET_CONNECTOR_NAME:"Bitget Wallet",FRONTIER_CONNECTOR_NAME:"Frontier",XVERSE_CONNECTOR_NAME:"Xverse Wallet",LEATHER_CONNECTOR_NAME:"Leather",OKX_CONNECTOR_NAME:"OKX Wallet",BINANCE_CONNECTOR_NAME:"Binance Wallet",EIP155:N.CHAIN.EVM,ADD_CHAIN_METHOD:"wallet_addEthereumChain",EIP6963_ANNOUNCE_EVENT:"eip6963:announceProvider",EIP6963_REQUEST_EVENT:"eip6963:requestProvider",CONNECTOR_RDNS_MAP:{coinbaseWallet:"com.coinbase.wallet",coinbaseWalletSDK:"com.coinbase.wallet"},CONNECTOR_TYPE_EXTERNAL:"EXTERNAL",CONNECTOR_TYPE_WALLET_CONNECT:"WALLET_CONNECT",CONNECTOR_TYPE_INJECTED:"INJECTED",CONNECTOR_TYPE_ANNOUNCED:"ANNOUNCED",CONNECTOR_TYPE_AUTH:"AUTH",CONNECTOR_TYPE_MULTI_CHAIN:"MULTI_CHAIN",CONNECTOR_TYPE_W3M_AUTH:"AUTH",getSDKVersionWarningMessage(e,t){return`
     @@@@@@@           @@@@@@@@@@@@@@@@@@      
   @@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@@@@   
  @@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@@  
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@@@@@@@@@@@@@@@  
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@@   @@@@@@@@@@@ 
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@   @@@@@@@@@@@@ 
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@  @@@@@@@@@@@@@
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@   @@@@@@@@@@@@@    
 @@@@@@   @@@@@@  @@@@@@@@@@@   @@@@@@@@@@@@@@    
 @@@@@@   @@@@@@  @@@@@@@@@@@  @@@@@@@@@@@@@@@ 
 @@@@@@@@@@@@@@@  @@@@@@@@@@   @@@@@@@@@@@@@@@ 
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@@@@@@@@@@@@@@@  
  @@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@@  
   @@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@@@@   
      @@@@@            @@@@@@@@@@@@@@@@@@  
      
AppKit SDK version ${e} is outdated. Latest version is ${t}. Please update to the latest version for bug fixes and new features.
            
Changelog: https://github.com/reown-com/appkit/releases
NPM Registry: https://www.npmjs.com/package/@reown/appkit`}},O3={NetworkImageIds:{1:"ba0ba0cd-17c6-4806-ad93-f9d174f17900",42161:"3bff954d-5cb0-47a0-9a23-d20192e74600",43114:"30c46e53-e989-45fb-4549-be3bd4eb3b00",56:"93564157-2e8e-4ce7-81df-b264dbee9b00",250:"06b26297-fe0c-4733-5d6b-ffa5498aac00",10:"ab9c186a-c52f-464b-2906-ca59d760a400",137:"41d04d42-da3b-4453-8506-668cc0727900",5e3:"e86fae9b-b770-4eea-e520-150e12c81100",295:"6a97d510-cac8-4e58-c7ce-e8681b044c00",11155111:"e909ea0a-f92a-4512-c8fc-748044ea6800",84532:"a18a7ecd-e307-4360-4746-283182228e00",1301:"4eeea7ef-0014-4649-5d1d-07271a80f600",130:"2257980a-3463-48c6-cbac-a42d2a956e00",10143:"0a728e83-bacb-46db-7844-948f05434900",100:"02b53f6a-e3d4-479e-1cb4-21178987d100",9001:"f926ff41-260d-4028-635e-91913fc28e00",324:"b310f07f-4ef7-49f3-7073-2a0a39685800",314:"5a73b3dd-af74-424e-cae0-0de859ee9400",4689:"34e68754-e536-40da-c153-6ef2e7188a00",1088:"3897a66d-40b9-4833-162f-a2c90531c900",1284:"161038da-44ae-4ec7-1208-0ea569454b00",1285:"f1d73bb6-5450-4e18-38f7-fb6484264a00",7777777:"845c60df-d429-4991-e687-91ae45791600",42220:"ab781bbc-ccc6-418d-d32d-789b15da1f00",8453:"7289c336-3981-4081-c5f4-efc26ac64a00",1313161554:"3ff73439-a619-4894-9262-4470c773a100",2020:"b8101fc0-9c19-4b6f-ec65-f6dfff106e00",2021:"b8101fc0-9c19-4b6f-ec65-f6dfff106e00",80094:"e329c2c9-59b0-4a02-83e4-212ff3779900",2741:"fc2427d1-5af9-4a9c-8da5-6f94627cd900","5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp":"a1b58899-f671-4276-6a5e-56ca5bd59700","4uhcVJyU9pJkvQyS88uRDiswHXSCkY3z":"a1b58899-f671-4276-6a5e-56ca5bd59700",EtWTRABZaYq6iMfeYKouRu166VU2xqa1:"a1b58899-f671-4276-6a5e-56ca5bd59700","000000000019d6689c085ae165831e93":"0b4838db-0161-4ffe-022d-532bf03dba00","000000000933ea01ad0ee984209779ba":"39354064-d79b-420b-065d-f980c4b78200","00000008819873e925422c1ff0f99f7c":"b3406e4a-bbfc-44fb-e3a6-89673c78b700","-239":"20f673c0-095e-49b2-07cf-eb5049dcf600","-3":"20f673c0-095e-49b2-07cf-eb5049dcf600"}},Wt={getCaipTokens(e){if(!e)return;const t={};return Object.entries(e).forEach(([n,r])=>{t[`${ef.EIP155}:${n}`]=r}),t},isLowerCaseMatch(e,t){return e?.toLowerCase()===t?.toLowerCase()},getActiveNamespaceConnectedToAuth(){const e=p.state.activeChain;return N.AUTH_CONNECTOR_SUPPORTED_CHAINS.find(t=>O.getConnectorId(t)===N.CONNECTOR_ID.AUTH&&t===e)},withRetry({conditionFn:e,intervalMs:t,maxRetries:n}){let r=0;return new Promise(o=>{async function i(){return r+=1,await e()?o(!0):r>=n?o(!1):(setTimeout(i,t),null)}i()})},userChainIdToChainNamespace(e){if(typeof e=="number")return N.CHAIN.EVM;const[t]=e.split(":");return t},getOtherAuthNamespaces(e){return e?N.AUTH_CONNECTOR_SUPPORTED_CHAINS.filter(r=>r!==e):[]},getConnectorStorageInfo(e,t){const r=G.getConnections()[t]??[];return{hasDisconnected:G.isConnectorDisconnected(e,t),hasConnected:r.some(o=>Wt.isLowerCaseMatch(o.connectorId,e))}}},P3=new AbortController,L3={EmbeddedWalletAbortController:P3,UniversalProviderErrors:{UNAUTHORIZED_DOMAIN_NOT_ALLOWED:{message:"Unauthorized: origin not allowed",alertErrorKey:"ORIGIN_NOT_ALLOWED"},JWT_VALIDATION_ERROR:{message:"JWT validation error: JWT Token is not yet valid",alertErrorKey:"JWT_TOKEN_NOT_VALID"},INVALID_KEY:{message:"Unauthorized: invalid key",alertErrorKey:"INVALID_PROJECT_ID"}},ALERT_ERRORS:{SWITCH_NETWORK_NOT_FOUND:{code:"APKT001",displayMessage:"Network Not Found",debugMessage:"The specified network is not recognized. Please ensure it is included in the `networks` array of your `createAppKit` configuration."},ORIGIN_NOT_ALLOWED:{code:"APKT002",displayMessage:"Invalid App Configuration",debugMessage:()=>`The origin ${Io()?window.origin:"unknown"} is not in your allow list. Please update your allowed domains at https://dashboard.reown.com. [PID: ${R.state.projectId}]`},IFRAME_LOAD_FAILED:{code:"APKT003",displayMessage:"Network Error: Wallet Load Failed",debugMessage:()=>"Failed to load the embedded wallet. This may be due to network issues or server downtime. Please check your network connection and try again shortly. Contact support if the issue persists."},IFRAME_REQUEST_TIMEOUT:{code:"APKT004",displayMessage:"Wallet Request Timeout",debugMessage:()=>"The request to the embedded wallet timed out. Please check your network connection and try again shortly. Contact support if the issue persists."},UNVERIFIED_DOMAIN:{code:"APKT005",displayMessage:"Unverified Domain",debugMessage:()=>"Embedded wallet load failed. Ensure your domain is verified in https://dashboard.reown.com."},JWT_TOKEN_NOT_VALID:{code:"APKT006",displayMessage:"Session Expired",debugMessage:"Your session is invalid or expired. Please check your system’s date and time settings, then reconnect."},INVALID_PROJECT_ID:{code:"APKT007",displayMessage:"Invalid Project ID",debugMessage:"The specified project ID is invalid. Please visit https://dashboard.reown.com to obtain a valid project ID."},PROJECT_ID_NOT_CONFIGURED:{code:"APKT008",displayMessage:"Project ID Missing",debugMessage:"No project ID is configured. You can create and configure a project ID at https://dashboard.reown.com."},SERVER_ERROR_APP_CONFIGURATION:{code:"APKT009",displayMessage:"Server Error",debugMessage:e=>`Unable to fetch App Configuration. ${e}. Please check your network connection and try again shortly. Contact support if the issue persists.`},RATE_LIMITED_APP_CONFIGURATION:{code:"APKT010",displayMessage:"Rate Limited",debugMessage:"You have been rate limited while retrieving App Configuration. Please wait a few minutes and try again. Contact support if the issue persists."}},ALERT_WARNINGS:{LOCAL_CONFIGURATION_IGNORED:{debugMessage:e=>`[Reown Config Notice] ${e}`},INACTIVE_NAMESPACE_NOT_CONNECTED:{code:"APKTW001",displayMessage:"Inactive Namespace Not Connected",debugMessage:(e,t)=>`An error occurred while connecting an inactive namespace ${e}: "${t}"`},INVALID_EMAIL:{code:"APKTW002",displayMessage:"Invalid Email Address",debugMessage:"Please enter a valid email address"}}},D3="rpc.walletconnect.org";function Ku(e,t){const n=new URL("https://rpc.walletconnect.org/v1/");return n.searchParams.set("chainId",e),n.searchParams.set("projectId",t),n.toString()}const il=["near:mainnet","solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp","eip155:1101","eip155:56","eip155:42161","eip155:7777777","eip155:59144","eip155:324","solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1","eip155:5000","solana:4sgjmw1sunhzsxgspuhpqldx6wiyjntz","eip155:80084","eip155:5003","eip155:100","eip155:8453","eip155:42220","eip155:1313161555","eip155:17000","eip155:1","eip155:300","eip155:1313161554","eip155:1329","eip155:84532","eip155:421614","eip155:11155111","eip155:8217","eip155:43114","solana:4uhcVJyU9pJkvQyS88uRDiswHXSCkY3z","eip155:999999999","eip155:11155420","eip155:80002","eip155:97","eip155:43113","eip155:137","eip155:10","eip155:1301","eip155:80094","eip155:80069","eip155:560048","eip155:31","eip155:2818","eip155:57054","eip155:911867","eip155:534351","eip155:1112","eip155:534352","eip155:1111","eip155:146","eip155:130","eip155:1284","eip155:30","eip155:2810","bip122:000000000019d6689c085ae165831e93","bip122:000000000933ea01ad0ee984209779ba"],tf={extendRpcUrlWithProjectId(e,t){let n=!1;try{n=new URL(e).host===D3}catch{n=!1}if(n){const r=new URL(e);return r.searchParams.has("projectId")||r.searchParams.set("projectId",t),r.toString()}return e},isCaipNetwork(e){return"chainNamespace"in e&&"caipNetworkId"in e},getChainNamespace(e){return this.isCaipNetwork(e)?e.chainNamespace:N.CHAIN.EVM},getCaipNetworkId(e){return this.isCaipNetwork(e)?e.caipNetworkId:`${N.CHAIN.EVM}:${e.id}`},getDefaultRpcUrl(e,t,n){const r=e.rpcUrls?.default?.http?.[0];return il.includes(t)?Ku(t,n):r||""},extendCaipNetwork(e,{customNetworkImageUrls:t,projectId:n,customRpcUrls:r}){const o=this.getChainNamespace(e),i=this.getCaipNetworkId(e),s=e.rpcUrls?.default?.http?.[0],a=this.getDefaultRpcUrl(e,i,n),c=e?.rpcUrls?.chainDefault?.http?.[0]||s,l=r?.[i]?.map(f=>f.url)||[],d=[...l,...a?[a]:[]],h=[...l];return c&&!h.includes(c)&&h.push(c),{...e,chainNamespace:o,caipNetworkId:i,assets:{imageId:O3.NetworkImageIds[e.id],imageUrl:t?.[e.id]},rpcUrls:{...e.rpcUrls,default:{http:d},chainDefault:{http:h}}}},extendCaipNetworks(e,{customNetworkImageUrls:t,projectId:n,customRpcUrls:r}){return e.map(o=>tf.extendCaipNetwork(o,{customNetworkImageUrls:t,customRpcUrls:r,projectId:n}))},getViemTransport(e,t,n){const r=[];return n?.forEach(o=>{r.push(fa(o.url,o.config))}),il.includes(e.caipNetworkId)&&r.push(fa(Ku(e.caipNetworkId,t),{fetchOptions:{headers:{"Content-Type":"text/plain"}}})),e?.rpcUrls?.default?.http?.forEach(o=>{r.push(fa(o))}),Lu(r)},extendWagmiTransports(e,t,n){if(il.includes(e.caipNetworkId)){const r=this.getDefaultRpcUrl(e,e.caipNetworkId,t);return Lu([n,fa(r)])}return n},getUnsupportedNetwork(e){return{id:e.split(":")[1],caipNetworkId:e,name:N.UNSUPPORTED_NETWORK_NAME,chainNamespace:e.split(":")[0],nativeCurrency:{name:"",decimals:0,symbol:""},rpcUrls:{default:{http:[]}}}},getCaipNetworkFromStorage(e){const t=G.getActiveCaipNetworkId(),n=p.getAllRequestedCaipNetworks(),r=Array.from(p.state.chains?.keys()||[]),o=t?.split(":")[0],i=o?r.includes(o):!1,s=n?.find(c=>c.caipNetworkId===t);return i&&!s&&t?this.getUnsupportedNetwork(t):s||e||n?.[0]}};function M3(e){if(e.length>=255)throw new TypeError("Alphabet too long");const t=new Uint8Array(256);for(let l=0;l<t.length;l++)t[l]=255;for(let l=0;l<e.length;l++){const d=e.charAt(l),h=d.charCodeAt(0);if(t[h]!==255)throw new TypeError(d+" is ambiguous");t[h]=l}const n=e.length,r=e.charAt(0),o=Math.log(n)/Math.log(256),i=Math.log(256)/Math.log(n);function s(l){if(l instanceof Uint8Array||(ArrayBuffer.isView(l)?l=new Uint8Array(l.buffer,l.byteOffset,l.byteLength):Array.isArray(l)&&(l=Uint8Array.from(l))),!(l instanceof Uint8Array))throw new TypeError("Expected Uint8Array");if(l.length===0)return"";let d=0,h=0,f=0;const w=l.length;for(;f!==w&&l[f]===0;)f++,d++;const v=(w-f)*i+1>>>0,y=new Uint8Array(v);for(;f!==w;){let k=l[f],D=0;for(let C=v-1;(k!==0||D<h)&&C!==-1;C--,D++)k+=256*y[C]>>>0,y[C]=k%n>>>0,k=k/n>>>0;if(k!==0)throw new Error("Non-zero carry");h=D,f++}let $=v-h;for(;$!==v&&y[$]===0;)$++;let I=r.repeat(d);for(;$<v;++$)I+=e.charAt(y[$]);return I}function a(l){if(typeof l!="string")throw new TypeError("Expected String");if(l.length===0)return new Uint8Array;let d=0,h=0,f=0;for(;l[d]===r;)h++,d++;const w=(l.length-d)*o+1>>>0,v=new Uint8Array(w);for(;d<l.length;){const k=l.charCodeAt(d);if(k>255)return;let D=t[k];if(D===255)return;let C=0;for(let A=w-1;(D!==0||C<f)&&A!==-1;A--,C++)D+=n*v[A]>>>0,v[A]=D%256>>>0,D=D/256>>>0;if(D!==0)throw new Error("Non-zero carry");f=C,d++}let y=w-f;for(;y!==w&&v[y]===0;)y++;const $=new Uint8Array(h+(w-y));let I=h;for(;y!==w;)$[I++]=v[y++];return $}function c(l){const d=a(l);if(d)return d;throw new Error("Non-base"+n+" character")}return{encode:s,decodeUnsafe:a,decode:c}}var U3="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";const Nv=M3(U3),Ja={interpolate(e,t,n){if(e.length!==2||t.length!==2)throw new Error("inputRange and outputRange must be an array of length 2");const r=e[0]||0,o=e[1]||0,i=t[0]||0,s=t[1]||0;return n<r?i:n>o?s:(s-i)/(o-r)*(n-r)+i}};/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ka=globalThis,Pd=ka.ShadowRoot&&(ka.ShadyCSS===void 0||ka.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Ld=Symbol(),Gu=new WeakMap;let nf=class{constructor(t,n,r){if(this._$cssResult$=!0,r!==Ld)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=n}get styleSheet(){let t=this.o;const n=this.t;if(Pd&&t===void 0){const r=n!==void 0&&n.length===1;r&&(t=Gu.get(n)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),r&&Gu.set(n,t))}return t}toString(){return this.cssText}};const ln=e=>new nf(typeof e=="string"?e:e+"",void 0,Ld),Nt=(e,...t)=>{const n=e.length===1?e[0]:t.reduce((r,o,i)=>r+(s=>{if(s._$cssResult$===!0)return s.cssText;if(typeof s=="number")return s;throw Error("Value passed to 'css' function must be a 'css' function result: "+s+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(o)+e[i+1],e[0]);return new nf(n,e,Ld)},B3=(e,t)=>{if(Pd)e.adoptedStyleSheets=t.map(n=>n instanceof CSSStyleSheet?n:n.styleSheet);else for(const n of t){const r=document.createElement("style"),o=ka.litNonce;o!==void 0&&r.setAttribute("nonce",o),r.textContent=n.cssText,e.appendChild(r)}},Zu=Pd?e=>e:e=>e instanceof CSSStyleSheet?(t=>{let n="";for(const r of t.cssRules)n+=r.cssText;return ln(n)})(e):e;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:W3,defineProperty:j3,getOwnPropertyDescriptor:F3,getOwnPropertyNames:z3,getOwnPropertySymbols:H3,getPrototypeOf:V3}=Object,Rc=globalThis,Yu=Rc.trustedTypes,q3=Yu?Yu.emptyScript:"",K3=Rc.reactiveElementPolyfillSupport,Lo=(e,t)=>e,Xa={toAttribute(e,t){switch(t){case Boolean:e=e?q3:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},Dd=(e,t)=>!W3(e,t),Ju={attribute:!0,type:String,converter:Xa,reflect:!1,useDefault:!1,hasChanged:Dd};Symbol.metadata??=Symbol("metadata"),Rc.litPropertyMetadata??=new WeakMap;let ji=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,n=Ju){if(n.state&&(n.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(t)&&((n=Object.create(n)).wrapped=!0),this.elementProperties.set(t,n),!n.noAccessor){const r=Symbol(),o=this.getPropertyDescriptor(t,r,n);o!==void 0&&j3(this.prototype,t,o)}}static getPropertyDescriptor(t,n,r){const{get:o,set:i}=F3(this.prototype,t)??{get(){return this[n]},set(s){this[n]=s}};return{get:o,set(s){const a=o?.call(this);i?.call(this,s),this.requestUpdate(t,a,r)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??Ju}static _$Ei(){if(this.hasOwnProperty(Lo("elementProperties")))return;const t=V3(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(Lo("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(Lo("properties"))){const n=this.properties,r=[...z3(n),...H3(n)];for(const o of r)this.createProperty(o,n[o])}const t=this[Symbol.metadata];if(t!==null){const n=litPropertyMetadata.get(t);if(n!==void 0)for(const[r,o]of n)this.elementProperties.set(r,o)}this._$Eh=new Map;for(const[n,r]of this.elementProperties){const o=this._$Eu(n,r);o!==void 0&&this._$Eh.set(o,n)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const n=[];if(Array.isArray(t)){const r=new Set(t.flat(1/0).reverse());for(const o of r)n.unshift(Zu(o))}else t!==void 0&&n.push(Zu(t));return n}static _$Eu(t,n){const r=n.attribute;return r===!1?void 0:typeof r=="string"?r:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(t=>t(this))}addController(t){(this._$EO??=new Set).add(t),this.renderRoot!==void 0&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){const t=new Map,n=this.constructor.elementProperties;for(const r of n.keys())this.hasOwnProperty(r)&&(t.set(r,this[r]),delete this[r]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return B3(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(t=>t.hostConnected?.())}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach(t=>t.hostDisconnected?.())}attributeChangedCallback(t,n,r){this._$AK(t,r)}_$ET(t,n){const r=this.constructor.elementProperties.get(t),o=this.constructor._$Eu(t,r);if(o!==void 0&&r.reflect===!0){const i=(r.converter?.toAttribute!==void 0?r.converter:Xa).toAttribute(n,r.type);this._$Em=t,i==null?this.removeAttribute(o):this.setAttribute(o,i),this._$Em=null}}_$AK(t,n){const r=this.constructor,o=r._$Eh.get(t);if(o!==void 0&&this._$Em!==o){const i=r.getPropertyOptions(o),s=typeof i.converter=="function"?{fromAttribute:i.converter}:i.converter?.fromAttribute!==void 0?i.converter:Xa;this._$Em=o;const a=s.fromAttribute(n,i.type);this[o]=a??this._$Ej?.get(o)??a,this._$Em=null}}requestUpdate(t,n,r,o=!1,i){if(t!==void 0){const s=this.constructor;if(o===!1&&(i=this[t]),r??=s.getPropertyOptions(t),!((r.hasChanged??Dd)(i,n)||r.useDefault&&r.reflect&&i===this._$Ej?.get(t)&&!this.hasAttribute(s._$Eu(t,r))))return;this.C(t,n,r)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(t,n,{useDefault:r,reflect:o,wrapped:i},s){r&&!(this._$Ej??=new Map).has(t)&&(this._$Ej.set(t,s??n??this[t]),i!==!0||s!==void 0)||(this._$AL.has(t)||(this.hasUpdated||r||(n=void 0),this._$AL.set(t,n)),o===!0&&this._$Em!==t&&(this._$Eq??=new Set).add(t))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(n){Promise.reject(n)}const t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[o,i]of this._$Ep)this[o]=i;this._$Ep=void 0}const r=this.constructor.elementProperties;if(r.size>0)for(const[o,i]of r){const{wrapped:s}=i,a=this[o];s!==!0||this._$AL.has(o)||a===void 0||this.C(o,void 0,i,a)}}let t=!1;const n=this._$AL;try{t=this.shouldUpdate(n),t?(this.willUpdate(n),this._$EO?.forEach(r=>r.hostUpdate?.()),this.update(n)):this._$EM()}catch(r){throw t=!1,this._$EM(),r}t&&this._$AE(n)}willUpdate(t){}_$AE(t){this._$EO?.forEach(n=>n.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Eq&&=this._$Eq.forEach(n=>this._$ET(n,this[n])),this._$EM()}updated(t){}firstUpdated(t){}};ji.elementStyles=[],ji.shadowRootOptions={mode:"open"},ji[Lo("elementProperties")]=new Map,ji[Lo("finalized")]=new Map,K3?.({ReactiveElement:ji}),(Rc.reactiveElementVersions??=[]).push("2.1.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Md=globalThis,Xu=e=>e,Qa=Md.trustedTypes,Qu=Qa?Qa.createPolicy("lit-html",{createHTML:e=>e}):void 0,rf="$lit$",ur=`lit$${Math.random().toFixed(9).slice(2)}$`,of="?"+ur,G3=`<${of}>`,Jr=document,vs=()=>Jr.createComment(""),Es=e=>e===null||typeof e!="object"&&typeof e!="function",Ud=Array.isArray,Z3=e=>Ud(e)||typeof e?.[Symbol.iterator]=="function",ol=`[ 	
\f\r]`,$o=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,eh=/-->/g,th=/>/g,Lr=RegExp(`>|${ol}(?:([^\\s"'>=/]+)(${ol}*=${ol}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),nh=/'/g,rh=/"/g,sf=/^(?:script|style|textarea|title)$/i,af=e=>(t,...n)=>({_$litType$:e,strings:t,values:n}),x=af(1),pe=af(2),Xr=Symbol.for("lit-noChange"),Je=Symbol.for("lit-nothing"),ih=new WeakMap,Wr=Jr.createTreeWalker(Jr,129);function cf(e,t){if(!Ud(e)||!e.hasOwnProperty("raw"))throw Error("invalid template strings array");return Qu!==void 0?Qu.createHTML(t):t}const Y3=(e,t)=>{const n=e.length-1,r=[];let o,i=t===2?"<svg>":t===3?"<math>":"",s=$o;for(let a=0;a<n;a++){const c=e[a];let l,d,h=-1,f=0;for(;f<c.length&&(s.lastIndex=f,d=s.exec(c),d!==null);)f=s.lastIndex,s===$o?d[1]==="!--"?s=eh:d[1]!==void 0?s=th:d[2]!==void 0?(sf.test(d[2])&&(o=RegExp("</"+d[2],"g")),s=Lr):d[3]!==void 0&&(s=Lr):s===Lr?d[0]===">"?(s=o??$o,h=-1):d[1]===void 0?h=-2:(h=s.lastIndex-d[2].length,l=d[1],s=d[3]===void 0?Lr:d[3]==='"'?rh:nh):s===rh||s===nh?s=Lr:s===eh||s===th?s=$o:(s=Lr,o=void 0);const w=s===Lr&&e[a+1].startsWith("/>")?" ":"";i+=s===$o?c+G3:h>=0?(r.push(l),c.slice(0,h)+rf+c.slice(h)+ur+w):c+ur+(h===-2?a:w)}return[cf(e,i+(e[n]||"<?>")+(t===2?"</svg>":t===3?"</math>":"")),r]};let ed=class lf{constructor({strings:t,_$litType$:n},r){let o;this.parts=[];let i=0,s=0;const a=t.length-1,c=this.parts,[l,d]=Y3(t,n);if(this.el=lf.createElement(l,r),Wr.currentNode=this.el.content,n===2||n===3){const h=this.el.content.firstChild;h.replaceWith(...h.childNodes)}for(;(o=Wr.nextNode())!==null&&c.length<a;){if(o.nodeType===1){if(o.hasAttributes())for(const h of o.getAttributeNames())if(h.endsWith(rf)){const f=d[s++],w=o.getAttribute(h).split(ur),v=/([.?@])?(.*)/.exec(f);c.push({type:1,index:i,name:v[2],strings:w,ctor:v[1]==="."?X3:v[1]==="?"?Q3:v[1]==="@"?eb:kc}),o.removeAttribute(h)}else h.startsWith(ur)&&(c.push({type:6,index:i}),o.removeAttribute(h));if(sf.test(o.tagName)){const h=o.textContent.split(ur),f=h.length-1;if(f>0){o.textContent=Qa?Qa.emptyScript:"";for(let w=0;w<f;w++)o.append(h[w],vs()),Wr.nextNode(),c.push({type:2,index:++i});o.append(h[f],vs())}}}else if(o.nodeType===8)if(o.data===of)c.push({type:2,index:i});else{let h=-1;for(;(h=o.data.indexOf(ur,h+1))!==-1;)c.push({type:7,index:i}),h+=ur.length-1}i++}}static createElement(t,n){const r=Jr.createElement("template");return r.innerHTML=t,r}};function io(e,t,n=e,r){if(t===Xr)return t;let o=r!==void 0?n._$Co?.[r]:n._$Cl;const i=Es(t)?void 0:t._$litDirective$;return o?.constructor!==i&&(o?._$AO?.(!1),i===void 0?o=void 0:(o=new i(e),o._$AT(e,n,r)),r!==void 0?(n._$Co??=[])[r]=o:n._$Cl=o),o!==void 0&&(t=io(e,o._$AS(e,t.values),o,r)),t}let J3=class{constructor(t,n){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=n}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:n},parts:r}=this._$AD,o=(t?.creationScope??Jr).importNode(n,!0);Wr.currentNode=o;let i=Wr.nextNode(),s=0,a=0,c=r[0];for(;c!==void 0;){if(s===c.index){let l;c.type===2?l=new Bd(i,i.nextSibling,this,t):c.type===1?l=new c.ctor(i,c.name,c.strings,this,t):c.type===6&&(l=new tb(i,this,t)),this._$AV.push(l),c=r[++a]}s!==c?.index&&(i=Wr.nextNode(),s++)}return Wr.currentNode=Jr,o}p(t){let n=0;for(const r of this._$AV)r!==void 0&&(r.strings!==void 0?(r._$AI(t,r,n),n+=r.strings.length-2):r._$AI(t[n])),n++}},Bd=class df{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,n,r,o){this.type=2,this._$AH=Je,this._$AN=void 0,this._$AA=t,this._$AB=n,this._$AM=r,this.options=o,this._$Cv=o?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const n=this._$AM;return n!==void 0&&t?.nodeType===11&&(t=n.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,n=this){t=io(this,t,n),Es(t)?t===Je||t==null||t===""?(this._$AH!==Je&&this._$AR(),this._$AH=Je):t!==this._$AH&&t!==Xr&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):Z3(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==Je&&Es(this._$AH)?this._$AA.nextSibling.data=t:this.T(Jr.createTextNode(t)),this._$AH=t}$(t){const{values:n,_$litType$:r}=t,o=typeof r=="number"?this._$AC(t):(r.el===void 0&&(r.el=ed.createElement(cf(r.h,r.h[0]),this.options)),r);if(this._$AH?._$AD===o)this._$AH.p(n);else{const i=new J3(o,this),s=i.u(this.options);i.p(n),this.T(s),this._$AH=i}}_$AC(t){let n=ih.get(t.strings);return n===void 0&&ih.set(t.strings,n=new ed(t)),n}k(t){Ud(this._$AH)||(this._$AH=[],this._$AR());const n=this._$AH;let r,o=0;for(const i of t)o===n.length?n.push(r=new df(this.O(vs()),this.O(vs()),this,this.options)):r=n[o],r._$AI(i),o++;o<n.length&&(this._$AR(r&&r._$AB.nextSibling,o),n.length=o)}_$AR(t=this._$AA.nextSibling,n){for(this._$AP?.(!1,!0,n);t!==this._$AB;){const r=Xu(t).nextSibling;Xu(t).remove(),t=r}}setConnected(t){this._$AM===void 0&&(this._$Cv=t,this._$AP?.(t))}},kc=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,n,r,o,i){this.type=1,this._$AH=Je,this._$AN=void 0,this.element=t,this.name=n,this._$AM=o,this.options=i,r.length>2||r[0]!==""||r[1]!==""?(this._$AH=Array(r.length-1).fill(new String),this.strings=r):this._$AH=Je}_$AI(t,n=this,r,o){const i=this.strings;let s=!1;if(i===void 0)t=io(this,t,n,0),s=!Es(t)||t!==this._$AH&&t!==Xr,s&&(this._$AH=t);else{const a=t;let c,l;for(t=i[0],c=0;c<i.length-1;c++)l=io(this,a[r+c],n,c),l===Xr&&(l=this._$AH[c]),s||=!Es(l)||l!==this._$AH[c],l===Je?t=Je:t!==Je&&(t+=(l??"")+i[c+1]),this._$AH[c]=l}s&&!o&&this.j(t)}j(t){t===Je?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}},X3=class extends kc{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===Je?void 0:t}},Q3=class extends kc{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==Je)}},eb=class extends kc{constructor(t,n,r,o,i){super(t,n,r,o,i),this.type=5}_$AI(t,n=this){if((t=io(this,t,n,0)??Je)===Xr)return;const r=this._$AH,o=t===Je&&r!==Je||t.capture!==r.capture||t.once!==r.once||t.passive!==r.passive,i=t!==Je&&(r===Je||o);o&&this.element.removeEventListener(this.name,this,r),i&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}},tb=class{constructor(t,n,r){this.element=t,this.type=6,this._$AN=void 0,this._$AM=n,this.options=r}get _$AU(){return this._$AM._$AU}_$AI(t){io(this,t)}};const nb=Md.litHtmlPolyfillSupport;nb?.(ed,Bd),(Md.litHtmlVersions??=[]).push("3.3.2");const rb=(e,t,n)=>{const r=n?.renderBefore??t;let o=r._$litPart$;if(o===void 0){const i=n?.renderBefore??null;r._$litPart$=o=new Bd(t.insertBefore(vs(),i),i,void 0,n??{})}return o._$AI(e),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Wd=globalThis;let de=class extends ji{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const n=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=rb(n,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return Xr}};de._$litElement$=!0,de.finalized=!0,Wd.litElementHydrateSupport?.({LitElement:de});const ib=Wd.litElementPolyfillSupport;ib?.({LitElement:de});(Wd.litElementVersions??=[]).push("4.2.2");const ob={black:"#202020",white:"#FFFFFF",white010:"rgba(255, 255, 255, 0.1)",accent010:"rgba(9, 136, 240, 0.1)",accent020:"rgba(9, 136, 240, 0.2)",accent030:"rgba(9, 136, 240, 0.3)",accent040:"rgba(9, 136, 240, 0.4)",accent050:"rgba(9, 136, 240, 0.5)",accent060:"rgba(9, 136, 240, 0.6)",accent070:"rgba(9, 136, 240, 0.7)",accent080:"rgba(9, 136, 240, 0.8)",accent090:"rgba(9, 136, 240, 0.9)",accent100:"rgba(9, 136, 240, 1.0)",accentSecondary010:"rgba(199, 185, 148, 0.1)",accentSecondary020:"rgba(199, 185, 148, 0.2)",accentSecondary030:"rgba(199, 185, 148, 0.3)",accentSecondary040:"rgba(199, 185, 148, 0.4)",accentSecondary050:"rgba(199, 185, 148, 0.5)",accentSecondary060:"rgba(199, 185, 148, 0.6)",accentSecondary070:"rgba(199, 185, 148, 0.7)",accentSecondary080:"rgba(199, 185, 148, 0.8)",accentSecondary090:"rgba(199, 185, 148, 0.9)",accentSecondary100:"rgba(199, 185, 148, 1.0)",productWalletKit:"#FFB800",productAppKit:"#FF573B",productCloud:"#0988F0",productDocumentation:"#008847",neutrals050:"#F6F6F6",neutrals100:"#F3F3F3",neutrals200:"#E9E9E9",neutrals300:"#D0D0D0",neutrals400:"#BBB",neutrals500:"#9A9A9A",neutrals600:"#6C6C6C",neutrals700:"#4F4F4F",neutrals800:"#363636",neutrals900:"#2A2A2A",neutrals1000:"#252525",semanticSuccess010:"rgba(48, 164, 107, 0.1)",semanticSuccess020:"rgba(48, 164, 107, 0.2)",semanticSuccess030:"rgba(48, 164, 107, 0.3)",semanticSuccess040:"rgba(48, 164, 107, 0.4)",semanticSuccess050:"rgba(48, 164, 107, 0.5)",semanticSuccess060:"rgba(48, 164, 107, 0.6)",semanticSuccess070:"rgba(48, 164, 107, 0.7)",semanticSuccess080:"rgba(48, 164, 107, 0.8)",semanticSuccess090:"rgba(48, 164, 107, 0.9)",semanticSuccess100:"rgba(48, 164, 107, 1.0)",semanticError010:"rgba(223, 74, 52, 0.1)",semanticError020:"rgba(223, 74, 52, 0.2)",semanticError030:"rgba(223, 74, 52, 0.3)",semanticError040:"rgba(223, 74, 52, 0.4)",semanticError050:"rgba(223, 74, 52, 0.5)",semanticError060:"rgba(223, 74, 52, 0.6)",semanticError070:"rgba(223, 74, 52, 0.7)",semanticError080:"rgba(223, 74, 52, 0.8)",semanticError090:"rgba(223, 74, 52, 0.9)",semanticError100:"rgba(223, 74, 52, 1.0)",semanticWarning010:"rgba(243, 161, 63, 0.1)",semanticWarning020:"rgba(243, 161, 63, 0.2)",semanticWarning030:"rgba(243, 161, 63, 0.3)",semanticWarning040:"rgba(243, 161, 63, 0.4)",semanticWarning050:"rgba(243, 161, 63, 0.5)",semanticWarning060:"rgba(243, 161, 63, 0.6)",semanticWarning070:"rgba(243, 161, 63, 0.7)",semanticWarning080:"rgba(243, 161, 63, 0.8)",semanticWarning090:"rgba(243, 161, 63, 0.9)",semanticWarning100:"rgba(243, 161, 63, 1.0)"},ec={core:{backgroundAccentPrimary:"#0988F0",backgroundAccentCertified:"#C7B994",backgroundWalletKit:"#FFB800",backgroundAppKit:"#FF573B",backgroundCloud:"#0988F0",backgroundDocumentation:"#008847",backgroundSuccess:"rgba(48, 164, 107, 0.20)",backgroundError:"rgba(223, 74, 52, 0.20)",backgroundWarning:"rgba(243, 161, 63, 0.20)",textAccentPrimary:"#0988F0",textAccentCertified:"#C7B994",textWalletKit:"#FFB800",textAppKit:"#FF573B",textCloud:"#0988F0",textDocumentation:"#008847",textSuccess:"#30A46B",textError:"#DF4A34",textWarning:"#F3A13F",borderAccentPrimary:"#0988F0",borderSecondary:"#C7B994",borderSuccess:"#30A46B",borderError:"#DF4A34",borderWarning:"#F3A13F",foregroundAccent010:"rgba(9, 136, 240, 0.1)",foregroundAccent020:"rgba(9, 136, 240, 0.2)",foregroundAccent040:"rgba(9, 136, 240, 0.4)",foregroundAccent060:"rgba(9, 136, 240, 0.6)",foregroundSecondary020:"rgba(199, 185, 148, 0.2)",foregroundSecondary040:"rgba(199, 185, 148, 0.4)",foregroundSecondary060:"rgba(199, 185, 148, 0.6)",iconAccentPrimary:"#0988F0",iconAccentCertified:"#C7B994",iconSuccess:"#30A46B",iconError:"#DF4A34",iconWarning:"#F3A13F",glass010:"rgba(255, 255, 255, 0.1)",zIndex:"9999"},dark:{overlay:"rgba(0, 0, 0, 0.50)",backgroundPrimary:"#202020",backgroundInvert:"#FFFFFF",textPrimary:"#FFFFFF",textSecondary:"#9A9A9A",textTertiary:"#BBBBBB",textInvert:"#202020",borderPrimary:"#2A2A2A",borderPrimaryDark:"#363636",borderSecondary:"#4F4F4F",foregroundPrimary:"#252525",foregroundSecondary:"#2A2A2A",foregroundTertiary:"#363636",iconDefault:"#9A9A9A",iconInverse:"#FFFFFF"},light:{overlay:"rgba(230 , 230, 230, 0.5)",backgroundPrimary:"#FFFFFF",borderPrimaryDark:"#E9E9E9",backgroundInvert:"#202020",textPrimary:"#202020",textSecondary:"#9A9A9A",textTertiary:"#6C6C6C",textInvert:"#FFFFFF",borderPrimary:"#E9E9E9",borderSecondary:"#D0D0D0",foregroundPrimary:"#F3F3F3",foregroundSecondary:"#E9E9E9",foregroundTertiary:"#D0D0D0",iconDefault:"#9A9A9A",iconInverse:"#202020"}},sb={1:"4px",2:"8px",10:"10px",3:"12px",4:"16px",6:"24px",5:"20px",8:"32px",16:"64px",20:"80px",32:"128px",64:"256px",128:"512px",round:"9999px"},ab={0:"0px","01":"2px",1:"4px",2:"8px",3:"12px",4:"16px",5:"20px",6:"24px",7:"28px",8:"32px",9:"36px",10:"40px",12:"48px",14:"56px",16:"64px",20:"80px",32:"128px",64:"256px"},cb={regular:"KHTeka",mono:"KHTekaMono"},lb={regular:"400",medium:"500"},db={h1:"50px",h2:"44px",h3:"38px",h4:"32px",h5:"26px",h6:"20px",large:"16px",medium:"14px",small:"12px"},ub={"h1-regular-mono":{lineHeight:"50px",letterSpacing:"-3px"},"h1-regular":{lineHeight:"50px",letterSpacing:"-1px"},"h1-medium":{lineHeight:"50px",letterSpacing:"-0.84px"},"h2-regular-mono":{lineHeight:"44px",letterSpacing:"-2.64px"},"h2-regular":{lineHeight:"44px",letterSpacing:"-0.88px"},"h2-medium":{lineHeight:"44px",letterSpacing:"-0.88px"},"h3-regular-mono":{lineHeight:"38px",letterSpacing:"-2.28px"},"h3-regular":{lineHeight:"38px",letterSpacing:"-0.76px"},"h3-medium":{lineHeight:"38px",letterSpacing:"-0.76px"},"h4-regular-mono":{lineHeight:"32px",letterSpacing:"-1.92px"},"h4-regular":{lineHeight:"32px",letterSpacing:"-0.32px"},"h4-medium":{lineHeight:"32px",letterSpacing:"-0.32px"},"h5-regular-mono":{lineHeight:"26px",letterSpacing:"-1.56px"},"h5-regular":{lineHeight:"26px",letterSpacing:"-0.26px"},"h5-medium":{lineHeight:"26px",letterSpacing:"-0.26px"},"h6-regular-mono":{lineHeight:"20px",letterSpacing:"-1.2px"},"h6-regular":{lineHeight:"20px",letterSpacing:"-0.6px"},"h6-medium":{lineHeight:"20px",letterSpacing:"-0.6px"},"lg-regular-mono":{lineHeight:"16px",letterSpacing:"-0.96px"},"lg-regular":{lineHeight:"18px",letterSpacing:"-0.16px"},"lg-medium":{lineHeight:"18px",letterSpacing:"-0.16px"},"md-regular-mono":{lineHeight:"14px",letterSpacing:"-0.84px"},"md-regular":{lineHeight:"16px",letterSpacing:"-0.14px"},"md-medium":{lineHeight:"16px",letterSpacing:"-0.14px"},"sm-regular-mono":{lineHeight:"12px",letterSpacing:"-0.72px"},"sm-regular":{lineHeight:"14px",letterSpacing:"-0.12px"},"sm-medium":{lineHeight:"14px",letterSpacing:"-0.12px"}},hb={"ease-out-power-2":"cubic-bezier(0.23, 0.09, 0.08, 1.13)","ease-out-power-1":"cubic-bezier(0.12, 0.04, 0.2, 1.06)","ease-in-power-2":"cubic-bezier(0.92, -0.13, 0.77, 0.91)","ease-in-power-1":"cubic-bezier(0.88, -0.06, 0.8, 0.96)","ease-inout-power-2":"cubic-bezier(0.77, 0.09, 0.23, 1.13)","ease-inout-power-1":"cubic-bezier(0.88, 0.04, 0.12, 1.06)"},pb={xl:"400ms",lg:"200ms",md:"125ms",sm:"75ms"},td={colors:ob,fontFamily:cb,fontWeight:lb,textSize:db,typography:ub,tokens:{core:ec.core,theme:ec.dark},borderRadius:sb,spacing:ab,durations:pb,easings:hb},oh="--apkt";function ya(e){if(!e)return{};const t={};return t["font-family"]=e["--apkt-font-family"]??e["--w3m-font-family"]??"KHTeka",t.accent=e["--apkt-accent"]??e["--w3m-accent"]??"#0988F0",t["color-mix"]=e["--apkt-color-mix"]??e["--w3m-color-mix"]??"#000",t["color-mix-strength"]=e["--apkt-color-mix-strength"]??e["--w3m-color-mix-strength"]??0,t["font-size-master"]=e["--apkt-font-size-master"]??e["--w3m-font-size-master"]??"10px",t["border-radius-master"]=e["--apkt-border-radius-master"]??e["--w3m-border-radius-master"]??"4px",e["--apkt-z-index"]!==void 0?t["z-index"]=e["--apkt-z-index"]:e["--w3m-z-index"]!==void 0&&(t["z-index"]=e["--w3m-z-index"]),t}const Kn={createCSSVariables(e){const t={},n={};function r(i,s,a=""){for(const[c,l]of Object.entries(i)){const d=a?`${a}-${c}`:c;l&&typeof l=="object"&&Object.keys(l).length?(s[c]={},r(l,s[c],d)):typeof l=="string"&&(s[c]=`${oh}-${d}`)}}function o(i,s){for(const[a,c]of Object.entries(i))c&&typeof c=="object"?(s[a]={},o(c,s[a])):typeof c=="string"&&(s[a]=`var(${c})`)}return r(e,t),o(t,n),{cssVariables:t,cssVariablesVarPrefix:n}},assignCSSVariables(e,t){const n={};function r(o,i,s){for(const[a,c]of Object.entries(o)){const l=s?`${s}-${a}`:a,d=i[a];c&&typeof c=="object"?r(c,d,l):typeof d=="string"&&(n[`${oh}-${l}`]=d)}}return r(e,t),n},createRootStyles(e,t){const n={...td,tokens:{...td.tokens,theme:e==="light"?ec.light:ec.dark}},{cssVariables:r}=Kn.createCSSVariables(n),o=Kn.assignCSSVariables(r,n),i=Kn.generateW3MVariables(t),s=Kn.generateW3MOverrides(t),a=Kn.generateScaledVariables(t),c=Kn.generateBaseVariables(o),l={...o,...c,...i,...s,...a},d=Kn.applyColorMixToVariables(t,l),h={...l,...d};return`:root {${Object.entries(h).map(([w,v])=>`${w}:${v.replace("/[:;{}</>]/g","")};`).join("")}}`},generateW3MVariables(e){if(!e)return{};const t=ya(e),n={};return n["--w3m-font-family"]=t["font-family"],n["--w3m-accent"]=t.accent,n["--w3m-color-mix"]=t["color-mix"],n["--w3m-color-mix-strength"]=`${t["color-mix-strength"]}%`,n["--w3m-font-size-master"]=t["font-size-master"],n["--w3m-border-radius-master"]=t["border-radius-master"],n},generateW3MOverrides(e){if(!e)return{};const t=ya(e),n={};if(e["--apkt-accent"]||e["--w3m-accent"]){const r=t.accent;n["--apkt-tokens-core-iconAccentPrimary"]=r,n["--apkt-tokens-core-borderAccentPrimary"]=r,n["--apkt-tokens-core-textAccentPrimary"]=r,n["--apkt-tokens-core-backgroundAccentPrimary"]=r}return(e["--apkt-font-family"]||e["--w3m-font-family"])&&(n["--apkt-fontFamily-regular"]=t["font-family"]),t["z-index"]!==void 0&&(n["--apkt-tokens-core-zIndex"]=`${t["z-index"]}`),n},generateScaledVariables(e){if(!e)return{};const t=ya(e),n={};if(e["--apkt-font-size-master"]||e["--w3m-font-size-master"]){const r=parseFloat(t["font-size-master"].replace("px",""));n["--apkt-textSize-h1"]=`${Number(r)*5}px`,n["--apkt-textSize-h2"]=`${Number(r)*4.4}px`,n["--apkt-textSize-h3"]=`${Number(r)*3.8}px`,n["--apkt-textSize-h4"]=`${Number(r)*3.2}px`,n["--apkt-textSize-h5"]=`${Number(r)*2.6}px`,n["--apkt-textSize-h6"]=`${Number(r)*2}px`,n["--apkt-textSize-large"]=`${Number(r)*1.6}px`,n["--apkt-textSize-medium"]=`${Number(r)*1.4}px`,n["--apkt-textSize-small"]=`${Number(r)*1.2}px`}if(e["--apkt-border-radius-master"]||e["--w3m-border-radius-master"]){const r=parseFloat(t["border-radius-master"].replace("px",""));n["--apkt-borderRadius-1"]=`${Number(r)}px`,n["--apkt-borderRadius-2"]=`${Number(r)*2}px`,n["--apkt-borderRadius-3"]=`${Number(r)*3}px`,n["--apkt-borderRadius-4"]=`${Number(r)*4}px`,n["--apkt-borderRadius-5"]=`${Number(r)*5}px`,n["--apkt-borderRadius-6"]=`${Number(r)*6}px`,n["--apkt-borderRadius-8"]=`${Number(r)*8}px`,n["--apkt-borderRadius-16"]=`${Number(r)*16}px`,n["--apkt-borderRadius-20"]=`${Number(r)*20}px`,n["--apkt-borderRadius-32"]=`${Number(r)*32}px`,n["--apkt-borderRadius-64"]=`${Number(r)*64}px`,n["--apkt-borderRadius-128"]=`${Number(r)*128}px`}return n},generateColorMixCSS(e,t){if(!e?.["--w3m-color-mix"]||!e["--w3m-color-mix-strength"])return"";const n=e["--w3m-color-mix"],r=e["--w3m-color-mix-strength"];if(!r||r===0)return"";const o=Object.keys(t||{}).filter(s=>{const a=s.includes("-tokens-core-background")||s.includes("-tokens-core-text")||s.includes("-tokens-core-border")||s.includes("-tokens-core-foreground")||s.includes("-tokens-core-icon")||s.includes("-tokens-theme-background")||s.includes("-tokens-theme-text")||s.includes("-tokens-theme-border")||s.includes("-tokens-theme-foreground")||s.includes("-tokens-theme-icon"),c=s.includes("-borderRadius-")||s.includes("-spacing-")||s.includes("-textSize-")||s.includes("-fontFamily-")||s.includes("-fontWeight-")||s.includes("-typography-")||s.includes("-duration-")||s.includes("-ease-")||s.includes("-path-")||s.includes("-width-")||s.includes("-height-")||s.includes("-visual-size-")||s.includes("-modal-width")||s.includes("-cover");return a&&!c});return o.length===0?"":` @supports (background: color-mix(in srgb, white 50%, black)) {
      :root {
        ${o.map(s=>{const a=t?.[s]||"";return a.includes("color-mix")||a.startsWith("#")||a.startsWith("rgb")?`${s}: color-mix(in srgb, ${n} ${r}%, ${a});`:`${s}: color-mix(in srgb, ${n} ${r}%, var(${s}-base, ${a}));`}).join("")}
      }
    }`},generateBaseVariables(e){const t={},n=e["--apkt-tokens-theme-backgroundPrimary"];n&&(t["--apkt-tokens-theme-backgroundPrimary-base"]=n);const r=e["--apkt-tokens-core-backgroundAccentPrimary"];return r&&(t["--apkt-tokens-core-backgroundAccentPrimary-base"]=r),t},applyColorMixToVariables(e,t){const n={};t?.["--apkt-tokens-theme-backgroundPrimary"]&&(n["--apkt-tokens-theme-backgroundPrimary"]="var(--apkt-tokens-theme-backgroundPrimary-base)"),t?.["--apkt-tokens-core-backgroundAccentPrimary"]&&(n["--apkt-tokens-core-backgroundAccentPrimary"]="var(--apkt-tokens-core-backgroundAccentPrimary-base)");const r=ya(e),o=r["color-mix"],i=r["color-mix-strength"];if(!i||i===0)return n;const s=Object.keys(t||{}).filter(a=>{const c=a.includes("-tokens-core-background")||a.includes("-tokens-core-text")||a.includes("-tokens-core-border")||a.includes("-tokens-core-foreground")||a.includes("-tokens-core-icon")||a.includes("-tokens-theme-background")||a.includes("-tokens-theme-text")||a.includes("-tokens-theme-border")||a.includes("-tokens-theme-foreground")||a.includes("-tokens-theme-icon")||a.includes("-tokens-theme-overlay"),l=a.includes("-borderRadius-")||a.includes("-spacing-")||a.includes("-textSize-")||a.includes("-fontFamily-")||a.includes("-fontWeight-")||a.includes("-typography-")||a.includes("-duration-")||a.includes("-ease-")||a.includes("-path-")||a.includes("-width-")||a.includes("-height-")||a.includes("-visual-size-")||a.includes("-modal-width")||a.includes("-cover");return c&&!l});return s.length===0||s.forEach(a=>{const c=t?.[a]||"";a.endsWith("-base")||(a==="--apkt-tokens-theme-backgroundPrimary"||a==="--apkt-tokens-core-backgroundAccentPrimary"?n[a]=`color-mix(in srgb, ${o} ${i}%, var(${a}-base))`:c.includes("color-mix")||c.startsWith("#")||c.startsWith("rgb")?n[a]=`color-mix(in srgb, ${o} ${i}%, ${c})`:n[a]=`color-mix(in srgb, ${o} ${i}%, var(${a}-base, ${c}))`)}),n}},{cssVariablesVarPrefix:Ke}=Kn.createCSSVariables(td);function Q(e,...t){return Nt(e,...t.map(n=>ln(typeof n=="function"?n(Ke):n)))}let Ur,jr,$n,un,tc;const qn={"KHTeka-500-woff2":"https://fonts.reown.com/KHTeka-Medium.woff2","KHTeka-400-woff2":"https://fonts.reown.com/KHTeka-Regular.woff2","KHTeka-300-woff2":"https://fonts.reown.com/KHTeka-Light.woff2","KHTekaMono-400-woff2":"https://fonts.reown.com/KHTekaMono-Regular.woff2","KHTeka-500-woff":"https://fonts.reown.com/KHTeka-Light.woff","KHTeka-400-woff":"https://fonts.reown.com/KHTeka-Regular.woff","KHTeka-300-woff":"https://fonts.reown.com/KHTeka-Light.woff","KHTekaMono-400-woff":"https://fonts.reown.com/KHTekaMono-Regular.woff"};function nc(e,t="dark"){Ur&&document.head.removeChild(Ur),Ur=document.createElement("style"),Ur.textContent=Kn.createRootStyles(t,e),document.head.appendChild(Ur)}function Bv(e,t="dark"){if(tc=e,jr=document.createElement("style"),$n=document.createElement("style"),un=document.createElement("style"),jr.textContent=Gi(e).core.cssText,$n.textContent=Gi(e).dark.cssText,un.textContent=Gi(e).light.cssText,document.head.appendChild(jr),document.head.appendChild($n),document.head.appendChild(un),nc(e,t),sh(t),!(e?.["--apkt-font-family"]||e?.["--w3m-font-family"]))for(const[r,o]of Object.entries(qn)){const i=document.createElement("link");i.rel="preload",i.href=o,i.as="font",i.type=r.includes("woff2")?"font/woff2":"font/woff",i.crossOrigin="anonymous",document.head.appendChild(i)}sh(t)}function sh(e="dark"){$n&&un&&Ur&&(e==="light"?(nc(tc,e),$n.removeAttribute("media"),un.media="enabled"):(nc(tc,e),un.removeAttribute("media"),$n.media="enabled"))}function Wv(e){if(tc=e,jr&&$n&&un){jr.textContent=Gi(e).core.cssText,$n.textContent=Gi(e).dark.cssText,un.textContent=Gi(e).light.cssText;const t=e?.["--apkt-font-family"]||e?.["--w3m-font-family"];t&&(jr.textContent=jr.textContent?.replace("font-family: KHTeka",`font-family: ${t}`),$n.textContent=$n.textContent?.replace("font-family: KHTeka",`font-family: ${t}`),un.textContent=un.textContent?.replace("font-family: KHTeka",`font-family: ${t}`))}if(Ur){const t=un?.media==="enabled"?"light":"dark";nc(e,t)}}function Gi(e){const t=!!(e?.["--apkt-font-family"]||e?.["--w3m-font-family"]);return{core:Nt`
      ${t?Nt``:Nt`
            @font-face {
              font-family: 'KHTeka';
              src:
                url(${ln(qn["KHTeka-400-woff2"])}) format('woff2'),
                url(${ln(qn["KHTeka-400-woff"])}) format('woff');
              font-weight: 400;
              font-style: normal;
              font-display: swap;
            }

            @font-face {
              font-family: 'KHTeka';
              src:
                url(${ln(qn["KHTeka-300-woff2"])}) format('woff2'),
                url(${ln(qn["KHTeka-300-woff"])}) format('woff');
              font-weight: 300;
              font-style: normal;
            }

            @font-face {
              font-family: 'KHTekaMono';
              src:
                url(${ln(qn["KHTekaMono-400-woff2"])}) format('woff2'),
                url(${ln(qn["KHTekaMono-400-woff"])}) format('woff');
              font-weight: 400;
              font-style: normal;
            }

            @font-face {
              font-family: 'KHTeka';
              src:
                url(${ln(qn["KHTeka-400-woff2"])}) format('woff2'),
                url(${ln(qn["KHTeka-400-woff"])}) format('woff');
              font-weight: 400;
              font-style: normal;
            }
          `}

      @keyframes w3m-shake {
        0% {
          transform: scale(1) rotate(0deg);
        }
        20% {
          transform: scale(1) rotate(-1deg);
        }
        40% {
          transform: scale(1) rotate(1.5deg);
        }
        60% {
          transform: scale(1) rotate(-1.5deg);
        }
        80% {
          transform: scale(1) rotate(1deg);
        }
        100% {
          transform: scale(1) rotate(0deg);
        }
      }
      @keyframes w3m-iframe-fade-out {
        0% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @keyframes w3m-iframe-zoom-in {
        0% {
          transform: translateY(50px);
          opacity: 0;
        }
        100% {
          transform: translateY(0px);
          opacity: 1;
        }
      }
      @keyframes w3m-iframe-zoom-in-mobile {
        0% {
          transform: scale(0.95);
          opacity: 0;
        }
        100% {
          transform: scale(1);
          opacity: 1;
        }
      }
      :root {
        --apkt-modal-width: 370px;

        --apkt-visual-size-inherit: inherit;
        --apkt-visual-size-sm: 40px;
        --apkt-visual-size-md: 55px;
        --apkt-visual-size-lg: 80px;

        --apkt-path-network-sm: path(
          'M15.4 2.1a5.21 5.21 0 0 1 5.2 0l11.61 6.7a5.21 5.21 0 0 1 2.61 4.52v13.4c0 1.87-1 3.59-2.6 4.52l-11.61 6.7c-1.62.93-3.6.93-5.22 0l-11.6-6.7a5.21 5.21 0 0 1-2.61-4.51v-13.4c0-1.87 1-3.6 2.6-4.52L15.4 2.1Z'
        );

        --apkt-path-network-md: path(
          'M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z'
        );

        --apkt-path-network-lg: path(
          'M78.3244 18.926L50.1808 2.45078C45.7376 -0.150261 40.2624 -0.150262 35.8192 2.45078L7.6756 18.926C3.23322 21.5266 0.5 26.3301 0.5 31.5248V64.4752C0.5 69.6699 3.23322 74.4734 7.6756 77.074L35.8192 93.5492C40.2624 96.1503 45.7376 96.1503 50.1808 93.5492L78.3244 77.074C82.7668 74.4734 85.5 69.6699 85.5 64.4752V31.5248C85.5 26.3301 82.7668 21.5266 78.3244 18.926Z'
        );

        --apkt-width-network-sm: 36px;
        --apkt-width-network-md: 48px;
        --apkt-width-network-lg: 86px;

        --apkt-duration-dynamic: 0ms;
        --apkt-height-network-sm: 40px;
        --apkt-height-network-md: 54px;
        --apkt-height-network-lg: 96px;
      }
    `,dark:Nt`
      :root {
      }
    `,light:Nt`
      :root {
      }
    `}}const we=Nt`
  div,
  span,
  iframe,
  a,
  img,
  form,
  button,
  label,
  *::after,
  *::before {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-style: normal;
    text-rendering: optimizeSpeed;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-tap-highlight-color: transparent;
    backface-visibility: hidden;
  }

  :host {
    font-family: var(--apkt-fontFamily-regular);
  }
`,Be=Nt`
  button,
  a {
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;

    will-change: background-color, color, border, box-shadow, width, height, transform, opacity;
    outline: none;
    border: none;
    text-decoration: none;
    transition:
      background-color var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2),
      color var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2),
      border var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2),
      box-shadow var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2),
      width var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2),
      height var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2),
      transform var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2),
      opacity var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2),
      scale var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2),
      border-radius var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2);
    will-change:
      background-color, color, border, box-shadow, width, height, transform, opacity, scale,
      border-radius;
  }

  a:active:not([disabled]),
  button:active:not([disabled]) {
    scale: 0.975;
    transform-origin: center;
  }

  button:disabled {
    cursor: default;
  }

  input {
    border: none;
    outline: none;
    appearance: none;
  }
`,Ca=".",Fe={getSpacingStyles(e,t){if(Array.isArray(e))return e[t]?`var(--apkt-spacing-${e[t]})`:void 0;if(typeof e=="string")return`var(--apkt-spacing-${e})`},getFormattedDate(e){return new Intl.DateTimeFormat("en-US",{month:"short",day:"numeric"}).format(e)},formatCurrency(e=0,t={}){const n=Number(e);return isNaN(n)?"$0.00":new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",minimumFractionDigits:2,maximumFractionDigits:2,...t}).format(n)},getHostName(e){try{return new URL(e).hostname}catch{return""}},getTruncateString({string:e,charsStart:t,charsEnd:n,truncate:r}){return e.length<=t+n?e:r==="end"?`${e.substring(0,t)}...`:r==="start"?`...${e.substring(e.length-n)}`:`${e.substring(0,Math.floor(t))}...${e.substring(e.length-Math.floor(n))}`},generateAvatarColors(e){const n=e.toLowerCase().replace(/^0x/iu,"").replace(/[^a-f0-9]/gu,"").substring(0,6).padEnd(6,"0"),r=this.hexToRgb(n),o=getComputedStyle(document.documentElement).getPropertyValue("--w3m-border-radius-master"),s=100-3*Number(o?.replace("px","")),a=`${s}% ${s}% at 65% 40%`,c=[];for(let l=0;l<5;l+=1){const d=this.tintColor(r,.15*l);c.push(`rgb(${d[0]}, ${d[1]}, ${d[2]})`)}return`
    --local-color-1: ${c[0]};
    --local-color-2: ${c[1]};
    --local-color-3: ${c[2]};
    --local-color-4: ${c[3]};
    --local-color-5: ${c[4]};
    --local-radial-circle: ${a}
   `},hexToRgb(e){const t=parseInt(e,16),n=t>>16&255,r=t>>8&255,o=t&255;return[n,r,o]},tintColor(e,t){const[n,r,o]=e,i=Math.round(n+(255-n)*t),s=Math.round(r+(255-r)*t),a=Math.round(o+(255-o)*t);return[i,s,a]},isNumber(e){return{number:/^[0-9]+$/u}.number.test(e)},getColorTheme(e){return e||(typeof window<"u"&&window.matchMedia&&typeof window.matchMedia=="function"?window.matchMedia("(prefers-color-scheme: dark)")?.matches?"dark":"light":"dark")},splitBalance(e){const t=e.split(".");return t.length===2?[t[0],t[1]]:["0","00"]},roundNumber(e,t,n){return e.toString().length>=t?Number(e).toFixed(n):e},cssDurationToNumber(e){return e.endsWith("s")?Number(e.replace("s",""))*1e3:e.endsWith("ms")?Number(e.replace("ms","")):0},maskInput({value:e,decimals:t,integers:n}){if(e=e.replace(",","."),e===Ca)return`0${Ca}`;const[r="",o]=e.split(Ca).map(d=>d.replace(/[^0-9]/gu,"")),i=n?r.substring(0,n):r,s=i.length===2?String(Number(i)):i,a=typeof t=="number"?o?.substring(0,t):o,c=typeof t!="number"||t>0;return(typeof a=="string"&&c?[s,a].join(Ca):s)??""},capitalize(e){return e?e.charAt(0).toUpperCase()+e.slice(1):""}},fb=3,va=.1,mb=["receive","deposit","borrow","claim"],gb=["withdraw","repay","burn"],zi={getTransactionGroupTitle(e,t){const n=Wl.getYear(),r=Wl.getMonthNameByIndex(t);return e===n?r:`${r} ${e}`},getTransactionImages(e){const[t]=e;return e?.length>1?e.map(r=>this.getTransactionImage(r)):[this.getTransactionImage(t)]},getTransactionImage(e){return{type:zi.getTransactionTransferTokenType(e),url:zi.getTransactionImageURL(e)}},getTransactionImageURL(e){let t;const n=!!e?.nft_info,r=!!e?.fungible_info;return e&&n?t=e?.nft_info?.content?.preview?.url:e&&r&&(t=e?.fungible_info?.icon?.url),t},getTransactionTransferTokenType(e){if(e?.fungible_info)return"FUNGIBLE";if(e?.nft_info)return"NFT"},getTransactionDescriptions(e,t){const n=e?.metadata?.operationType,r=t||e?.transfers,o=r&&r.length>0,i=r&&r.length>1,s=o&&r.every(f=>!!f?.fungible_info),[a,c]=r||[];let l=this.getTransferDescription(a),d=this.getTransferDescription(c);if(!o)return(n==="send"||n==="receive")&&s?(l=Fe.getTruncateString({string:e?.metadata.sentFrom,charsStart:4,charsEnd:6,truncate:"middle"}),d=Fe.getTruncateString({string:e?.metadata.sentTo,charsStart:4,charsEnd:6,truncate:"middle"}),[l,d]):[e.metadata.status];if(i)return r?.map(f=>this.getTransferDescription(f));let h="";return mb.includes(n)?h="+":gb.includes(n)&&(h="-"),l=h.concat(l),[l]},getTransferDescription(e){let t="";return e&&(e?.nft_info?t=e?.nft_info?.name||"-":e?.fungible_info&&(t=this.getFungibleTransferDescription(e)||"-")),t},getFungibleTransferDescription(e){return e?[this.getQuantityFixedValue(e?.quantity.numeric),e?.fungible_info?.symbol].join(" ").trim():null},mergeTransfers(e){if(e?.length<=1)return e;const n=this.filterGasFeeTransfers(e).reduce((o,i)=>{const s=i?.fungible_info?.name,a=o.find(({fungible_info:c,direction:l})=>s&&s===c?.name&&l===i.direction);if(a){const c=Number(a.quantity.numeric)+Number(i.quantity.numeric);a.quantity.numeric=c.toString(),a.value=(a.value||0)+(i.value||0)}else o.push(i);return o},[]);let r=n;return n.length>2&&(r=n.sort((o,i)=>(i.value||0)-(o.value||0)).slice(0,2)),r=r.sort((o,i)=>o.direction==="out"&&i.direction==="in"?-1:o.direction==="in"&&i.direction==="out"?1:0),r},filterGasFeeTransfers(e){const t=e?.reduce((r,o)=>{const i=o?.fungible_info?.name;return i&&(r[i]||(r[i]=[]),r[i].push(o)),r},{}),n=[];return Object.values(t??{}).forEach(r=>{if(r.length===1){const o=r[0];o&&n.push(o)}else{const o=r.filter(s=>s.direction==="in"),i=r.filter(s=>s.direction==="out");if(o.length===1&&i.length===1){const s=o[0],a=i[0];let c=!1;if(s&&a){const l=Number(s.quantity.numeric),d=Number(a.quantity.numeric);d<l*va?(n.push(s),c=!0):l<d*va&&(n.push(a),c=!0)}c||n.push(...r)}else{const s=this.filterGasFeesFromTokenGroup(r);n.push(...s)}}}),e?.forEach(r=>{r?.fungible_info?.name||n.push(r)}),n},filterGasFeesFromTokenGroup(e){if(e.length<=1)return e;const t=e?.map(a=>Number(a.quantity.numeric)),n=Math.max(...t),r=Math.min(...t),o=.01;if(r<n*o)return e?.filter(c=>Number(c.quantity.numeric)>=n*o);const i=e?.filter(a=>a.direction==="in"),s=e?.filter(a=>a.direction==="out");if(i.length===1&&s.length===1){const a=i[0],c=s[0];if(a&&c){const l=Number(a.quantity.numeric),d=Number(c.quantity.numeric);if(d<l*va)return[a];if(l<d*va)return[c]}}return e},getQuantityFixedValue(e){return e?parseFloat(e).toFixed(fb):null}};function wb(e,t){const{kind:n,elements:r}=t;return{kind:n,elements:r,finisher(o){customElements.get(e)||customElements.define(e,o)}}}function bb(e,t){return customElements.get(e)||customElements.define(e,t),t}function M(e){return function(n){return typeof n=="function"?bb(e,n):wb(e,n)}}let Ia;function jv(e){e&&(Ia=e)}function Fv(){if(!Ia)throw new Error('Please call "createAppKit" before using "useAppKit" hook');async function e(n){return Ia?.open(n)}async function t(){await Ia?.close()}return{open:e,close:t}}/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const yb=new Set(["children","localName","ref","style","className"]),ah=new WeakMap,ch=(e,t,n,r,o)=>{const i=o?.[t];i===void 0?(e[t]=n,n==null&&t in HTMLElement.prototype&&e.removeAttribute(t)):n!==r&&((s,a,c)=>{let l=ah.get(s);l===void 0&&ah.set(s,l=new Map);let d=l.get(a);c!==void 0?d===void 0?(l.set(a,d={handleEvent:c}),s.addEventListener(a,d)):d.handleEvent=c:d!==void 0&&(l.delete(a),s.removeEventListener(a,d))})(e,i,n)},Ic=({react:e,tagName:t,elementClass:n,events:r,displayName:o})=>{const i=new Set(Object.keys(r??{})),s=e.forwardRef(((a,c)=>{const l=e.useRef(new Map),d=e.useRef(null),h={},f={};for(const[w,v]of Object.entries(a))yb.has(w)?h[w==="className"?"class":w]=v:i.has(w)||w in n.prototype?f[w]=v:h[w]=v;return e.useLayoutEffect((()=>{if(d.current===null)return;const w=new Map;for(const v in f)ch(d.current,v,a[v],l.current.get(v),r),l.current.delete(v),w.set(v,a[v]);for(const[v,y]of l.current)ch(d.current,v,void 0,y,r);l.current=w})),e.useLayoutEffect((()=>{d.current?.removeAttribute("defer-hydration")}),[]),h.suppressHydrationWarning=!0,e.createElement(t,{...h,ref:e.useCallback((w=>{d.current=w,typeof c=="function"?c(w):c!==null&&(c.current=w)}),[c])})}));return s.displayName=o??n.name,s};/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Oa=globalThis,jd=Oa.ShadowRoot&&(Oa.ShadyCSS===void 0||Oa.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Fd=Symbol(),lh=new WeakMap;let uf=class{constructor(t,n,r){if(this._$cssResult$=!0,r!==Fd)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=n}get styleSheet(){let t=this.o;const n=this.t;if(jd&&t===void 0){const r=n!==void 0&&n.length===1;r&&(t=lh.get(n)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),r&&lh.set(n,t))}return t}toString(){return this.cssText}};const Cb=e=>new uf(typeof e=="string"?e:e+"",void 0,Fd),Vt=(e,...t)=>{const n=e.length===1?e[0]:t.reduce((r,o,i)=>r+(s=>{if(s._$cssResult$===!0)return s.cssText;if(typeof s=="number")return s;throw Error("Value passed to 'css' function must be a 'css' function result: "+s+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(o)+e[i+1],e[0]);return new uf(n,e,Fd)},vb=(e,t)=>{if(jd)e.adoptedStyleSheets=t.map(n=>n instanceof CSSStyleSheet?n:n.styleSheet);else for(const n of t){const r=document.createElement("style"),o=Oa.litNonce;o!==void 0&&r.setAttribute("nonce",o),r.textContent=n.cssText,e.appendChild(r)}},dh=jd?e=>e:e=>e instanceof CSSStyleSheet?(t=>{let n="";for(const r of t.cssRules)n+=r.cssText;return Cb(n)})(e):e;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:Eb,defineProperty:_b,getOwnPropertyDescriptor:Ab,getOwnPropertyNames:xb,getOwnPropertySymbols:Sb,getPrototypeOf:Tb}=Object,Oc=globalThis,uh=Oc.trustedTypes,$b=uh?uh.emptyScript:"",Nb=Oc.reactiveElementPolyfillSupport,Do=(e,t)=>e,rc={toAttribute(e,t){switch(t){case Boolean:e=e?$b:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},zd=(e,t)=>!Eb(e,t),hh={attribute:!0,type:String,converter:rc,reflect:!1,useDefault:!1,hasChanged:zd};Symbol.metadata??=Symbol("metadata"),Oc.litPropertyMetadata??=new WeakMap;let Fi=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,n=hh){if(n.state&&(n.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(t)&&((n=Object.create(n)).wrapped=!0),this.elementProperties.set(t,n),!n.noAccessor){const r=Symbol(),o=this.getPropertyDescriptor(t,r,n);o!==void 0&&_b(this.prototype,t,o)}}static getPropertyDescriptor(t,n,r){const{get:o,set:i}=Ab(this.prototype,t)??{get(){return this[n]},set(s){this[n]=s}};return{get:o,set(s){const a=o?.call(this);i?.call(this,s),this.requestUpdate(t,a,r)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??hh}static _$Ei(){if(this.hasOwnProperty(Do("elementProperties")))return;const t=Tb(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(Do("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(Do("properties"))){const n=this.properties,r=[...xb(n),...Sb(n)];for(const o of r)this.createProperty(o,n[o])}const t=this[Symbol.metadata];if(t!==null){const n=litPropertyMetadata.get(t);if(n!==void 0)for(const[r,o]of n)this.elementProperties.set(r,o)}this._$Eh=new Map;for(const[n,r]of this.elementProperties){const o=this._$Eu(n,r);o!==void 0&&this._$Eh.set(o,n)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const n=[];if(Array.isArray(t)){const r=new Set(t.flat(1/0).reverse());for(const o of r)n.unshift(dh(o))}else t!==void 0&&n.push(dh(t));return n}static _$Eu(t,n){const r=n.attribute;return r===!1?void 0:typeof r=="string"?r:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(t=>t(this))}addController(t){(this._$EO??=new Set).add(t),this.renderRoot!==void 0&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){const t=new Map,n=this.constructor.elementProperties;for(const r of n.keys())this.hasOwnProperty(r)&&(t.set(r,this[r]),delete this[r]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return vb(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(t=>t.hostConnected?.())}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach(t=>t.hostDisconnected?.())}attributeChangedCallback(t,n,r){this._$AK(t,r)}_$ET(t,n){const r=this.constructor.elementProperties.get(t),o=this.constructor._$Eu(t,r);if(o!==void 0&&r.reflect===!0){const i=(r.converter?.toAttribute!==void 0?r.converter:rc).toAttribute(n,r.type);this._$Em=t,i==null?this.removeAttribute(o):this.setAttribute(o,i),this._$Em=null}}_$AK(t,n){const r=this.constructor,o=r._$Eh.get(t);if(o!==void 0&&this._$Em!==o){const i=r.getPropertyOptions(o),s=typeof i.converter=="function"?{fromAttribute:i.converter}:i.converter?.fromAttribute!==void 0?i.converter:rc;this._$Em=o;const a=s.fromAttribute(n,i.type);this[o]=a??this._$Ej?.get(o)??a,this._$Em=null}}requestUpdate(t,n,r,o=!1,i){if(t!==void 0){const s=this.constructor;if(o===!1&&(i=this[t]),r??=s.getPropertyOptions(t),!((r.hasChanged??zd)(i,n)||r.useDefault&&r.reflect&&i===this._$Ej?.get(t)&&!this.hasAttribute(s._$Eu(t,r))))return;this.C(t,n,r)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(t,n,{useDefault:r,reflect:o,wrapped:i},s){r&&!(this._$Ej??=new Map).has(t)&&(this._$Ej.set(t,s??n??this[t]),i!==!0||s!==void 0)||(this._$AL.has(t)||(this.hasUpdated||r||(n=void 0),this._$AL.set(t,n)),o===!0&&this._$Em!==t&&(this._$Eq??=new Set).add(t))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(n){Promise.reject(n)}const t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[o,i]of this._$Ep)this[o]=i;this._$Ep=void 0}const r=this.constructor.elementProperties;if(r.size>0)for(const[o,i]of r){const{wrapped:s}=i,a=this[o];s!==!0||this._$AL.has(o)||a===void 0||this.C(o,void 0,i,a)}}let t=!1;const n=this._$AL;try{t=this.shouldUpdate(n),t?(this.willUpdate(n),this._$EO?.forEach(r=>r.hostUpdate?.()),this.update(n)):this._$EM()}catch(r){throw t=!1,this._$EM(),r}t&&this._$AE(n)}willUpdate(t){}_$AE(t){this._$EO?.forEach(n=>n.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Eq&&=this._$Eq.forEach(n=>this._$ET(n,this[n])),this._$EM()}updated(t){}firstUpdated(t){}};Fi.elementStyles=[],Fi.shadowRootOptions={mode:"open"},Fi[Do("elementProperties")]=new Map,Fi[Do("finalized")]=new Map,Nb?.({ReactiveElement:Fi}),(Oc.reactiveElementVersions??=[]).push("2.1.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Hd=globalThis,ph=e=>e,ic=Hd.trustedTypes,fh=ic?ic.createPolicy("lit-html",{createHTML:e=>e}):void 0,hf="$lit$",hr=`lit$${Math.random().toFixed(9).slice(2)}$`,pf="?"+hr,Rb=`<${pf}>`,Qr=document,_s=()=>Qr.createComment(""),As=e=>e===null||typeof e!="object"&&typeof e!="function",Vd=Array.isArray,kb=e=>Vd(e)||typeof e?.[Symbol.iterator]=="function",sl=`[ 	
\f\r]`,No=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,mh=/-->/g,gh=/>/g,Dr=RegExp(`>|${sl}(?:([^\\s"'>=/]+)(${sl}*=${sl}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),wh=/'/g,bh=/"/g,ff=/^(?:script|style|textarea|title)$/i,Ib=e=>(t,...n)=>({_$litType$:e,strings:t,values:n}),g=Ib(1),ei=Symbol.for("lit-noChange"),Xe=Symbol.for("lit-nothing"),yh=new WeakMap,Fr=Qr.createTreeWalker(Qr,129);function mf(e,t){if(!Vd(e)||!e.hasOwnProperty("raw"))throw Error("invalid template strings array");return fh!==void 0?fh.createHTML(t):t}const Ob=(e,t)=>{const n=e.length-1,r=[];let o,i=t===2?"<svg>":t===3?"<math>":"",s=No;for(let a=0;a<n;a++){const c=e[a];let l,d,h=-1,f=0;for(;f<c.length&&(s.lastIndex=f,d=s.exec(c),d!==null);)f=s.lastIndex,s===No?d[1]==="!--"?s=mh:d[1]!==void 0?s=gh:d[2]!==void 0?(ff.test(d[2])&&(o=RegExp("</"+d[2],"g")),s=Dr):d[3]!==void 0&&(s=Dr):s===Dr?d[0]===">"?(s=o??No,h=-1):d[1]===void 0?h=-2:(h=s.lastIndex-d[2].length,l=d[1],s=d[3]===void 0?Dr:d[3]==='"'?bh:wh):s===bh||s===wh?s=Dr:s===mh||s===gh?s=No:(s=Dr,o=void 0);const w=s===Dr&&e[a+1].startsWith("/>")?" ":"";i+=s===No?c+Rb:h>=0?(r.push(l),c.slice(0,h)+hf+c.slice(h)+hr+w):c+hr+(h===-2?a:w)}return[mf(e,i+(e[n]||"<?>")+(t===2?"</svg>":t===3?"</math>":"")),r]};class xs{constructor({strings:t,_$litType$:n},r){let o;this.parts=[];let i=0,s=0;const a=t.length-1,c=this.parts,[l,d]=Ob(t,n);if(this.el=xs.createElement(l,r),Fr.currentNode=this.el.content,n===2||n===3){const h=this.el.content.firstChild;h.replaceWith(...h.childNodes)}for(;(o=Fr.nextNode())!==null&&c.length<a;){if(o.nodeType===1){if(o.hasAttributes())for(const h of o.getAttributeNames())if(h.endsWith(hf)){const f=d[s++],w=o.getAttribute(h).split(hr),v=/([.?@])?(.*)/.exec(f);c.push({type:1,index:i,name:v[2],strings:w,ctor:v[1]==="."?Lb:v[1]==="?"?Db:v[1]==="@"?Mb:Pc}),o.removeAttribute(h)}else h.startsWith(hr)&&(c.push({type:6,index:i}),o.removeAttribute(h));if(ff.test(o.tagName)){const h=o.textContent.split(hr),f=h.length-1;if(f>0){o.textContent=ic?ic.emptyScript:"";for(let w=0;w<f;w++)o.append(h[w],_s()),Fr.nextNode(),c.push({type:2,index:++i});o.append(h[f],_s())}}}else if(o.nodeType===8)if(o.data===pf)c.push({type:2,index:i});else{let h=-1;for(;(h=o.data.indexOf(hr,h+1))!==-1;)c.push({type:7,index:i}),h+=hr.length-1}i++}}static createElement(t,n){const r=Qr.createElement("template");return r.innerHTML=t,r}}function oo(e,t,n=e,r){if(t===ei)return t;let o=r!==void 0?n._$Co?.[r]:n._$Cl;const i=As(t)?void 0:t._$litDirective$;return o?.constructor!==i&&(o?._$AO?.(!1),i===void 0?o=void 0:(o=new i(e),o._$AT(e,n,r)),r!==void 0?(n._$Co??=[])[r]=o:n._$Cl=o),o!==void 0&&(t=oo(e,o._$AS(e,t.values),o,r)),t}class Pb{constructor(t,n){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=n}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:n},parts:r}=this._$AD,o=(t?.creationScope??Qr).importNode(n,!0);Fr.currentNode=o;let i=Fr.nextNode(),s=0,a=0,c=r[0];for(;c!==void 0;){if(s===c.index){let l;c.type===2?l=new Ws(i,i.nextSibling,this,t):c.type===1?l=new c.ctor(i,c.name,c.strings,this,t):c.type===6&&(l=new Ub(i,this,t)),this._$AV.push(l),c=r[++a]}s!==c?.index&&(i=Fr.nextNode(),s++)}return Fr.currentNode=Qr,o}p(t){let n=0;for(const r of this._$AV)r!==void 0&&(r.strings!==void 0?(r._$AI(t,r,n),n+=r.strings.length-2):r._$AI(t[n])),n++}}class Ws{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,n,r,o){this.type=2,this._$AH=Xe,this._$AN=void 0,this._$AA=t,this._$AB=n,this._$AM=r,this.options=o,this._$Cv=o?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const n=this._$AM;return n!==void 0&&t?.nodeType===11&&(t=n.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,n=this){t=oo(this,t,n),As(t)?t===Xe||t==null||t===""?(this._$AH!==Xe&&this._$AR(),this._$AH=Xe):t!==this._$AH&&t!==ei&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):kb(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==Xe&&As(this._$AH)?this._$AA.nextSibling.data=t:this.T(Qr.createTextNode(t)),this._$AH=t}$(t){const{values:n,_$litType$:r}=t,o=typeof r=="number"?this._$AC(t):(r.el===void 0&&(r.el=xs.createElement(mf(r.h,r.h[0]),this.options)),r);if(this._$AH?._$AD===o)this._$AH.p(n);else{const i=new Pb(o,this),s=i.u(this.options);i.p(n),this.T(s),this._$AH=i}}_$AC(t){let n=yh.get(t.strings);return n===void 0&&yh.set(t.strings,n=new xs(t)),n}k(t){Vd(this._$AH)||(this._$AH=[],this._$AR());const n=this._$AH;let r,o=0;for(const i of t)o===n.length?n.push(r=new Ws(this.O(_s()),this.O(_s()),this,this.options)):r=n[o],r._$AI(i),o++;o<n.length&&(this._$AR(r&&r._$AB.nextSibling,o),n.length=o)}_$AR(t=this._$AA.nextSibling,n){for(this._$AP?.(!1,!0,n);t!==this._$AB;){const r=ph(t).nextSibling;ph(t).remove(),t=r}}setConnected(t){this._$AM===void 0&&(this._$Cv=t,this._$AP?.(t))}}class Pc{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,n,r,o,i){this.type=1,this._$AH=Xe,this._$AN=void 0,this.element=t,this.name=n,this._$AM=o,this.options=i,r.length>2||r[0]!==""||r[1]!==""?(this._$AH=Array(r.length-1).fill(new String),this.strings=r):this._$AH=Xe}_$AI(t,n=this,r,o){const i=this.strings;let s=!1;if(i===void 0)t=oo(this,t,n,0),s=!As(t)||t!==this._$AH&&t!==ei,s&&(this._$AH=t);else{const a=t;let c,l;for(t=i[0],c=0;c<i.length-1;c++)l=oo(this,a[r+c],n,c),l===ei&&(l=this._$AH[c]),s||=!As(l)||l!==this._$AH[c],l===Xe?t=Xe:t!==Xe&&(t+=(l??"")+i[c+1]),this._$AH[c]=l}s&&!o&&this.j(t)}j(t){t===Xe?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}class Lb extends Pc{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===Xe?void 0:t}}class Db extends Pc{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==Xe)}}class Mb extends Pc{constructor(t,n,r,o,i){super(t,n,r,o,i),this.type=5}_$AI(t,n=this){if((t=oo(this,t,n,0)??Xe)===ei)return;const r=this._$AH,o=t===Xe&&r!==Xe||t.capture!==r.capture||t.once!==r.once||t.passive!==r.passive,i=t!==Xe&&(r===Xe||o);o&&this.element.removeEventListener(this.name,this,r),i&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}}class Ub{constructor(t,n,r){this.element=t,this.type=6,this._$AN=void 0,this._$AM=n,this.options=r}get _$AU(){return this._$AM._$AU}_$AI(t){oo(this,t)}}const Bb=Hd.litHtmlPolyfillSupport;Bb?.(xs,Ws),(Hd.litHtmlVersions??=[]).push("3.3.2");const Wb=(e,t,n)=>{const r=n?.renderBefore??t;let o=r._$litPart$;if(o===void 0){const i=n?.renderBefore??null;r._$litPart$=o=new Ws(t.insertBefore(_s(),i),i,void 0,n??{})}return o._$AI(e),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const qd=globalThis;let he=class extends Fi{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const n=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=Wb(n,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return ei}};he._$litElement$=!0,he.finalized=!0,qd.litElementHydrateSupport?.({LitElement:he});const jb=qd.litElementPolyfillSupport;jb?.({LitElement:he});(qd.litElementVersions??=[]).push("4.2.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Fb={attribute:!0,type:String,converter:rc,reflect:!1,hasChanged:zd},zb=(e=Fb,t,n)=>{const{kind:r,metadata:o}=n;let i=globalThis.litPropertyMetadata.get(o);if(i===void 0&&globalThis.litPropertyMetadata.set(o,i=new Map),r==="setter"&&((e=Object.create(e)).wrapped=!0),i.set(n.name,e),r==="accessor"){const{name:s}=n;return{set(a){const c=t.get.call(this);t.set.call(this,a),this.requestUpdate(s,c,e,!0,a)},init(a){return a!==void 0&&this.C(s,void 0,e,a),a}}}if(r==="setter"){const{name:s}=n;return function(a){const c=this[s];t.call(this,a),this.requestUpdate(s,c,e,!0,a)}}throw Error("Unsupported decorator location: "+r)};function ve(e){return(t,n)=>typeof n=="object"?zb(e,t,n):((r,o,i)=>{const s=o.hasOwnProperty(i);return o.constructor.createProperty(i,r),s?Object.getOwnPropertyDescriptor(o,i):void 0})(e,t,n)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function T(e){return ve({...e,state:!0,attribute:!1})}/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ae=e=>e??Xe;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Hb={attribute:!0,type:String,converter:Xa,reflect:!1,hasChanged:Dd},Vb=(e=Hb,t,n)=>{const{kind:r,metadata:o}=n;let i=globalThis.litPropertyMetadata.get(o);if(i===void 0&&globalThis.litPropertyMetadata.set(o,i=new Map),r==="setter"&&((e=Object.create(e)).wrapped=!0),i.set(n.name,e),r==="accessor"){const{name:s}=n;return{set(a){const c=t.get.call(this);t.set.call(this,a),this.requestUpdate(s,c,e,!0,a)},init(a){return a!==void 0&&this.C(s,void 0,e,a),a}}}if(r==="setter"){const{name:s}=n;return function(a){const c=this[s];t.call(this,a),this.requestUpdate(s,c,e,!0,a)}}throw Error("Unsupported decorator location: "+r)};function m(e){return(t,n)=>typeof n=="object"?Vb(e,t,n):((r,o,i)=>{const s=o.hasOwnProperty(i);return o.constructor.createProperty(i,r),s?Object.getOwnPropertyDescriptor(o,i):void 0})(e,t,n)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function gf(e){return m({...e,state:!0,attribute:!1})}/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Qe=e=>e??Je;/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const wf=Symbol.for(""),qb=e=>{if(e?.r===wf)return e?._$litStatic$},Kb=e=>({_$litStatic$:e,r:wf}),Ch=new Map,Gb=e=>(t,...n)=>{const r=n.length;let o,i;const s=[],a=[];let c,l=0,d=!1;for(;l<r;){for(c=t[l];l<r&&(i=n[l],(o=qb(i))!==void 0);)c+=o+t[++l],d=!0;l!==r&&a.push(i),s.push(c),l++}if(l===r&&s.push(t[r]),d){const h=s.join("$$lit$$");(t=Ch.get(h))===void 0&&(s.raw=s,Ch.set(h,t=s)),n=a}return e(t,...n)},vh=Gb(x),Zb=pe`<svg width="30" height="30" viewBox="0 0 30 30" fill="none">
  <g clip-path="url(#clip0_87_33)">
    <path d="M23.9367 2.29447e-07H6.05917C5.26333 -0.000218805 4.47526 0.156384 3.73997 0.46086C3.00469 0.765337 2.33661 1.21172 1.77391 1.7745C1.21121 2.33727 0.764917 3.00542 0.460542 3.74074C0.156167 4.47607 -0.000327963 5.26417 5.16031e-07 6.06V23.9433C4.48257e-07 24.7389 0.156744 25.5267 0.461276 26.2617C0.765808 26.9967 1.21216 27.6645 1.77484 28.2269C2.33752 28.7894 3.0055 29.2355 3.74061 29.5397C4.47573 29.8439 5.26358 30.0003 6.05917 30H23.9417C25.5486 29.9996 27.0895 29.3609 28.2257 28.2245C29.3618 27.0881 30 25.5469 30 23.94V6.06C29.9993 4.45241 29.3602 2.91091 28.2232 1.77449C27.0861 0.638064 25.5443 -0.000220881 23.9367 2.29447e-07Z" fill="url(#paint0_linear_87_33)"/>
    <path d="M14.8708 6.89259L15.4783 5.84259C15.5679 5.68703 15.6873 5.55064 15.8296 5.44122C15.9719 5.3318 16.1344 5.25148 16.3078 5.20486C16.4812 5.15824 16.662 5.14622 16.8401 5.1695C17.0181 5.19277 17.1898 5.25088 17.3453 5.34051C17.5009 5.43013 17.6373 5.54952 17.7467 5.69186C17.8561 5.83419 17.9364 5.99669 17.9831 6.17006C18.0297 6.34344 18.0417 6.5243 18.0184 6.70232C17.9952 6.88034 17.9371 7.05203 17.8474 7.20759L11.9949 17.3401H16.2283C17.5999 17.3401 18.3691 18.9526 17.7724 20.0701H5.36159C5.18215 20.0707 5.00436 20.0359 4.83845 19.9675C4.67254 19.8992 4.5218 19.7986 4.39492 19.6718C4.26803 19.5449 4.16751 19.3941 4.09915 19.2282C4.03079 19.0623 3.99593 18.8845 3.99659 18.7051C3.99659 17.9476 4.60492 17.3401 5.36159 17.3401H8.84159L13.2958 9.61926L11.9041 7.20426C11.738 6.89096 11.7 6.52543 11.7982 6.18469C11.8963 5.84395 12.1229 5.5546 12.4301 5.37763C12.7374 5.20065 13.1014 5.14987 13.4454 5.23599C13.7893 5.3221 14.0864 5.53838 14.2741 5.83926L14.8708 6.89259ZM9.60659 21.4759L8.29409 23.7526C8.20446 23.9082 8.08506 24.0446 7.94271 24.1541C7.80035 24.2636 7.63783 24.344 7.46441 24.3906C7.291 24.4373 7.11009 24.4493 6.93202 24.4261C6.75395 24.4028 6.58221 24.3447 6.42659 24.2551C6.27097 24.1655 6.13454 24.0461 6.02506 23.9037C5.91559 23.7613 5.83523 23.5988 5.78857 23.4254C5.74191 23.252 5.72986 23.0711 5.75311 22.893C5.77637 22.715 5.83446 22.5432 5.92409 22.3876L6.89909 20.7001C8.00159 20.3584 8.89742 20.6209 9.60659 21.4759ZM20.9066 17.3476H24.4583C25.2158 17.3476 25.8233 17.9551 25.8233 18.7126C25.8233 19.4701 25.2149 20.0776 24.4583 20.0776H22.4858L23.8166 22.3876C24.1916 23.0443 23.9708 23.8726 23.3149 24.2551C23.0006 24.4359 22.6274 24.4845 22.2772 24.3903C21.927 24.2961 21.6286 24.0667 21.4474 23.7526C19.2058 19.8643 17.5216 16.9534 16.4041 15.0151C15.2608 13.0426 16.0783 11.0626 16.8841 10.3909C17.7799 11.9293 19.1191 14.2501 20.9074 17.3476H20.9066Z" fill="white"/>
  </g>
  <defs>
    <linearGradient id="paint0_linear_87_33" x1="15" y1="2.29447e-07" x2="15" y2="30" gradientUnits="userSpaceOnUse">
      <stop stop-color="#18BFFB"/>
      <stop offset="1" stop-color="#2072F3"/>
    </linearGradient>
    <clipPath id="clip0_87_33">
      <rect width="30" height="30" fill="white"/>
    </clipPath>
  </defs>
</svg>`,Yb=pe`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#000" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M28.77 23.3c-.69 1.99-2.75 5.52-4.87 5.56-1.4.03-1.86-.84-3.46-.84-1.61 0-2.12.81-3.45.86-2.25.1-5.72-5.1-5.72-9.62 0-4.15 2.9-6.2 5.42-6.25 1.36-.02 2.64.92 3.47.92.83 0 2.38-1.13 4.02-.97.68.03 2.6.28 3.84 2.08-3.27 2.14-2.76 6.61.75 8.25ZM24.2 7.88c-2.47.1-4.49 2.69-4.2 4.84 2.28.17 4.47-2.39 4.2-4.84Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`,Jb=pe`
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 8 11">
    <path
      fill="var(--apkt-tokens-theme-textPrimary)"
      d="M7.862 4.86c.159-1.064-.652-1.637-1.76-2.018l.36-1.443-.879-.218-.35 1.404c-.23-.058-.468-.112-.703-.166l.352-1.413-.877-.219-.36 1.442a29.02 29.02 0 0 1-.56-.132v-.005l-1.21-.302-.234.938s.652.15.638.158c.356.089.42.324.41.51l-.41 1.644a.715.715 0 0 1 .09.03l-.092-.024-.574 2.302c-.044.108-.154.27-.402.208.008.013-.639-.16-.639-.16L.227 8.403l1.142.285c.213.053.42.109.626.161l-.363 1.459.877.218.36-1.443c.239.065.472.125.7.182l-.36 1.436.879.219.363-1.456c1.497.283 2.623.17 3.097-1.185.381-1.09-.02-1.719-.807-2.129.574-.132 1.006-.51 1.12-1.289ZM5.856 7.673c-.272 1.09-2.107.5-2.702.353l.482-1.933c.595.149 2.503.443 2.22 1.58Zm.271-2.829c-.247.992-1.775.488-2.27.365l.436-1.753c.496.124 2.092.354 1.834 1.388Z"
    />
  </svg>
`,Xb=pe`<svg width="30" height="30" viewBox="0 0 30 30" fill="none">
<path d="M14.9978 7.80003H27.4668C26.2032 5.61107 24.3857 3.79333 22.1968 2.52955C20.008 1.26577 17.525 0.600485 14.9975 0.600586C12.47 0.600687 9.98712 1.26617 7.79838 2.53012C5.60964 3.79408 3.79221 5.61197 2.52881 7.80103L8.76281 18.599L8.76881 18.598C8.13412 17.5044 7.79906 16.2628 7.79743 14.9983C7.79579 13.7339 8.12764 12.4914 8.7595 11.3961C9.39136 10.3008 10.3009 9.39159 11.3963 8.76005C12.4918 8.12851 13.7344 7.79702 14.9988 7.79903L14.9978 7.80003Z" fill="url(#paint0_linear_87_32)"/>
<path d="M21.237 18.5981L15.003 29.3961C17.5305 29.3961 20.0134 28.7308 22.2022 27.467C24.391 26.2032 26.2086 24.3854 27.4721 22.1965C28.7356 20.0075 29.4006 17.5245 29.4003 14.997C29.3999 12.4695 28.7342 9.9867 27.47 7.7981H15.002L15 7.8041C16.2642 7.80168 17.5067 8.13257 18.6022 8.76342C19.6977 9.39428 20.6076 10.3028 21.2401 11.3974C21.8726 12.492 22.2053 13.734 22.2048 14.9982C22.2042 16.2623 21.8704 17.504 21.237 18.5981Z" fill="url(#paint1_linear_87_32)"/>
<path d="M8.76502 18.601L2.53102 7.80298C1.26664 9.99172 0.600848 12.4748 0.600586 15.0025C0.600324 17.5302 1.2656 20.0134 2.52953 22.2024C3.79345 24.3914 5.61145 26.209 7.80071 27.4725C9.98998 28.736 12.4733 29.4008 15.001 29.4L21.236 18.602L21.232 18.598C20.6022 19.6941 19.6944 20.6049 18.6003 21.2383C17.5062 21.8717 16.2644 22.2055 15.0002 22.2059C13.7359 22.2063 12.4939 21.8733 11.3994 21.2406C10.3049 20.6079 9.39657 19.6977 8.76602 18.602L8.76502 18.601Z" fill="url(#paint2_linear_87_32)"/>
<path d="M14.9998 22.2C16.9094 22.2 18.7407 21.4415 20.091 20.0912C21.4412 18.741 22.1998 16.9096 22.1998 15C22.1998 13.0905 21.4412 11.2591 20.091 9.90888C18.7407 8.55862 16.9094 7.80005 14.9998 7.80005C13.0902 7.80005 11.2589 8.55862 9.90864 9.90888C8.55837 11.2591 7.7998 13.0905 7.7998 15C7.7998 16.9096 8.55837 18.741 9.90864 20.0912C11.2589 21.4415 13.0902 22.2 14.9998 22.2Z" fill="white"/>
<path d="M14.9998 20.7C16.5115 20.7 17.9614 20.0995 19.0303 19.0306C20.0993 17.9616 20.6998 16.5118 20.6998 15C20.6998 13.4883 20.0993 12.0385 19.0303 10.9695C17.9614 9.90058 16.5115 9.30005 14.9998 9.30005C13.4881 9.30005 12.0383 9.90058 10.9693 10.9695C9.90034 12.0385 9.2998 13.4883 9.2998 15C9.2998 16.5118 9.90034 17.9616 10.9693 19.0306C12.0383 20.0995 13.4881 20.7 14.9998 20.7Z" fill="#1A73E8"/>
<defs>
  <linearGradient id="paint0_linear_87_32" x1="3.29381" y1="2.99503" x2="38.0998" y2="2.99503" gradientUnits="userSpaceOnUse">
    <stop stop-color="#D93025"/>
    <stop offset="1" stop-color="#EA4335"/>
  </linearGradient>
  <linearGradient id="paint1_linear_87_32" x1="17.953" y1="29.1431" x2="34.194" y2="-0.298904" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FCC934"/>
    <stop offset="1" stop-color="#FBBC04"/>
  </linearGradient>
  <linearGradient id="paint2_linear_87_32" x1="22.873" y1="28.2" x2="6.63202" y2="-1.24102" gradientUnits="userSpaceOnUse">
    <stop stop-color="#1E8E3E"/>
    <stop offset="1" stop-color="#34A853"/>
  </linearGradient>
</defs>
</svg>`,Qb=pe`<svg width="32" height="32" viewBox="0 0 32 32" fill="none">
<path d="M23 11.1962V10.5C23 7.365 18.2712 5 12 5C5.72875 5 1 7.365 1 10.5V15.5C1 18.1112 4.28125 20.1863 9 20.8075V21.5C9 24.635 13.7288 27 20 27C26.2712 27 31 24.635 31 21.5V16.5C31 13.9125 27.8225 11.835 23 11.1962ZM7 18.3587C4.55125 17.675 3 16.5487 3 15.5V13.7413C4.02 14.4637 5.38625 15.0463 7 15.4375V18.3587ZM17 15.4375C18.6138 15.0463 19.98 14.4637 21 13.7413V15.5C21 16.5487 19.4487 17.675 17 18.3587V15.4375ZM15 24.3587C12.5513 23.675 11 22.5487 11 21.5V20.9788C11.3287 20.9913 11.6613 21 12 21C12.485 21 12.9587 20.9837 13.4237 20.9562C13.9403 21.1412 14.4665 21.2981 15 21.4263V24.3587ZM15 18.7812C14.0068 18.928 13.004 19.0011 12 19C10.996 19.0011 9.99324 18.928 9 18.7812V15.8075C9.99472 15.9371 10.9969 16.0014 12 16C13.0031 16.0014 14.0053 15.9371 15 15.8075V18.7812ZM23 24.7812C21.0106 25.0729 18.9894 25.0729 17 24.7812V21.8C17.9944 21.9337 18.9967 22.0005 20 22C21.0031 22.0014 22.0053 21.9371 23 21.8075V24.7812ZM29 21.5C29 22.5487 27.4487 23.675 25 24.3587V21.4375C26.6138 21.0462 27.98 20.4637 29 19.7412V21.5Z" fill="currentColor"/>
</svg>
`,ey=pe` <svg fill="none" viewBox="0 0 13 4">
  <path fill="currentColor" d="M.5 0h12L8.9 3.13a3.76 3.76 0 0 1-4.8 0L.5 0Z" />
</svg>`,ty=pe`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#5865F2" />
      <path
        fill="#fff"
        fill-rule="evenodd"
        d="M25.71 28.15C30.25 28 32 25.02 32 25.02c0-6.61-2.96-11.98-2.96-11.98-2.96-2.22-5.77-2.15-5.77-2.15l-.29.32c3.5 1.07 5.12 2.61 5.12 2.61a16.75 16.75 0 0 0-10.34-1.93l-.35.04a15.43 15.43 0 0 0-5.88 1.9s1.71-1.63 5.4-2.7l-.2-.24s-2.81-.07-5.77 2.15c0 0-2.96 5.37-2.96 11.98 0 0 1.73 2.98 6.27 3.13l1.37-1.7c-2.6-.79-3.6-2.43-3.6-2.43l.58.35.09.06.08.04.02.01.08.05a17.25 17.25 0 0 0 4.52 1.58 14.4 14.4 0 0 0 8.3-.86c.72-.27 1.52-.66 2.37-1.21 0 0-1.03 1.68-3.72 2.44.61.78 1.35 1.67 1.35 1.67Zm-9.55-9.6c-1.17 0-2.1 1.03-2.1 2.28 0 1.25.95 2.28 2.1 2.28 1.17 0 2.1-1.03 2.1-2.28.01-1.25-.93-2.28-2.1-2.28Zm7.5 0c-1.17 0-2.1 1.03-2.1 2.28 0 1.25.95 2.28 2.1 2.28 1.17 0 2.1-1.03 2.1-2.28 0-1.25-.93-2.28-2.1-2.28Z"
        clip-rule="evenodd"
      />
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
  </defs>
</svg>`,ny=pe`<svg
  xmlns="http://www.w3.org/2000/svg"
  fill="none"
  viewBox="0 0 9 12"
>
  <path
    fill="var(--apkt-tokens-theme-textPrimary)"
    d="M4.666.001v4.435l3.748 1.675L4.666.001Zm0 0L.917 6.111l3.749-1.675V.001Zm0 8.984V12l3.75-5.19-3.75 2.176Zm0 3.014V8.985L.917 6.81 4.666 12Zm0-3.712 3.748-2.176-3.748-1.675v3.851Z"
  />
  <path fill="var(--apkt-tokens-theme-textPrimary)" d="m.917 6.111 3.749 2.176v-3.85L.917 6.11Z" />
</svg>`,ry=pe`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    d="M4.25 7a.63.63 0 0 0-.63.63v3.97c0 .28-.2.51-.47.54l-.75.07a.93.93 0 0 1-.9-.47A7.51 7.51 0 0 1 5.54.92a7.5 7.5 0 0 1 9.54 4.62c.12.35.06.72-.16 1-.74.97-1.68 1.78-2.6 2.44V4.44a.64.64 0 0 0-.63-.64h-1.06c-.35 0-.63.3-.63.64v5.5c0 .23-.12.42-.32.5l-.52.23V6.05c0-.36-.3-.64-.64-.64H7.45c-.35 0-.64.3-.64.64v4.97c0 .25-.17.46-.4.52a5.8 5.8 0 0 0-.45.11v-4c0-.36-.3-.65-.64-.65H4.25ZM14.07 12.4A7.49 7.49 0 0 1 3.6 14.08c4.09-.58 9.14-2.5 11.87-6.6v.03a7.56 7.56 0 0 1-1.41 4.91Z"
  />
</svg>`,iy=pe`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#1877F2" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M26 12.38h-2.89c-.92 0-1.61.38-1.61 1.34v1.66H26l-.36 4.5H21.5v12H17v-12h-3v-4.5h3V12.5c0-3.03 1.6-4.62 5.2-4.62H26v4.5Z"
        />
      </g>
    </g>
    <path
      fill="#1877F2"
      d="M40 20a20 20 0 1 0-23.13 19.76V25.78H11.8V20h5.07v-4.4c0-5.02 3-7.79 7.56-7.79 2.19 0 4.48.4 4.48.4v4.91h-2.53c-2.48 0-3.25 1.55-3.25 3.13V20h5.54l-.88 5.78h-4.66v13.98A20 20 0 0 0 40 20Z"
    />
    <path
      fill="#fff"
      d="m27.79 25.78.88-5.78h-5.55v-3.75c0-1.58.78-3.13 3.26-3.13h2.53V8.2s-2.3-.39-4.48-.39c-4.57 0-7.55 2.77-7.55 7.78V20H11.8v5.78h5.07v13.98a20.15 20.15 0 0 0 6.25 0V25.78h4.67Z"
    />
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`,oy=pe`<svg style="border-radius: 9999px; overflow: hidden;"  fill="none" viewBox="0 0 1000 1000">
  <rect width="1000" height="1000" rx="9999" ry="9999" fill="#855DCD"/>
  <path fill="#855DCD" d="M0 0h1000v1000H0V0Z" />
  <path
    fill="#fff"
    d="M320 248h354v504h-51.96V521.13h-.5c-5.76-63.8-59.31-113.81-124.54-113.81s-118.78 50-124.53 113.81h-.5V752H320V248Z"
  />
  <path
    fill="#fff"
    d="m225 320 21.16 71.46h17.9v289.09a16.29 16.29 0 0 0-16.28 16.24v19.49h-3.25a16.3 16.3 0 0 0-16.28 16.24V752h182.26v-19.48a16.22 16.22 0 0 0-16.28-16.24h-3.25v-19.5a16.22 16.22 0 0 0-16.28-16.23h-19.52V320H225Zm400.3 360.55a16.3 16.3 0 0 0-15.04 10.02 16.2 16.2 0 0 0-1.24 6.22v19.49h-3.25a16.29 16.29 0 0 0-16.27 16.24V752h182.24v-19.48a16.23 16.23 0 0 0-16.27-16.24h-3.25v-19.5a16.2 16.2 0 0 0-10.04-15 16.3 16.3 0 0 0-6.23-1.23v-289.1h17.9L775 320H644.82v360.55H625.3Z"
  />
</svg>`,sy=pe`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#1B1F23" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M8 19.89a12 12 0 1 1 15.8 11.38c-.6.12-.8-.26-.8-.57v-3.3c0-1.12-.4-1.85-.82-2.22 2.67-.3 5.48-1.31 5.48-5.92 0-1.31-.47-2.38-1.24-3.22.13-.3.54-1.52-.12-3.18 0 0-1-.32-3.3 1.23a11.54 11.54 0 0 0-6 0c-2.3-1.55-3.3-1.23-3.3-1.23a4.32 4.32 0 0 0-.12 3.18 4.64 4.64 0 0 0-1.24 3.22c0 4.6 2.8 5.63 5.47 5.93-.34.3-.65.83-.76 1.6-.69.31-2.42.84-3.5-1 0 0-.63-1.15-1.83-1.23 0 0-1.18-.02-.09.73 0 0 .8.37 1.34 1.76 0 0 .7 2.14 4.03 1.41v2.24c0 .31-.2.68-.8.57A12 12 0 0 1 8 19.9Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`,ay=pe`<svg fill="none" viewBox="0 0 40 40">
  <path
    fill="#4285F4"
    d="M32.74 20.3c0-.93-.08-1.81-.24-2.66H20.26v5.03h7a6 6 0 0 1-2.62 3.91v3.28h4.22c2.46-2.27 3.88-5.6 3.88-9.56Z"
  />
  <path
    fill="#34A853"
    d="M20.26 33a12.4 12.4 0 0 0 8.6-3.14l-4.22-3.28a7.74 7.74 0 0 1-4.38 1.26 7.76 7.76 0 0 1-7.28-5.36H8.65v3.36A12.99 12.99 0 0 0 20.26 33Z"
  />
  <path
    fill="#FBBC05"
    d="M12.98 22.47a7.79 7.79 0 0 1 0-4.94v-3.36H8.65a12.84 12.84 0 0 0 0 11.66l3.37-2.63.96-.73Z"
  />
  <path
    fill="#EA4335"
    d="M20.26 12.18a7.1 7.1 0 0 1 4.98 1.93l3.72-3.72A12.47 12.47 0 0 0 20.26 7c-5.08 0-9.47 2.92-11.6 7.17l4.32 3.36a7.76 7.76 0 0 1 7.28-5.35Z"
  />
</svg>`,cy=pe`<svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
<path d="M4.875 0C3.91082 0 2.96829 0.285914 2.1666 0.821586C1.36491 1.35726 0.740067 2.11863 0.371089 3.00942C0.00211226 3.90021 -0.094429 4.88041 0.093674 5.82607C0.281777 6.77172 0.746076 7.64036 1.42786 8.32215C2.10964 9.00393 2.97828 9.46823 3.92394 9.65633C4.86959 9.84443 5.84979 9.74789 6.74058 9.37891C7.63137 9.00994 8.39274 8.38509 8.92842 7.5834C9.46409 6.78171 9.75 5.83918 9.75 4.875C9.74864 3.58249 9.23458 2.34331 8.32064 1.42936C7.4067 0.515418 6.16751 0.00136492 4.875 0ZM4.6875 2.25C4.79875 2.25 4.90751 2.28299 5.00001 2.3448C5.09251 2.40661 5.16461 2.49446 5.20718 2.59724C5.24976 2.70002 5.2609 2.81312 5.23919 2.92224C5.21749 3.03135 5.16392 3.13158 5.08525 3.21025C5.00658 3.28891 4.90635 3.34249 4.79724 3.36419C4.68813 3.3859 4.57503 3.37476 4.47224 3.33218C4.36946 3.28961 4.28161 3.21751 4.2198 3.12501C4.15799 3.03251 4.125 2.92375 4.125 2.8125C4.125 2.66332 4.18427 2.52024 4.28975 2.41475C4.39524 2.30926 4.53832 2.25 4.6875 2.25ZM5.25 7.5C5.05109 7.5 4.86032 7.42098 4.71967 7.28033C4.57902 7.13968 4.5 6.94891 4.5 6.75V4.875C4.40055 4.875 4.30516 4.83549 4.23484 4.76516C4.16451 4.69484 4.125 4.59946 4.125 4.5C4.125 4.40054 4.16451 4.30516 4.23484 4.23484C4.30516 4.16451 4.40055 4.125 4.5 4.125C4.69891 4.125 4.88968 4.20402 5.03033 4.34467C5.17098 4.48532 5.25 4.67609 5.25 4.875V6.75C5.34946 6.75 5.44484 6.78951 5.51517 6.85983C5.58549 6.93016 5.625 7.02554 5.625 7.125C5.625 7.22446 5.58549 7.31984 5.51517 7.39017C5.44484 7.46049 5.34946 7.5 5.25 7.5Z" fill="#9A9A9A"/>
</svg>
`,ly=pe`<svg width="32" height="32" viewBox="0 0 32 32" fill="none">
<path d="M28.925 5.5425C28.925 5.5425 28.925 5.555 28.925 5.56125L21.65 29.5537C21.5399 29.9434 21.3132 30.2901 21.0004 30.5473C20.6876 30.8045 20.3036 30.9598 19.9 30.9925C19.8425 30.9975 19.785 31 19.7275 31C19.3493 31.0012 18.9786 30.8941 18.6592 30.6915C18.3398 30.4888 18.085 30.199 17.925 29.8563L13.375 20.5187C13.3295 20.4252 13.3143 20.3197 13.3315 20.2171C13.3488 20.1145 13.3976 20.0198 13.4713 19.9463L20.7113 12.7063C20.8909 12.5172 20.9895 12.2654 20.9862 12.0047C20.9829 11.7439 20.8778 11.4948 20.6934 11.3104C20.509 11.126 20.2599 11.0209 19.9991 11.0176C19.7383 11.0142 19.4866 11.1129 19.2975 11.2925L12.0538 18.5325C11.9802 18.6061 11.8855 18.655 11.7829 18.6722C11.6803 18.6895 11.5748 18.6743 11.4813 18.6287L2.13502 14.08C1.76954 13.9047 1.46598 13.6224 1.26454 13.2706C1.06311 12.9189 0.973316 12.5142 1.00707 12.1102C1.04082 11.7063 1.19652 11.3221 1.45354 11.0087C1.71056 10.6952 2.05676 10.4673 2.44627 10.355L26.4388 3.08H26.4575C26.7991 2.98403 27.1601 2.98066 27.5034 3.07025C27.8468 3.15984 28.1601 3.33916 28.4113 3.58981C28.6624 3.84045 28.8424 4.15341 28.9326 4.49656C29.0229 4.83971 29.0203 5.2007 28.925 5.5425Z" fill="currentColor"/>
</svg>
`,dy=pe` <svg width="27" height="30" viewBox="0 0 27 30" fill="none">
  <path d="M12.5395 14.3237L0.116699 27.5049V27.5188C0.251527 28.0177 0.49972 28.4788 0.841941 28.866C1.18416 29.2533 1.61117 29.5563 2.0897 29.7515C2.56823 29.9467 3.08536 30.0287 3.60081 29.9913C4.11625 29.9538 4.61609 29.7979 5.06139 29.5356L5.0975 29.512L19.0718 21.4519L12.5395 14.3237Z" fill="#EA4335"/>
  <path d="M25.103 12.0833L25.0919 12.0722L19.0611 8.57202L12.2607 14.6279L19.0847 21.4504L25.0919 17.9864C25.6229 17.6983 26.0665 17.2725 26.376 16.7537C26.6854 16.2349 26.8493 15.6422 26.8505 15.0381C26.8516 14.434 26.6899 13.8408 26.3824 13.3208C26.0749 12.8008 25.633 12.3734 25.103 12.0833Z" fill="#FBBC04"/>
  <path d="M0.116672 2.49553C0.047224 2.7761 0 3.05528 0 3.35946V26.6537C0 26.9565 0.0347234 27.237 0.116672 27.5162L12.959 14.6725L0.116672 2.49553Z" fill="#4285F4"/>
  <path d="M12.634 15.0001L19.0607 8.57198L5.0975 0.477133C4.65115 0.210463 4.14916 0.0506574 3.63079 0.0102139C3.11242 -0.0302296 2.59172 0.0497852 2.10941 0.244001C1.6271 0.438216 1.19625 0.741368 0.850556 1.12975C0.504864 1.51813 0.253698 1.98121 0.116699 2.48279L12.634 15.0001Z" fill="#34A853"/>
</svg>`,uy=pe`<svg width="75" height="20" viewBox="0 0 75 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M11.6666 5.83334C11.6666 2.61168 14.2783 0 17.5 0H25.8334C29.055 0 31.6666 2.61168 31.6666 5.83334V14.1666C31.6666 17.3883 29.055 20 25.8334 20H17.5C14.2783 20 11.6666 17.3883 11.6666 14.1666V5.83334Z" fill="var(--apkt-tokens-theme-foregroundTertiary)"/>
<path d="M19.5068 13.7499L22.4309 5.83331H23.2895L20.3654 13.7499H19.5068Z" fill="var(--apkt-tokens-theme-textPrimary)"/>
<path d="M0 5.41666C0 2.42513 2.42513 0 5.41666 0C8.40821 0 10.8334 2.42513 10.8334 5.41666V14.5833C10.8334 17.5748 8.40821 20 5.41666 20C2.42513 20 0 17.5748 0 14.5833V5.41666Z" fill="var(--apkt-tokens-theme-foregroundTertiary)"/>
<path d="M4.89581 12.4997V11.458H5.93747V12.4997H4.89581Z" fill="var(--apkt-tokens-theme-textPrimary)"/>
<path d="M32.5 10C32.5 4.47715 36.6896 0 41.8578 0H65.6422C70.8104 0 75 4.47715 75 10C75 15.5229 70.8104 20 65.6422 20H41.8578C36.6896 20 32.5 15.5229 32.5 10Z" fill="var(--apkt-tokens-theme-foregroundTertiary)"/>
<path d="M61.7108 12.4475V7.82751H62.5266V8.52418C62.8199 8.01084 63.4157 7.70834 64.0757 7.70834C65.0749 7.70834 65.7715 8.34084 65.7715 9.56918V12.4475H64.9649V9.61503C64.9649 8.80831 64.5066 8.38668 63.8374 8.38668C63.1132 8.38668 62.5266 8.9642 62.5266 9.78001V12.4475H61.7108Z" fill="var(--apkt-tokens-theme-textPrimary)"/>
<path d="M56.5671 12.4475L55.7147 7.82748H56.4846L57.0896 11.6409L57.8871 9.12916H58.6479L59.4363 11.6134L60.0505 7.82748H60.8204L59.9679 12.4475H59.0513L58.2721 10.0458L57.4838 12.4475H56.5671Z" fill="var(--apkt-tokens-theme-textPrimary)"/>
<path d="M52.9636 12.5666C51.5611 12.5666 50.7361 11.5217 50.7361 10.1375C50.7361 8.76254 51.5611 7.70834 52.9636 7.70834C54.3661 7.70834 55.1911 8.76254 55.1911 10.1375C55.1911 11.5217 54.3661 12.5666 52.9636 12.5666ZM52.9636 11.8883C53.9719 11.8883 54.357 11.0266 54.357 10.1283C54.357 9.23914 53.9719 8.38668 52.9636 8.38668C51.9552 8.38668 51.5702 9.23914 51.5702 10.1283C51.5702 11.0266 51.9552 11.8883 52.9636 11.8883Z" fill="var(--apkt-tokens-theme-textPrimary)"/>
<path d="M47.8507 12.5666C46.494 12.5666 45.6415 11.5308 45.6415 10.1375C45.6415 8.75337 46.494 7.70834 47.8507 7.70834C48.9965 7.70834 50.0048 8.35917 49.8948 10.3483H46.4756C46.5398 11.2009 46.934 11.8975 47.8507 11.8975C48.4648 11.8975 48.8681 11.5217 49.0057 11.0908H49.8123C49.684 11.8609 48.9598 12.5666 47.8507 12.5666ZM46.494 9.73416H49.1065C49.0423 8.80831 48.6114 8.37751 47.8507 8.37751C47.0165 8.37751 46.604 8.98254 46.494 9.73416Z" fill="var(--apkt-tokens-theme-textPrimary)"/>
<path d="M41.7284 12.4475V7.82748H42.5625V8.60665C42.8559 8.09332 43.3601 7.82748 43.8825 7.82748H44.9917V8.60665H43.8184C43.0851 8.60665 42.5625 9.08331 42.5625 10.0092V12.4475H41.7284Z" fill="var(--apkt-tokens-theme-textPrimary)"/>
</svg>

`,hy=pe`
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 8">
    <path
      fill="var(--apkt-tokens-theme-textPrimary)"
      d="m9.524 6.307-1.51 1.584A.35.35 0 0 1 7.76 8H.604a.178.178 0 0 1-.161-.103.168.168 0 0 1 .033-.186l1.51-1.583a.35.35 0 0 1 .256-.11h7.154c.034 0 .068.01.096.029a.168.168 0 0 1 .032.26Zm-1.51-3.189a.35.35 0 0 0-.255-.109H.604a.178.178 0 0 0-.161.103.168.168 0 0 0 .033.186l1.51 1.583a.35.35 0 0 0 .256.11h7.154a.178.178 0 0 0 .16-.104.168.168 0 0 0-.032-.185l-1.51-1.584ZM.605 1.981H7.76a.357.357 0 0 0 .256-.11L9.525.289a.17.17 0 0 0 .032-.185.173.173 0 0 0-.16-.103H2.241a.357.357 0 0 0-.256.109L.476 1.692a.17.17 0 0 0-.033.185.178.178 0 0 0 .16.103Z"
    />
  </svg>
`,py=pe`<svg width="32" height="32" fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
  <g clip-path="url(#a)">
    <path fill="url(#b)" d="M0 0h32v32H0z"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M7.034 15.252c4.975-2.167 8.293-3.596 9.953-4.287 4.74-1.971 5.725-2.314 6.366-2.325.142-.002.457.033.662.198.172.14.22.33.243.463.022.132.05.435.028.671-.257 2.7-1.368 9.248-1.933 12.27-.24 1.28-.71 1.708-1.167 1.75-.99.091-1.743-.655-2.703-1.284-1.502-.985-2.351-1.598-3.81-2.558-1.684-1.11-.592-1.721.368-2.718.252-.261 4.619-4.233 4.703-4.594.01-.045.02-.213-.08-.301-.1-.09-.246-.059-.353-.035-.15.034-2.55 1.62-7.198 4.758-.682.468-1.298.696-1.851.684-.61-.013-1.782-.344-2.653-.628-1.069-.347-1.918-.53-1.845-1.12.039-.308.462-.623 1.27-.944Z" fill="#fff"/>
  </g>
  <path d="M.5 16C.5 7.44 7.44.5 16 .5 24.56.5 31.5 7.44 31.5 16c0 8.56-6.94 15.5-15.5 15.5C7.44 31.5.5 24.56.5 16Z" stroke="#141414" stroke-opacity=".05"/>
  <defs>
    <linearGradient id="b" x1="1600" y1="0" x2="1600" y2="3176.27" gradientUnits="userSpaceOnUse">
      <stop stop-color="#2AABEE"/>
      <stop offset="1" stop-color="#229ED9"/>
    </linearGradient>
    <clipPath id="a">
      <path d="M0 16C0 7.163 7.163 0 16 0s16 7.163 16 16-7.163 16-16 16S0 24.837 0 16Z" fill="#fff"/>
    </clipPath>
  </defs>
</svg>`,bf=pe`
  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 10 10">
  <path d="M8.37651 0H1.62309C0.381381 0 -0.405611 1.33944 0.219059 2.42225L4.38701 9.64649C4.659 10.1182 5.3406 10.1182 5.61259 9.64649L9.78139 2.42225C10.4052 1.34117 9.61822 0 8.37736 0H8.37651ZM4.38362 7.48005L3.47591 5.72329L1.2857 1.80606C1.14121 1.55534 1.31968 1.23405 1.62225 1.23405H4.38278V7.4809L4.38362 7.48005ZM8.71221 1.80521L6.52284 5.72414L5.61513 7.48005V1.2332H8.37566C8.67823 1.2332 8.85669 1.55449 8.71221 1.80521Z" fill="var(--apkt-tokens-theme-textPrimary)" />
</svg>
`,fy=pe`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#5A3E85" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M18.22 25.7 20 23.91h3.34l2.1-2.1v-6.68H15.4v8.78h2.82v1.77Zm3.87-8.16h1.25v3.66H22.1v-3.66Zm-3.34 0H20v3.66h-1.25v-3.66ZM20 7.9a12 12 0 1 0 0 24 12 12 0 0 0 0-24Zm6.69 14.56-3.66 3.66h-2.72l-1.77 1.78h-1.88V26.1H13.3v-9.82l.94-2.4H26.7v8.56Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`,my=pe`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    d="m14.36 4.74.01.42c0 4.34-3.3 9.34-9.34 9.34A9.3 9.3 0 0 1 0 13.03a6.6 6.6 0 0 0 4.86-1.36 3.29 3.29 0 0 1-3.07-2.28c.5.1 1 .07 1.48-.06A3.28 3.28 0 0 1 .64 6.11v-.04c.46.26.97.4 1.49.41A3.29 3.29 0 0 1 1.11 2.1a9.32 9.32 0 0 0 6.77 3.43 3.28 3.28 0 0 1 5.6-3 6.59 6.59 0 0 0 2.08-.8 3.3 3.3 0 0 1-1.45 1.82A6.53 6.53 0 0 0 16 3.04c-.44.66-1 1.23-1.64 1.7Z"
  />
</svg>`,gy=pe`
<svg xmlns="http://www.w3.org/2000/svg" width="89" height="89" viewBox="0 0 89 89" fill="none">
<path d="M60.0468 39.2502L65.9116 33.3854C52.6562 20.13 36.1858 20.13 22.9304 33.3854L28.7952 39.2502C38.8764 29.169 49.9725 29.169 60.0536 39.2502H60.0468Z" fill="var(--apkt-tokens-theme-textPrimary)"/>
<path d="M58.0927 52.9146L44.415 39.2369L30.7373 52.9146L17.0596 39.2369L11.2017 45.0949L30.7373 64.6374L44.415 50.9597L58.0927 64.6374L77.6284 45.0949L71.7704 39.2369L58.0927 52.9146Z" fill="var(--apkt-tokens-theme-textPrimary)"/>
</svg>`,wy=pe`
<svg xmlns="http://www.w3.org/2000/svg" width="89" height="89" viewBox="0 0 89 89" fill="none">
<path d="M60.0468 39.2502L65.9116 33.3854C52.6562 20.13 36.1858 20.13 22.9304 33.3854L28.7952 39.2502C38.8764 29.169 49.9725 29.169 60.0536 39.2502H60.0468Z" fill="var(--apkt-tokens-theme-textInvert)"/>
<path d="M58.0927 52.9146L44.415 39.2369L30.7373 52.9146L17.0596 39.2369L11.2017 45.0949L30.7373 64.6374L44.415 50.9597L58.0927 64.6374L77.6284 45.0949L71.7704 39.2369L58.0927 52.9146Z" fill="var(--apkt-tokens-theme-textInvert)"/>
</svg>`,by=pe`
<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_22274_4692)">
<path d="M0 6.64C0 4.17295 0 2.93942 0.525474 2.01817C0.880399 1.39592 1.39592 0.880399 2.01817 0.525474C2.93942 0 4.17295 0 6.64 0H9.36C11.8271 0 13.0606 0 13.9818 0.525474C14.6041 0.880399 15.1196 1.39592 15.4745 2.01817C16 2.93942 16 4.17295 16 6.64V9.36C16 11.8271 16 13.0606 15.4745 13.9818C15.1196 14.6041 14.6041 15.1196 13.9818 15.4745C13.0606 16 11.8271 16 9.36 16H6.64C4.17295 16 2.93942 16 2.01817 15.4745C1.39592 15.1196 0.880399 14.6041 0.525474 13.9818C0 13.0606 0 11.8271 0 9.36V6.64Z" fill="#C7B994"/>
<path d="M4.49038 5.76609C6.42869 3.86833 9.5713 3.86833 11.5096 5.76609L11.7429 5.99449C11.8398 6.08938 11.8398 6.24323 11.7429 6.33811L10.9449 7.11942C10.8964 7.16686 10.8179 7.16686 10.7694 7.11942L10.4484 6.80512C9.09617 5.48119 6.90381 5.48119 5.5516 6.80512L5.20782 7.14171C5.15936 7.18915 5.08079 7.18915 5.03234 7.14171L4.23434 6.3604C4.13742 6.26552 4.13742 6.11167 4.23434 6.01678L4.49038 5.76609ZM13.1599 7.38192L13.8702 8.07729C13.9671 8.17217 13.9671 8.32602 13.8702 8.4209L10.6677 11.5564C10.5708 11.6513 10.4137 11.6513 10.3168 11.5564L8.04388 9.33105C8.01965 9.30733 7.98037 9.30733 7.95614 9.33105L5.6833 11.5564C5.58638 11.6513 5.42925 11.6513 5.33234 11.5564L2.12982 8.42087C2.0329 8.32598 2.0329 8.17213 2.12982 8.07724L2.84004 7.38188C2.93695 7.28699 3.09408 7.28699 3.191 7.38188L5.46392 9.60726C5.48815 9.63098 5.52743 9.63098 5.55166 9.60726L7.82447 7.38188C7.92138 7.28699 8.07851 7.28699 8.17543 7.38187L10.4484 9.60726C10.4726 9.63098 10.5119 9.63098 10.5361 9.60726L12.809 7.38192C12.9059 7.28703 13.063 7.28703 13.1599 7.38192Z" fill="currentColor"/>
</g>
<defs>
<clipPath id="clip0_22274_4692">
<path d="M0 8C0 3.58172 3.58172 0 8 0C12.4183 0 16 3.58172 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8Z" fill="white"/>
</clipPath>
</defs>
</svg>
`,yy=pe`
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="11" cy="11" r="11" transform="matrix(-1 0 0 1 23 1)" fill="#202020"/>
<circle cx="11" cy="11" r="11.5" transform="matrix(-1 0 0 1 23 1)" stroke="#C7B994" stroke-opacity="0.7"/>
<path d="M15.4523 11.0686L16.7472 9.78167C13.8205 6.87297 10.1838 6.87297 7.25708 9.78167L8.55201 11.0686C10.7779 8.85645 13.2279 8.85645 15.4538 11.0686H15.4523Z" fill="#C7B994"/>
<path d="M15.0199 14.067L12 11.0656L8.98 14.067L5.96004 11.0656L4.66663 12.3511L8.98 16.6393L12 13.638L15.0199 16.6393L19.3333 12.3511L18.0399 11.0656L15.0199 14.067Z" fill="#C7B994"/>
</svg>
`,Eh=pe`<svg fill="none" viewBox="0 0 41 40">
  <g clip-path="url(#a)">
    <path fill="#000" d="M.8 0h40v40H.8z" />
    <path
      fill="#fff"
      d="m22.63 18.46 7.14-8.3h-1.69l-6.2 7.2-4.96-7.2H11.2l7.5 10.9-7.5 8.71h1.7l6.55-7.61 5.23 7.61h5.72l-7.77-11.31Zm-9.13-7.03h2.6l11.98 17.13h-2.6L13.5 11.43Z"
    />
  </g>
  <defs>
    <clipPath id="a"><path fill="#fff" d="M.8 20a20 20 0 1 1 40 0 20 20 0 0 1-40 0Z" /></clipPath>
  </defs>
</svg>`,Cy=Nt`
  :host {
    display: flex;
    justify-content: center;
    align-items: center;
    aspect-ratio: 1 / 1;
    color: var(--local-color);
    width: var(--local-width);
  }

  svg {
    height: inherit;
    width: inherit;
    object-fit: contain;
    object-position: center;
  }
`;var js=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const vy={add:"ph-plus",allWallets:"ph-dots-three",arrowBottom:"ph-arrow-down",arrowBottomCircle:"ph-arrow-circle-down",arrowClockWise:"ph-arrow-clockwise",arrowLeft:"ph-arrow-left",arrowRight:"ph-arrow-right",arrowTop:"ph-arrow-up",arrowTopRight:"ph-arrow-up-right",bank:"ph-bank",bin:"ph-trash",browser:"ph-browser",card:"ph-credit-card",checkmark:"ph-check",checkmarkBold:"ph-check",chevronBottom:"ph-caret-down",chevronLeft:"ph-caret-left",chevronRight:"ph-caret-right",chevronTop:"ph-caret-up",clock:"ph-clock",close:"ph-x",coinPlaceholder:"ph-circle-half",compass:"ph-compass",copy:"ph-copy",desktop:"ph-desktop",dollar:"ph-currency-dollar",download:"ph-vault",exclamationCircle:"ph-warning-circle",extension:"ph-puzzle-piece",externalLink:"ph-arrow-square-out",filters:"ph-funnel-simple",helpCircle:"ph-question",id:"ph-identification-card",image:"ph-image",info:"ph-info",lightbulb:"ph-lightbulb",mail:"ph-envelope",mobile:"ph-device-mobile",more:"ph-dots-three",networkPlaceholder:"ph-globe",nftPlaceholder:"ph-image",plus:"ph-plus",power:"ph-power",qrCode:"ph-qr-code",questionMark:"ph-question",refresh:"ph-arrow-clockwise",recycleHorizontal:"ph-arrows-clockwise",search:"ph-magnifying-glass",sealCheck:"ph-seal-check",send:"ph-paper-plane-right",signOut:"ph-sign-out",spinner:"ph-spinner",swapHorizontal:"ph-arrows-left-right",swapVertical:"ph-arrows-down-up",threeDots:"ph-dots-three",user:"ph-user",verify:"ph-seal-check",verifyFilled:"ph-seal-check",wallet:"ph-wallet",warning:"ph-warning",warningCircle:"ph-warning-circle",appStore:"",apple:"",bitcoin:"",coins:"",chromeStore:"",cursor:"",discord:"",ethereum:"",etherscan:"",facebook:"",farcaster:"",github:"",google:"",playStore:"",paperPlaneTitle:"",reown:"",solana:"",ton:"",telegram:"",twitch:"",twitterIcon:"",twitter:"",walletConnect:"",walletConnectBrown:"",walletConnectLightBrown:"",x:"",infoSeal:""},Ey={"ph-arrow-circle-down":()=>me(()=>import("./PhArrowCircleDown.DpTlEmjn.js"),__vite__mapDeps([4,5])),"ph-arrow-clockwise":()=>me(()=>import("./PhArrowClockwise.DU2_XBhG.js"),__vite__mapDeps([6,5])),"ph-arrow-down":()=>me(()=>import("./PhArrowDown.BbOcQoFa.js"),__vite__mapDeps([7,5])),"ph-arrow-left":()=>me(()=>import("./PhArrowLeft.C0hwOvkE.js"),__vite__mapDeps([8,5])),"ph-arrow-right":()=>me(()=>import("./PhArrowRight.B3N_MsWO.js"),__vite__mapDeps([9,5])),"ph-arrow-square-out":()=>me(()=>import("./PhArrowSquareOut.CFK5dEhN.js"),__vite__mapDeps([10,5])),"ph-arrows-down-up":()=>me(()=>import("./PhArrowsDownUp.N2PvwKLd.js"),__vite__mapDeps([11,5])),"ph-arrows-left-right":()=>me(()=>import("./PhArrowsLeftRight.Cc-F68gA.js"),__vite__mapDeps([12,5])),"ph-arrow-up":()=>me(()=>import("./PhArrowUp.SN6CI-jL.js"),__vite__mapDeps([13,5])),"ph-arrow-up-right":()=>me(()=>import("./PhArrowUpRight.BnS67Kzh.js"),__vite__mapDeps([14,5])),"ph-arrows-clockwise":()=>me(()=>import("./PhArrowsClockwise.yF9hERLY.js"),__vite__mapDeps([15,5])),"ph-bank":()=>me(()=>import("./PhBank.BMnogOUG.js"),__vite__mapDeps([16,5])),"ph-browser":()=>me(()=>import("./PhBrowser.gW-agjVt.js"),__vite__mapDeps([17,5])),"ph-caret-down":()=>me(()=>import("./PhCaretDown.BtyvyF9R.js"),__vite__mapDeps([18,5])),"ph-caret-left":()=>me(()=>import("./PhCaretLeft.CdQcRrju.js"),__vite__mapDeps([19,5])),"ph-caret-right":()=>me(()=>import("./PhCaretRight.BiYkkFoB.js"),__vite__mapDeps([20,5])),"ph-caret-up":()=>me(()=>import("./PhCaretUp.Dyjid-5C.js"),__vite__mapDeps([21,5])),"ph-check":()=>me(()=>import("./PhCheck.DlYt6a6X.js"),__vite__mapDeps([22,5])),"ph-circle-half":()=>me(()=>import("./PhCircleHalf.CuKM9E54.js"),__vite__mapDeps([23,5])),"ph-clock":()=>me(()=>import("./PhClock.CfY33k15.js"),__vite__mapDeps([24,5])),"ph-compass":()=>me(()=>import("./PhCompass.q1sqZw0y.js"),__vite__mapDeps([25,5])),"ph-copy":()=>me(()=>import("./PhCopy.ChWE7L-X.js"),__vite__mapDeps([26,5])),"ph-credit-card":()=>me(()=>import("./PhCreditCard.Cs2VF4ME.js"),__vite__mapDeps([27,5])),"ph-currency-dollar":()=>me(()=>import("./PhCurrencyDollar.BetClcFM.js"),__vite__mapDeps([28,5])),"ph-desktop":()=>me(()=>import("./PhDesktop.DZ44q8KV.js"),__vite__mapDeps([29,5])),"ph-device-mobile":()=>me(()=>import("./PhDeviceMobile.BYTsoJFv.js"),__vite__mapDeps([30,5])),"ph-dots-three":()=>me(()=>import("./PhDotsThree.CZl-eiZJ.js"),__vite__mapDeps([31,5])),"ph-vault":()=>me(()=>import("./PhVault.CVlykDI9.js"),__vite__mapDeps([32,5])),"ph-envelope":()=>me(()=>import("./PhEnvelope.DffTKA6H.js"),__vite__mapDeps([33,5])),"ph-funnel-simple":()=>me(()=>import("./PhFunnelSimple.BgL9D_9c.js"),__vite__mapDeps([34,5])),"ph-globe":()=>me(()=>import("./PhGlobe.Bu5QHqxs.js"),__vite__mapDeps([35,5])),"ph-identification-card":()=>me(()=>import("./PhIdentificationCard.BmdwlhZM.js"),__vite__mapDeps([36,5])),"ph-image":()=>me(()=>import("./PhImage.Cw1zzbVt.js"),__vite__mapDeps([37,5])),"ph-info":()=>me(()=>import("./PhInfo.DWWHh28B.js"),__vite__mapDeps([38,5])),"ph-lightbulb":()=>me(()=>import("./PhLightbulb.B88rUY5q.js"),__vite__mapDeps([39,5])),"ph-magnifying-glass":()=>me(()=>import("./PhMagnifyingGlass.Xl-MBUds.js"),__vite__mapDeps([40,5])),"ph-paper-plane-right":()=>me(()=>import("./PhPaperPlaneRight.CeWoaYLA.js"),__vite__mapDeps([41,5])),"ph-plus":()=>me(()=>import("./PhPlus.BOh0VIBX.js"),__vite__mapDeps([42,5])),"ph-power":()=>me(()=>import("./PhPower.CFW3N-Js.js"),__vite__mapDeps([43,5])),"ph-puzzle-piece":()=>me(()=>import("./PhPuzzlePiece.D9Tojhi5.js"),__vite__mapDeps([44,5])),"ph-qr-code":()=>me(()=>import("./PhQrCode.Ccd2EEMd.js"),__vite__mapDeps([45,5])),"ph-question":()=>me(()=>import("./PhQuestion.BkXZv5hE.js"),__vite__mapDeps([46,5])),"ph-question-circle":()=>me(()=>import("./PhQuestionMark.CeXm2EQz.js"),__vite__mapDeps([47,5])),"ph-seal-check":()=>me(()=>import("./PhSealCheck.D9d9Qyuj.js"),__vite__mapDeps([48,5])),"ph-sign-out":()=>me(()=>import("./PhSignOut.CD7kynsO.js"),__vite__mapDeps([49,5])),"ph-spinner":()=>me(()=>import("./PhSpinner.m0odOB7o.js"),__vite__mapDeps([50,5])),"ph-trash":()=>me(()=>import("./PhTrash.HCBZ7UKb.js"),__vite__mapDeps([51,5])),"ph-user":()=>me(()=>import("./PhUser.X51TxfNz.js"),__vite__mapDeps([52,5])),"ph-wallet":()=>me(()=>import("./PhWallet.Dw50jz15.js"),__vite__mapDeps([53,5])),"ph-warning":()=>me(()=>import("./PhWarning.CCjNwBAf.js"),__vite__mapDeps([54,5])),"ph-warning-circle":()=>me(()=>import("./PhWarningCircle.CXrpBVHt.js"),__vite__mapDeps([55,5])),"ph-x":()=>me(()=>import("./PhX.CF9mDFKD.js"),__vite__mapDeps([56,5]))},_y={appStore:Zb,apple:Yb,bitcoin:Jb,coins:Qb,chromeStore:Xb,cursor:ey,discord:ty,ethereum:ny,etherscan:ry,facebook:iy,farcaster:oy,github:sy,google:ay,playStore:dy,paperPlaneTitle:ly,reown:uy,solana:hy,ton:bf,telegram:py,twitch:fy,twitter:Eh,twitterIcon:my,walletConnect:gy,walletConnectInvert:wy,walletConnectBrown:yy,walletConnectLightBrown:by,x:Eh,infoSeal:cy},Ay={"accent-primary":Ke.tokens.core.iconAccentPrimary,"accent-certified":Ke.tokens.core.iconAccentCertified,"foreground-secondary":Ke.tokens.theme.foregroundSecondary,default:Ke.tokens.theme.iconDefault,success:Ke.tokens.core.iconSuccess,error:Ke.tokens.core.iconError,warning:Ke.tokens.core.iconWarning,inverse:Ke.tokens.theme.iconInverse};let ti=class extends de{constructor(){super(...arguments),this.size="md",this.name="copy",this.weight="bold",this.color="inherit"}render(){const t={xxs:"2",xs:"3",sm:"3",md:"4",mdl:"5",lg:"5",xl:"6",xxl:"7",inherit:"inherit"};this.style.cssText=`
      --local-width: ${this.size==="inherit"?"inherit":`var(--apkt-spacing-${t[this.size]})`};
      --local-color: ${this.color==="inherit"?"inherit":Ay[this.color]}
    `;const n=vy[this.name];if(n&&n!==""){const r=Ey[n];r&&r();const o=Kb(n);return vh`<${o} size=${{xxs:"0.5em",xs:"0.75em",sm:"0.75em",md:"1em",mdl:"1.25em",lg:"1.25em",xl:"1.5em",xxl:"1.75em"}[this.size]} weight="${this.weight}"></${o}>`}return _y[this.name]||vh``}};ti.styles=[we,Cy];js([m()],ti.prototype,"size",void 0);js([m()],ti.prototype,"name",void 0);js([m()],ti.prototype,"weight",void 0);js([m()],ti.prototype,"color",void 0);ti=js([M("wui-icon")],ti);const xy=Q`
  :host {
    display: block;
    width: var(--local-width);
    height: var(--local-height);
  }

  img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
    border-radius: inherit;
    user-select: none;
    user-drag: none;
    -webkit-user-drag: none;
    -khtml-user-drag: none;
    -moz-user-drag: none;
    -o-user-drag: none;
  }

  :host([data-boxed='true']) {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  :host([data-boxed='true']) img {
    width: 20px;
    height: 20px;
    border-radius: ${({borderRadius:e})=>e[16]};
  }

  :host([data-full='true']) img {
    width: 100%;
    height: 100%;
  }

  :host([data-boxed='true']) wui-icon {
    width: 20px;
    height: 20px;
  }

  :host([data-icon='error']) {
    background-color: ${({tokens:e})=>e.core.backgroundError};
  }

  :host([data-rounded='true']) {
    border-radius: ${({borderRadius:e})=>e[16]};
  }
`;var Mn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Qt=class extends de{constructor(){super(...arguments),this.src="./path/to/image.jpg",this.alt="Image",this.size=void 0,this.boxed=!1,this.rounded=!1,this.fullSize=!1}render(){const t={inherit:"inherit",xxs:"2",xs:"3",sm:"4",md:"4",mdl:"5",lg:"5",xl:"6",xxl:"7","3xl":"8","4xl":"9","5xl":"10"};return this.style.cssText=`
      --local-width: ${this.size?`var(--apkt-spacing-${t[this.size]});`:"100%"};
      --local-height: ${this.size?`var(--apkt-spacing-${t[this.size]});`:"100%"};
      `,this.dataset.boxed=this.boxed?"true":"false",this.dataset.rounded=this.rounded?"true":"false",this.dataset.full=this.fullSize?"true":"false",this.dataset.icon=this.iconColor||"inherit",this.icon?x`<wui-icon
        color=${this.iconColor||"inherit"}
        name=${this.icon}
        size="lg"
      ></wui-icon> `:this.logo?x`<wui-icon size="lg" color="inherit" name=${this.logo}></wui-icon> `:x`<img src=${Qe(this.src)} alt=${this.alt} @error=${this.handleImageError} />`}handleImageError(){this.dispatchEvent(new CustomEvent("onLoadError",{bubbles:!0,composed:!0}))}};Qt.styles=[we,xy];Mn([m()],Qt.prototype,"src",void 0);Mn([m()],Qt.prototype,"logo",void 0);Mn([m()],Qt.prototype,"icon",void 0);Mn([m()],Qt.prototype,"iconColor",void 0);Mn([m()],Qt.prototype,"alt",void 0);Mn([m()],Qt.prototype,"size",void 0);Mn([m({type:Boolean})],Qt.prototype,"boxed",void 0);Mn([m({type:Boolean})],Qt.prototype,"rounded",void 0);Mn([m({type:Boolean})],Qt.prototype,"fullSize",void 0);Qt=Mn([M("wui-image")],Qt);const Sy=Nt`
  :host {
    display: flex;
  }

  :host([data-size='sm']) > svg {
    width: 12px;
    height: 12px;
  }

  :host([data-size='md']) > svg {
    width: 16px;
    height: 16px;
  }

  :host([data-size='lg']) > svg {
    width: 24px;
    height: 24px;
  }

  :host([data-size='xl']) > svg {
    width: 32px;
    height: 32px;
  }

  svg {
    animation: rotate 1.4s linear infinite;
    color: var(--local-color);
  }

  :host([data-size='md']) > svg > circle {
    stroke-width: 6px;
  }

  :host([data-size='sm']) > svg > circle {
    stroke-width: 8px;
  }

  @keyframes rotate {
    100% {
      transform: rotate(360deg);
    }
  }
`;var Kd=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ss=class extends de{constructor(){super(...arguments),this.color="primary",this.size="lg"}render(){const t={primary:Ke.tokens.theme.textPrimary,secondary:Ke.tokens.theme.textSecondary,tertiary:Ke.tokens.theme.textTertiary,invert:Ke.tokens.theme.textInvert,error:Ke.tokens.core.textError,warning:Ke.tokens.core.textWarning,"accent-primary":Ke.tokens.core.textAccentPrimary};return this.style.cssText=`
      --local-color: ${this.color==="inherit"?"inherit":t[this.color]};
      `,this.dataset.size=this.size,x`<svg viewBox="0 0 16 17" fill="none">
      <path
        d="M8.75 2.65625V4.65625C8.75 4.85516 8.67098 5.04593 8.53033 5.18658C8.38968 5.32723 8.19891 5.40625 8 5.40625C7.80109 5.40625 7.61032 5.32723 7.46967 5.18658C7.32902 5.04593 7.25 4.85516 7.25 4.65625V2.65625C7.25 2.45734 7.32902 2.26657 7.46967 2.12592C7.61032 1.98527 7.80109 1.90625 8 1.90625C8.19891 1.90625 8.38968 1.98527 8.53033 2.12592C8.67098 2.26657 8.75 2.45734 8.75 2.65625ZM14 7.90625H12C11.8011 7.90625 11.6103 7.98527 11.4697 8.12592C11.329 8.26657 11.25 8.45734 11.25 8.65625C11.25 8.85516 11.329 9.04593 11.4697 9.18658C11.6103 9.32723 11.8011 9.40625 12 9.40625H14C14.1989 9.40625 14.3897 9.32723 14.5303 9.18658C14.671 9.04593 14.75 8.85516 14.75 8.65625C14.75 8.45734 14.671 8.26657 14.5303 8.12592C14.3897 7.98527 14.1989 7.90625 14 7.90625ZM11.3588 10.9544C11.289 10.8846 11.2062 10.8293 11.115 10.7915C11.0239 10.7538 10.9262 10.7343 10.8275 10.7343C10.7288 10.7343 10.6311 10.7538 10.54 10.7915C10.4488 10.8293 10.366 10.8846 10.2963 10.9544C10.2265 11.0241 10.1711 11.107 10.1334 11.1981C10.0956 11.2893 10.0762 11.387 10.0762 11.4856C10.0762 11.5843 10.0956 11.682 10.1334 11.7731C10.1711 11.8643 10.2265 11.9471 10.2963 12.0169L11.7106 13.4312C11.8515 13.5721 12.0426 13.6513 12.2419 13.6513C12.4411 13.6513 12.6322 13.5721 12.7731 13.4312C12.914 13.2904 12.9932 13.0993 12.9932 12.9C12.9932 12.7007 12.914 12.5096 12.7731 12.3687L11.3588 10.9544ZM8 11.9062C7.80109 11.9062 7.61032 11.9853 7.46967 12.1259C7.32902 12.2666 7.25 12.4573 7.25 12.6562V14.6562C7.25 14.8552 7.32902 15.0459 7.46967 15.1866C7.61032 15.3272 7.80109 15.4062 8 15.4062C8.19891 15.4062 8.38968 15.3272 8.53033 15.1866C8.67098 15.0459 8.75 14.8552 8.75 14.6562V12.6562C8.75 12.4573 8.67098 12.2666 8.53033 12.1259C8.38968 11.9853 8.19891 11.9062 8 11.9062ZM4.64125 10.9544L3.22688 12.3687C3.08598 12.5096 3.00682 12.7007 3.00682 12.9C3.00682 13.0993 3.08598 13.2904 3.22688 13.4312C3.36777 13.5721 3.55887 13.6513 3.75813 13.6513C3.95738 13.6513 4.14848 13.5721 4.28937 13.4312L5.70375 12.0169C5.84465 11.876 5.9238 11.6849 5.9238 11.4856C5.9238 11.2864 5.84465 11.0953 5.70375 10.9544C5.56285 10.8135 5.37176 10.7343 5.1725 10.7343C4.97324 10.7343 4.78215 10.8135 4.64125 10.9544ZM4.75 8.65625C4.75 8.45734 4.67098 8.26657 4.53033 8.12592C4.38968 7.98527 4.19891 7.90625 4 7.90625H2C1.80109 7.90625 1.61032 7.98527 1.46967 8.12592C1.32902 8.26657 1.25 8.45734 1.25 8.65625C1.25 8.85516 1.32902 9.04593 1.46967 9.18658C1.61032 9.32723 1.80109 9.40625 2 9.40625H4C4.19891 9.40625 4.38968 9.32723 4.53033 9.18658C4.67098 9.04593 4.75 8.85516 4.75 8.65625ZM4.2875 3.88313C4.1466 3.74223 3.95551 3.66307 3.75625 3.66307C3.55699 3.66307 3.3659 3.74223 3.225 3.88313C3.0841 4.02402 3.00495 4.21512 3.00495 4.41438C3.00495 4.61363 3.0841 4.80473 3.225 4.94562L4.64125 6.35813C4.78215 6.49902 4.97324 6.57818 5.1725 6.57818C5.37176 6.57818 5.56285 6.49902 5.70375 6.35813C5.84465 6.21723 5.9238 6.02613 5.9238 5.82688C5.9238 5.62762 5.84465 5.43652 5.70375 5.29563L4.2875 3.88313Z"
        fill="currentColor"
      />
    </svg>`}};Ss.styles=[we,Sy];Kd([m()],Ss.prototype,"color",void 0);Kd([m()],Ss.prototype,"size",void 0);Ss=Kd([M("wui-loading-spinner")],Ss);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const yf={ATTRIBUTE:1,CHILD:2},Cf=e=>(...t)=>({_$litDirective$:e,values:t});let vf=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,n,r){this._$Ct=t,this._$AM=n,this._$Ci=r}_$AS(t,n){return this.update(t,n)}update(t,n){return this.render(...n)}};/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ty=Cf(class extends vf{constructor(e){if(super(e),e.type!==yf.ATTRIBUTE||e.name!=="class"||e.strings?.length>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(e){return" "+Object.keys(e).filter(t=>e[t]).join(" ")+" "}update(e,[t]){if(this.st===void 0){this.st=new Set,e.strings!==void 0&&(this.nt=new Set(e.strings.join(" ").split(/\s/).filter(r=>r!=="")));for(const r in t)t[r]&&!this.nt?.has(r)&&this.st.add(r);return this.render(t)}const n=e.element.classList;for(const r of this.st)r in t||(n.remove(r),this.st.delete(r));for(const r in t){const o=!!t[r];o===this.st.has(r)||this.nt?.has(r)||(o?(n.add(r),this.st.add(r)):(n.remove(r),this.st.delete(r)))}return Xr}}),$y=Q`
  slot {
    width: 100%;
    display: inline-block;
    font-style: normal;
    overflow: inherit;
    text-overflow: inherit;
    text-align: var(--local-align);
    color: var(--local-color);
  }

  .wui-line-clamp-1 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }

  .wui-line-clamp-2 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  /* -- Headings --------------------------------------------------- */
  .wui-font-h1-regular-mono {
    font-size: ${({textSize:e})=>e.h1};
    line-height: ${({typography:e})=>e["h1-regular-mono"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h1-regular-mono"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.mono};
  }

  .wui-font-h1-regular {
    font-size: ${({textSize:e})=>e.h1};
    line-height: ${({typography:e})=>e["h1-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h1-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h1-medium {
    font-size: ${({textSize:e})=>e.h1};
    line-height: ${({typography:e})=>e["h1-medium"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h1-medium"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.medium};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h2-regular-mono {
    font-size: ${({textSize:e})=>e.h2};
    line-height: ${({typography:e})=>e["h2-regular-mono"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h2-regular-mono"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.mono};
  }

  .wui-font-h2-regular {
    font-size: ${({textSize:e})=>e.h2};
    line-height: ${({typography:e})=>e["h2-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h2-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h2-medium {
    font-size: ${({textSize:e})=>e.h2};
    line-height: ${({typography:e})=>e["h2-medium"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h2-medium"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.medium};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h3-regular-mono {
    font-size: ${({textSize:e})=>e.h3};
    line-height: ${({typography:e})=>e["h3-regular-mono"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h3-regular-mono"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.mono};
  }

  .wui-font-h3-regular {
    font-size: ${({textSize:e})=>e.h3};
    line-height: ${({typography:e})=>e["h3-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h3-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h3-medium {
    font-size: ${({textSize:e})=>e.h3};
    line-height: ${({typography:e})=>e["h3-medium"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h3-medium"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.medium};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h4-regular-mono {
    font-size: ${({textSize:e})=>e.h4};
    line-height: ${({typography:e})=>e["h4-regular-mono"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h4-regular-mono"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.mono};
  }

  .wui-font-h4-regular {
    font-size: ${({textSize:e})=>e.h4};
    line-height: ${({typography:e})=>e["h4-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h4-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h4-medium {
    font-size: ${({textSize:e})=>e.h4};
    line-height: ${({typography:e})=>e["h4-medium"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h4-medium"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.medium};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h5-regular-mono {
    font-size: ${({textSize:e})=>e.h5};
    line-height: ${({typography:e})=>e["h5-regular-mono"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h5-regular-mono"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.mono};
  }

  .wui-font-h5-regular {
    font-size: ${({textSize:e})=>e.h5};
    line-height: ${({typography:e})=>e["h5-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h5-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h5-medium {
    font-size: ${({textSize:e})=>e.h5};
    line-height: ${({typography:e})=>e["h5-medium"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h5-medium"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.medium};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h6-regular-mono {
    font-size: ${({textSize:e})=>e.h6};
    line-height: ${({typography:e})=>e["h6-regular-mono"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h6-regular-mono"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.mono};
  }

  .wui-font-h6-regular {
    font-size: ${({textSize:e})=>e.h6};
    line-height: ${({typography:e})=>e["h6-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h6-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-h6-medium {
    font-size: ${({textSize:e})=>e.h6};
    line-height: ${({typography:e})=>e["h6-medium"].lineHeight};
    letter-spacing: ${({typography:e})=>e["h6-medium"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.medium};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-lg-regular-mono {
    font-size: ${({textSize:e})=>e.large};
    line-height: ${({typography:e})=>e["lg-regular-mono"].lineHeight};
    letter-spacing: ${({typography:e})=>e["lg-regular-mono"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.mono};
  }

  .wui-font-lg-regular {
    font-size: ${({textSize:e})=>e.large};
    line-height: ${({typography:e})=>e["lg-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["lg-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-lg-medium {
    font-size: ${({textSize:e})=>e.large};
    line-height: ${({typography:e})=>e["lg-medium"].lineHeight};
    letter-spacing: ${({typography:e})=>e["lg-medium"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.medium};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-md-regular-mono {
    font-size: ${({textSize:e})=>e.medium};
    line-height: ${({typography:e})=>e["md-regular-mono"].lineHeight};
    letter-spacing: ${({typography:e})=>e["md-regular-mono"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.mono};
  }

  .wui-font-md-regular {
    font-size: ${({textSize:e})=>e.medium};
    line-height: ${({typography:e})=>e["md-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["md-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-md-medium {
    font-size: ${({textSize:e})=>e.medium};
    line-height: ${({typography:e})=>e["md-medium"].lineHeight};
    letter-spacing: ${({typography:e})=>e["md-medium"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.medium};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-sm-regular-mono {
    font-size: ${({textSize:e})=>e.small};
    line-height: ${({typography:e})=>e["sm-regular-mono"].lineHeight};
    letter-spacing: ${({typography:e})=>e["sm-regular-mono"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.mono};
  }

  .wui-font-sm-regular {
    font-size: ${({textSize:e})=>e.small};
    line-height: ${({typography:e})=>e["sm-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["sm-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }

  .wui-font-sm-medium {
    font-size: ${({textSize:e})=>e.small};
    line-height: ${({typography:e})=>e["sm-medium"].lineHeight};
    letter-spacing: ${({typography:e})=>e["sm-medium"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.medium};
    font-family: ${({fontFamily:e})=>e.regular};
    font-feature-settings:
      'liga' off,
      'clig' off;
  }
`;var go=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const Ny={primary:Ke.tokens.theme.textPrimary,secondary:Ke.tokens.theme.textSecondary,tertiary:Ke.tokens.theme.textTertiary,invert:Ke.tokens.theme.textInvert,error:Ke.tokens.core.textError,success:Ke.tokens.core.textSuccess,warning:Ke.tokens.core.textWarning,"accent-primary":Ke.tokens.core.textAccentPrimary};let yr=class extends de{constructor(){super(...arguments),this.variant="md-regular",this.color="inherit",this.align="left",this.lineClamp=void 0,this.display="inline-flex"}render(){const t={[`wui-font-${this.variant}`]:!0,[`wui-line-clamp-${this.lineClamp}`]:!!this.lineClamp};return this.style.cssText=`
      display: ${this.display};
      --local-align: ${this.align};
      --local-color: ${this.color==="inherit"?"inherit":Ny[this.color??"primary"]};
      `,x`<slot class=${Ty(t)}></slot>`}};yr.styles=[we,$y];go([m()],yr.prototype,"variant",void 0);go([m()],yr.prototype,"color",void 0);go([m()],yr.prototype,"align",void 0);go([m()],yr.prototype,"lineClamp",void 0);go([m()],yr.prototype,"display",void 0);yr=go([M("wui-text")],yr);const Ry=Nt`
  :host {
    display: flex;
    width: inherit;
    height: inherit;
    box-sizing: border-box;
  }
`;var Lt=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let pt=class extends de{render(){return this.style.cssText=`
      flex-direction: ${this.flexDirection};
      flex-wrap: ${this.flexWrap};
      flex-basis: ${this.flexBasis};
      flex-grow: ${this.flexGrow};
      flex-shrink: ${this.flexShrink};
      align-items: ${this.alignItems};
      justify-content: ${this.justifyContent};
      column-gap: ${this.columnGap&&`var(--apkt-spacing-${this.columnGap})`};
      row-gap: ${this.rowGap&&`var(--apkt-spacing-${this.rowGap})`};
      gap: ${this.gap&&`var(--apkt-spacing-${this.gap})`};
      padding-top: ${this.padding&&Fe.getSpacingStyles(this.padding,0)};
      padding-right: ${this.padding&&Fe.getSpacingStyles(this.padding,1)};
      padding-bottom: ${this.padding&&Fe.getSpacingStyles(this.padding,2)};
      padding-left: ${this.padding&&Fe.getSpacingStyles(this.padding,3)};
      margin-top: ${this.margin&&Fe.getSpacingStyles(this.margin,0)};
      margin-right: ${this.margin&&Fe.getSpacingStyles(this.margin,1)};
      margin-bottom: ${this.margin&&Fe.getSpacingStyles(this.margin,2)};
      margin-left: ${this.margin&&Fe.getSpacingStyles(this.margin,3)};
      width: ${this.width};
    `,x`<slot></slot>`}};pt.styles=[we,Ry];Lt([m()],pt.prototype,"flexDirection",void 0);Lt([m()],pt.prototype,"flexWrap",void 0);Lt([m()],pt.prototype,"flexBasis",void 0);Lt([m()],pt.prototype,"flexGrow",void 0);Lt([m()],pt.prototype,"flexShrink",void 0);Lt([m()],pt.prototype,"alignItems",void 0);Lt([m()],pt.prototype,"justifyContent",void 0);Lt([m()],pt.prototype,"columnGap",void 0);Lt([m()],pt.prototype,"rowGap",void 0);Lt([m()],pt.prototype,"gap",void 0);Lt([m()],pt.prototype,"padding",void 0);Lt([m()],pt.prototype,"margin",void 0);Lt([m()],pt.prototype,"width",void 0);pt=Lt([M("wui-flex")],pt);const ky=Q`
  :host {
    display: block;
    width: var(--local-width);
    height: var(--local-height);
    border-radius: ${({borderRadius:e})=>e[16]};
    overflow: hidden;
    position: relative;
  }

  :host([data-variant='generated']) {
    --mixed-local-color-1: var(--local-color-1);
    --mixed-local-color-2: var(--local-color-2);
    --mixed-local-color-3: var(--local-color-3);
    --mixed-local-color-4: var(--local-color-4);
    --mixed-local-color-5: var(--local-color-5);
  }

  :host([data-variant='generated']) {
    background: radial-gradient(
      var(--local-radial-circle),
      #fff 0.52%,
      var(--mixed-local-color-5) 31.25%,
      var(--mixed-local-color-3) 51.56%,
      var(--mixed-local-color-2) 65.63%,
      var(--mixed-local-color-1) 82.29%,
      var(--mixed-local-color-4) 100%
    );
  }

  :host([data-variant='default']) {
    background: radial-gradient(
      75.29% 75.29% at 64.96% 24.36%,
      #fff 0.52%,
      #f5ccfc 31.25%,
      #dba4f5 51.56%,
      #9a8ee8 65.63%,
      #6493da 82.29%,
      #6ebdea 100%
    );
  }
`;var Fs=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ni=class extends de{constructor(){super(...arguments),this.imageSrc=void 0,this.alt=void 0,this.address=void 0,this.size="xl"}render(){const t={inherit:"inherit",xxs:"3",xs:"5",sm:"6",md:"8",mdl:"8",lg:"10",xl:"16",xxl:"20"};return this.style.cssText=`
    --local-width: var(--apkt-spacing-${t[this.size??"xl"]});
    --local-height: var(--apkt-spacing-${t[this.size??"xl"]});
    `,x`${this.visualTemplate()}`}visualTemplate(){if(this.imageSrc)return this.dataset.variant="image",x`<wui-image src=${this.imageSrc} alt=${this.alt??"avatar"}></wui-image>`;if(this.address){this.dataset.variant="generated";const t=Fe.generateAvatarColors(this.address);return this.style.cssText+=`
 ${t}`,null}return this.dataset.variant="default",null}};ni.styles=[we,ky];Fs([m()],ni.prototype,"imageSrc",void 0);Fs([m()],ni.prototype,"alt",void 0);Fs([m()],ni.prototype,"address",void 0);Fs([m()],ni.prototype,"size",void 0);ni=Fs([M("wui-avatar")],ni);const Iy=Q`
  :host {
    display: block;
  }

  button {
    border-radius: ${({borderRadius:e})=>e[20]};
    background: ${({tokens:e})=>e.theme.foregroundPrimary};
    display: flex;
    gap: ${({spacing:e})=>e[1]};
    padding: ${({spacing:e})=>e[1]};
    color: ${({tokens:e})=>e.theme.textSecondary};
    border-radius: ${({borderRadius:e})=>e[16]};
    height: 32px;
    transition: box-shadow ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: box-shadow;
  }

  button wui-flex.avatar-container {
    width: 28px;
    height: 24px;
    position: relative;

    wui-flex.network-image-container {
      position: absolute;
      bottom: 0px;
      right: 0px;
      width: 12px;
      height: 12px;
    }

    wui-flex.network-image-container wui-icon {
      background: ${({tokens:e})=>e.theme.foregroundPrimary};
    }

    wui-avatar {
      width: 24px;
      min-width: 24px;
      height: 24px;
    }

    wui-icon {
      width: 12px;
      height: 12px;
    }
  }

  wui-image,
  wui-icon {
    border-radius: ${({borderRadius:e})=>e[16]};
  }

  wui-text {
    white-space: nowrap;
  }

  button wui-flex.balance-container {
    height: 100%;
    border-radius: ${({borderRadius:e})=>e[16]};
    padding-left: ${({spacing:e})=>e[1]};
    padding-right: ${({spacing:e})=>e[1]};
    background: ${({tokens:e})=>e.theme.foregroundSecondary};
    color: ${({tokens:e})=>e.theme.textPrimary};
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
  }

  /* -- Hover & Active states ----------------------------------------------------------- */
  button:hover:enabled,
  button:focus-visible:enabled,
  button:active:enabled {
    box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.2);

    wui-flex.balance-container {
      background: ${({tokens:e})=>e.theme.foregroundTertiary};
    }
  }

  /* -- Disabled states --------------------------------------------------- */
  button:disabled wui-text,
  button:disabled wui-flex.avatar-container {
    opacity: 0.3;
  }
`;var wn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let jt=class extends de{constructor(){super(...arguments),this.networkSrc=void 0,this.avatarSrc=void 0,this.balance=void 0,this.isUnsupportedChain=void 0,this.disabled=!1,this.loading=!1,this.address="",this.profileName="",this.charsStart=4,this.charsEnd=6}render(){return x`
      <button
        ?disabled=${this.disabled}
        class=${Qe(this.balance?void 0:"local-no-balance")}
        data-error=${Qe(this.isUnsupportedChain)}
      >
        ${this.imageTemplate()} ${this.addressTemplate()} ${this.balanceTemplate()}
      </button>
    `}imageTemplate(){const t=this.networkSrc?x`<wui-image src=${this.networkSrc}></wui-image>`:x` <wui-icon size="inherit" color="inherit" name="networkPlaceholder"></wui-icon> `;return x`<wui-flex class="avatar-container">
      <wui-avatar
        .imageSrc=${this.avatarSrc}
        alt=${this.address}
        address=${this.address}
      ></wui-avatar>

      <wui-flex class="network-image-container">${t}</wui-flex>
    </wui-flex>`}addressTemplate(){return x`<wui-text variant="md-regular" color="inherit">
      ${this.address?Fe.getTruncateString({string:this.profileName||this.address,charsStart:this.profileName?18:this.charsStart,charsEnd:this.profileName?0:this.charsEnd,truncate:this.profileName?"end":"middle"}):null}
    </wui-text>`}balanceTemplate(){if(this.balance){const t=this.loading?x`<wui-loading-spinner size="md" color="inherit"></wui-loading-spinner>`:x`<wui-text variant="md-regular" color="inherit"> ${this.balance}</wui-text>`;return x`<wui-flex alignItems="center" justifyContent="center" class="balance-container"
        >${t}</wui-flex
      >`}return null}};jt.styles=[we,Be,Iy];wn([m()],jt.prototype,"networkSrc",void 0);wn([m()],jt.prototype,"avatarSrc",void 0);wn([m()],jt.prototype,"balance",void 0);wn([m({type:Boolean})],jt.prototype,"isUnsupportedChain",void 0);wn([m({type:Boolean})],jt.prototype,"disabled",void 0);wn([m({type:Boolean})],jt.prototype,"loading",void 0);wn([m()],jt.prototype,"address",void 0);wn([m()],jt.prototype,"profileName",void 0);wn([m()],jt.prototype,"charsStart",void 0);wn([m()],jt.prototype,"charsEnd",void 0);jt=wn([M("wui-account-button")],jt);var At=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};class xt extends he{constructor(){super(...arguments),this.unsubscribe=[],this.disabled=!1,this.balance="show",this.charsStart=4,this.charsEnd=6,this.namespace=void 0,this.isSupported=R.state.allowUnsupportedChain?!0:p.state.activeChain?p.checkIfSupportedNetwork(p.state.activeChain):!0}connectedCallback(){super.connectedCallback(),this.setAccountData(p.getAccountData(this.namespace)),this.setNetworkData(p.getNetworkData(this.namespace))}firstUpdated(){const t=this.namespace;t?this.unsubscribe.push(p.subscribeChainProp("accountState",n=>{this.setAccountData(n)},t),p.subscribeChainProp("networkState",n=>{this.setNetworkData(n),this.isSupported=p.checkIfSupportedNetwork(t,n?.caipNetwork?.caipNetworkId)},t)):this.unsubscribe.push(rt.subscribeNetworkImages(()=>{this.networkImage=De.getNetworkImage(this.network)}),p.subscribeKey("activeCaipAddress",n=>{this.caipAddress=n}),p.subscribeChainProp("accountState",n=>{this.setAccountData(n)}),p.subscribeKey("activeCaipNetwork",n=>{this.network=n,this.networkImage=De.getNetworkImage(n),this.isSupported=n?.chainNamespace?p.checkIfSupportedNetwork(n?.chainNamespace):!0,this.fetchNetworkImage(n)}))}updated(){this.fetchNetworkImage(this.network)}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){if(!p.state.activeChain)return null;const t=this.balance==="show",n=typeof this.balanceVal!="string",{formattedText:r}=L.parseBalance(this.balanceVal,this.balanceSymbol);return g`
      <wui-account-button
        .disabled=${!!this.disabled}
        .isUnsupportedChain=${R.state.allowUnsupportedChain?!1:!this.isSupported}
        address=${ae(L.getPlainAddress(this.caipAddress))}
        profileName=${ae(this.profileName)}
        networkSrc=${ae(this.networkImage)}
        avatarSrc=${ae(this.profileImage)}
        balance=${t?r:""}
        @click=${this.onClick.bind(this)}
        data-testid=${`account-button${this.namespace?`-${this.namespace}`:""}`}
        .charsStart=${this.charsStart}
        .charsEnd=${this.charsEnd}
        ?loading=${n}
      >
      </wui-account-button>
    `}onClick(){this.isSupported||R.state.allowUnsupportedChain?ye.open({namespace:this.namespace}):ye.open({view:"UnsupportedChain"})}async fetchNetworkImage(t){t?.assets?.imageId&&(this.networkImage=await De.fetchNetworkImage(t?.assets?.imageId))}setAccountData(t){t&&(this.caipAddress=t.caipAddress,this.balanceVal=t.balance,this.balanceSymbol=t.balanceSymbol,this.profileName=t.profileName,this.profileImage=t.profileImage)}setNetworkData(t){t&&(this.network=t.caipNetwork,this.networkImage=De.getNetworkImage(t.caipNetwork))}}At([ve({type:Boolean})],xt.prototype,"disabled",void 0);At([ve()],xt.prototype,"balance",void 0);At([ve()],xt.prototype,"charsStart",void 0);At([ve()],xt.prototype,"charsEnd",void 0);At([ve()],xt.prototype,"namespace",void 0);At([T()],xt.prototype,"caipAddress",void 0);At([T()],xt.prototype,"balanceVal",void 0);At([T()],xt.prototype,"balanceSymbol",void 0);At([T()],xt.prototype,"profileName",void 0);At([T()],xt.prototype,"profileImage",void 0);At([T()],xt.prototype,"network",void 0);At([T()],xt.prototype,"networkImage",void 0);At([T()],xt.prototype,"isSupported",void 0);let _h=class extends xt{};_h=At([M("w3m-account-button")],_h);let nd=class extends xt{};nd=At([M("appkit-account-button")],nd);const Oy=Vt`
  :host {
    display: block;
    width: max-content;
  }
`;var bn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};class tn extends he{constructor(){super(...arguments),this.unsubscribe=[],this.disabled=!1,this.balance=void 0,this.size=void 0,this.label=void 0,this.loadingLabel=void 0,this.charsStart=4,this.charsEnd=6,this.namespace=void 0}firstUpdated(){this.caipAddress=this.namespace?p.getAccountData(this.namespace)?.caipAddress:p.state.activeCaipAddress,this.namespace?this.unsubscribe.push(p.subscribeChainProp("accountState",t=>{this.caipAddress=t?.caipAddress},this.namespace)):this.unsubscribe.push(p.subscribeKey("activeCaipAddress",t=>this.caipAddress=t))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return this.caipAddress?g`
          <appkit-account-button
            .disabled=${!!this.disabled}
            balance=${ae(this.balance)}
            .charsStart=${ae(this.charsStart)}
            .charsEnd=${ae(this.charsEnd)}
            namespace=${ae(this.namespace)}
          >
          </appkit-account-button>
        `:g`
          <appkit-connect-button
            size=${ae(this.size)}
            label=${ae(this.label)}
            loadingLabel=${ae(this.loadingLabel)}
            namespace=${ae(this.namespace)}
          ></appkit-connect-button>
        `}}tn.styles=Oy;bn([ve({type:Boolean})],tn.prototype,"disabled",void 0);bn([ve()],tn.prototype,"balance",void 0);bn([ve()],tn.prototype,"size",void 0);bn([ve()],tn.prototype,"label",void 0);bn([ve()],tn.prototype,"loadingLabel",void 0);bn([ve()],tn.prototype,"charsStart",void 0);bn([ve()],tn.prototype,"charsEnd",void 0);bn([ve()],tn.prototype,"namespace",void 0);bn([T()],tn.prototype,"caipAddress",void 0);let Ah=class extends tn{};Ah=bn([M("w3m-button")],Ah);let rd=class extends tn{};rd=bn([M("appkit-button")],rd);const Py=Q`
  :host {
    position: relative;
    display: block;
  }

  button {
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  button[data-size='sm'] {
    padding: ${({spacing:e})=>e[2]};
  }

  button[data-size='md'] {
    padding: ${({spacing:e})=>e[3]};
  }

  button[data-size='lg'] {
    padding: ${({spacing:e})=>e[4]};
  }

  button[data-variant='primary'] {
    background: ${({tokens:e})=>e.core.backgroundAccentPrimary};
  }

  button[data-variant='secondary'] {
    background: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  button:hover:enabled {
    border-radius: ${({borderRadius:e})=>e[3]};
  }

  button:disabled {
    cursor: not-allowed;
  }

  button[data-loading='true'] {
    cursor: not-allowed;
  }

  button[data-loading='true'][data-size='sm'] {
    border-radius: ${({borderRadius:e})=>e[32]};
    padding: ${({spacing:e})=>e[2]} ${({spacing:e})=>e[3]};
  }

  button[data-loading='true'][data-size='md'] {
    border-radius: ${({borderRadius:e})=>e[20]};
    padding: ${({spacing:e})=>e[3]} ${({spacing:e})=>e[4]};
  }

  button[data-loading='true'][data-size='lg'] {
    border-radius: ${({borderRadius:e})=>e[16]};
    padding: ${({spacing:e})=>e[4]} ${({spacing:e})=>e[5]};
  }
`;var zs=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ri=class extends de{constructor(){super(...arguments),this.size="md",this.variant="primary",this.loading=!1,this.text="Connect Wallet"}render(){return x`
      <button
        data-loading=${this.loading}
        data-variant=${this.variant}
        data-size=${this.size}
        ?disabled=${this.loading}
      >
        ${this.contentTemplate()}
      </button>
    `}contentTemplate(){const t={lg:"lg-regular",md:"md-regular",sm:"sm-regular"},n={primary:"invert",secondary:"accent-primary"};return this.loading?x`<wui-loading-spinner
      color=${n[this.variant]}
      size=${this.size}
    ></wui-loading-spinner>`:x` <wui-text variant=${t[this.size]} color=${n[this.variant]}>
        ${this.text}
      </wui-text>`}};ri.styles=[we,Be,Py];zs([m()],ri.prototype,"size",void 0);zs([m()],ri.prototype,"variant",void 0);zs([m({type:Boolean})],ri.prototype,"loading",void 0);zs([m()],ri.prototype,"text",void 0);ri=zs([M("wui-connect-button")],ri);var Sr=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};class Tr extends he{constructor(){super(),this.unsubscribe=[],this.size="md",this.label="Connect Wallet",this.loadingLabel="Connecting...",this.open=ye.state.open,this.loading=this.namespace?ye.state.loadingNamespaceMap.get(this.namespace):ye.state.loading,this.unsubscribe.push(ye.subscribe(t=>{this.open=t.open,this.loading=this.namespace?t.loadingNamespaceMap.get(this.namespace):t.loading}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return g`
      <wui-connect-button
        size=${ae(this.size)}
        .loading=${this.loading}
        @click=${this.onClick.bind(this)}
        data-testid=${`connect-button${this.namespace?`-${this.namespace}`:""}`}
      >
        ${this.loading?this.loadingLabel:this.label}
      </wui-connect-button>
    `}onClick(){this.open?ye.close():this.loading||ye.open({view:"Connect",namespace:this.namespace})}}Sr([ve()],Tr.prototype,"size",void 0);Sr([ve()],Tr.prototype,"label",void 0);Sr([ve()],Tr.prototype,"loadingLabel",void 0);Sr([ve()],Tr.prototype,"namespace",void 0);Sr([T()],Tr.prototype,"open",void 0);Sr([T()],Tr.prototype,"loading",void 0);let xh=class extends Tr{};xh=Sr([M("w3m-connect-button")],xh);let id=class extends Tr{};id=Sr([M("appkit-connect-button")],id);const Ly=Q`
  :host {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    border-radius: ${({borderRadius:e})=>e[2]};
    padding: ${({spacing:e})=>e[1]} !important;
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
    position: relative;
  }

  :host([data-padding='2']) {
    padding: ${({spacing:e})=>e[2]} !important;
  }

  :host:after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  :host > wui-icon {
    z-index: 10;
  }

  /* -- Colors --------------------------------------------------- */
  :host([data-color='accent-primary']) {
    color: ${({tokens:e})=>e.core.iconAccentPrimary};
  }

  :host([data-color='accent-primary']):after {
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  :host([data-color='default']),
  :host([data-color='secondary']) {
    color: ${({tokens:e})=>e.theme.iconDefault};
  }

  :host([data-color='default']):after {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  :host([data-color='secondary']):after {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  :host([data-color='success']) {
    color: ${({tokens:e})=>e.core.iconSuccess};
  }

  :host([data-color='success']):after {
    background-color: ${({tokens:e})=>e.core.backgroundSuccess};
  }

  :host([data-color='error']) {
    color: ${({tokens:e})=>e.core.iconError};
  }

  :host([data-color='error']):after {
    background-color: ${({tokens:e})=>e.core.backgroundError};
  }

  :host([data-color='warning']) {
    color: ${({tokens:e})=>e.core.iconWarning};
  }

  :host([data-color='warning']):after {
    background-color: ${({tokens:e})=>e.core.backgroundWarning};
  }

  :host([data-color='inverse']) {
    color: ${({tokens:e})=>e.theme.iconInverse};
  }

  :host([data-color='inverse']):after {
    background-color: transparent;
  }
`;var Hs=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ii=class extends de{constructor(){super(...arguments),this.icon="copy",this.size="md",this.padding="1",this.color="default"}render(){return this.dataset.padding=this.padding,this.dataset.color=this.color,x`
      <wui-icon size=${Qe(this.size)} name=${this.icon} color="inherit"></wui-icon>
    `}};ii.styles=[we,Be,Ly];Hs([m()],ii.prototype,"icon",void 0);Hs([m()],ii.prototype,"size",void 0);Hs([m()],ii.prototype,"padding",void 0);Hs([m()],ii.prototype,"color",void 0);ii=Hs([M("wui-icon-box")],ii);const Dy=Q`
  :host {
    display: block;
  }

  button {
    border-radius: ${({borderRadius:e})=>e[32]};
    display: flex;
    gap: ${({spacing:e})=>e[1]};
    padding: ${({spacing:e})=>e[1]} ${({spacing:e})=>e[2]}
      ${({spacing:e})=>e[1]} ${({spacing:e})=>e[1]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }

  button[data-size='sm'] > wui-icon-box,
  button[data-size='sm'] > wui-image {
    width: 16px;
    height: 16px;
  }

  button[data-size='md'] > wui-icon-box,
  button[data-size='md'] > wui-image {
    width: 20px;
    height: 20px;
  }

  button[data-size='lg'] > wui-icon-box,
  button[data-size='lg'] > wui-image {
    width: 24px;
    height: 24px;
  }

  wui-image,
  wui-icon-box {
    border-radius: ${({borderRadius:e})=>e[32]};
  }
`;var Vs=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let oi=class extends de{constructor(){super(...arguments),this.imageSrc=void 0,this.isUnsupportedChain=void 0,this.disabled=!1,this.size="lg"}render(){const t={sm:"sm-regular",md:"md-regular",lg:"lg-regular"};return x`
      <button data-size=${this.size} data-testid="wui-network-button" ?disabled=${this.disabled}>
        ${this.visualTemplate()}
        <wui-text variant=${t[this.size]} color="primary">
          <slot></slot>
        </wui-text>
      </button>
    `}visualTemplate(){return this.isUnsupportedChain?x` <wui-icon-box color="error" icon="warningCircle"></wui-icon-box> `:this.imageSrc?x`<wui-image src=${this.imageSrc}></wui-image>`:x` <wui-icon size="xl" color="default" name="networkPlaceholder"></wui-icon> `}};oi.styles=[we,Be,Dy];Vs([m()],oi.prototype,"imageSrc",void 0);Vs([m({type:Boolean})],oi.prototype,"isUnsupportedChain",void 0);Vs([m({type:Boolean})],oi.prototype,"disabled",void 0);Vs([m()],oi.prototype,"size",void 0);oi=Vs([M("wui-network-button")],oi);const My=Vt`
  :host {
    display: block;
    width: max-content;
  }
`;var or=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};class Un extends he{constructor(){super(),this.unsubscribe=[],this.disabled=!1,this.network=p.state.activeCaipNetwork,this.networkImage=De.getNetworkImage(this.network),this.caipAddress=p.state.activeCaipAddress,this.loading=ye.state.loading,this.isSupported=R.state.allowUnsupportedChain?!0:p.state.activeChain?p.checkIfSupportedNetwork(p.state.activeChain):!0,this.unsubscribe.push(rt.subscribeNetworkImages(()=>{this.networkImage=De.getNetworkImage(this.network)}),p.subscribeKey("activeCaipAddress",t=>{this.caipAddress=t}),p.subscribeKey("activeCaipNetwork",t=>{this.network=t,this.networkImage=De.getNetworkImage(t),this.isSupported=t?.chainNamespace?p.checkIfSupportedNetwork(t.chainNamespace):!0,De.fetchNetworkImage(t?.assets?.imageId)}),ye.subscribeKey("loading",t=>this.loading=t))}firstUpdated(){De.fetchNetworkImage(this.network?.assets?.imageId)}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){const t=this.network?p.checkIfSupportedNetwork(this.network.chainNamespace):!0;return g`
      <wui-network-button
        .disabled=${!!(this.disabled||this.loading)}
        .isUnsupportedChain=${R.state.allowUnsupportedChain?!1:!t}
        imageSrc=${ae(this.networkImage)}
        @click=${this.onClick.bind(this)}
        data-testid="w3m-network-button"
      >
        ${this.getLabel()}
        <slot></slot>
      </wui-network-button>
    `}getLabel(){return this.network?!this.isSupported&&!R.state.allowUnsupportedChain?"Switch Network":this.network.name:this.label?this.label:this.caipAddress?"Unknown Network":"Select Network"}onClick(){this.loading||(X.sendEvent({type:"track",event:"CLICK_NETWORKS"}),ye.open({view:"Networks"}))}}Un.styles=My;or([ve({type:Boolean})],Un.prototype,"disabled",void 0);or([ve({type:String})],Un.prototype,"label",void 0);or([T()],Un.prototype,"network",void 0);or([T()],Un.prototype,"networkImage",void 0);or([T()],Un.prototype,"caipAddress",void 0);or([T()],Un.prototype,"loading",void 0);or([T()],Un.prototype,"isSupported",void 0);let Sh=class extends Un{};Sh=or([M("w3m-network-button")],Sh);let od=class extends Un{};od=or([M("appkit-network-button")],od);const Uy="https://reown.com",By=Q`
  .reown-logo {
    height: 24px;
  }

  a {
    text-decoration: none;
    cursor: pointer;
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  a:hover {
    opacity: 0.9;
  }
`;var Wy=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let sd=class extends de{render(){return x`
      <a
        data-testid="ux-branding-reown"
        href=${Uy}
        rel="noreferrer"
        target="_blank"
        style="text-decoration: none;"
      >
        <wui-flex
          justifyContent="center"
          alignItems="center"
          gap="1"
          .padding=${["01","0","3","0"]}
        >
          <wui-text variant="sm-regular" color="inherit"> UX by </wui-text>
          <wui-icon name="reown" size="inherit" class="reown-logo"></wui-icon>
        </wui-flex>
      </a>
    `}};sd.styles=[we,Be,By];sd=Wy([M("wui-ux-by-reown")],sd);const jy=Q`
  :host wui-ux-by-reown {
    padding-top: 0;
  }

  :host wui-ux-by-reown.branding-only {
    padding-top: ${({spacing:e})=>e[3]};
  }

  a {
    text-decoration: none;
    color: ${({tokens:e})=>e.core.textAccentPrimary};
    font-weight: 500;
  }
`;var Ef=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let oc=class extends he{constructor(){super(),this.unsubscribe=[],this.remoteFeatures=R.state.remoteFeatures,this.unsubscribe.push(R.subscribeKey("remoteFeatures",t=>this.remoteFeatures=t))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){const{termsConditionsUrl:t,privacyPolicyUrl:n}=R.state,r=R.state.features?.legalCheckbox;return!t&&!n||r?g`
        <wui-flex flexDirection="column"> ${this.reownBrandingTemplate(!0)} </wui-flex>
      `:g`
      <wui-flex flexDirection="column">
        <wui-flex .padding=${["4","3","3","3"]} justifyContent="center">
          <wui-text color="secondary" variant="md-regular" align="center">
            By connecting your wallet, you agree to our <br />
            ${this.termsTemplate()} ${this.andTemplate()} ${this.privacyTemplate()}
          </wui-text>
        </wui-flex>
        ${this.reownBrandingTemplate()}
      </wui-flex>
    `}andTemplate(){const{termsConditionsUrl:t,privacyPolicyUrl:n}=R.state;return t&&n?"and":""}termsTemplate(){const{termsConditionsUrl:t}=R.state;return t?g`<a href=${t} target="_blank" rel="noopener noreferrer"
      >Terms of Service</a
    >`:null}privacyTemplate(){const{privacyPolicyUrl:t}=R.state;return t?g`<a href=${t} target="_blank" rel="noopener noreferrer"
      >Privacy Policy</a
    >`:null}reownBrandingTemplate(t=!1){return this.remoteFeatures?.reownBranding?t?g`<wui-ux-by-reown class="branding-only"></wui-ux-by-reown>`:g`<wui-ux-by-reown></wui-ux-by-reown>`:null}};oc.styles=[jy];Ef([T()],oc.prototype,"remoteFeatures",void 0);oc=Ef([M("w3m-legal-footer")],oc);const Fy=Q`
  button {
    border: none;
    background: transparent;
    height: 20px;
    padding: ${({spacing:e})=>e[2]};
    column-gap: ${({spacing:e})=>e[1]};
    border-radius: ${({borderRadius:e})=>e[1]};
    padding: 0 ${({spacing:e})=>e[1]};
    border-radius: ${({spacing:e})=>e[1]};
  }

  /* -- Variants --------------------------------------------------------- */
  button[data-variant='accent'] {
    color: ${({tokens:e})=>e.core.textAccentPrimary};
  }

  button[data-variant='secondary'] {
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  /* -- Focus states --------------------------------------------------- */
  button:focus-visible:enabled {
    box-shadow: 0px 0px 0px 4px rgba(9, 136, 240, 0.2);
  }

  button[data-variant='accent']:focus-visible:enabled {
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  button[data-variant='secondary']:focus-visible:enabled {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  /* -- Hover & Active states ----------------------------------------------------------- */
  button[data-variant='accent']:hover:enabled {
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  button[data-variant='secondary']:hover:enabled {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  button[data-variant='accent']:focus-visible {
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  button[data-variant='secondary']:focus-visible {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    box-shadow: 0px 0px 0px 4px rgba(9, 136, 240, 0.2);
  }

  button[disabled] {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;var qs=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const zy={sm:"sm-medium",md:"md-medium"},Hy={accent:"accent-primary",secondary:"secondary"};let si=class extends de{constructor(){super(...arguments),this.size="md",this.disabled=!1,this.variant="accent",this.icon=void 0}render(){return x`
      <button ?disabled=${this.disabled} data-variant=${this.variant}>
        <slot name="iconLeft"></slot>
        <wui-text
          color=${Hy[this.variant]}
          variant=${zy[this.size]}
        >
          <slot></slot>
        </wui-text>
        ${this.iconTemplate()}
      </button>
    `}iconTemplate(){return this.icon?x`<wui-icon name=${this.icon} size="sm"></wui-icon>`:null}};si.styles=[we,Be,Fy];qs([m()],si.prototype,"size",void 0);qs([m({type:Boolean})],si.prototype,"disabled",void 0);qs([m()],si.prototype,"variant",void 0);qs([m()],si.prototype,"icon",void 0);si=qs([M("wui-link")],si);const Vy=Vt``;var qy=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ad=class extends he{render(){const{termsConditionsUrl:t,privacyPolicyUrl:n}=R.state;return!t&&!n?null:g`
      <wui-flex
        .padding=${["4","3","3","3"]}
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        gap="3"
      >
        <wui-text color="secondary" variant="md-regular" align="center">
          We work with the best providers to give you the lowest fees and best support. More options
          coming soon!
        </wui-text>

        ${this.howDoesItWorkTemplate()}
      </wui-flex>
    `}howDoesItWorkTemplate(){return g` <wui-link @click=${this.onWhatIsBuy.bind(this)}>
      <wui-icon size="xs" color="accent-primary" slot="iconLeft" name="helpCircle"></wui-icon>
      How does it work?
    </wui-link>`}onWhatIsBuy(){X.sendEvent({type:"track",event:"SELECT_WHAT_IS_A_BUY",properties:{isSmartAccount:ut(p.state.activeChain)===je.ACCOUNT_TYPES.SMART_ACCOUNT}}),S.push("WhatIsABuy")}};ad.styles=[Vy];ad=qy([M("w3m-onramp-providers-footer")],ad);var Th={};const Ea={ACCOUNT_TABS:[{label:"Tokens"},{label:"Activity"}],SECURE_SITE_ORIGIN:(typeof process<"u"&&typeof Th<"u"?Th.NEXT_PUBLIC_SECURE_SITE_ORIGIN:void 0)||"https://secure.walletconnect.org",VIEW_DIRECTION:{Next:"next",Prev:"prev"},ANIMATION_DURATIONS:{HeaderText:120},VIEWS_WITH_LEGAL_FOOTER:["Connect","ConnectWallets","OnRampTokenSelect","OnRampFiatSelect","OnRampProviders"],VIEWS_WITH_DEFAULT_FOOTER:["Networks"]},Zi={getTabsByNamespace(e){return!!e&&e===N.CHAIN.EVM?R.state.remoteFeatures?.activity===!1?Ea.ACCOUNT_TABS.filter(n=>n.label!=="Activity"):Ea.ACCOUNT_TABS:[]},isValidReownName(e){return/^[a-zA-Z0-9]+$/gu.test(e)},isValidEmail(e){return/^[^\s@]+@[^\s@]+\.[^\s@]+$/gu.test(e)},validateReownName(e){return e.replace(/\^/gu,"").toLowerCase().replace(/[^a-zA-Z0-9]/gu,"")},hasFooter(){const e=S.state.view;if(Ea.VIEWS_WITH_LEGAL_FOOTER.includes(e)){const{termsConditionsUrl:t,privacyPolicyUrl:n}=R.state,r=R.state.features?.legalCheckbox;return!(!t&&!n||r)}return Ea.VIEWS_WITH_DEFAULT_FOOTER.includes(e)}},Ky=Q`
  :host {
    display: block;
  }

  div.container {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    overflow: hidden;
    height: auto;
    display: block;
  }

  div.container[status='hide'] {
    animation: fade-out;
    animation-duration: var(--apkt-duration-dynamic);
    animation-timing-function: ${({easings:e})=>e["ease-out-power-2"]};
    animation-fill-mode: both;
    animation-delay: 0s;
  }

  div.container[status='show'] {
    animation: fade-in;
    animation-duration: var(--apkt-duration-dynamic);
    animation-timing-function: ${({easings:e})=>e["ease-out-power-2"]};
    animation-fill-mode: both;
    animation-delay: var(--apkt-duration-dynamic);
  }

  @keyframes fade-in {
    from {
      opacity: 0;
      filter: blur(6px);
    }
    to {
      opacity: 1;
      filter: blur(0px);
    }
  }

  @keyframes fade-out {
    from {
      opacity: 1;
      filter: blur(0px);
    }
    to {
      opacity: 0;
      filter: blur(6px);
    }
  }
`;var Gd=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ts=class extends he{constructor(){super(...arguments),this.resizeObserver=void 0,this.unsubscribe=[],this.status="hide",this.view=S.state.view}firstUpdated(){this.status=Zi.hasFooter()?"show":"hide",this.unsubscribe.push(S.subscribeKey("view",t=>{this.view=t,this.status=Zi.hasFooter()?"show":"hide",this.status==="hide"&&document.documentElement.style.setProperty("--apkt-footer-height","0px")})),this.resizeObserver=new ResizeObserver(t=>{for(const n of t)if(n.target===this.getWrapper()){const r=`${n.contentRect.height}px`;document.documentElement.style.setProperty("--apkt-footer-height",r)}}),this.resizeObserver.observe(this.getWrapper())}render(){return g`
      <div class="container" status=${this.status}>${this.templatePageContainer()}</div>
    `}templatePageContainer(){return Zi.hasFooter()?g` ${this.templateFooter()}`:null}templateFooter(){switch(this.view){case"Networks":return this.templateNetworksFooter();case"Connect":case"ConnectWallets":case"OnRampFiatSelect":case"OnRampTokenSelect":return g`<w3m-legal-footer></w3m-legal-footer>`;case"OnRampProviders":return g`<w3m-onramp-providers-footer></w3m-onramp-providers-footer>`;default:return null}}templateNetworksFooter(){return g` <wui-flex
      class="footer-in"
      padding="3"
      flexDirection="column"
      gap="3"
      alignItems="center"
    >
      <wui-text variant="md-regular" color="secondary" align="center">
        Your connected wallet may not support some of the networks available for this dApp
      </wui-text>
      <wui-link @click=${this.onNetworkHelp.bind(this)}>
        <wui-icon size="sm" color="accent-primary" slot="iconLeft" name="helpCircle"></wui-icon>
        What is a network
      </wui-link>
    </wui-flex>`}onNetworkHelp(){X.sendEvent({type:"track",event:"CLICK_NETWORK_HELP"}),S.push("WhatIsANetwork")}getWrapper(){return this.shadowRoot?.querySelector("div.container")}};Ts.styles=[Ky];Gd([T()],Ts.prototype,"status",void 0);Gd([T()],Ts.prototype,"view",void 0);Ts=Gd([M("w3m-footer")],Ts);const Gy=Q`
  :host {
    display: block;
    width: inherit;
  }
`;var Zd=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let $s=class extends he{constructor(){super(),this.unsubscribe=[],this.viewState=S.state.view,this.history=S.state.history.join(","),this.unsubscribe.push(S.subscribeKey("view",()=>{this.history=S.state.history.join(","),document.documentElement.style.setProperty("--apkt-duration-dynamic","var(--apkt-durations-lg)")}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t()),document.documentElement.style.setProperty("--apkt-duration-dynamic","0s")}render(){return g`${this.templatePageContainer()}`}templatePageContainer(){return g`<w3m-router-container
      history=${this.history}
      .setView=${()=>{this.viewState=S.state.view}}
    >
      ${this.viewTemplate(this.viewState)}
    </w3m-router-container>`}viewTemplate(t){switch(t){case"AccountSettings":return g`<w3m-account-settings-view></w3m-account-settings-view>`;case"Account":return g`<w3m-account-view></w3m-account-view>`;case"AllWallets":return g`<w3m-all-wallets-view></w3m-all-wallets-view>`;case"ApproveTransaction":return g`<w3m-approve-transaction-view></w3m-approve-transaction-view>`;case"BuyInProgress":return g`<w3m-buy-in-progress-view></w3m-buy-in-progress-view>`;case"ChooseAccountName":return g`<w3m-choose-account-name-view></w3m-choose-account-name-view>`;case"Connect":return g`<w3m-connect-view></w3m-connect-view>`;case"Create":return g`<w3m-connect-view walletGuide="explore"></w3m-connect-view>`;case"ConnectingWalletConnect":return g`<w3m-connecting-wc-view></w3m-connecting-wc-view>`;case"ConnectingWalletConnectBasic":return g`<w3m-connecting-wc-basic-view></w3m-connecting-wc-basic-view>`;case"ConnectingExternal":return g`<w3m-connecting-external-view></w3m-connecting-external-view>`;case"ConnectingSiwe":return g`<w3m-connecting-siwe-view></w3m-connecting-siwe-view>`;case"ConnectWallets":return g`<w3m-connect-wallets-view></w3m-connect-wallets-view>`;case"ConnectSocials":return g`<w3m-connect-socials-view></w3m-connect-socials-view>`;case"ConnectingSocial":return g`<w3m-connecting-social-view></w3m-connecting-social-view>`;case"DataCapture":return g`<w3m-data-capture-view></w3m-data-capture-view>`;case"DataCaptureOtpConfirm":return g`<w3m-data-capture-otp-confirm-view></w3m-data-capture-otp-confirm-view>`;case"Downloads":return g`<w3m-downloads-view></w3m-downloads-view>`;case"EmailLogin":return g`<w3m-email-login-view></w3m-email-login-view>`;case"EmailVerifyOtp":return g`<w3m-email-verify-otp-view></w3m-email-verify-otp-view>`;case"EmailVerifyDevice":return g`<w3m-email-verify-device-view></w3m-email-verify-device-view>`;case"GetWallet":return g`<w3m-get-wallet-view></w3m-get-wallet-view>`;case"Networks":return g`<w3m-networks-view></w3m-networks-view>`;case"SwitchNetwork":return g`<w3m-network-switch-view></w3m-network-switch-view>`;case"ProfileWallets":return g`<w3m-profile-wallets-view></w3m-profile-wallets-view>`;case"Transactions":return g`<w3m-transactions-view></w3m-transactions-view>`;case"OnRampProviders":return g`<w3m-onramp-providers-view></w3m-onramp-providers-view>`;case"OnRampTokenSelect":return g`<w3m-onramp-token-select-view></w3m-onramp-token-select-view>`;case"OnRampFiatSelect":return g`<w3m-onramp-fiat-select-view></w3m-onramp-fiat-select-view>`;case"UpgradeEmailWallet":return g`<w3m-upgrade-wallet-view></w3m-upgrade-wallet-view>`;case"UpdateEmailWallet":return g`<w3m-update-email-wallet-view></w3m-update-email-wallet-view>`;case"UpdateEmailPrimaryOtp":return g`<w3m-update-email-primary-otp-view></w3m-update-email-primary-otp-view>`;case"UpdateEmailSecondaryOtp":return g`<w3m-update-email-secondary-otp-view></w3m-update-email-secondary-otp-view>`;case"UnsupportedChain":return g`<w3m-unsupported-chain-view></w3m-unsupported-chain-view>`;case"Swap":return g`<w3m-swap-view></w3m-swap-view>`;case"SwapSelectToken":return g`<w3m-swap-select-token-view></w3m-swap-select-token-view>`;case"SwapPreview":return g`<w3m-swap-preview-view></w3m-swap-preview-view>`;case"WalletSend":return g`<w3m-wallet-send-view></w3m-wallet-send-view>`;case"WalletSendSelectToken":return g`<w3m-wallet-send-select-token-view></w3m-wallet-send-select-token-view>`;case"WalletSendPreview":return g`<w3m-wallet-send-preview-view></w3m-wallet-send-preview-view>`;case"WalletSendConfirmed":return g`<w3m-send-confirmed-view></w3m-send-confirmed-view>`;case"WhatIsABuy":return g`<w3m-what-is-a-buy-view></w3m-what-is-a-buy-view>`;case"WalletReceive":return g`<w3m-wallet-receive-view></w3m-wallet-receive-view>`;case"WalletCompatibleNetworks":return g`<w3m-wallet-compatible-networks-view></w3m-wallet-compatible-networks-view>`;case"WhatIsAWallet":return g`<w3m-what-is-a-wallet-view></w3m-what-is-a-wallet-view>`;case"ConnectingMultiChain":return g`<w3m-connecting-multi-chain-view></w3m-connecting-multi-chain-view>`;case"WhatIsANetwork":return g`<w3m-what-is-a-network-view></w3m-what-is-a-network-view>`;case"ConnectingFarcaster":return g`<w3m-connecting-farcaster-view></w3m-connecting-farcaster-view>`;case"SwitchActiveChain":return g`<w3m-switch-active-chain-view></w3m-switch-active-chain-view>`;case"RegisterAccountName":return g`<w3m-register-account-name-view></w3m-register-account-name-view>`;case"RegisterAccountNameSuccess":return g`<w3m-register-account-name-success-view></w3m-register-account-name-success-view>`;case"SmartSessionCreated":return g`<w3m-smart-session-created-view></w3m-smart-session-created-view>`;case"SmartSessionList":return g`<w3m-smart-session-list-view></w3m-smart-session-list-view>`;case"SIWXSignMessage":return g`<w3m-siwx-sign-message-view></w3m-siwx-sign-message-view>`;case"Pay":return g`<w3m-pay-view></w3m-pay-view>`;case"PayLoading":return g`<w3m-pay-loading-view></w3m-pay-loading-view>`;case"PayQuote":return g`<w3m-pay-quote-view></w3m-pay-quote-view>`;case"FundWallet":return g`<w3m-fund-wallet-view></w3m-fund-wallet-view>`;case"PayWithExchange":return g`<w3m-deposit-from-exchange-view></w3m-deposit-from-exchange-view>`;case"PayWithExchangeSelectAsset":return g`<w3m-deposit-from-exchange-select-asset-view></w3m-deposit-from-exchange-select-asset-view>`;case"UsageExceeded":return g`<w3m-usage-exceeded-view></w3m-usage-exceeded-view>`;case"SmartAccountSettings":return g`<w3m-smart-account-settings-view></w3m-smart-account-settings-view>`;default:return g`<w3m-connect-view></w3m-connect-view>`}}};$s.styles=[Gy];Zd([T()],$s.prototype,"viewState",void 0);Zd([T()],$s.prototype,"history",void 0);$s=Zd([M("w3m-router")],$s);const Zy=Q`
  button {
    background-color: transparent;
    padding: ${({spacing:e})=>e[1]};
  }

  button:focus-visible {
    box-shadow: 0 0 0 4px ${({tokens:e})=>e.core.foregroundAccent020};
  }

  button[data-variant='accent']:hover:enabled,
  button[data-variant='accent']:focus-visible {
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  button[data-variant='primary']:hover:enabled,
  button[data-variant='primary']:focus-visible,
  button[data-variant='secondary']:hover:enabled,
  button[data-variant='secondary']:focus-visible {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  button[data-size='xs'] > wui-icon {
    width: 8px;
    height: 8px;
  }

  button[data-size='sm'] > wui-icon {
    width: 12px;
    height: 12px;
  }

  button[data-size='xs'],
  button[data-size='sm'] {
    border-radius: ${({borderRadius:e})=>e[1]};
  }

  button[data-size='md'],
  button[data-size='lg'] {
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  button[data-size='md'] > wui-icon {
    width: 16px;
    height: 16px;
  }

  button[data-size='lg'] > wui-icon {
    width: 20px;
    height: 20px;
  }

  button:disabled {
    background-color: transparent;
    cursor: not-allowed;
    opacity: 0.5;
  }

  button:hover:not(:disabled) {
    background-color: var(--wui-color-accent-glass-015);
  }

  button:focus-visible:not(:disabled) {
    background-color: var(--wui-color-accent-glass-015);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-accent-100),
      0 0 0 4px var(--wui-color-accent-glass-020);
  }
`;var wo=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Cr=class extends de{constructor(){super(...arguments),this.size="md",this.disabled=!1,this.icon="copy",this.iconColor="default",this.variant="accent"}render(){const t={accent:"accent-primary",primary:"inverse",secondary:"default"};return x`
      <button data-variant=${this.variant} ?disabled=${this.disabled} data-size=${this.size}>
        <wui-icon
          color=${t[this.variant]||this.iconColor}
          size=${this.size}
          name=${this.icon}
        ></wui-icon>
      </button>
    `}};Cr.styles=[we,Be,Zy];wo([m()],Cr.prototype,"size",void 0);wo([m({type:Boolean})],Cr.prototype,"disabled",void 0);wo([m()],Cr.prototype,"icon",void 0);wo([m()],Cr.prototype,"iconColor",void 0);wo([m()],Cr.prototype,"variant",void 0);Cr=wo([M("wui-icon-link")],Cr);const Yy=Q`
  :host {
    width: 100%;
  }

  :host([data-type='primary']) > button {
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
  }

  :host([data-type='secondary']) > button {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: ${({spacing:e})=>e[3]};
    width: 100%;
    border-radius: ${({borderRadius:e})=>e[4]};
    transition:
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      scale ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color, scale;
  }

  wui-text {
    text-transform: capitalize;
  }

  wui-image {
    color: ${({tokens:e})=>e.theme.textPrimary};
  }

  @media (hover: hover) {
    :host([data-type='primary']) > button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    }

    :host([data-type='secondary']) > button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;var Dt=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ft=class extends de{constructor(){super(...arguments),this.type="primary",this.imageSrc="google",this.imageSize=void 0,this.loading=!1,this.boxColor="foregroundPrimary",this.disabled=!1,this.rightIcon=!0,this.boxed=!0,this.rounded=!1,this.fullSize=!1}render(){return this.dataset.rounded=this.rounded?"true":"false",this.dataset.type=this.type,x`
      <button
        ?disabled=${this.loading?!0:!!this.disabled}
        data-loading=${this.loading}
        tabindex=${Qe(this.tabIdx)}
      >
        <wui-flex gap="2" alignItems="center">
          ${this.templateLeftIcon()}
          <wui-flex gap="1">
            <slot></slot>
          </wui-flex>
        </wui-flex>
        ${this.templateRightIcon()}
      </button>
    `}templateLeftIcon(){return this.icon?x`<wui-image
        icon=${this.icon}
        iconColor=${Qe(this.iconColor)}
        ?boxed=${this.boxed}
        ?rounded=${this.rounded}
        boxColor=${this.boxColor}
      ></wui-image>`:x`<wui-image
      ?boxed=${this.boxed}
      ?rounded=${this.rounded}
      ?fullSize=${this.fullSize}
      size=${Qe(this.imageSize)}
      src=${this.imageSrc}
      boxColor=${this.boxColor}
    ></wui-image>`}templateRightIcon(){return this.rightIcon?this.loading?x`<wui-loading-spinner size="md" color="accent-primary"></wui-loading-spinner>`:x`<wui-icon name="chevronRight" size="lg" color="default"></wui-icon>`:null}};ft.styles=[we,Be,Yy];Dt([m()],ft.prototype,"type",void 0);Dt([m()],ft.prototype,"imageSrc",void 0);Dt([m()],ft.prototype,"imageSize",void 0);Dt([m()],ft.prototype,"icon",void 0);Dt([m()],ft.prototype,"iconColor",void 0);Dt([m({type:Boolean})],ft.prototype,"loading",void 0);Dt([m()],ft.prototype,"tabIdx",void 0);Dt([m()],ft.prototype,"boxColor",void 0);Dt([m({type:Boolean})],ft.prototype,"disabled",void 0);Dt([m({type:Boolean})],ft.prototype,"rightIcon",void 0);Dt([m({type:Boolean})],ft.prototype,"boxed",void 0);Dt([m({type:Boolean})],ft.prototype,"rounded",void 0);Dt([m({type:Boolean})],ft.prototype,"fullSize",void 0);ft=Dt([M("wui-list-item")],ft);const Jy=Q`
  :host {
    width: var(--local-width);
  }

  button {
    width: var(--local-width);
    white-space: nowrap;
    column-gap: ${({spacing:e})=>e[2]};
    transition:
      scale ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-1"]},
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      border-radius ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-1"]};
    will-change: scale, background-color, border-radius;
    cursor: pointer;
  }

  /* -- Sizes --------------------------------------------------- */
  button[data-size='sm'] {
    border-radius: ${({borderRadius:e})=>e[2]};
    padding: 0 ${({spacing:e})=>e[2]};
    height: 28px;
  }

  button[data-size='md'] {
    border-radius: ${({borderRadius:e})=>e[3]};
    padding: 0 ${({spacing:e})=>e[4]};
    height: 38px;
  }

  button[data-size='lg'] {
    border-radius: ${({borderRadius:e})=>e[4]};
    padding: 0 ${({spacing:e})=>e[5]};
    height: 48px;
  }

  /* -- Variants --------------------------------------------------------- */
  button[data-variant='accent-primary'] {
    background-color: ${({tokens:e})=>e.core.backgroundAccentPrimary};
    color: ${({tokens:e})=>e.theme.textInvert};
  }

  button[data-variant='accent-secondary'] {
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
    color: ${({tokens:e})=>e.core.textAccentPrimary};
  }

  button[data-variant='neutral-primary'] {
    background-color: ${({tokens:e})=>e.theme.backgroundInvert};
    color: ${({tokens:e})=>e.theme.textInvert};
  }

  button[data-variant='neutral-secondary'] {
    background-color: transparent;
    border: 1px solid ${({tokens:e})=>e.theme.borderSecondary};
    color: ${({tokens:e})=>e.theme.textPrimary};
  }

  button[data-variant='neutral-tertiary'] {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    color: ${({tokens:e})=>e.theme.textPrimary};
  }

  button[data-variant='error-primary'] {
    background-color: ${({tokens:e})=>e.core.textError};
    color: ${({tokens:e})=>e.theme.textInvert};
  }

  button[data-variant='error-secondary'] {
    background-color: ${({tokens:e})=>e.core.backgroundError};
    color: ${({tokens:e})=>e.core.textError};
  }

  button[data-variant='shade'] {
    background: var(--wui-color-gray-glass-002);
    color: var(--wui-color-fg-200);
    border: none;
    box-shadow: inset 0 0 0 1px var(--wui-color-gray-glass-005);
  }

  /* -- Focus states --------------------------------------------------- */
  button[data-size='sm']:focus-visible:enabled {
    border-radius: 28px;
  }

  button[data-size='md']:focus-visible:enabled {
    border-radius: 38px;
  }

  button[data-size='lg']:focus-visible:enabled {
    border-radius: 48px;
  }
  button[data-variant='shade']:focus-visible:enabled {
    background: var(--wui-color-gray-glass-005);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-gray-glass-010),
      0 0 0 4px var(--wui-color-gray-glass-002);
  }

  /* -- Hover & Active states ----------------------------------------------------------- */
  @media (hover: hover) {
    button[data-size='sm']:hover:enabled {
      border-radius: 28px;
    }

    button[data-size='md']:hover:enabled {
      border-radius: 38px;
    }

    button[data-size='lg']:hover:enabled {
      border-radius: 48px;
    }

    button[data-variant='shade']:hover:enabled {
      background: var(--wui-color-gray-glass-002);
    }

    button[data-variant='shade']:active:enabled {
      background: var(--wui-color-gray-glass-005);
    }
  }

  button[data-size='sm']:active:enabled {
    border-radius: 28px;
  }

  button[data-size='md']:active:enabled {
    border-radius: 38px;
  }

  button[data-size='lg']:active:enabled {
    border-radius: 48px;
  }

  /* -- Disabled states --------------------------------------------------- */
  button:disabled {
    opacity: 0.3;
  }
`;var Si=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const Xy={lg:"lg-regular-mono",md:"md-regular-mono",sm:"sm-regular-mono"},Qy={lg:"md",md:"md",sm:"sm"};let Xn=class extends de{constructor(){super(...arguments),this.size="lg",this.disabled=!1,this.fullWidth=!1,this.loading=!1,this.variant="accent-primary"}render(){this.style.cssText=`
    --local-width: ${this.fullWidth?"100%":"auto"};
     `;const t=this.textVariant??Xy[this.size];return x`
      <button data-variant=${this.variant} data-size=${this.size} ?disabled=${this.disabled}>
        ${this.loadingTemplate()}
        <slot name="iconLeft"></slot>
        <wui-text variant=${t} color="inherit">
          <slot></slot>
        </wui-text>
        <slot name="iconRight"></slot>
      </button>
    `}loadingTemplate(){if(this.loading){const t=Qy[this.size],n=this.variant==="neutral-primary"||this.variant==="accent-primary"?"invert":"primary";return x`<wui-loading-spinner color=${n} size=${t}></wui-loading-spinner>`}return null}};Xn.styles=[we,Be,Jy];Si([m()],Xn.prototype,"size",void 0);Si([m({type:Boolean})],Xn.prototype,"disabled",void 0);Si([m({type:Boolean})],Xn.prototype,"fullWidth",void 0);Si([m({type:Boolean})],Xn.prototype,"loading",void 0);Si([m()],Xn.prototype,"variant",void 0);Si([m()],Xn.prototype,"textVariant",void 0);Xn=Si([M("wui-button")],Xn);const e5=Q`
  :host {
    display: block;
  }

  button {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: ${({spacing:e})=>e[4]};
    padding: ${({spacing:e})=>e[3]};
    border-radius: ${({borderRadius:e})=>e[4]};
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  wui-flex > wui-icon {
    padding: ${({spacing:e})=>e[2]};
    color: ${({tokens:e})=>e.theme.textInvert};
    background-color: ${({tokens:e})=>e.core.backgroundAccentPrimary};
    border-radius: ${({borderRadius:e})=>e[2]};
    align-items: center;
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.core.foregroundAccent020};
    }
  }
`;var Lc=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let so=class extends de{constructor(){super(...arguments),this.label="",this.description="",this.icon="wallet"}render(){return x`
      <button>
        <wui-flex gap="2" alignItems="center">
          <wui-icon weight="fill" size="lg" name=${this.icon} color="inherit"></wui-icon>
          <wui-flex flexDirection="column" gap="1">
            <wui-text variant="md-medium" color="primary">${this.label}</wui-text>
            <wui-text variant="md-regular" color="tertiary">${this.description}</wui-text>
          </wui-flex>
        </wui-flex>
        <wui-icon size="lg" color="accent-primary" name="chevronRight"></wui-icon>
      </button>
    `}};so.styles=[we,Be,e5];Lc([m()],so.prototype,"label",void 0);Lc([m()],so.prototype,"description",void 0);Lc([m()],so.prototype,"icon",void 0);so=Lc([M("wui-notice-card")],so);var _f=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let cd=class extends he{constructor(){super(),this.unsubscribe=[],this.socialProvider=G.getConnectedSocialProvider(),this.socialUsername=G.getConnectedSocialUsername(),this.namespace=p.state.activeChain,this.unsubscribe.push(p.subscribeKey("activeChain",t=>{this.namespace=t}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){const t=O.getConnectorId(this.namespace),n=O.getAuthConnector();if(!n||t!==N.CONNECTOR_ID.AUTH)return this.style.cssText="display: none",null;const r=n.provider.getEmail()??"";return!r&&!this.socialUsername?(this.style.cssText="display: none",null):g`
      <wui-list-item
        ?rounded=${!0}
        icon=${this.socialProvider??"mail"}
        data-testid="w3m-account-email-update"
        ?chevron=${!this.socialProvider}
        @click=${()=>{this.onGoToUpdateEmail(r,this.socialProvider)}}
      >
        <wui-text variant="lg-regular" color="primary">${this.getAuthName(r)}</wui-text>
      </wui-list-item>
    `}onGoToUpdateEmail(t,n){n||S.push("UpdateEmailWallet",{email:t,redirectView:"Account"})}getAuthName(t){return this.socialUsername?this.socialProvider==="discord"&&this.socialUsername.endsWith("0")?this.socialUsername.slice(0,-1):this.socialUsername:t.length>30?`${t.slice(0,-3)}...`:t}};_f([T()],cd.prototype,"namespace",void 0);cd=_f([M("w3m-account-auth-button")],cd);var Ti=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let vr=class extends he{constructor(){super(),this.usubscribe=[],this.networkImages=rt.state.networkImages,this.address=p.getAccountData()?.address,this.profileImage=p.getAccountData()?.profileImage,this.profileName=p.getAccountData()?.profileName,this.network=p.state.activeCaipNetwork,this.disconnecting=!1,this.remoteFeatures=R.state.remoteFeatures,this.usubscribe.push(p.subscribeChainProp("accountState",t=>{t&&(this.address=t.address,this.profileImage=t.profileImage,this.profileName=t.profileName)}),p.subscribeKey("activeCaipNetwork",t=>{t?.id&&(this.network=t)}),R.subscribeKey("remoteFeatures",t=>{this.remoteFeatures=t}))}disconnectedCallback(){this.usubscribe.forEach(t=>t())}render(){if(!this.address)throw new Error("w3m-account-settings-view: No account provided");const t=this.networkImages[this.network?.assets?.imageId??""];return g`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        gap="4"
        .padding=${["0","5","3","5"]}
      >
        <wui-avatar
          alt=${this.address}
          address=${this.address}
          imageSrc=${ae(this.profileImage)}
          size="lg"
        ></wui-avatar>
        <wui-flex flexDirection="column" alignItems="center">
          <wui-flex gap="1" alignItems="center" justifyContent="center">
            <wui-text variant="h5-medium" color="primary" data-testid="account-settings-address">
              ${Fe.getTruncateString({string:this.address,charsStart:4,charsEnd:6,truncate:"middle"})}
            </wui-text>
            <wui-icon-link
              size="md"
              icon="copy"
              iconColor="default"
              @click=${this.onCopyAddress}
            ></wui-icon-link>
          </wui-flex>
        </wui-flex>
      </wui-flex>
      <wui-flex flexDirection="column" gap="4">
        <wui-flex flexDirection="column" gap="2" .padding=${["6","4","3","4"]}>
          ${this.authCardTemplate()}
          <w3m-account-auth-button></w3m-account-auth-button>
          <wui-list-item
            imageSrc=${ae(t)}
            ?chevron=${this.isAllowedNetworkSwitch()}
            ?fullSize=${!0}
            ?rounded=${!0}
            @click=${this.onNetworks.bind(this)}
            data-testid="account-switch-network-button"
          >
            <wui-text variant="lg-regular" color="primary">
              ${this.network?.name??"Unknown"}
            </wui-text>
          </wui-list-item>
          ${this.smartAccountSettingsTemplate()} ${this.chooseNameButtonTemplate()}
          <wui-list-item
            ?rounded=${!0}
            icon="power"
            iconColor="error"
            ?chevron=${!1}
            .loading=${this.disconnecting}
            @click=${this.onDisconnect.bind(this)}
            data-testid="disconnect-button"
          >
            <wui-text variant="lg-regular" color="primary">Disconnect</wui-text>
          </wui-list-item>
        </wui-flex>
      </wui-flex>
    `}chooseNameButtonTemplate(){const t=this.network?.chainNamespace,n=O.getConnectorId(t),r=O.getAuthConnector();return!p.checkIfNamesSupported()||!r||n!==N.CONNECTOR_ID.AUTH||this.profileName?null:g`
      <wui-list-item
        icon="id"
        ?rounded=${!0}
        ?chevron=${!0}
        @click=${this.onChooseName.bind(this)}
        data-testid="account-choose-name-button"
      >
        <wui-text variant="lg-regular" color="primary">Choose account name </wui-text>
      </wui-list-item>
    `}authCardTemplate(){const t=O.getConnectorId(this.network?.chainNamespace),n=O.getAuthConnector(),{origin:r}=location;return!n||t!==N.CONNECTOR_ID.AUTH||r.includes(ke.SECURE_SITE)?null:g`
      <wui-notice-card
        @click=${this.onGoToUpgradeView.bind(this)}
        label="Upgrade your wallet"
        description="Transition to a self-custodial wallet"
        icon="wallet"
        data-testid="w3m-wallet-upgrade-card"
      ></wui-notice-card>
    `}isAllowedNetworkSwitch(){const t=p.getAllRequestedCaipNetworks(),n=t?t.length>1:!1,r=t?.find(({id:o})=>o===this.network?.id);return n||!r}onCopyAddress(){try{this.address&&(L.copyToClopboard(this.address),Te.showSuccess("Address copied"))}catch{Te.showError("Failed to copy")}}smartAccountSettingsTemplate(){const t=this.network?.chainNamespace,n=p.checkIfSmartAccountEnabled(),r=O.getConnectorId(t);return!O.getAuthConnector()||r!==N.CONNECTOR_ID.AUTH||!n?null:g`
      <wui-list-item
        icon="user"
        ?rounded=${!0}
        ?chevron=${!0}
        @click=${this.onSmartAccountSettings.bind(this)}
        data-testid="account-smart-account-settings-button"
      >
        <wui-text variant="lg-regular" color="primary">Smart Account Settings</wui-text>
      </wui-list-item>
    `}onChooseName(){S.push("ChooseAccountName")}onNetworks(){this.isAllowedNetworkSwitch()&&S.push("Networks")}async onDisconnect(){try{this.disconnecting=!0;const t=this.network?.chainNamespace,r=U.getConnections(t).length>0,o=t&&O.state.activeConnectorIds[t],i=this.remoteFeatures?.multiWallet;await U.disconnect(i?{id:o,namespace:t}:{}),r&&i&&(S.push("ProfileWallets"),Te.showSuccess("Wallet deleted"))}catch{X.sendEvent({type:"track",event:"DISCONNECT_ERROR",properties:{message:"Failed to disconnect"}}),Te.showError("Failed to disconnect")}finally{this.disconnecting=!1}}onGoToUpgradeView(){X.sendEvent({type:"track",event:"EMAIL_UPGRADE_FROM_MODAL"}),S.push("UpgradeEmailWallet")}onSmartAccountSettings(){S.push("SmartAccountSettings")}};Ti([T()],vr.prototype,"address",void 0);Ti([T()],vr.prototype,"profileImage",void 0);Ti([T()],vr.prototype,"profileName",void 0);Ti([T()],vr.prototype,"network",void 0);Ti([T()],vr.prototype,"disconnecting",void 0);Ti([T()],vr.prototype,"remoteFeatures",void 0);vr=Ti([M("w3m-account-settings-view")],vr);const t5=Q`
  :host {
    flex: 1;
    height: 100%;
  }

  button {
    width: 100%;
    height: 100%;
    display: inline-flex;
    align-items: center;
    padding: ${({spacing:e})=>e[1]} ${({spacing:e})=>e[2]};
    column-gap: ${({spacing:e})=>e[1]};
    color: ${({tokens:e})=>e.theme.textSecondary};
    border-radius: ${({borderRadius:e})=>e[20]};
    background-color: transparent;
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
  }

  /* -- Hover & Active states ----------------------------------------------------------- */
  button[data-active='true'] {
    color: ${({tokens:e})=>e.theme.textPrimary};
    background-color: ${({tokens:e})=>e.theme.foregroundTertiary};
  }

  button:hover:enabled:not([data-active='true']),
  button:active:enabled:not([data-active='true']) {
    wui-text,
    wui-icon {
      color: ${({tokens:e})=>e.theme.textPrimary};
    }
  }
`;var Ks=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const n5={lg:"lg-regular",md:"md-regular",sm:"sm-regular"},r5={lg:"md",md:"sm",sm:"sm"};let ai=class extends de{constructor(){super(...arguments),this.icon="mobile",this.size="md",this.label="",this.active=!1}render(){return x`
      <button data-active=${this.active}>
        ${this.icon?x`<wui-icon size=${r5[this.size]} name=${this.icon}></wui-icon>`:""}
        <wui-text variant=${n5[this.size]}> ${this.label} </wui-text>
      </button>
    `}};ai.styles=[we,Be,t5];Ks([m()],ai.prototype,"icon",void 0);Ks([m()],ai.prototype,"size",void 0);Ks([m()],ai.prototype,"label",void 0);Ks([m({type:Boolean})],ai.prototype,"active",void 0);ai=Ks([M("wui-tab-item")],ai);const i5=Q`
  :host {
    display: inline-flex;
    align-items: center;
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    border-radius: ${({borderRadius:e})=>e[32]};
    padding: ${({spacing:e})=>e["01"]};
    box-sizing: border-box;
  }

  :host([data-size='sm']) {
    height: 26px;
  }

  :host([data-size='md']) {
    height: 36px;
  }
`;var Gs=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ci=class extends de{constructor(){super(...arguments),this.tabs=[],this.onTabChange=()=>null,this.size="md",this.activeTab=0}render(){return this.dataset.size=this.size,this.tabs.map((t,n)=>{const r=n===this.activeTab;return x`
        <wui-tab-item
          @click=${()=>this.onTabClick(n)}
          icon=${t.icon}
          size=${this.size}
          label=${t.label}
          ?active=${r}
          data-active=${r}
          data-testid="tab-${t.label?.toLowerCase()}"
        ></wui-tab-item>
      `})}onTabClick(t){this.activeTab=t,this.onTabChange(t)}};ci.styles=[we,Be,i5];Gs([m({type:Array})],ci.prototype,"tabs",void 0);Gs([m()],ci.prototype,"onTabChange",void 0);Gs([m()],ci.prototype,"size",void 0);Gs([gf()],ci.prototype,"activeTab",void 0);ci=Gs([M("wui-tabs")],ci);const o5=Q`
  :host {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: ${({spacing:e})=>e[1]};
    text-transform: uppercase;
    white-space: nowrap;
  }

  :host([data-variant='accent']) {
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
    color: ${({tokens:e})=>e.core.textAccentPrimary};
  }

  :host([data-variant='info']) {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  :host([data-variant='success']) {
    background-color: ${({tokens:e})=>e.core.backgroundSuccess};
    color: ${({tokens:e})=>e.core.textSuccess};
  }

  :host([data-variant='warning']) {
    background-color: ${({tokens:e})=>e.core.backgroundWarning};
    color: ${({tokens:e})=>e.core.textWarning};
  }

  :host([data-variant='error']) {
    background-color: ${({tokens:e})=>e.core.backgroundError};
    color: ${({tokens:e})=>e.core.textError};
  }

  :host([data-variant='certified']) {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  :host([data-size='md']) {
    height: 30px;
    padding: 0 ${({spacing:e})=>e[2]};
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  :host([data-size='sm']) {
    height: 20px;
    padding: 0 ${({spacing:e})=>e[1]};
    border-radius: ${({borderRadius:e})=>e[1]};
  }
`;var Dc=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ao=class extends de{constructor(){super(...arguments),this.variant="accent",this.size="md",this.icon=void 0}render(){this.dataset.variant=this.variant,this.dataset.size=this.size;const t=this.size==="md"?"md-medium":"sm-medium",n=this.size==="md"?"md":"sm";return x`
      ${this.icon?x`<wui-icon size=${n} name=${this.icon}></wui-icon>`:null}
      <wui-text
        display="inline"
        data-variant=${this.variant}
        variant=${t}
        color="inherit"
      >
        <slot></slot>
      </wui-text>
    `}};ao.styles=[we,o5];Dc([m()],ao.prototype,"variant",void 0);Dc([m()],ao.prototype,"size",void 0);Dc([m()],ao.prototype,"icon",void 0);ao=Dc([M("wui-tag")],ao);const s5=Q`
  button {
    display: flex;
    align-items: center;
    height: 40px;
    padding: ${({spacing:e})=>e[2]};
    border-radius: ${({borderRadius:e})=>e[4]};
    column-gap: ${({spacing:e})=>e[1]};
    background-color: transparent;
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
  }

  wui-image,
  .icon-box {
    width: ${({spacing:e})=>e[6]};
    height: ${({spacing:e})=>e[6]};
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  wui-text {
    flex: 1;
  }

  .icon-box {
    position: relative;
  }

  .icon-box[data-active='true'] {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  .circle {
    position: absolute;
    left: 16px;
    top: 15px;
    width: 8px;
    height: 8px;
    background-color: ${({tokens:e})=>e.core.textSuccess};
    box-shadow: 0 0 0 2px ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: 50%;
  }

  /* -- Hover & Active states ----------------------------------------------------------- */
  @media (hover: hover) {
    button:hover:enabled,
    button:active:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    }
  }
`;var yn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ft=class extends de{constructor(){super(...arguments),this.address="",this.profileName="",this.alt="",this.imageSrc="",this.icon=void 0,this.iconSize="md",this.enableGreenCircle=!0,this.loading=!1,this.charsStart=4,this.charsEnd=6}render(){return x`
      <button>
        ${this.leftImageTemplate()} ${this.textTemplate()} ${this.rightImageTemplate()}
      </button>
    `}leftImageTemplate(){const t=this.icon?x`<wui-icon
          size=${Qe(this.iconSize)}
          color="default"
          name=${this.icon}
          class="icon"
        ></wui-icon>`:x`<wui-image src=${this.imageSrc} alt=${this.alt}></wui-image>`;return x`
      <wui-flex
        alignItems="center"
        justifyContent="center"
        class="icon-box"
        data-active=${!!this.icon}
      >
        ${t}
        ${this.enableGreenCircle?x`<wui-flex class="circle"></wui-flex>`:null}
      </wui-flex>
    `}textTemplate(){return x`
      <wui-text variant="lg-regular" color="primary">
        ${Fe.getTruncateString({string:this.profileName||this.address,charsStart:this.profileName?16:this.charsStart,charsEnd:this.profileName?0:this.charsEnd,truncate:this.profileName?"end":"middle"})}
      </wui-text>
    `}rightImageTemplate(){return x`<wui-icon name="chevronBottom" size="sm" color="default"></wui-icon>`}};Ft.styles=[we,Be,s5];yn([m()],Ft.prototype,"address",void 0);yn([m()],Ft.prototype,"profileName",void 0);yn([m()],Ft.prototype,"alt",void 0);yn([m()],Ft.prototype,"imageSrc",void 0);yn([m()],Ft.prototype,"icon",void 0);yn([m()],Ft.prototype,"iconSize",void 0);yn([m({type:Boolean})],Ft.prototype,"enableGreenCircle",void 0);yn([m({type:Boolean})],Ft.prototype,"loading",void 0);yn([m({type:Number})],Ft.prototype,"charsStart",void 0);yn([m({type:Number})],Ft.prototype,"charsEnd",void 0);Ft=yn([M("wui-wallet-switch")],Ft);const a5=Q`
  wui-icon-link {
    margin-right: calc(${({spacing:e})=>e[8]} * -1);
  }

  wui-notice-card {
    margin-bottom: ${({spacing:e})=>e[1]};
  }

  wui-list-item > wui-text {
    flex: 1;
  }

  w3m-transactions-view {
    max-height: 200px;
  }

  .balance-container {
    display: inline;
  }

  .tab-content-container {
    height: 300px;
    overflow-y: auto;
    overflow-x: hidden;
    scrollbar-width: none;
  }

  .symbol {
    transform: translateY(-2px);
  }

  .tab-content-container::-webkit-scrollbar {
    display: none;
  }

  .account-button {
    width: auto;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: ${({spacing:e})=>e[3]};
    height: 48px;
    padding: ${({spacing:e})=>e[2]};
    padding-right: ${({spacing:e})=>e[3]};
    box-shadow: inset 0 0 0 1px ${({tokens:e})=>e.theme.foregroundPrimary};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[6]};
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
  }

  .account-button:hover {
    background-color: ${({tokens:e})=>e.core.glass010};
  }

  .avatar-container {
    position: relative;
  }

  wui-avatar.avatar {
    width: 32px;
    height: 32px;
    box-shadow: 0 0 0 2px ${({tokens:e})=>e.core.glass010};
  }

  wui-wallet-switch {
    margin-top: ${({spacing:e})=>e[2]};
  }

  wui-avatar.network-avatar {
    width: 16px;
    height: 16px;
    position: absolute;
    left: 100%;
    top: 100%;
    transform: translate(-75%, -75%);
    box-shadow: 0 0 0 2px ${({tokens:e})=>e.core.glass010};
  }

  .account-links {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .account-links wui-flex {
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1;
    background: red;
    align-items: center;
    justify-content: center;
    height: 48px;
    padding: 10px;
    flex: 1 0 0;
    border-radius: var(--XS, 16px);
    border: 1px solid var(--dark-accent-glass-010, rgba(71, 161, 255, 0.1));
    background: var(--dark-accent-glass-010, rgba(71, 161, 255, 0.1));
    transition:
      background-color ${({durations:e})=>e.md}
        ${({easings:e})=>e["ease-out-power-1"]},
      opacity ${({durations:e})=>e.md} ${({easings:e})=>e["ease-out-power-1"]};
    will-change: background-color, opacity;
  }

  .account-links wui-flex:hover {
    background: var(--dark-accent-glass-015, rgba(71, 161, 255, 0.15));
  }

  .account-links wui-flex wui-icon {
    width: var(--S, 20px);
    height: var(--S, 20px);
  }

  .account-links wui-flex wui-icon svg path {
    stroke: #667dff;
  }
`;var nn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Rt=class extends he{constructor(){super(),this.unsubscribe=[],this.caipAddress=p.getAccountData()?.caipAddress,this.address=L.getPlainAddress(p.getAccountData()?.caipAddress),this.profileImage=p.getAccountData()?.profileImage,this.profileName=p.getAccountData()?.profileName,this.disconnecting=!1,this.balance=p.getAccountData()?.balance,this.balanceSymbol=p.getAccountData()?.balanceSymbol,this.features=R.state.features,this.remoteFeatures=R.state.remoteFeatures,this.namespace=p.state.activeChain,this.activeConnectorIds=O.state.activeConnectorIds,this.unsubscribe.push(p.subscribeChainProp("accountState",t=>{this.address=L.getPlainAddress(t?.caipAddress),this.caipAddress=t?.caipAddress,this.balance=t?.balance,this.balanceSymbol=t?.balanceSymbol,this.profileName=t?.profileName,this.profileImage=t?.profileImage}),R.subscribeKey("features",t=>this.features=t),R.subscribeKey("remoteFeatures",t=>this.remoteFeatures=t),O.subscribeKey("activeConnectorIds",t=>{this.activeConnectorIds=t}),p.subscribeKey("activeChain",t=>this.namespace=t),p.subscribeKey("activeCaipNetwork",t=>{t?.chainNamespace&&(this.namespace=t?.chainNamespace)}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){if(!this.caipAddress||!this.namespace)return null;const t=this.activeConnectorIds[this.namespace],n=t?O.getConnectorById(t):void 0,r=De.getConnectorImage(n),{value:o,decimals:i,symbol:s}=L.parseBalance(this.balance,this.balanceSymbol);return g`<wui-flex
        flexDirection="column"
        .padding=${["0","5","4","5"]}
        alignItems="center"
        gap="3"
      >
        <wui-avatar
          alt=${ae(this.caipAddress)}
          address=${ae(L.getPlainAddress(this.caipAddress))}
          imageSrc=${ae(this.profileImage===null?void 0:this.profileImage)}
          data-testid="single-account-avatar"
        ></wui-avatar>
        <wui-wallet-switch
          profileName=${this.profileName}
          address=${this.address}
          imageSrc=${r}
          alt=${n?.name}
          @click=${this.onGoToProfileWalletsView.bind(this)}
          data-testid="wui-wallet-switch"
        ></wui-wallet-switch>
        <div class="balance-container">
          <wui-text variant="h3-regular" color="primary">${o}</wui-text>
          <wui-text variant="h3-regular" color="secondary">.${i}</wui-text>
          <wui-text variant="h6-medium" color="primary" class="symbol">${s}</wui-text>
        </div>
        ${this.explorerBtnTemplate()}
      </wui-flex>

      <wui-flex flexDirection="column" gap="2" .padding=${["0","3","3","3"]}>
        ${this.authCardTemplate()} <w3m-account-auth-button></w3m-account-auth-button>
        ${this.orderedFeaturesTemplate()} ${this.activityTemplate()}
        <wui-list-item
          .rounded=${!0}
          icon="power"
          iconColor="error"
          ?chevron=${!1}
          .loading=${this.disconnecting}
          .rightIcon=${!1}
          @click=${this.onDisconnect.bind(this)}
          data-testid="disconnect-button"
        >
          <wui-text variant="lg-regular" color="primary">Disconnect</wui-text>
        </wui-list-item>
      </wui-flex>`}fundWalletTemplate(){if(!this.namespace)return null;const t=ke.ONRAMP_SUPPORTED_CHAIN_NAMESPACES.includes(this.namespace),n=!!this.features?.receive,r=this.remoteFeatures?.onramp&&t,o=nt.isPayWithExchangeEnabled();return!r&&!n&&!o?null:g`
      <wui-list-item
        .rounded=${!0}
        data-testid="w3m-account-default-fund-wallet-button"
        iconVariant="blue"
        icon="dollar"
        ?chevron=${!0}
        @click=${this.handleClickFundWallet.bind(this)}
      >
        <wui-text variant="lg-regular" color="primary">Fund wallet</wui-text>
      </wui-list-item>
    `}orderedFeaturesTemplate(){return(this.features?.walletFeaturesOrder||ke.DEFAULT_FEATURES.walletFeaturesOrder).map(n=>{switch(n){case"onramp":return this.fundWalletTemplate();case"swaps":return this.swapsTemplate();case"send":return this.sendTemplate();default:return null}})}activityTemplate(){return this.namespace&&this.remoteFeatures?.activity&&ke.ACTIVITY_ENABLED_CHAIN_NAMESPACES.includes(this.namespace)?g` <wui-list-item
          .rounded=${!0}
          icon="clock"
          ?chevron=${!0}
          @click=${this.onTransactions.bind(this)}
          data-testid="w3m-account-default-activity-button"
        >
          <wui-text variant="lg-regular" color="primary">Activity</wui-text>
        </wui-list-item>`:null}swapsTemplate(){const t=this.remoteFeatures?.swaps,n=p.state.activeChain===N.CHAIN.EVM;return!t||!n?null:g`
      <wui-list-item
        .rounded=${!0}
        icon="recycleHorizontal"
        ?chevron=${!0}
        @click=${this.handleClickSwap.bind(this)}
        data-testid="w3m-account-default-swaps-button"
      >
        <wui-text variant="lg-regular" color="primary">Swap</wui-text>
      </wui-list-item>
    `}sendTemplate(){const t=this.features?.send,n=p.state.activeChain;if(!n)throw new Error("SendController:sendTemplate - namespace is required");const r=ke.SEND_SUPPORTED_NAMESPACES.includes(n);return!t||!r?null:g`
      <wui-list-item
        .rounded=${!0}
        icon="send"
        ?chevron=${!0}
        @click=${this.handleClickSend.bind(this)}
        data-testid="w3m-account-default-send-button"
      >
        <wui-text variant="lg-regular" color="primary">Send</wui-text>
      </wui-list-item>
    `}authCardTemplate(){const t=p.state.activeChain;if(!t)throw new Error("AuthCardTemplate:authCardTemplate - namespace is required");const n=O.getConnectorId(t),r=O.getAuthConnector(),{origin:o}=location;return!r||n!==N.CONNECTOR_ID.AUTH||o.includes(ke.SECURE_SITE)?null:g`
      <wui-notice-card
        @click=${this.onGoToUpgradeView.bind(this)}
        label="Upgrade your wallet"
        description="Transition to a self-custodial wallet"
        icon="wallet"
        data-testid="w3m-wallet-upgrade-card"
      ></wui-notice-card>
    `}handleClickFundWallet(){S.push("FundWallet")}handleClickSwap(){S.push("Swap")}handleClickSend(){S.push("WalletSend")}explorerBtnTemplate(){return p.getAccountData()?.addressExplorerUrl?g`
      <wui-button size="md" variant="accent-primary" @click=${this.onExplorer.bind(this)}>
        <wui-icon size="sm" color="inherit" slot="iconLeft" name="compass"></wui-icon>
        Block Explorer
        <wui-icon size="sm" color="inherit" slot="iconRight" name="externalLink"></wui-icon>
      </wui-button>
    `:null}onTransactions(){X.sendEvent({type:"track",event:"CLICK_TRANSACTIONS",properties:{isSmartAccount:ut(p.state.activeChain)===je.ACCOUNT_TYPES.SMART_ACCOUNT}}),S.push("Transactions")}async onDisconnect(){try{this.disconnecting=!0;const n=U.getConnections(this.namespace).length>0,r=this.namespace&&O.state.activeConnectorIds[this.namespace],o=this.remoteFeatures?.multiWallet;await U.disconnect(o?{id:r,namespace:this.namespace}:{}),n&&o&&(S.push("ProfileWallets"),Te.showSuccess("Wallet deleted"))}catch{X.sendEvent({type:"track",event:"DISCONNECT_ERROR",properties:{message:"Failed to disconnect"}}),Te.showError("Failed to disconnect")}finally{this.disconnecting=!1}}onExplorer(){const t=p.getAccountData()?.addressExplorerUrl;t&&L.openHref(t,"_blank")}onGoToUpgradeView(){X.sendEvent({type:"track",event:"EMAIL_UPGRADE_FROM_MODAL"}),S.push("UpgradeEmailWallet")}onGoToProfileWalletsView(){S.push("ProfileWallets")}};Rt.styles=a5;nn([T()],Rt.prototype,"caipAddress",void 0);nn([T()],Rt.prototype,"address",void 0);nn([T()],Rt.prototype,"profileImage",void 0);nn([T()],Rt.prototype,"profileName",void 0);nn([T()],Rt.prototype,"disconnecting",void 0);nn([T()],Rt.prototype,"balance",void 0);nn([T()],Rt.prototype,"balanceSymbol",void 0);nn([T()],Rt.prototype,"features",void 0);nn([T()],Rt.prototype,"remoteFeatures",void 0);nn([T()],Rt.prototype,"namespace",void 0);nn([T()],Rt.prototype,"activeConnectorIds",void 0);Rt=nn([M("w3m-account-default-widget")],Rt);const c5=Q`
  span {
    font-weight: 500;
    font-size: 38px;
    color: ${({tokens:e})=>e.theme.textPrimary};
    line-height: 38px;
    letter-spacing: -2%;
    text-align: center;
    font-family: var(--apkt-fontFamily-regular);
  }

  .pennies {
    color: ${({tokens:e})=>e.theme.textSecondary};
  }
`;var Yd=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ns=class extends de{constructor(){super(...arguments),this.dollars="0",this.pennies="00"}render(){return x`<span>$${this.dollars}<span class="pennies">.${this.pennies}</span></span>`}};Ns.styles=[we,c5];Yd([m()],Ns.prototype,"dollars",void 0);Yd([m()],Ns.prototype,"pennies",void 0);Ns=Yd([M("wui-balance")],Ns);const l5=Q`
  :host {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    position: relative;
  }

  wui-icon {
    position: absolute;
    width: 12px !important;
    height: 4px !important;
  }

  /* -- Variants --------------------------------------------------------- */
  :host([data-variant='fill']) {
    background-color: ${({colors:e})=>e.neutrals100};
  }

  :host([data-variant='shade']) {
    background-color: ${({colors:e})=>e.neutrals900};
  }

  :host([data-variant='fill']) > wui-text {
    color: ${({colors:e})=>e.black};
  }

  :host([data-variant='shade']) > wui-text {
    color: ${({colors:e})=>e.white};
  }

  :host([data-variant='fill']) > wui-icon {
    color: ${({colors:e})=>e.neutrals100};
  }

  :host([data-variant='shade']) > wui-icon {
    color: ${({colors:e})=>e.neutrals900};
  }

  /* -- Sizes --------------------------------------------------------- */
  :host([data-size='sm']) {
    padding: ${({spacing:e})=>e[1]} ${({spacing:e})=>e[2]};
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  :host([data-size='md']) {
    padding: ${({spacing:e})=>e[2]} ${({spacing:e})=>e[3]};
    border-radius: ${({borderRadius:e})=>e[3]};
  }

  /* -- Placements --------------------------------------------------------- */
  wui-icon[data-placement='top'] {
    bottom: 0px;
    left: 50%;
    transform: translate(-50%, 95%);
  }

  wui-icon[data-placement='bottom'] {
    top: 0;
    left: 50%;
    transform: translate(-50%, -95%) rotate(180deg);
  }

  wui-icon[data-placement='right'] {
    top: 50%;
    left: 0;
    transform: translate(-65%, -50%) rotate(90deg);
  }

  wui-icon[data-placement='left'] {
    top: 50%;
    right: 0%;
    transform: translate(65%, -50%) rotate(270deg);
  }
`;var Zs=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const d5={sm:"sm-regular",md:"md-regular"};let li=class extends de{constructor(){super(...arguments),this.placement="top",this.variant="fill",this.size="md",this.message=""}render(){return this.dataset.variant=this.variant,this.dataset.size=this.size,x`<wui-icon data-placement=${this.placement} size="inherit" name="cursor"></wui-icon>
      <wui-text variant=${d5[this.size]}>${this.message}</wui-text>`}};li.styles=[we,Be,l5];Zs([m()],li.prototype,"placement",void 0);Zs([m()],li.prototype,"variant",void 0);Zs([m()],li.prototype,"size",void 0);Zs([m()],li.prototype,"message",void 0);li=Zs([M("wui-tooltip")],li);var ld;(function(e){e.approve="approved",e.bought="bought",e.borrow="borrowed",e.burn="burnt",e.cancel="canceled",e.claim="claimed",e.deploy="deployed",e.deposit="deposited",e.execute="executed",e.mint="minted",e.receive="received",e.repay="repaid",e.send="sent",e.sell="sold",e.stake="staked",e.trade="swapped",e.unstake="unstaked",e.withdraw="withdrawn"})(ld||(ld={}));const u5=Q`
  :host > wui-flex {
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    width: 40px;
    height: 40px;
    box-shadow: inset 0 0 0 1px ${({tokens:e})=>e.core.glass010};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  :host([data-no-images='true']) > wui-flex {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[3]} !important;
  }

  :host > wui-flex wui-image {
    display: block;
  }

  :host > wui-flex,
  :host > wui-flex wui-image,
  .swap-images-container,
  .swap-images-container.nft,
  wui-image.nft {
    border-top-left-radius: var(--local-left-border-radius);
    border-top-right-radius: var(--local-right-border-radius);
    border-bottom-left-radius: var(--local-left-border-radius);
    border-bottom-right-radius: var(--local-right-border-radius);
  }

  .swap-images-container {
    position: relative;
    width: 40px;
    height: 40px;
    overflow: hidden;
  }

  .swap-images-container wui-image:first-child {
    position: absolute;
    width: 40px;
    height: 40px;
    top: 0;
    left: 0%;
    clip-path: inset(0px calc(50% + 2px) 0px 0%);
  }

  .swap-images-container wui-image:last-child {
    clip-path: inset(0px 0px 0px calc(50% + 2px));
  }

  .swap-fallback-container {
    position: absolute;
    inset: 0;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .swap-fallback-container.first {
    clip-path: inset(0px calc(50% + 2px) 0px 0%);
  }

  .swap-fallback-container.last {
    clip-path: inset(0px 0px 0px calc(50% + 2px));
  }

  wui-flex.status-box {
    position: absolute;
    right: 0;
    bottom: 0;
    transform: translate(20%, 20%);
    border-radius: ${({borderRadius:e})=>e[4]};
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
    box-shadow: 0 0 0 2px ${({tokens:e})=>e.theme.backgroundPrimary};
    overflow: hidden;
    width: 16px;
    height: 16px;
  }
`;var $r=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let On=class extends de{constructor(){super(...arguments),this.images=[],this.secondImage={type:void 0,url:""},this.failedImageUrls=new Set}handleImageError(t){return n=>{n.stopPropagation(),this.failedImageUrls.add(t),this.requestUpdate()}}render(){const[t,n]=this.images;this.images.length||(this.dataset.noImages="true");const r=t?.type==="NFT",o=n?.url?n.type==="NFT":r,i=r?"var(--apkt-borderRadius-3)":"var(--apkt-borderRadius-5)",s=o?"var(--apkt-borderRadius-3)":"var(--apkt-borderRadius-5)";return this.style.cssText=`
    --local-left-border-radius: ${i};
    --local-right-border-radius: ${s};
    `,x`<wui-flex> ${this.templateVisual()} ${this.templateIcon()} </wui-flex>`}templateVisual(){const[t,n]=this.images;return this.images.length===2&&(t?.url||n?.url)?this.renderSwapImages(t,n):t?.url&&!this.failedImageUrls.has(t.url)?this.renderSingleImage(t):t?.type==="NFT"?this.renderPlaceholderIcon("nftPlaceholder"):this.renderPlaceholderIcon("coinPlaceholder")}renderSwapImages(t,n){return x`<div class="swap-images-container">
      ${t?.url?this.renderImageOrFallback(t,"first",!0):null}
      ${n?.url?this.renderImageOrFallback(n,"last",!0):null}
    </div>`}renderSingleImage(t){return this.renderImageOrFallback(t,void 0,!1)}renderImageOrFallback(t,n,r=!1){return t.url?this.failedImageUrls.has(t.url)?r&&n?this.renderFallbackIconInContainer(n):this.renderFallbackIcon():x`<wui-image
      src=${t.url}
      alt="Transaction image"
      @onLoadError=${this.handleImageError(t.url)}
    ></wui-image>`:null}renderFallbackIconInContainer(t){return x`<div class="swap-fallback-container ${t}">${this.renderFallbackIcon()}</div>`}renderFallbackIcon(){return x`<wui-icon
      size="xl"
      weight="regular"
      color="default"
      name="networkPlaceholder"
    ></wui-icon>`}renderPlaceholderIcon(t){return x`<wui-icon size="xl" weight="regular" color="default" name=${t}></wui-icon>`}templateIcon(){let t="accent-primary",n;return n=this.getIcon(),this.status&&(t=this.getStatusColor()),n?x`
      <wui-flex alignItems="center" justifyContent="center" class="status-box">
        <wui-icon-box size="sm" color=${t} icon=${n}></wui-icon-box>
      </wui-flex>
    `:null}getDirectionIcon(){switch(this.direction){case"in":return"arrowBottom";case"out":return"arrowTop";default:return}}getIcon(){return this.onlyDirectionIcon?this.getDirectionIcon():this.type==="trade"?"swapHorizontal":this.type==="approve"?"checkmark":this.type==="cancel"?"close":this.getDirectionIcon()}getStatusColor(){switch(this.status){case"confirmed":return"success";case"failed":return"error";case"pending":return"inverse";default:return"accent-primary"}}};On.styles=[u5];$r([m()],On.prototype,"type",void 0);$r([m()],On.prototype,"status",void 0);$r([m()],On.prototype,"direction",void 0);$r([m({type:Boolean})],On.prototype,"onlyDirectionIcon",void 0);$r([m({type:Array})],On.prototype,"images",void 0);$r([m({type:Object})],On.prototype,"secondImage",void 0);$r([gf()],On.prototype,"failedImageUrls",void 0);On=$r([M("wui-transaction-visual")],On);const h5=Q`
  :host {
    width: 100%;
  }

  :host > wui-flex:first-child {
    align-items: center;
    column-gap: ${({spacing:e})=>e[2]};
    padding: ${({spacing:e})=>e[1]} ${({spacing:e})=>e[2]};
    width: 100%;
  }

  :host > wui-flex:first-child wui-text:nth-child(1) {
    text-transform: capitalize;
  }

  wui-transaction-visual {
    width: 40px;
    height: 40px;
  }

  wui-flex {
    flex: 1;
  }

  :host wui-flex wui-flex {
    overflow: hidden;
  }

  :host .description-container wui-text span {
    word-break: break-all;
  }

  :host .description-container wui-text {
    overflow: hidden;
  }

  :host .description-separator-icon {
    margin: 0px 6px;
  }

  :host wui-text > span {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }
`;var Nr=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Pn=class extends de{constructor(){super(...arguments),this.type="approve",this.onlyDirectionIcon=!1,this.images=[]}render(){return x`
      <wui-flex>
        <wui-transaction-visual
          .status=${this.status}
          direction=${Qe(this.direction)}
          type=${this.type}
          .onlyDirectionIcon=${this.onlyDirectionIcon}
          .images=${this.images}
        ></wui-transaction-visual>
        <wui-flex flexDirection="column" gap="1">
          <wui-text variant="lg-medium" color="primary">
            ${ld[this.type]||this.type}
          </wui-text>
          <wui-flex class="description-container">
            ${this.templateDescription()} ${this.templateSecondDescription()}
          </wui-flex>
        </wui-flex>
        <wui-text variant="sm-medium" color="secondary"><span>${this.date}</span></wui-text>
      </wui-flex>
    `}templateDescription(){const t=this.descriptions?.[0];return t?x`
          <wui-text variant="md-regular" color="secondary">
            <span>${t}</span>
          </wui-text>
        `:null}templateSecondDescription(){const t=this.descriptions?.[1];return t?x`
          <wui-icon class="description-separator-icon" size="sm" name="arrowRight"></wui-icon>
          <wui-text variant="md-regular" color="secondary">
            <span>${t}</span>
          </wui-text>
        `:null}};Pn.styles=[we,h5];Nr([m()],Pn.prototype,"type",void 0);Nr([m({type:Array})],Pn.prototype,"descriptions",void 0);Nr([m()],Pn.prototype,"date",void 0);Nr([m({type:Boolean})],Pn.prototype,"onlyDirectionIcon",void 0);Nr([m()],Pn.prototype,"status",void 0);Nr([m()],Pn.prototype,"direction",void 0);Nr([m({type:Array})],Pn.prototype,"images",void 0);Pn=Nr([M("wui-transaction-list-item")],Pn);const p5=Q`
  :host {
    display: block;
    background: linear-gradient(
      90deg,
      ${({tokens:e})=>e.theme.foregroundPrimary} 0%,
      ${({tokens:e})=>e.theme.foregroundSecondary} 50%,
      ${({tokens:e})=>e.theme.foregroundPrimary} 100%
    );
    background-size: 200% 100%;
    animation: shimmer 2s linear infinite;
    border-radius: ${({borderRadius:e})=>e[1]};
  }

  :host([data-rounded='true']) {
    border-radius: ${({borderRadius:e})=>e[16]};
  }

  @keyframes shimmer {
    0% {
      background-position: 100% 0;
    }
    100% {
      background-position: -100% 0;
    }
  }
`;var Ys=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let di=class extends de{constructor(){super(...arguments),this.width="",this.height="",this.variant="default",this.rounded=!1}render(){return this.style.cssText=`
      width: ${this.width};
      height: ${this.height};
    `,this.dataset.rounded=this.rounded?"true":"false",x`<slot></slot>`}};di.styles=[p5];Ys([m()],di.prototype,"width",void 0);Ys([m()],di.prototype,"height",void 0);Ys([m()],di.prototype,"variant",void 0);Ys([m({type:Boolean})],di.prototype,"rounded",void 0);di=Ys([M("wui-shimmer")],di);const f5=Q`
  wui-flex {
    position: relative;
    display: inline-flex;
    justify-content: center;
    align-items: center;
  }

  wui-image {
    border-radius: ${({borderRadius:e})=>e[128]};
  }

  .fallback-icon {
    color: ${({tokens:e})=>e.theme.iconInverse};
    border-radius: ${({borderRadius:e})=>e[3]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  .direction-icon,
  .status-image {
    position: absolute;
    right: 0;
    bottom: 0;
    border-radius: ${({borderRadius:e})=>e[128]};
    border: 2px solid ${({tokens:e})=>e.theme.backgroundPrimary};
  }

  .direction-icon {
    padding: ${({spacing:e})=>e["01"]};
    color: ${({tokens:e})=>e.core.iconSuccess};

    background-color: color-mix(
      in srgb,
      ${({tokens:e})=>e.core.textSuccess} 30%,
      ${({tokens:e})=>e.theme.backgroundPrimary} 70%
    );
  }

  /* -- Sizes --------------------------------------------------- */
  :host([data-size='sm']) > wui-image:not(.status-image),
  :host([data-size='sm']) > wui-flex {
    width: 24px;
    height: 24px;
  }

  :host([data-size='lg']) > wui-image:not(.status-image),
  :host([data-size='lg']) > wui-flex {
    width: 40px;
    height: 40px;
  }

  :host([data-size='sm']) .fallback-icon {
    height: 16px;
    width: 16px;
    padding: ${({spacing:e})=>e[1]};
  }

  :host([data-size='lg']) .fallback-icon {
    height: 32px;
    width: 32px;
    padding: ${({spacing:e})=>e[1]};
  }

  :host([data-size='sm']) .direction-icon,
  :host([data-size='sm']) .status-image {
    transform: translate(40%, 30%);
  }

  :host([data-size='lg']) .direction-icon,
  :host([data-size='lg']) .status-image {
    transform: translate(40%, 10%);
  }

  :host([data-size='sm']) .status-image {
    height: 14px;
    width: 14px;
  }

  :host([data-size='lg']) .status-image {
    height: 20px;
    width: 20px;
  }

  /* -- Crop effects --------------------------------------------------- */
  .swap-crop-left-image,
  .swap-crop-right-image {
    position: absolute;
    top: 0;
    bottom: 0;
  }

  .swap-crop-left-image {
    left: 0;
    clip-path: inset(0px calc(50% + 1.5px) 0px 0%);
  }

  .swap-crop-right-image {
    right: 0;
    clip-path: inset(0px 0px 0px calc(50% + 1.5px));
  }
`;var Js=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const al={sm:"xxs",lg:"md"};let ui=class extends de{constructor(){super(...arguments),this.type="approve",this.size="lg",this.statusImageUrl="",this.images=[]}render(){return x`<wui-flex>${this.templateVisual()} ${this.templateIcon()}</wui-flex>`}templateVisual(){switch(this.dataset.size=this.size,this.type){case"trade":return this.swapTemplate();case"fiat":return this.fiatTemplate();case"unknown":return this.unknownTemplate();default:return this.tokenTemplate()}}swapTemplate(){const[t,n]=this.images;return this.images.length===2&&(t||n)?x`
        <wui-image class="swap-crop-left-image" src=${t} alt="Swap image"></wui-image>
        <wui-image class="swap-crop-right-image" src=${n} alt="Swap image"></wui-image>
      `:t?x`<wui-image src=${t} alt="Swap image"></wui-image>`:null}fiatTemplate(){return x`<wui-icon
      class="fallback-icon"
      size=${al[this.size]}
      name="dollar"
    ></wui-icon>`}unknownTemplate(){return x`<wui-icon
      class="fallback-icon"
      size=${al[this.size]}
      name="questionMark"
    ></wui-icon>`}tokenTemplate(){const[t]=this.images;return t?x`<wui-image src=${t} alt="Token image"></wui-image> `:x`<wui-icon
      class="fallback-icon"
      name=${this.type==="nft"?"image":"coinPlaceholder"}
    ></wui-icon>`}templateIcon(){return this.statusImageUrl?x`<wui-image
        class="status-image"
        src=${this.statusImageUrl}
        alt="Status image"
      ></wui-image>`:x`<wui-icon
      class="direction-icon"
      size=${al[this.size]}
      name=${this.getTemplateIcon()}
    ></wui-icon>`}getTemplateIcon(){return this.type==="trade"?"arrowClockWise":"arrowBottom"}};ui.styles=[f5];Js([m()],ui.prototype,"type",void 0);Js([m()],ui.prototype,"size",void 0);Js([m()],ui.prototype,"statusImageUrl",void 0);Js([m({type:Array})],ui.prototype,"images",void 0);ui=Js([M("wui-transaction-thumbnail")],ui);const m5=Q`
  :host > wui-flex:first-child {
    gap: ${({spacing:e})=>e[2]};
    padding: ${({spacing:e})=>e[3]};
    width: 100%;
  }

  wui-flex {
    display: flex;
    flex: 1;
  }
`;var g5=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let dd=class extends de{render(){return x`
      <wui-flex alignItems="center" .padding=${["1","2","1","2"]}>
        <wui-shimmer width="40px" height="40px" rounded></wui-shimmer>
        <wui-flex flexDirection="column" gap="1">
          <wui-shimmer width="124px" height="16px" rounded></wui-shimmer>
          <wui-shimmer width="60px" height="14px" rounded></wui-shimmer>
        </wui-flex>
        <wui-shimmer width="24px" height="12px" rounded></wui-shimmer>
      </wui-flex>
    `}};dd.styles=[we,m5];dd=g5([M("wui-transaction-list-item-loader")],dd);const w5=Q`
  :host {
    min-height: 100%;
  }

  .group-container[last-group='true'] {
    padding-bottom: ${({spacing:e})=>e[3]};
  }

  .contentContainer {
    height: 280px;
  }

  .contentContainer > wui-icon-box {
    width: 40px;
    height: 40px;
    border-radius: ${({borderRadius:e})=>e[3]};
  }

  .contentContainer > .textContent {
    width: 65%;
  }

  .emptyContainer {
    height: 100%;
  }
`;var $i=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const $h="last-transaction",b5=7;let Qn=class extends he{constructor(){super(),this.unsubscribe=[],this.paginationObserver=void 0,this.page="activity",this.caipAddress=p.state.activeCaipAddress,this.transactionsByYear=vt.state.transactionsByYear,this.loading=vt.state.loading,this.empty=vt.state.empty,this.next=vt.state.next,vt.clearCursor(),this.unsubscribe.push(p.subscribeKey("activeCaipAddress",t=>{t&&this.caipAddress!==t&&(vt.resetTransactions(),vt.fetchTransactions(t)),this.caipAddress=t}),p.subscribeKey("activeCaipNetwork",()=>{this.updateTransactionView()}),vt.subscribe(t=>{this.transactionsByYear=t.transactionsByYear,this.loading=t.loading,this.empty=t.empty,this.next=t.next}))}firstUpdated(){this.updateTransactionView(),this.createPaginationObserver()}updated(){this.setPaginationObserver()}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return g` ${this.empty?null:this.templateTransactionsByYear()}
    ${this.loading?this.templateLoading():null}
    ${!this.loading&&this.empty?this.templateEmpty():null}`}updateTransactionView(){vt.resetTransactions(),this.caipAddress&&vt.fetchTransactions(L.getPlainAddress(this.caipAddress))}templateTransactionsByYear(){return Object.keys(this.transactionsByYear).sort().reverse().map(n=>{const r=parseInt(n,10),o=new Array(12).fill(null).map((i,s)=>{const a=zi.getTransactionGroupTitle(r,s),c=this.transactionsByYear[r]?.[s];return{groupTitle:a,transactions:c}}).filter(({transactions:i})=>i).reverse();return o.map(({groupTitle:i,transactions:s},a)=>{const c=a===o.length-1;return s?g`
          <wui-flex
            flexDirection="column"
            class="group-container"
            last-group="${c?"true":"false"}"
            data-testid="month-indexes"
          >
            <wui-flex
              alignItems="center"
              flexDirection="row"
              .padding=${["2","3","3","3"]}
            >
              <wui-text variant="md-medium" color="secondary" data-testid="group-title">
                ${i}
              </wui-text>
            </wui-flex>
            <wui-flex flexDirection="column" gap="2">
              ${this.templateTransactions(s,c)}
            </wui-flex>
          </wui-flex>
        `:null})})}templateRenderTransaction(t,n){const{date:r,descriptions:o,direction:i,images:s,status:a,type:c,transfers:l,isAllNFT:d}=this.getTransactionListItemProps(t);return g`
      <wui-transaction-list-item
        date=${r}
        .direction=${i}
        id=${n&&this.next?$h:""}
        status=${a}
        type=${c}
        .images=${s}
        .onlyDirectionIcon=${d||l.length===1}
        .descriptions=${o}
      ></wui-transaction-list-item>
    `}templateTransactions(t,n){return t.map((r,o)=>{const i=n&&o===t.length-1;return g`${this.templateRenderTransaction(r,i)}`})}emptyStateActivity(){return g`<wui-flex
      class="emptyContainer"
      flexGrow="1"
      flexDirection="column"
      justifyContent="center"
      alignItems="center"
      .padding=${["10","5","10","5"]}
      gap="5"
      data-testid="empty-activity-state"
    >
      <wui-icon-box color="default" icon="wallet" size="xl"></wui-icon-box>
      <wui-flex flexDirection="column" alignItems="center" gap="2">
        <wui-text align="center" variant="lg-medium" color="primary">No Transactions yet</wui-text>
        <wui-text align="center" variant="lg-regular" color="secondary"
          >Start trading on dApps <br />
          to grow your wallet!</wui-text
        >
      </wui-flex>
    </wui-flex>`}emptyStateAccount(){return g`<wui-flex
      class="contentContainer"
      alignItems="center"
      justifyContent="center"
      flexDirection="column"
      gap="4"
      data-testid="empty-account-state"
    >
      <wui-icon-box icon="swapHorizontal" size="lg" color="default"></wui-icon-box>
      <wui-flex
        class="textContent"
        gap="2"
        flexDirection="column"
        justifyContent="center"
        flexDirection="column"
      >
        <wui-text variant="md-regular" align="center" color="primary">No activity yet</wui-text>
        <wui-text variant="sm-regular" align="center" color="secondary"
          >Your next transactions will appear here</wui-text
        >
      </wui-flex>
      <wui-link @click=${this.onReceiveClick.bind(this)}>Trade</wui-link>
    </wui-flex>`}templateEmpty(){return this.page==="account"?g`${this.emptyStateAccount()}`:g`${this.emptyStateActivity()}`}templateLoading(){return this.page==="activity"?g` <wui-flex flexDirection="column" width="100%">
        <wui-flex .padding=${["2","3","3","3"]}>
          <wui-shimmer width="70px" height="16px" rounded></wui-shimmer>
        </wui-flex>
        <wui-flex flexDirection="column" gap="2" width="100%">
          ${Array(b5).fill(g` <wui-transaction-list-item-loader></wui-transaction-list-item-loader> `).map(t=>t)}
        </wui-flex>
      </wui-flex>`:null}onReceiveClick(){S.push("WalletReceive")}createPaginationObserver(){const{projectId:t}=R.state;this.paginationObserver=new IntersectionObserver(([n])=>{n?.isIntersecting&&!this.loading&&(vt.fetchTransactions(L.getPlainAddress(this.caipAddress)),X.sendEvent({type:"track",event:"LOAD_MORE_TRANSACTIONS",properties:{address:L.getPlainAddress(this.caipAddress),projectId:t,cursor:this.next,isSmartAccount:ut(p.state.activeChain)===je.ACCOUNT_TYPES.SMART_ACCOUNT}}))},{}),this.setPaginationObserver()}setPaginationObserver(){this.paginationObserver?.disconnect();const t=this.shadowRoot?.querySelector(`#${$h}`);t&&this.paginationObserver?.observe(t)}getTransactionListItemProps(t){const n=Wl.formatDate(t?.metadata?.minedAt),r=zi.mergeTransfers(t?.transfers||[]),o=zi.getTransactionDescriptions(t,r),i=r?.[0],s=!!i&&r?.every(c=>!!c.nft_info),a=zi.getTransactionImages(r);return{date:n,direction:i?.direction,descriptions:o,isAllNFT:s,images:a,status:t.metadata?.status,transfers:r,type:t.metadata?.operationType}}};Qn.styles=w5;$i([ve()],Qn.prototype,"page",void 0);$i([T()],Qn.prototype,"caipAddress",void 0);$i([T()],Qn.prototype,"transactionsByYear",void 0);$i([T()],Qn.prototype,"loading",void 0);$i([T()],Qn.prototype,"empty",void 0);$i([T()],Qn.prototype,"next",void 0);Qn=$i([M("w3m-activity-list")],Qn);const y5=Vt`
  :host {
    width: 100%;
    max-height: 280px;
    overflow: scroll;
    scrollbar-width: none;
  }

  :host::-webkit-scrollbar {
    display: none;
  }
`;var C5=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ud=class extends he{render(){return g`<w3m-activity-list page="account"></w3m-activity-list>`}};ud.styles=y5;ud=C5([M("w3m-account-activity-widget")],ud);const v5=Q`
  :host {
    width: 100%;
  }

  button {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: ${({spacing:e})=>e[4]};
    padding: ${({spacing:e})=>e[4]};
    background-color: transparent;
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  wui-text {
    max-width: 174px;
  }

  .tag-container {
    width: fit-content;
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    }
  }
`;var bo=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Er=class extends de{constructor(){super(...arguments),this.icon="card",this.text="",this.description="",this.tag=void 0,this.disabled=!1}render(){return x`
      <button ?disabled=${this.disabled}>
        <wui-flex alignItems="center" gap="3">
          <wui-icon-box padding="2" color="secondary" icon=${this.icon} size="lg"></wui-icon-box>
          <wui-flex flexDirection="column" gap="1">
            <wui-text variant="md-medium" color="primary">${this.text}</wui-text>
            ${this.description?x`<wui-text variant="md-regular" color="secondary">
                  ${this.description}</wui-text
                >`:null}
          </wui-flex>
        </wui-flex>

        <wui-flex class="tag-container" alignItems="center" gap="1" justifyContent="flex-end">
          ${this.tag?x`<wui-tag tagType="main" size="sm">${this.tag}</wui-tag>`:null}
          <wui-icon size="md" name="chevronRight" color="default"></wui-icon>
        </wui-flex>
      </button>
    `}};Er.styles=[we,Be,v5];bo([m()],Er.prototype,"icon",void 0);bo([m()],Er.prototype,"text",void 0);bo([m()],Er.prototype,"description",void 0);bo([m()],Er.prototype,"tag",void 0);bo([m({type:Boolean})],Er.prototype,"disabled",void 0);Er=bo([M("wui-list-description")],Er);const E5=Q`
  :host {
    width: 100%;
  }

  button {
    padding: ${({spacing:e})=>e[3]};
    display: flex;
    gap: ${({spacing:e})=>e[3]};
    justify-content: space-between;
    width: 100%;
    border-radius: ${({borderRadius:e})=>e[4]};
    background-color: transparent;
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }

  button:focus-visible:enabled {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    box-shadow: 0 0 0 4px ${({tokens:e})=>e.core.foregroundAccent040};
  }

  button[data-clickable='false'] {
    pointer-events: none;
    background-color: transparent;
  }

  wui-image,
  wui-icon {
    width: ${({spacing:e})=>e[10]};
    height: ${({spacing:e})=>e[10]};
  }

  wui-image {
    border-radius: ${({borderRadius:e})=>e[16]};
  }

  .token-name-container {
    flex: 1;
  }
`;var Ni=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let er=class extends de{constructor(){super(...arguments),this.tokenName="",this.tokenImageUrl="",this.tokenValue=0,this.tokenAmount="0.0",this.tokenCurrency="",this.clickable=!1}render(){return x`
      <button data-clickable=${String(this.clickable)}>
        <wui-flex gap="2" alignItems="center">
          ${this.visualTemplate()}
          <wui-flex
            flexDirection="column"
            justifyContent="space-between"
            gap="1"
            class="token-name-container"
          >
            <wui-text variant="md-regular" color="primary" lineClamp="1">
              ${this.tokenName}
            </wui-text>
            <wui-text variant="sm-regular-mono" color="secondary">
              ${Ji.formatNumberToLocalString(this.tokenAmount,4)} ${this.tokenCurrency}
            </wui-text>
          </wui-flex>
        </wui-flex>
        <wui-flex
          flexDirection="column"
          justifyContent="space-between"
          gap="1"
          alignItems="flex-end"
          width="auto"
        >
          <wui-text variant="md-regular-mono" color="primary"
            >$${this.tokenValue.toFixed(2)}</wui-text
          >
          <wui-text variant="sm-regular-mono" color="secondary">
            ${Ji.formatNumberToLocalString(this.tokenAmount,4)}
          </wui-text>
        </wui-flex>
      </button>
    `}visualTemplate(){return this.tokenName&&this.tokenImageUrl?x`<wui-image alt=${this.tokenName} src=${this.tokenImageUrl}></wui-image>`:x`<wui-icon name="coinPlaceholder" color="default"></wui-icon>`}};er.styles=[we,Be,E5];Ni([m()],er.prototype,"tokenName",void 0);Ni([m()],er.prototype,"tokenImageUrl",void 0);Ni([m({type:Number})],er.prototype,"tokenValue",void 0);Ni([m()],er.prototype,"tokenAmount",void 0);Ni([m()],er.prototype,"tokenCurrency",void 0);Ni([m({type:Boolean})],er.prototype,"clickable",void 0);er=Ni([M("wui-list-token")],er);const _5=Vt`
  :host {
    width: 100%;
  }

  wui-flex {
    width: 100%;
  }

  .contentContainer {
    max-height: 280px;
    overflow: scroll;
    scrollbar-width: none;
  }

  .contentContainer::-webkit-scrollbar {
    display: none;
  }
`;var Jd=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Rs=class extends he{constructor(){super(),this.unsubscribe=[],this.tokenBalance=p.getAccountData()?.tokenBalance,this.remoteFeatures=R.state.remoteFeatures,this.unsubscribe.push(p.subscribeChainProp("accountState",t=>{this.tokenBalance=t?.tokenBalance}),R.subscribeKey("remoteFeatures",t=>{this.remoteFeatures=t}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return g`${this.tokenTemplate()}`}tokenTemplate(){return this.tokenBalance&&this.tokenBalance?.length>0?g`<wui-flex class="contentContainer" flexDirection="column" gap="2">
        ${this.tokenItemTemplate()}
      </wui-flex>`:g` <wui-flex flexDirection="column">
      ${this.onRampTemplate()}
      <wui-list-description
        @click=${this.onReceiveClick.bind(this)}
        text="Receive funds"
        description="Scan the QR code and receive funds"
        icon="qrCode"
        iconColor="fg-200"
        iconBackgroundColor="fg-200"
        data-testid="w3m-account-receive-button"
      ></wui-list-description
    ></wui-flex>`}onRampTemplate(){return this.remoteFeatures?.onramp?g`<wui-list-description
        @click=${this.onBuyClick.bind(this)}
        text="Buy Crypto"
        description="Easy with card or bank account"
        icon="card"
        iconColor="success-100"
        iconBackgroundColor="success-100"
        tag="popular"
        data-testid="w3m-account-onramp-button"
      ></wui-list-description>`:g``}tokenItemTemplate(){return this.tokenBalance?.map(t=>g`<wui-list-token
          tokenName=${t.name}
          tokenImageUrl=${t.iconUrl}
          tokenAmount=${t.quantity.numeric}
          tokenValue=${t.value}
          tokenCurrency=${t.symbol}
        ></wui-list-token>`)}onReceiveClick(){S.push("WalletReceive")}onBuyClick(){X.sendEvent({type:"track",event:"SELECT_BUY_CRYPTO",properties:{isSmartAccount:ut(p.state.activeChain)===je.ACCOUNT_TYPES.SMART_ACCOUNT}}),S.push("OnRampProviders")}};Rs.styles=_5;Jd([T()],Rs.prototype,"tokenBalance",void 0);Jd([T()],Rs.prototype,"remoteFeatures",void 0);Rs=Jd([M("w3m-account-tokens-widget")],Rs);const A5=Vt`
  :host {
    width: 100%;
    display: block;
  }
`;var Xd=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ks=class extends he{constructor(){super(),this.unsubscribe=[],this.text="",this.open=Zt.state.open,this.unsubscribe.push(S.subscribeKey("view",()=>{Zt.hide()}),ye.subscribeKey("open",t=>{t||Zt.hide()}),Zt.subscribeKey("open",t=>{this.open=t}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t()),Zt.hide()}render(){return g`
      <div
        @pointermove=${this.onMouseEnter.bind(this)}
        @pointerleave=${this.onMouseLeave.bind(this)}
      >
        ${this.renderChildren()}
      </div>
    `}renderChildren(){return g`<slot></slot> `}onMouseEnter(){const t=this.getBoundingClientRect();if(!this.open){const n=document.querySelector("w3m-modal"),r={width:t.width,height:t.height,left:t.left,top:t.top};if(n){const o=n.getBoundingClientRect();r.left=t.left-(window.innerWidth-o.width)/2,r.top=t.top-(window.innerHeight-o.height)/2}Zt.showTooltip({message:this.text,triggerRect:r,variant:"shade"})}}onMouseLeave(t){this.contains(t.relatedTarget)||Zt.hide()}};ks.styles=[A5];Xd([ve()],ks.prototype,"text",void 0);Xd([T()],ks.prototype,"open",void 0);ks=Xd([M("w3m-tooltip-trigger")],ks);const x5=Q`
  :host {
    pointer-events: none;
  }

  :host > wui-flex {
    display: var(--w3m-tooltip-display);
    opacity: var(--w3m-tooltip-opacity);
    padding: 9px ${({spacing:e})=>e[3]} 10px ${({spacing:e})=>e[3]};
    border-radius: ${({borderRadius:e})=>e[3]};
    color: ${({tokens:e})=>e.theme.backgroundPrimary};
    position: absolute;
    top: var(--w3m-tooltip-top);
    left: var(--w3m-tooltip-left);
    transform: translate(calc(-50% + var(--w3m-tooltip-parent-width)), calc(-100% - 8px));
    max-width: calc(var(--apkt-modal-width) - ${({spacing:e})=>e[5]});
    transition: opacity ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: opacity;
    opacity: 0;
    animation-duration: ${({durations:e})=>e.xl};
    animation-timing-function: ${({easings:e})=>e["ease-out-power-2"]};
    animation-name: fade-in;
    animation-fill-mode: forwards;
  }

  :host([data-variant='shade']) > wui-flex {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  :host([data-variant='shade']) > wui-flex > wui-text {
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  :host([data-variant='fill']) > wui-flex {
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
    border: 1px solid ${({tokens:e})=>e.theme.borderPrimary};
  }

  wui-icon {
    position: absolute;
    width: 12px !important;
    height: 4px !important;
    color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  wui-icon[data-placement='top'] {
    bottom: 0px;
    left: 50%;
    transform: translate(-50%, 95%);
  }

  wui-icon[data-placement='bottom'] {
    top: 0;
    left: 50%;
    transform: translate(-50%, -95%) rotate(180deg);
  }

  wui-icon[data-placement='right'] {
    top: 50%;
    left: 0;
    transform: translate(-65%, -50%) rotate(90deg);
  }

  wui-icon[data-placement='left'] {
    top: 50%;
    right: 0%;
    transform: translate(65%, -50%) rotate(270deg);
  }

  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
`;var Xs=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let hi=class extends he{constructor(){super(),this.unsubscribe=[],this.open=Zt.state.open,this.message=Zt.state.message,this.triggerRect=Zt.state.triggerRect,this.variant=Zt.state.variant,this.unsubscribe.push(Zt.subscribe(t=>{this.open=t.open,this.message=t.message,this.triggerRect=t.triggerRect,this.variant=t.variant}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){this.dataset.variant=this.variant;const t=this.triggerRect.top,n=this.triggerRect.left;return this.style.cssText=`
    --w3m-tooltip-top: ${t}px;
    --w3m-tooltip-left: ${n}px;
    --w3m-tooltip-parent-width: ${this.triggerRect.width/2}px;
    --w3m-tooltip-display: ${this.open?"flex":"none"};
    --w3m-tooltip-opacity: ${this.open?1:0};
    `,g`<wui-flex>
      <wui-icon data-placement="top" size="inherit" name="cursor"></wui-icon>
      <wui-text color="primary" variant="sm-regular">${this.message}</wui-text>
    </wui-flex>`}};hi.styles=[x5];Xs([T()],hi.prototype,"open",void 0);Xs([T()],hi.prototype,"message",void 0);Xs([T()],hi.prototype,"triggerRect",void 0);Xs([T()],hi.prototype,"variant",void 0);hi=Xs([M("w3m-tooltip")],hi);const S5=Q`
  wui-flex {
    width: 100%;
  }

  wui-promo {
    position: absolute;
    top: -32px;
  }

  wui-profile-button {
    margin-top: calc(-1 * ${({spacing:e})=>e[4]});
  }

  wui-promo + wui-profile-button {
    margin-top: ${({spacing:e})=>e[4]};
  }

  wui-tabs {
    width: 100%;
  }

  .contentContainer {
    height: 280px;
  }

  .contentContainer > wui-icon-box {
    width: 40px;
    height: 40px;
    border-radius: ${({borderRadius:e})=>e[3]};
  }

  .contentContainer > .textContent {
    width: 65%;
  }
`;var Cn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let zt=class extends he{constructor(){super(...arguments),this.unsubscribe=[],this.network=p.state.activeCaipNetwork,this.profileName=p.getAccountData()?.profileName,this.address=p.getAccountData()?.address,this.currentTab=p.getAccountData()?.currentTab,this.tokenBalance=p.getAccountData()?.tokenBalance,this.features=R.state.features,this.namespace=p.state.activeChain,this.activeConnectorIds=O.state.activeConnectorIds,this.remoteFeatures=R.state.remoteFeatures}firstUpdated(){p.fetchTokenBalance(),this.unsubscribe.push(p.subscribeChainProp("accountState",t=>{t?.address?(this.address=t.address,this.profileName=t.profileName,this.currentTab=t.currentTab,this.tokenBalance=t.tokenBalance):ye.close()}),O.subscribeKey("activeConnectorIds",t=>{this.activeConnectorIds=t}),p.subscribeKey("activeChain",t=>this.namespace=t),p.subscribeKey("activeCaipNetwork",t=>this.network=t),R.subscribeKey("features",t=>this.features=t),R.subscribeKey("remoteFeatures",t=>this.remoteFeatures=t)),this.watchSwapValues()}disconnectedCallback(){this.unsubscribe.forEach(t=>t()),clearInterval(this.watchTokenBalance)}render(){if(!this.address)throw new Error("w3m-account-features-widget: No account provided");if(!this.namespace)return null;const t=this.activeConnectorIds[this.namespace],n=t?O.getConnectorById(t):void 0,{icon:r,iconSize:o}=this.getAuthData();return g`<wui-flex
      flexDirection="column"
      .padding=${["0","3","4","3"]}
      alignItems="center"
      gap="4"
      data-testid="w3m-account-wallet-features-widget"
    >
      <wui-flex flexDirection="column" justifyContent="center" alignItems="center" gap="2">
        <wui-wallet-switch
          profileName=${this.profileName}
          address=${this.address}
          icon=${r}
          iconSize=${o}
          alt=${n?.name}
          @click=${this.onGoToProfileWalletsView.bind(this)}
          data-testid="wui-wallet-switch"
        ></wui-wallet-switch>

        ${this.tokenBalanceTemplate()}
      </wui-flex>
      ${this.orderedWalletFeatures()} ${this.tabsTemplate()} ${this.listContentTemplate()}
    </wui-flex>`}orderedWalletFeatures(){const t=this.features?.walletFeaturesOrder||ke.DEFAULT_FEATURES.walletFeaturesOrder;if(t.every(i=>i==="send"||i==="receive"?!this.features?.[i]:i==="swaps"||i==="onramp"?!this.remoteFeatures?.[i]:!0))return null;const r=t.map(i=>i==="receive"||i==="onramp"?"fund":i),o=[...new Set(r)];return g`<wui-flex gap="2">
      ${o.map(i=>{switch(i){case"fund":return this.fundWalletTemplate();case"swaps":return this.swapsTemplate();case"send":return this.sendTemplate();default:return null}})}
    </wui-flex>`}fundWalletTemplate(){if(!this.namespace)return null;const t=ke.ONRAMP_SUPPORTED_CHAIN_NAMESPACES.includes(this.namespace),n=this.features?.receive,r=this.remoteFeatures?.onramp&&t,o=nt.isPayWithExchangeEnabled();return!r&&!n&&!o?null:g`
      <w3m-tooltip-trigger text="Fund wallet">
        <wui-button
          data-testid="wallet-features-fund-wallet-button"
          @click=${this.onFundWalletClick.bind(this)}
          variant="accent-secondary"
          size="lg"
          fullWidth
        >
          <wui-icon name="dollar"></wui-icon>
        </wui-button>
      </w3m-tooltip-trigger>
    `}swapsTemplate(){const t=this.remoteFeatures?.swaps,n=p.state.activeChain===N.CHAIN.EVM;return!t||!n?null:g`
      <w3m-tooltip-trigger text="Swap">
        <wui-button
          fullWidth
          data-testid="wallet-features-swaps-button"
          @click=${this.onSwapClick.bind(this)}
          variant="accent-secondary"
          size="lg"
        >
          <wui-icon name="recycleHorizontal"></wui-icon>
        </wui-button>
      </w3m-tooltip-trigger>
    `}sendTemplate(){const t=this.features?.send,n=p.state.activeChain,r=ke.SEND_SUPPORTED_NAMESPACES.includes(n);return!t||!r?null:g`
      <w3m-tooltip-trigger text="Send">
        <wui-button
          fullWidth
          data-testid="wallet-features-send-button"
          @click=${this.onSendClick.bind(this)}
          variant="accent-secondary"
          size="lg"
        >
          <wui-icon name="send"></wui-icon>
        </wui-button>
      </w3m-tooltip-trigger>
    `}watchSwapValues(){this.watchTokenBalance=setInterval(()=>p.fetchTokenBalance(t=>this.onTokenBalanceError(t)),1e4)}onTokenBalanceError(t){t instanceof Error&&t.cause instanceof Response&&t.cause.status===N.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE&&clearInterval(this.watchTokenBalance)}listContentTemplate(){return this.currentTab===0?g`<w3m-account-tokens-widget></w3m-account-tokens-widget>`:this.currentTab===1?g`<w3m-account-activity-widget></w3m-account-activity-widget>`:g`<w3m-account-tokens-widget></w3m-account-tokens-widget>`}tokenBalanceTemplate(){if(this.tokenBalance&&this.tokenBalance?.length>=0){const t=L.calculateBalance(this.tokenBalance),{dollars:n="0",pennies:r="00"}=L.formatTokenBalance(t);return g`<wui-balance dollars=${n} pennies=${r}></wui-balance>`}return g`<wui-balance dollars="0" pennies="00"></wui-balance>`}tabsTemplate(){const t=Zi.getTabsByNamespace(p.state.activeChain);return t.length===0?null:g`<wui-tabs
      .onTabChange=${this.onTabChange.bind(this)}
      .activeTab=${this.currentTab}
      .tabs=${t}
    ></wui-tabs>`}onTabChange(t){p.setAccountProp("currentTab",t,this.namespace)}onFundWalletClick(){S.push("FundWallet")}onSwapClick(){this.network?.caipNetworkId&&!ke.SWAP_SUPPORTED_NETWORKS.includes(this.network?.caipNetworkId)?S.push("UnsupportedChain",{swapUnsupportedChain:!0}):(X.sendEvent({type:"track",event:"OPEN_SWAP",properties:{network:this.network?.caipNetworkId||"",isSmartAccount:ut(p.state.activeChain)===je.ACCOUNT_TYPES.SMART_ACCOUNT}}),S.push("Swap"))}getAuthData(){const t=G.getConnectedSocialProvider(),n=G.getConnectedSocialUsername(),o=O.getAuthConnector()?.provider.getEmail()??"";return{name:dt.getAuthName({email:o,socialUsername:n,socialProvider:t}),icon:t??"mail",iconSize:t?"xl":"md"}}onGoToProfileWalletsView(){S.push("ProfileWallets")}onSendClick(){X.sendEvent({type:"track",event:"OPEN_SEND",properties:{network:this.network?.caipNetworkId||"",isSmartAccount:ut(p.state.activeChain)===je.ACCOUNT_TYPES.SMART_ACCOUNT}}),S.push("WalletSend")}};zt.styles=S5;Cn([T()],zt.prototype,"watchTokenBalance",void 0);Cn([T()],zt.prototype,"network",void 0);Cn([T()],zt.prototype,"profileName",void 0);Cn([T()],zt.prototype,"address",void 0);Cn([T()],zt.prototype,"currentTab",void 0);Cn([T()],zt.prototype,"tokenBalance",void 0);Cn([T()],zt.prototype,"features",void 0);Cn([T()],zt.prototype,"namespace",void 0);Cn([T()],zt.prototype,"activeConnectorIds",void 0);Cn([T()],zt.prototype,"remoteFeatures",void 0);zt=Cn([M("w3m-account-wallet-features-widget")],zt);var Af=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let hd=class extends he{constructor(){super(),this.unsubscribe=[],this.namespace=p.state.activeChain,this.unsubscribe.push(p.subscribeKey("activeChain",t=>{this.namespace=t}))}render(){if(!this.namespace)return null;const t=O.getConnectorId(this.namespace),n=O.getAuthConnector();return g`
      ${n&&t===N.CONNECTOR_ID.AUTH?this.walletFeaturesTemplate():this.defaultTemplate()}
    `}walletFeaturesTemplate(){return g`<w3m-account-wallet-features-widget></w3m-account-wallet-features-widget>`}defaultTemplate(){return g`<w3m-account-default-widget></w3m-account-default-widget>`}};Af([T()],hd.prototype,"namespace",void 0);hd=Af([M("w3m-account-view")],hd);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const xf={ATTRIBUTE:1,CHILD:2},Sf=e=>(...t)=>({_$litDirective$:e,values:t});class Tf{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,n,r){this._$Ct=t,this._$AM=n,this._$Ci=r}_$AS(t,n){return this.update(t,n)}update(t,n){return this.render(...n)}}/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const $f=Sf(class extends Tf{constructor(e){if(super(e),e.type!==xf.ATTRIBUTE||e.name!=="class"||e.strings?.length>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(e){return" "+Object.keys(e).filter(t=>e[t]).join(" ")+" "}update(e,[t]){if(this.st===void 0){this.st=new Set,e.strings!==void 0&&(this.nt=new Set(e.strings.join(" ").split(/\s/).filter(r=>r!=="")));for(const r in t)t[r]&&!this.nt?.has(r)&&this.st.add(r);return this.render(t)}const n=e.element.classList;for(const r of this.st)r in t||(n.remove(r),this.st.delete(r));for(const r in t){const o=!!t[r];o===this.st.has(r)||this.nt?.has(r)||(o?(n.add(r),this.st.add(r)):(n.remove(r),this.st.delete(r)))}return ei}}),T5=Q`
  :host {
    position: relative;
    background-color: ${({tokens:e})=>e.theme.foregroundTertiary};
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host([data-image='true']) {
    background-color: transparent;
  }

  :host > wui-flex {
    overflow: hidden;
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host([data-size='sm']) {
    width: 32px;
    height: 32px;
  }

  :host([data-size='md']) {
    width: 40px;
    height: 40px;
  }

  :host([data-size='lg']) {
    width: 56px;
    height: 56px;
  }

  :host([name='Extension'])::after {
    border: 1px solid ${({colors:e})=>e.accent010};
  }

  :host([data-wallet-icon='allWallets'])::after {
    border: 1px solid ${({colors:e})=>e.accent010};
  }

  wui-icon[data-parent-size='inherit'] {
    width: 75%;
    height: 75%;
    align-items: center;
  }

  wui-icon {
    color: ${({tokens:e})=>e.theme.iconDefault};
  }

  wui-icon[data-parent-size='sm'] {
    width: 24px;
    height: 24px;
  }

  wui-icon[data-parent-size='md'] {
    width: 32px;
    height: 32px;
  }

  :host > wui-icon-box {
    position: absolute;
    overflow: hidden;
    right: -1px;
    bottom: -2px;
    z-index: 1;
    border: 2px solid ${({tokens:e})=>e.theme.backgroundPrimary};
    padding: 1px;
  }
`;var Ri=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let tr=class extends de{constructor(){super(...arguments),this.size="md",this.name="",this.installed=!1,this.badgeSize="xs"}render(){let t="1";return this.size==="lg"?t="4":this.size==="md"?t="2":this.size==="sm"&&(t="1"),this.style.cssText=`
       --local-border-radius: var(--apkt-borderRadius-${t});
   `,this.dataset.size=this.size,this.imageSrc&&(this.dataset.image="true"),this.walletIcon&&(this.dataset.walletIcon=this.walletIcon),x`
      <wui-flex justifyContent="center" alignItems="center"> ${this.templateVisual()} </wui-flex>
    `}templateVisual(){return this.imageSrc?x`<wui-image src=${this.imageSrc} alt=${this.name}></wui-image>`:this.walletIcon?x`<wui-icon size="md" color="default" name=${this.walletIcon}></wui-icon>`:x`<wui-icon
      data-parent-size=${this.size}
      size="inherit"
      color="inherit"
      name="wallet"
    ></wui-icon>`}};tr.styles=[we,T5];Ri([m()],tr.prototype,"size",void 0);Ri([m()],tr.prototype,"name",void 0);Ri([m()],tr.prototype,"imageSrc",void 0);Ri([m()],tr.prototype,"walletIcon",void 0);Ri([m({type:Boolean})],tr.prototype,"installed",void 0);Ri([m()],tr.prototype,"badgeSize",void 0);tr=Ri([M("wui-wallet-image")],tr);const $5=Q`
  wui-image {
    width: 24px;
    height: 24px;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  wui-image,
  .icon-box {
    width: 32px;
    height: 32px;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  wui-icon:not(.custom-icon, .icon-badge) {
    cursor: pointer;
  }

  .icon-box {
    position: relative;
    border-radius: ${({borderRadius:e})=>e[2]};
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  .icon-badge {
    position: absolute;
    top: 18px;
    left: 23px;
    z-index: 3;
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border: 2px solid ${({tokens:e})=>e.theme.backgroundPrimary};
    border-radius: 50%;
    padding: ${({spacing:e})=>e["01"]};
  }

  .icon-badge {
    width: 8px;
    height: 8px;
  }
`;var Mt=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let mt=class extends de{constructor(){super(...arguments),this.address="",this.profileName="",this.content=[],this.alt="",this.imageSrc="",this.icon=void 0,this.iconSize="md",this.iconBadge=void 0,this.iconBadgeSize="md",this.buttonVariant="neutral-primary",this.enableMoreButton=!1,this.charsStart=4,this.charsEnd=6}render(){return x`
      <wui-flex flexDirection="column" rowgap="2">
        ${this.topTemplate()} ${this.bottomTemplate()}
      </wui-flex>
    `}topTemplate(){return x`
      <wui-flex alignItems="flex-start" justifyContent="space-between">
        ${this.imageOrIconTemplate()}
        <wui-icon-link
          variant="secondary"
          size="md"
          icon="copy"
          @click=${this.dispatchCopyEvent}
        ></wui-icon-link>
        <wui-icon-link
          variant="secondary"
          size="md"
          icon="externalLink"
          @click=${this.dispatchExternalLinkEvent}
        ></wui-icon-link>
        ${this.enableMoreButton?x`<wui-icon-link
              variant="secondary"
              size="md"
              icon="threeDots"
              @click=${this.dispatchMoreButtonEvent}
              data-testid="wui-active-profile-wallet-item-more-button"
            ></wui-icon-link>`:null}
      </wui-flex>
    `}bottomTemplate(){return x` <wui-flex flexDirection="column">${this.contentTemplate()}</wui-flex> `}imageOrIconTemplate(){return this.icon?x`
        <wui-flex flexGrow="1" alignItems="center">
          <wui-flex alignItems="center" justifyContent="center" class="icon-box">
            <wui-icon size="lg" color="default" name=${this.icon} class="custom-icon"></wui-icon>

            ${this.iconBadge?x`<wui-icon
                  color="accent-primary"
                  size="inherit"
                  name=${this.iconBadge}
                  class="icon-badge"
                ></wui-icon>`:null}
          </wui-flex>
        </wui-flex>
      `:x`
      <wui-flex flexGrow="1" alignItems="center">
        <wui-image objectFit="contain" src=${this.imageSrc} alt=${this.alt}></wui-image>
      </wui-flex>
    `}contentTemplate(){return this.content.length===0?null:x`
      <wui-flex flexDirection="column" rowgap="3">
        ${this.content.map(t=>this.labelAndTagTemplate(t))}
      </wui-flex>
    `}labelAndTagTemplate({address:t,profileName:n,label:r,description:o,enableButton:i,buttonType:s,buttonLabel:a,buttonVariant:c,tagVariant:l,tagLabel:d,alignItems:h="flex-end"}){return x`
      <wui-flex justifyContent="space-between" alignItems=${h} columngap="1">
        <wui-flex flexDirection="column" rowgap="01">
          ${r?x`<wui-text variant="sm-medium" color="secondary">${r}</wui-text>`:null}

          <wui-flex alignItems="center" columngap="1">
            <wui-text variant="md-regular" color="primary">
              ${Fe.getTruncateString({string:n||t,charsStart:n?16:this.charsStart,charsEnd:n?0:this.charsEnd,truncate:n?"end":"middle"})}
            </wui-text>

            ${l&&d?x`<wui-tag variant=${l} size="sm">${d}</wui-tag>`:null}
          </wui-flex>

          ${o?x`<wui-text variant="sm-regular" color="secondary">${o}</wui-text>`:null}
        </wui-flex>

        ${i?this.buttonTemplate({buttonType:s,buttonLabel:a,buttonVariant:c}):null}
      </wui-flex>
    `}buttonTemplate({buttonType:t,buttonLabel:n,buttonVariant:r}){return x`
      <wui-button
        size="sm"
        variant=${r}
        @click=${t==="disconnect"?this.dispatchDisconnectEvent.bind(this):this.dispatchSwitchEvent.bind(this)}
        data-testid=${t==="disconnect"?"wui-active-profile-wallet-item-disconnect-button":"wui-active-profile-wallet-item-switch-button"}
      >
        ${n}
      </wui-button>
    `}dispatchDisconnectEvent(){this.dispatchEvent(new CustomEvent("disconnect",{bubbles:!0,composed:!0}))}dispatchSwitchEvent(){this.dispatchEvent(new CustomEvent("switch",{bubbles:!0,composed:!0}))}dispatchExternalLinkEvent(){this.dispatchEvent(new CustomEvent("externalLink",{bubbles:!0,composed:!0}))}dispatchMoreButtonEvent(){this.dispatchEvent(new CustomEvent("more",{bubbles:!0,composed:!0}))}dispatchCopyEvent(){this.dispatchEvent(new CustomEvent("copy",{bubbles:!0,composed:!0}))}};mt.styles=[we,Be,$5];Mt([m()],mt.prototype,"address",void 0);Mt([m()],mt.prototype,"profileName",void 0);Mt([m({type:Array})],mt.prototype,"content",void 0);Mt([m()],mt.prototype,"alt",void 0);Mt([m()],mt.prototype,"imageSrc",void 0);Mt([m()],mt.prototype,"icon",void 0);Mt([m()],mt.prototype,"iconSize",void 0);Mt([m()],mt.prototype,"iconBadge",void 0);Mt([m()],mt.prototype,"iconBadgeSize",void 0);Mt([m()],mt.prototype,"buttonVariant",void 0);Mt([m({type:Boolean})],mt.prototype,"enableMoreButton",void 0);Mt([m({type:Number})],mt.prototype,"charsStart",void 0);Mt([m({type:Number})],mt.prototype,"charsEnd",void 0);mt=Mt([M("wui-active-profile-wallet-item")],mt);const N5=Q`
  wui-image,
  .icon-box {
    width: 32px;
    height: 32px;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  .right-icon {
    cursor: pointer;
  }

  .icon-box {
    position: relative;
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  .icon-badge {
    position: absolute;
    top: 18px;
    left: 23px;
    z-index: 3;
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border: 2px solid ${({tokens:e})=>e.theme.backgroundPrimary};
    border-radius: 50%;
    padding: ${({spacing:e})=>e["01"]};
  }

  .icon-badge {
    width: 8px;
    height: 8px;
  }
`;var wt=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let at=class extends de{constructor(){super(...arguments),this.address="",this.profileName="",this.alt="",this.buttonLabel="",this.buttonVariant="accent-primary",this.imageSrc="",this.icon=void 0,this.iconSize="md",this.iconBadgeSize="md",this.rightIcon="signOut",this.rightIconSize="md",this.loading=!1,this.charsStart=4,this.charsEnd=6}render(){return x`
      <wui-flex alignItems="center" columngap="2">
        ${this.imageOrIconTemplate()} ${this.labelAndDescriptionTemplate()}
        ${this.buttonActionTemplate()}
      </wui-flex>
    `}imageOrIconTemplate(){return this.icon?x`
        <wui-flex alignItems="center" justifyContent="center" class="icon-box">
          <wui-flex alignItems="center" justifyContent="center" class="icon-box">
            <wui-icon size="lg" color="default" name=${this.icon} class="custom-icon"></wui-icon>

            ${this.iconBadge?x`<wui-icon
                  color="default"
                  size="inherit"
                  name=${this.iconBadge}
                  class="icon-badge"
                ></wui-icon>`:null}
          </wui-flex>
        </wui-flex>
      `:x`<wui-image objectFit="contain" src=${this.imageSrc} alt=${this.alt}></wui-image>`}labelAndDescriptionTemplate(){return x`
      <wui-flex
        flexDirection="column"
        flexGrow="1"
        justifyContent="flex-start"
        alignItems="flex-start"
      >
        <wui-text variant="lg-regular" color="primary">
          ${Fe.getTruncateString({string:this.profileName||this.address,charsStart:this.profileName?16:this.charsStart,charsEnd:this.profileName?0:this.charsEnd,truncate:this.profileName?"end":"middle"})}
        </wui-text>
      </wui-flex>
    `}buttonActionTemplate(){return x`
      <wui-flex columngap="1" alignItems="center" justifyContent="center">
        <wui-button
          size="sm"
          variant=${this.buttonVariant}
          .loading=${this.loading}
          @click=${this.handleButtonClick}
          data-testid="wui-inactive-profile-wallet-item-button"
        >
          ${this.buttonLabel}
        </wui-button>

        <wui-icon-link
          variant="secondary"
          size="md"
          icon=${Qe(this.rightIcon)}
          class="right-icon"
          @click=${this.handleIconClick}
        ></wui-icon-link>
      </wui-flex>
    `}handleButtonClick(){this.dispatchEvent(new CustomEvent("buttonClick",{bubbles:!0,composed:!0}))}handleIconClick(){this.dispatchEvent(new CustomEvent("iconClick",{bubbles:!0,composed:!0}))}};at.styles=[we,Be,N5];wt([m()],at.prototype,"address",void 0);wt([m()],at.prototype,"profileName",void 0);wt([m()],at.prototype,"alt",void 0);wt([m()],at.prototype,"buttonLabel",void 0);wt([m()],at.prototype,"buttonVariant",void 0);wt([m()],at.prototype,"imageSrc",void 0);wt([m()],at.prototype,"icon",void 0);wt([m()],at.prototype,"iconSize",void 0);wt([m()],at.prototype,"iconBadge",void 0);wt([m()],at.prototype,"iconBadgeSize",void 0);wt([m()],at.prototype,"rightIcon",void 0);wt([m()],at.prototype,"rightIconSize",void 0);wt([m({type:Boolean})],at.prototype,"loading",void 0);wt([m({type:Number})],at.prototype,"charsStart",void 0);wt([m({type:Number})],at.prototype,"charsEnd",void 0);at=wt([M("wui-inactive-profile-wallet-item")],at);const R5=Q`
  :host {
    position: relative;
    display: flex;
    width: 100%;
    height: 1px;
    background-color: ${({tokens:e})=>e.theme.borderPrimary};
    justify-content: center;
    align-items: center;
  }

  :host > wui-text {
    position: absolute;
    padding: 0px 8px;
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
  }

  :host([data-bg-color='primary']) > wui-text {
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
  }

  :host([data-bg-color='secondary']) > wui-text {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }
`;var Qd=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Is=class extends de{constructor(){super(...arguments),this.text="",this.bgColor="primary"}render(){return this.dataset.bgColor=this.bgColor,x`${this.template()}`}template(){return this.text?x`<wui-text variant="md-regular" color="secondary">${this.text}</wui-text>`:null}};Is.styles=[we,R5];Qd([m()],Is.prototype,"text",void 0);Qd([m()],Is.prototype,"bgColor",void 0);Is=Qd([M("wui-separator")],Is);const cl={getAuthData(e){const t=e.connectorId===N.CONNECTOR_ID.AUTH;if(!t)return{isAuth:!1,icon:void 0,iconSize:void 0,name:void 0};const n=e?.auth?.name??G.getConnectedSocialProvider(),r=e?.auth?.username??G.getConnectedSocialUsername(),i=O.getAuthConnector()?.provider.getEmail()??"";return{isAuth:!0,icon:n??"mail",iconSize:n?"xl":"md",name:t?dt.getAuthName({email:i,socialUsername:r,socialProvider:n}):void 0}}},k5=Q`
  :host {
    --connect-scroll--top-opacity: 0;
    --connect-scroll--bottom-opacity: 0;
  }

  .balance-amount {
    flex: 1;
  }

  .wallet-list {
    scrollbar-width: none;
    overflow-y: scroll;
    overflow-x: hidden;
    transition: opacity ${({easings:e})=>e["ease-out-power-1"]}
      ${({durations:e})=>e.md};
    will-change: opacity;
    mask-image: linear-gradient(
      to bottom,
      rgba(0, 0, 0, calc(1 - var(--connect-scroll--top-opacity))) 0px,
      rgba(200, 200, 200, calc(1 - var(--connect-scroll--top-opacity))) 1px,
      black 40px,
      black calc(100% - 40px),
      rgba(155, 155, 155, calc(1 - var(--connect-scroll--bottom-opacity))) calc(100% - 1px),
      rgba(0, 0, 0, calc(1 - var(--connect-scroll--bottom-opacity))) 100%
    );
  }

  .active-wallets {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  .active-wallets-box {
    height: 330px;
  }

  .empty-wallet-list-box {
    height: 400px;
  }

  .empty-box {
    width: 100%;
    padding: ${({spacing:e})=>e[4]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  wui-separator {
    margin: ${({spacing:e})=>e[2]} 0 ${({spacing:e})=>e[2]} 0;
  }

  .active-connection {
    padding: ${({spacing:e})=>e[2]};
  }

  .recent-connection {
    padding: ${({spacing:e})=>e[2]} 0 ${({spacing:e})=>e[2]} 0;
  }

  @media (max-width: 430px) {
    .active-wallets-box,
    .empty-wallet-list-box {
      height: auto;
      max-height: clamp(360px, 470px, 80vh);
    }
  }
`;var qt=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const Kt={ADDRESS_DISPLAY:{START:4,END:6},BADGE:{SIZE:"md",ICON:"lightbulb"},SCROLL_THRESHOLD:50,OPACITY_RANGE:[0,1]},Hi={eip155:"ethereum",solana:"solana",bip122:"bitcoin",ton:"ton"},I5=[{namespace:"eip155",icon:Hi.eip155,label:"EVM"},{namespace:"solana",icon:Hi.solana,label:"Solana"},{namespace:"bip122",icon:Hi.bip122,label:"Bitcoin"},{namespace:"ton",icon:Hi.ton,label:"Ton"}],O5={eip155:{title:"Add EVM Wallet",description:"Add your first EVM wallet"},solana:{title:"Add Solana Wallet",description:"Add your first Solana wallet"},bip122:{title:"Add Bitcoin Wallet",description:"Add your first Bitcoin wallet"},ton:{title:"Add TON Wallet",description:"Add your first TON wallet"}};let _t=class extends he{constructor(){super(),this.unsubscribers=[],this.currentTab=0,this.namespace=p.state.activeChain,this.namespaces=Array.from(p.state.chains.keys()),this.caipAddress=void 0,this.profileName=void 0,this.activeConnectorIds=O.state.activeConnectorIds,this.lastSelectedAddress="",this.lastSelectedConnectorId="",this.isSwitching=!1,this.caipNetwork=p.state.activeCaipNetwork,this.user=p.getAccountData()?.user,this.remoteFeatures=R.state.remoteFeatures,this.currentTab=this.namespace?this.namespaces.indexOf(this.namespace):0,this.caipAddress=p.getAccountData(this.namespace)?.caipAddress,this.profileName=p.getAccountData(this.namespace)?.profileName,this.unsubscribers.push(U.subscribeKey("connections",()=>this.onConnectionsChange()),U.subscribeKey("recentConnections",()=>this.requestUpdate()),O.subscribeKey("activeConnectorIds",t=>{this.activeConnectorIds=t}),p.subscribeKey("activeCaipNetwork",t=>this.caipNetwork=t),p.subscribeChainProp("accountState",t=>{this.user=t?.user}),R.subscribeKey("remoteFeatures",t=>this.remoteFeatures=t)),this.chainListener=p.subscribeChainProp("accountState",t=>{this.caipAddress=t?.caipAddress,this.profileName=t?.profileName},this.namespace)}disconnectedCallback(){this.unsubscribers.forEach(t=>t()),this.resizeObserver?.disconnect(),this.removeScrollListener(),this.chainListener?.()}firstUpdated(){const t=this.shadowRoot?.querySelector(".wallet-list");if(!t)return;const n=()=>this.updateScrollOpacity(t);requestAnimationFrame(n),t.addEventListener("scroll",n),this.resizeObserver=new ResizeObserver(n),this.resizeObserver.observe(t),n()}render(){const t=this.namespace;if(!t)throw new Error("Namespace is not set");return g`
      <wui-flex flexDirection="column" .padding=${["0","4","4","4"]} gap="4">
        ${this.renderTabs()} ${this.renderHeader(t)} ${this.renderConnections(t)}
        ${this.renderAddConnectionButton(t)}
      </wui-flex>
    `}renderTabs(){const t=this.namespaces.map(r=>I5.find(o=>o.namespace===r)).filter(Boolean);return t.length>1?g`
        <wui-tabs
          .onTabChange=${r=>this.handleTabChange(r)}
          .activeTab=${this.currentTab}
          .tabs=${t}
        ></wui-tabs>
      `:null}renderHeader(t){const r=this.getActiveConnections(t).flatMap(({accounts:o})=>o).length+(this.caipAddress?1:0);return g`
      <wui-flex alignItems="center" columngap="1">
        <wui-icon
          size="sm"
          name=${Hi[t]??Hi.eip155}
        ></wui-icon>
        <wui-text color="secondary" variant="lg-regular"
          >${r>1?"Wallets":"Wallet"}</wui-text
        >
        <wui-text
          color="primary"
          variant="lg-regular"
          class="balance-amount"
          data-testid="balance-amount"
        >
          ${r}
        </wui-text>
        <wui-link
          color="secondary"
          variant="secondary"
          @click=${()=>U.disconnect({namespace:t})}
          ?disabled=${!this.hasAnyConnections(t)}
          data-testid="disconnect-all-button"
        >
          Disconnect All
        </wui-link>
      </wui-flex>
    `}renderConnections(t){const n=this.hasAnyConnections(t);return g`
      <wui-flex flexDirection="column" class=${$f({"wallet-list":!0,"active-wallets-box":n,"empty-wallet-list-box":!n})} rowgap="3">
        ${n?this.renderActiveConnections(t):this.renderEmptyState(t)}
      </wui-flex>
    `}renderActiveConnections(t){const n=this.getActiveConnections(t),r=this.activeConnectorIds[t],o=this.getPlainAddress();return g`
      ${o||r||n.length>0?g`<wui-flex
            flexDirection="column"
            .padding=${["4","0","4","0"]}
            class="active-wallets"
          >
            ${this.renderActiveProfile(t)} ${this.renderActiveConnectionsList(t)}
          </wui-flex>`:null}
      ${this.renderRecentConnections(t)}
    `}renderActiveProfile(t){const n=this.activeConnectorIds[t];if(!n)return null;const{connections:r}=dn.getConnectionsData(t),o=O.getConnectorById(n),i=De.getConnectorImage(o),s=this.getPlainAddress();if(!s)return null;const a=t===N.CHAIN.BITCOIN,c=cl.getAuthData({connectorId:n,accounts:[]}),l=this.getActiveConnections(t).flatMap(f=>f.accounts).length>0,d=r.find(f=>f.connectorId===n),h=d?.accounts.filter(f=>!Wt.isLowerCaseMatch(f.address,s));return g`
      <wui-flex flexDirection="column" .padding=${["0","4","0","4"]}>
        <wui-active-profile-wallet-item
          address=${s}
          alt=${o?.name}
          .content=${this.getProfileContent({address:s,connections:r,connectorId:n,namespace:t})}
          .charsStart=${Kt.ADDRESS_DISPLAY.START}
          .charsEnd=${Kt.ADDRESS_DISPLAY.END}
          .icon=${c.icon}
          .iconSize=${c.iconSize}
          .iconBadge=${this.isSmartAccount(s)?Kt.BADGE.ICON:void 0}
          .iconBadgeSize=${this.isSmartAccount(s)?Kt.BADGE.SIZE:void 0}
          imageSrc=${i}
          ?enableMoreButton=${c.isAuth}
          @copy=${()=>this.handleCopyAddress(s)}
          @disconnect=${()=>this.handleDisconnect(t,n)}
          @switch=${()=>{a&&d&&h?.[0]&&this.handleSwitchWallet(d,h[0].address,t)}}
          @externalLink=${()=>this.handleExternalLink(s)}
          @more=${()=>this.handleMore()}
          data-testid="wui-active-profile-wallet-item"
        ></wui-active-profile-wallet-item>
        ${l?g`<wui-separator></wui-separator>`:null}
      </wui-flex>
    `}renderActiveConnectionsList(t){const n=this.getActiveConnections(t);return n.length===0?null:g`
      <wui-flex flexDirection="column" .padding=${["0","2","0","2"]}>
        ${this.renderConnectionList(n,!1,t)}
      </wui-flex>
    `}renderRecentConnections(t){const{recentConnections:n}=dn.getConnectionsData(t);return n.flatMap(o=>o.accounts).length===0?null:g`
      <wui-flex flexDirection="column" .padding=${["0","2","0","2"]} rowGap="2">
        <wui-text color="secondary" variant="sm-medium" data-testid="recently-connected-text"
          >RECENTLY CONNECTED</wui-text
        >
        <wui-flex flexDirection="column" .padding=${["0","2","0","2"]}>
          ${this.renderConnectionList(n,!0,t)}
        </wui-flex>
      </wui-flex>
    `}renderConnectionList(t,n,r){return t.filter(o=>o.accounts.length>0).map((o,i)=>{const s=O.getConnectorById(o.connectorId),a=De.getConnectorImage(s)??"",c=cl.getAuthData(o);return o.accounts.map((l,d)=>{const h=i!==0||d!==0,f=this.isAccountLoading(o.connectorId,l.address);return g`
            <wui-flex flexDirection="column">
              ${h?g`<wui-separator></wui-separator>`:null}
              <wui-inactive-profile-wallet-item
                address=${l.address}
                alt=${o.connectorId}
                buttonLabel=${n?"Connect":"Switch"}
                buttonVariant=${n?"neutral-secondary":"accent-secondary"}
                rightIcon=${n?"bin":"power"}
                rightIconSize="sm"
                class=${n?"recent-connection":"active-connection"}
                data-testid=${n?"recent-connection":"active-connection"}
                imageSrc=${a}
                .iconBadge=${this.isSmartAccount(l.address)?Kt.BADGE.ICON:void 0}
                .iconBadgeSize=${this.isSmartAccount(l.address)?Kt.BADGE.SIZE:void 0}
                .icon=${c.icon}
                .iconSize=${c.iconSize}
                .loading=${f}
                .showBalance=${!1}
                .charsStart=${Kt.ADDRESS_DISPLAY.START}
                .charsEnd=${Kt.ADDRESS_DISPLAY.END}
                @buttonClick=${()=>this.handleSwitchWallet(o,l.address,r)}
                @iconClick=${()=>this.handleWalletAction({connection:o,address:l.address,isRecentConnection:n,namespace:r})}
              ></wui-inactive-profile-wallet-item>
            </wui-flex>
          `})})}renderAddConnectionButton(t){if(!this.isMultiWalletEnabled()&&this.caipAddress||!this.hasAnyConnections(t))return null;const{title:n}=this.getChainLabelInfo(t);return g`
      <wui-list-item
        variant="icon"
        iconVariant="overlay"
        icon="plus"
        iconSize="sm"
        ?chevron=${!0}
        @click=${()=>this.handleAddConnection(t)}
        data-testid="add-connection-button"
      >
        <wui-text variant="md-medium" color="secondary">${n}</wui-text>
      </wui-list-item>
    `}renderEmptyState(t){const{title:n,description:r}=this.getChainLabelInfo(t);return g`
      <wui-flex alignItems="flex-start" class="empty-template" data-testid="empty-template">
        <wui-flex
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          rowgap="3"
          class="empty-box"
        >
          <wui-icon-box size="xl" icon="wallet" color="secondary"></wui-icon-box>

          <wui-flex flexDirection="column" alignItems="center" justifyContent="center" gap="1">
            <wui-text color="primary" variant="lg-regular" data-testid="empty-state-text"
              >No wallet connected</wui-text
            >
            <wui-text color="secondary" variant="md-regular" data-testid="empty-state-description"
              >${r}</wui-text
            >
          </wui-flex>

          <wui-link
            @click=${()=>this.handleAddConnection(t)}
            data-testid="empty-state-button"
            icon="plus"
          >
            ${n}
          </wui-link>
        </wui-flex>
      </wui-flex>
    `}handleTabChange(t){const n=this.namespaces[t];n&&(this.chainListener?.(),this.currentTab=this.namespaces.indexOf(n),this.namespace=n,this.caipAddress=p.getAccountData(n)?.caipAddress,this.profileName=p.getAccountData(n)?.profileName,this.chainListener=p.subscribeChainProp("accountState",r=>{this.caipAddress=r?.caipAddress},n))}async handleSwitchWallet(t,n,r){try{this.isSwitching=!0,this.lastSelectedConnectorId=t.connectorId,this.lastSelectedAddress=n,this.caipNetwork?.chainNamespace!==r&&t?.caipNetwork&&(O.setFilterByNamespace(r),await p.switchActiveNetwork(t?.caipNetwork)),await U.switchConnection({connection:t,address:n,namespace:r,closeModalOnConnect:!1,onChange({hasSwitchedAccount:i,hasSwitchedWallet:s}){s?Te.showSuccess("Wallet switched"):i&&Te.showSuccess("Account switched")}})}catch{Te.showError("Failed to switch wallet")}finally{this.isSwitching=!1}}handleWalletAction(t){const{connection:n,address:r,isRecentConnection:o,namespace:i}=t;o?(G.deleteAddressFromConnection({connectorId:n.connectorId,address:r,namespace:i}),U.syncStorageConnections(),Te.showSuccess("Wallet deleted")):this.handleDisconnect(i,n.connectorId)}async handleDisconnect(t,n){try{await U.disconnect({id:n,namespace:t}),Te.showSuccess("Wallet disconnected")}catch{Te.showError("Failed to disconnect wallet")}}handleCopyAddress(t){L.copyToClopboard(t),Te.showSuccess("Address copied")}handleMore(){S.push("AccountSettings")}handleExternalLink(t){const n=this.caipNetwork?.blockExplorers?.default.url;n&&L.openHref(`${n}/address/${t}`,"_blank")}handleAddConnection(t){O.setFilterByNamespace(t),S.push("Connect",{addWalletForNamespace:t})}getChainLabelInfo(t){return O5[t]??{title:"Add Wallet",description:"Add your first wallet"}}isSmartAccount(t){if(!this.namespace)return!1;const n=this.user?.accounts?.find(r=>r.type==="smartAccount");return n&&t?Wt.isLowerCaseMatch(n.address,t):!1}getPlainAddress(){return this.caipAddress?L.getPlainAddress(this.caipAddress):void 0}getActiveConnections(t){const n=this.activeConnectorIds[t],{connections:r}=dn.getConnectionsData(t),[o]=r.filter(c=>Wt.isLowerCaseMatch(c.connectorId,n));if(!n)return r;const i=t===N.CHAIN.BITCOIN,{address:s}=this.caipAddress?Jt.parseCaipAddress(this.caipAddress):{};let a=[...s?[s]:[]];return i&&o&&(a=o.accounts.map(c=>c.address)||[]),dn.excludeConnectorAddressFromConnections({connectorId:n,addresses:a,connections:r})}hasAnyConnections(t){const n=this.getActiveConnections(t),{recentConnections:r}=dn.getConnectionsData(t);return!!this.caipAddress||n.length>0||r.length>0}isAccountLoading(t,n){return Wt.isLowerCaseMatch(this.lastSelectedConnectorId,t)&&Wt.isLowerCaseMatch(this.lastSelectedAddress,n)&&this.isSwitching}getProfileContent(t){const{address:n,connections:r,connectorId:o,namespace:i}=t,[s]=r.filter(c=>Wt.isLowerCaseMatch(c.connectorId,o));if(i===N.CHAIN.BITCOIN&&s?.accounts.every(c=>typeof c.type=="string"))return this.getBitcoinProfileContent(s.accounts,n);const a=cl.getAuthData({connectorId:o,accounts:[]});return[{address:n,tagLabel:"Active",tagVariant:"success",enableButton:!0,profileName:this.profileName,buttonType:"disconnect",buttonLabel:"Disconnect",buttonVariant:"neutral-secondary",...a.isAuth?{description:this.isSmartAccount(n)?"Smart Account":"EOA Account"}:{}}]}getBitcoinProfileContent(t,n){const r=t.length>1,o=this.getPlainAddress();return t.map(i=>{const s=Wt.isLowerCaseMatch(i.address,o);let a="PAYMENT";return i.type==="ordinal"&&(a="ORDINALS"),{address:i.address,tagLabel:Wt.isLowerCaseMatch(i.address,n)?"Active":void 0,tagVariant:Wt.isLowerCaseMatch(i.address,n)?"success":void 0,enableButton:!0,...r?{label:a,alignItems:"flex-end",buttonType:s?"disconnect":"switch",buttonLabel:s?"Disconnect":"Switch",buttonVariant:s?"neutral-secondary":"accent-secondary"}:{alignItems:"center",buttonType:"disconnect",buttonLabel:"Disconnect",buttonVariant:"neutral-secondary"}}})}removeScrollListener(){const t=this.shadowRoot?.querySelector(".wallet-list");t&&t.removeEventListener("scroll",()=>this.handleConnectListScroll())}handleConnectListScroll(){const t=this.shadowRoot?.querySelector(".wallet-list");t&&this.updateScrollOpacity(t)}isMultiWalletEnabled(){return!!this.remoteFeatures?.multiWallet}updateScrollOpacity(t){t.style.setProperty("--connect-scroll--top-opacity",Ja.interpolate([0,Kt.SCROLL_THRESHOLD],Kt.OPACITY_RANGE,t.scrollTop).toString()),t.style.setProperty("--connect-scroll--bottom-opacity",Ja.interpolate([0,Kt.SCROLL_THRESHOLD],Kt.OPACITY_RANGE,t.scrollHeight-t.scrollTop-t.offsetHeight).toString())}onConnectionsChange(){if(this.isMultiWalletEnabled()&&this.namespace){const{connections:t}=dn.getConnectionsData(this.namespace);t.length===0&&S.reset("ProfileWallets")}this.requestUpdate()}};_t.styles=k5;qt([T()],_t.prototype,"currentTab",void 0);qt([T()],_t.prototype,"namespace",void 0);qt([T()],_t.prototype,"namespaces",void 0);qt([T()],_t.prototype,"caipAddress",void 0);qt([T()],_t.prototype,"profileName",void 0);qt([T()],_t.prototype,"activeConnectorIds",void 0);qt([T()],_t.prototype,"lastSelectedAddress",void 0);qt([T()],_t.prototype,"lastSelectedConnectorId",void 0);qt([T()],_t.prototype,"isSwitching",void 0);qt([T()],_t.prototype,"caipNetwork",void 0);qt([T()],_t.prototype,"user",void 0);qt([T()],_t.prototype,"remoteFeatures",void 0);_t=qt([M("w3m-profile-wallets-view")],_t);var yo=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let pi=class extends he{constructor(){super(),this.unsubscribe=[],this.activeCaipNetwork=p.state.activeCaipNetwork,this.features=R.state.features,this.remoteFeatures=R.state.remoteFeatures,this.exchangesLoading=nt.state.isLoading,this.exchanges=nt.state.exchanges,this.unsubscribe.push(R.subscribeKey("features",t=>this.features=t),R.subscribeKey("remoteFeatures",t=>this.remoteFeatures=t),p.subscribeKey("activeCaipNetwork",t=>{this.activeCaipNetwork=t,this.setDefaultPaymentAsset()}),nt.subscribeKey("isLoading",t=>this.exchangesLoading=t),nt.subscribeKey("exchanges",t=>this.exchanges=t))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}async firstUpdated(){nt.isPayWithExchangeSupported()&&(await this.setDefaultPaymentAsset(),await nt.fetchExchanges())}render(){return g`
      <wui-flex flexDirection="column" .padding=${["1","3","3","3"]} gap="2">
        ${this.onrampTemplate()} ${this.receiveTemplate()} ${this.depositFromExchangeTemplate()}
      </wui-flex>
    `}async setDefaultPaymentAsset(){if(!this.activeCaipNetwork)return;const t=await nt.getAssetsForNetwork(this.activeCaipNetwork.caipNetworkId),n=t.find(r=>r.metadata.symbol==="USDC")||t[0];n&&nt.setPaymentAsset(n)}onrampTemplate(){if(!this.activeCaipNetwork)return null;const t=this.remoteFeatures?.onramp,n=ke.ONRAMP_SUPPORTED_CHAIN_NAMESPACES.includes(this.activeCaipNetwork.chainNamespace);return!t||!n?null:g`
      <wui-list-item
        @click=${this.onBuyCrypto.bind(this)}
        icon="card"
        data-testid="wallet-features-onramp-button"
      >
        <wui-text variant="lg-regular" color="primary">Buy crypto</wui-text>
      </wui-list-item>
    `}depositFromExchangeTemplate(){return!this.activeCaipNetwork||!nt.isPayWithExchangeSupported()?null:g`
      <wui-list-item
        @click=${this.onDepositFromExchange.bind(this)}
        icon="arrowBottomCircle"
        data-testid="wallet-features-deposit-from-exchange-button"
        ?loading=${this.exchangesLoading}
        ?disabled=${this.exchangesLoading||!this.exchanges.length}
      >
        <wui-text variant="lg-regular" color="primary">Deposit from exchange</wui-text>
      </wui-list-item>
    `}receiveTemplate(){return!this.features?.receive?null:g`
      <wui-list-item
        @click=${this.onReceive.bind(this)}
        icon="qrCode"
        data-testid="wallet-features-receive-button"
      >
        <wui-text variant="lg-regular" color="primary">Receive funds</wui-text>
      </wui-list-item>
    `}onBuyCrypto(){S.push("OnRampProviders")}onReceive(){S.push("WalletReceive")}onDepositFromExchange(){nt.reset(),S.push("PayWithExchange",{redirectView:S.state.data?.redirectView})}};yo([T()],pi.prototype,"activeCaipNetwork",void 0);yo([T()],pi.prototype,"features",void 0);yo([T()],pi.prototype,"remoteFeatures",void 0);yo([T()],pi.prototype,"exchangesLoading",void 0);yo([T()],pi.prototype,"exchanges",void 0);pi=yo([M("w3m-fund-wallet-view")],pi);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const P5=e=>e.strings===void 0;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Mo=(e,t)=>{const n=e._$AN;if(n===void 0)return!1;for(const r of n)r._$AO?.(t,!1),Mo(r,t);return!0},sc=e=>{let t,n;do{if((t=e._$AM)===void 0)break;n=t._$AN,n.delete(e),e=t}while(n?.size===0)},Nf=e=>{for(let t;t=e._$AM;e=t){let n=t._$AN;if(n===void 0)t._$AN=n=new Set;else if(n.has(e))break;n.add(e),M5(t)}};function L5(e){this._$AN!==void 0?(sc(this),this._$AM=e,Nf(this)):this._$AM=e}function D5(e,t=!1,n=0){const r=this._$AH,o=this._$AN;if(o!==void 0&&o.size!==0)if(t)if(Array.isArray(r))for(let i=n;i<r.length;i++)Mo(r[i],!1),sc(r[i]);else r!=null&&(Mo(r,!1),sc(r));else Mo(this,e)}const M5=e=>{e.type==yf.CHILD&&(e._$AP??=D5,e._$AQ??=L5)};let U5=class extends vf{constructor(){super(...arguments),this._$AN=void 0}_$AT(t,n,r){super._$AT(t,n,r),Nf(this),this.isConnected=t._$AU}_$AO(t,n=!0){t!==this.isConnected&&(this.isConnected=t,t?this.reconnected?.():this.disconnected?.()),n&&(Mo(this,t),sc(this))}setValue(t){if(P5(this._$Ct))this._$Ct._$AI(t,this);else{const n=[...this._$Ct._$AH];n[this._$Ci]=t,this._$Ct._$AI(n,this,0)}}disconnected(){}reconnected(){}};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Mc=()=>new B5;let B5=class{};const ll=new WeakMap,Uc=Cf(class extends U5{render(e){return Je}update(e,[t]){const n=t!==this.G;return n&&this.G!==void 0&&this.rt(void 0),(n||this.lt!==this.ct)&&(this.G=t,this.ht=e.options?.host,this.rt(this.ct=e.element)),Je}rt(e){if(this.isConnected||(e=void 0),typeof this.G=="function"){const t=this.ht??globalThis;let n=ll.get(t);n===void 0&&(n=new WeakMap,ll.set(t,n)),n.get(this.G)!==void 0&&this.G.call(this.ht,void 0),n.set(this.G,e),e!==void 0&&this.G.call(this.ht,e)}else this.G.value=e}get lt(){return typeof this.G=="function"?ll.get(this.ht??globalThis)?.get(this.G):this.G?.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}}),W5=Q`
  :host {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  label {
    position: relative;
    display: inline-block;
    user-select: none;
    transition:
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      color ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      border ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      box-shadow ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      width ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      height ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      transform ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      opacity ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color, color, border, box-shadow, width, height, transform, opacity;
  }

  input {
    width: 0;
    height: 0;
    opacity: 0;
  }

  span {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: ${({colors:e})=>e.neutrals300};
    border-radius: ${({borderRadius:e})=>e.round};
    border: 1px solid transparent;
    will-change: border;
    transition:
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      color ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      border ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      box-shadow ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      width ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      height ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      transform ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      opacity ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color, color, border, box-shadow, width, height, transform, opacity;
  }

  span:before {
    content: '';
    position: absolute;
    background-color: ${({colors:e})=>e.white};
    border-radius: 50%;
  }

  /* -- Sizes --------------------------------------------------------- */
  label[data-size='lg'] {
    width: 48px;
    height: 32px;
  }

  label[data-size='md'] {
    width: 40px;
    height: 28px;
  }

  label[data-size='sm'] {
    width: 32px;
    height: 22px;
  }

  label[data-size='lg'] > span:before {
    height: 24px;
    width: 24px;
    left: 4px;
    top: 3px;
  }

  label[data-size='md'] > span:before {
    height: 20px;
    width: 20px;
    left: 4px;
    top: 3px;
  }

  label[data-size='sm'] > span:before {
    height: 16px;
    width: 16px;
    left: 3px;
    top: 2px;
  }

  /* -- Focus states --------------------------------------------------- */
  input:focus-visible:not(:checked) + span,
  input:focus:not(:checked) + span {
    border: 1px solid ${({tokens:e})=>e.core.iconAccentPrimary};
    background-color: ${({tokens:e})=>e.theme.textTertiary};
    box-shadow: 0px 0px 0px 4px rgba(9, 136, 240, 0.2);
  }

  input:focus-visible:checked + span,
  input:focus:checked + span {
    border: 1px solid ${({tokens:e})=>e.core.iconAccentPrimary};
    box-shadow: 0px 0px 0px 4px rgba(9, 136, 240, 0.2);
  }

  /* -- Checked states --------------------------------------------------- */
  input:checked + span {
    background-color: ${({tokens:e})=>e.core.iconAccentPrimary};
  }

  label[data-size='lg'] > input:checked + span:before {
    transform: translateX(calc(100% - 9px));
  }

  label[data-size='md'] > input:checked + span:before {
    transform: translateX(calc(100% - 9px));
  }

  label[data-size='sm'] > input:checked + span:before {
    transform: translateX(calc(100% - 7px));
  }

  /* -- Hover states ------------------------------------------------------- */
  label:hover > input:not(:checked):not(:disabled) + span {
    background-color: ${({colors:e})=>e.neutrals400};
  }

  label:hover > input:checked:not(:disabled) + span {
    background-color: ${({colors:e})=>e.accent080};
  }

  /* -- Disabled state --------------------------------------------------- */
  label:has(input:disabled) {
    pointer-events: none;
    user-select: none;
  }

  input:not(:checked):disabled + span {
    background-color: ${({colors:e})=>e.neutrals700};
  }

  input:checked:disabled + span {
    background-color: ${({colors:e})=>e.neutrals700};
  }

  input:not(:checked):disabled + span::before {
    background-color: ${({colors:e})=>e.neutrals400};
  }

  input:checked:disabled + span::before {
    background-color: ${({tokens:e})=>e.theme.textTertiary};
  }
`;var Bc=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let co=class extends de{constructor(){super(...arguments),this.inputElementRef=Mc(),this.checked=!1,this.disabled=!1,this.size="md"}render(){return x`
      <label data-size=${this.size}>
        <input
          ${Uc(this.inputElementRef)}
          type="checkbox"
          ?checked=${this.checked}
          ?disabled=${this.disabled}
          @change=${this.dispatchChangeEvent.bind(this)}
        />
        <span></span>
      </label>
    `}dispatchChangeEvent(){this.dispatchEvent(new CustomEvent("switchChange",{detail:this.inputElementRef.value?.checked,bubbles:!0,composed:!0}))}};co.styles=[we,Be,W5];Bc([m({type:Boolean})],co.prototype,"checked",void 0);Bc([m({type:Boolean})],co.prototype,"disabled",void 0);Bc([m()],co.prototype,"size",void 0);co=Bc([M("wui-toggle")],co);const j5=Q`
  :host {
    height: auto;
  }

  :host > wui-flex {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    column-gap: ${({spacing:e})=>e[2]};
    padding: ${({spacing:e})=>e[2]} ${({spacing:e})=>e[3]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[4]};
    box-shadow: inset 0 0 0 1px ${({tokens:e})=>e.theme.foregroundPrimary};
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
    cursor: pointer;
  }

  wui-switch {
    pointer-events: none;
  }
`;var Rf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ac=class extends de{constructor(){super(...arguments),this.checked=!1}render(){return x`
      <wui-flex>
        <wui-icon size="xl" name="walletConnectBrown"></wui-icon>
        <wui-toggle
          ?checked=${this.checked}
          size="sm"
          @switchChange=${this.handleToggleChange.bind(this)}
        ></wui-toggle>
      </wui-flex>
    `}handleToggleChange(t){t.stopPropagation(),this.checked=t.detail,this.dispatchSwitchEvent()}dispatchSwitchEvent(){this.dispatchEvent(new CustomEvent("certifiedSwitchChange",{detail:this.checked,bubbles:!0,composed:!0}))}};ac.styles=[we,Be,j5];Rf([m({type:Boolean})],ac.prototype,"checked",void 0);ac=Rf([M("wui-certified-switch")],ac);const F5=Q`
  :host {
    position: relative;
    width: 100%;
    display: inline-flex;
    flex-direction: column;
    gap: ${({spacing:e})=>e[3]};
    color: ${({tokens:e})=>e.theme.textPrimary};
    caret-color: ${({tokens:e})=>e.core.textAccentPrimary};
  }

  .wui-input-text-container {
    position: relative;
    display: flex;
  }

  input {
    width: 100%;
    border-radius: ${({borderRadius:e})=>e[4]};
    color: inherit;
    background: transparent;
    border: 1px solid ${({tokens:e})=>e.theme.borderPrimary};
    caret-color: ${({tokens:e})=>e.core.textAccentPrimary};
    padding: ${({spacing:e})=>e[3]} ${({spacing:e})=>e[3]}
      ${({spacing:e})=>e[3]} ${({spacing:e})=>e[10]};
    font-size: ${({textSize:e})=>e.large};
    line-height: ${({typography:e})=>e["lg-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["lg-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
  }

  input[data-size='lg'] {
    padding: ${({spacing:e})=>e[4]} ${({spacing:e})=>e[3]}
      ${({spacing:e})=>e[4]} ${({spacing:e})=>e[10]};
  }

  @media (hover: hover) and (pointer: fine) {
    input:hover:enabled {
      border: 1px solid ${({tokens:e})=>e.theme.borderSecondary};
    }
  }

  input:disabled {
    cursor: unset;
    border: 1px solid ${({tokens:e})=>e.theme.borderPrimary};
  }

  input::placeholder {
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  input:focus:enabled {
    border: 1px solid ${({tokens:e})=>e.theme.borderSecondary};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    -webkit-box-shadow: 0px 0px 0px 4px ${({tokens:e})=>e.core.foregroundAccent040};
    -moz-box-shadow: 0px 0px 0px 4px ${({tokens:e})=>e.core.foregroundAccent040};
    box-shadow: 0px 0px 0px 4px ${({tokens:e})=>e.core.foregroundAccent040};
  }

  div.wui-input-text-container:has(input:disabled) {
    opacity: 0.5;
  }

  wui-icon.wui-input-text-left-icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
    left: ${({spacing:e})=>e[4]};
    color: ${({tokens:e})=>e.theme.iconDefault};
  }

  button.wui-input-text-submit-button {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: ${({spacing:e})=>e[3]};
    width: 24px;
    height: 24px;
    border: none;
    background: transparent;
    border-radius: ${({borderRadius:e})=>e[2]};
    color: ${({tokens:e})=>e.core.textAccentPrimary};
  }

  button.wui-input-text-submit-button:disabled {
    opacity: 1;
  }

  button.wui-input-text-submit-button.loading wui-icon {
    animation: spin 1s linear infinite;
  }

  button.wui-input-text-submit-button:hover {
    background: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  input:has(+ .wui-input-text-submit-button) {
    padding-right: ${({spacing:e})=>e[12]};
  }

  input[type='number'] {
    -moz-appearance: textfield;
  }

  input[type='search']::-webkit-search-decoration,
  input[type='search']::-webkit-search-cancel-button,
  input[type='search']::-webkit-search-results-button,
  input[type='search']::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  /* -- Keyframes --------------------------------------------------- */
  @keyframes spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
`;var rn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let kt=class extends de{constructor(){super(...arguments),this.inputElementRef=Mc(),this.disabled=!1,this.loading=!1,this.placeholder="",this.type="text",this.value="",this.size="md"}render(){return x` <div class="wui-input-text-container">
        ${this.templateLeftIcon()}
        <input
          data-size=${this.size}
          ${Uc(this.inputElementRef)}
          data-testid="wui-input-text"
          type=${this.type}
          enterkeyhint=${Qe(this.enterKeyHint)}
          ?disabled=${this.disabled}
          placeholder=${this.placeholder}
          @input=${this.dispatchInputChangeEvent.bind(this)}
          @keydown=${this.onKeyDown}
          .value=${this.value||""}
        />
        ${this.templateSubmitButton()}
        <slot class="wui-input-text-slot"></slot>
      </div>
      ${this.templateError()} ${this.templateWarning()}`}templateLeftIcon(){return this.icon?x`<wui-icon
        class="wui-input-text-left-icon"
        size="md"
        data-size=${this.size}
        color="inherit"
        name=${this.icon}
      ></wui-icon>`:null}templateSubmitButton(){return this.onSubmit?x`<button
        class="wui-input-text-submit-button ${this.loading?"loading":""}"
        @click=${this.onSubmit?.bind(this)}
        ?disabled=${this.disabled||this.loading}
      >
        ${this.loading?x`<wui-icon name="spinner" size="md"></wui-icon>`:x`<wui-icon name="chevronRight" size="md"></wui-icon>`}
      </button>`:null}templateError(){return this.errorText?x`<wui-text variant="sm-regular" color="error">${this.errorText}</wui-text>`:null}templateWarning(){return this.warningText?x`<wui-text variant="sm-regular" color="warning">${this.warningText}</wui-text>`:null}dispatchInputChangeEvent(){this.dispatchEvent(new CustomEvent("inputChange",{detail:this.inputElementRef.value?.value,bubbles:!0,composed:!0}))}};kt.styles=[we,Be,F5];rn([m()],kt.prototype,"icon",void 0);rn([m({type:Boolean})],kt.prototype,"disabled",void 0);rn([m({type:Boolean})],kt.prototype,"loading",void 0);rn([m()],kt.prototype,"placeholder",void 0);rn([m()],kt.prototype,"type",void 0);rn([m()],kt.prototype,"value",void 0);rn([m()],kt.prototype,"errorText",void 0);rn([m()],kt.prototype,"warningText",void 0);rn([m()],kt.prototype,"onSubmit",void 0);rn([m()],kt.prototype,"size",void 0);rn([m({attribute:!1})],kt.prototype,"onKeyDown",void 0);kt=rn([M("wui-input-text")],kt);const z5=Q`
  :host {
    position: relative;
    display: inline-block;
    width: 100%;
  }

  wui-icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: ${({spacing:e})=>e[3]};
    color: ${({tokens:e})=>e.theme.iconDefault};
    cursor: pointer;
    padding: ${({spacing:e})=>e[2]};
    background-color: transparent;
    border-radius: ${({borderRadius:e})=>e[4]};
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
  }

  @media (hover: hover) {
    wui-icon:hover {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }
`;var kf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let cc=class extends de{constructor(){super(...arguments),this.inputComponentRef=Mc(),this.inputValue=""}render(){return x`
      <wui-input-text
        ${Uc(this.inputComponentRef)}
        placeholder="Search wallet"
        icon="search"
        type="search"
        enterKeyHint="search"
        size="sm"
        @inputChange=${this.onInputChange}
      >
        ${this.inputValue?x`<wui-icon
              @click=${this.clearValue}
              color="inherit"
              size="sm"
              name="close"
            ></wui-icon>`:null}
      </wui-input-text>
    `}onInputChange(t){this.inputValue=t.detail||""}clearValue(){const n=this.inputComponentRef.value?.inputElementRef.value;n&&(n.value="",this.inputValue="",n.focus(),n.dispatchEvent(new Event("input")))}};cc.styles=[we,z5];kf([m()],cc.prototype,"inputValue",void 0);cc=kf([M("wui-search-bar")],cc);const If=pe`<svg  viewBox="0 0 48 54" fill="none">
  <path
    d="M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z"
  />
</svg>`,H5=Q`
  :host {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 104px;
    width: 104px;
    row-gap: ${({spacing:e})=>e[2]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[5]};
    position: relative;
  }

  wui-shimmer[data-type='network'] {
    border: none;
    -webkit-clip-path: var(--apkt-path-network);
    clip-path: var(--apkt-path-network);
  }

  svg {
    position: absolute;
    width: 48px;
    height: 54px;
    z-index: 1;
  }

  svg > path {
    stroke: ${({tokens:e})=>e.theme.foregroundSecondary};
    stroke-width: 1px;
  }

  @media (max-width: 350px) {
    :host {
      width: 100%;
    }
  }
`;var Of=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let lc=class extends de{constructor(){super(...arguments),this.type="wallet"}render(){return x`
      ${this.shimmerTemplate()}
      <wui-shimmer width="80px" height="20px"></wui-shimmer>
    `}shimmerTemplate(){return this.type==="network"?x` <wui-shimmer data-type=${this.type} width="48px" height="54px"></wui-shimmer>
        ${If}`:x`<wui-shimmer width="56px" height="56px"></wui-shimmer>`}};lc.styles=[we,Be,H5];Of([m()],lc.prototype,"type",void 0);lc=Of([M("wui-card-select-loader")],lc);const V5=Nt`
  :host {
    display: grid;
    width: inherit;
    height: inherit;
  }
`;var on=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let It=class extends de{render(){return this.style.cssText=`
      grid-template-rows: ${this.gridTemplateRows};
      grid-template-columns: ${this.gridTemplateColumns};
      justify-items: ${this.justifyItems};
      align-items: ${this.alignItems};
      justify-content: ${this.justifyContent};
      align-content: ${this.alignContent};
      column-gap: ${this.columnGap&&`var(--apkt-spacing-${this.columnGap})`};
      row-gap: ${this.rowGap&&`var(--apkt-spacing-${this.rowGap})`};
      gap: ${this.gap&&`var(--apkt-spacing-${this.gap})`};
      padding-top: ${this.padding&&Fe.getSpacingStyles(this.padding,0)};
      padding-right: ${this.padding&&Fe.getSpacingStyles(this.padding,1)};
      padding-bottom: ${this.padding&&Fe.getSpacingStyles(this.padding,2)};
      padding-left: ${this.padding&&Fe.getSpacingStyles(this.padding,3)};
      margin-top: ${this.margin&&Fe.getSpacingStyles(this.margin,0)};
      margin-right: ${this.margin&&Fe.getSpacingStyles(this.margin,1)};
      margin-bottom: ${this.margin&&Fe.getSpacingStyles(this.margin,2)};
      margin-left: ${this.margin&&Fe.getSpacingStyles(this.margin,3)};
    `,x`<slot></slot>`}};It.styles=[we,V5];on([m()],It.prototype,"gridTemplateRows",void 0);on([m()],It.prototype,"gridTemplateColumns",void 0);on([m()],It.prototype,"justifyItems",void 0);on([m()],It.prototype,"alignItems",void 0);on([m()],It.prototype,"justifyContent",void 0);on([m()],It.prototype,"alignContent",void 0);on([m()],It.prototype,"columnGap",void 0);on([m()],It.prototype,"rowGap",void 0);on([m()],It.prototype,"gap",void 0);on([m()],It.prototype,"padding",void 0);on([m()],It.prototype,"margin",void 0);It=on([M("wui-grid")],It);const q5=Q`
  button {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    width: 104px;
    row-gap: ${({spacing:e})=>e[2]};
    padding: ${({spacing:e})=>e[3]} ${({spacing:e})=>e[0]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: clamp(0px, ${({borderRadius:e})=>e[4]}, 20px);
    transition:
      color ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-1"]},
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-1"]},
      border-radius ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-1"]};
    will-change: background-color, color, border-radius;
    outline: none;
    border: none;
  }

  button > wui-flex > wui-text {
    color: ${({tokens:e})=>e.theme.textPrimary};
    max-width: 86px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    justify-content: center;
  }

  button > wui-flex > wui-text.certified {
    max-width: 66px;
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }

  button:disabled > wui-flex > wui-text {
    color: ${({tokens:e})=>e.core.glass010};
  }

  [data-selected='true'] {
    background-color: ${({colors:e})=>e.accent020};
  }

  @media (hover: hover) and (pointer: fine) {
    [data-selected='true']:hover:enabled {
      background-color: ${({colors:e})=>e.accent010};
    }
  }

  [data-selected='true']:active:enabled {
    background-color: ${({colors:e})=>e.accent010};
  }

  @media (max-width: 350px) {
    button {
      width: 100%;
    }
  }
`;var Bn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let en=class extends he{constructor(){super(),this.observer=new IntersectionObserver(()=>{}),this.visible=!1,this.imageSrc=void 0,this.imageLoading=!1,this.isImpressed=!1,this.explorerId="",this.walletQuery="",this.certified=!1,this.displayIndex=0,this.wallet=void 0,this.observer=new IntersectionObserver(t=>{t.forEach(n=>{n.isIntersecting?(this.visible=!0,this.fetchImageSrc(),this.sendImpressionEvent()):this.visible=!1})},{threshold:.01})}firstUpdated(){this.observer.observe(this)}disconnectedCallback(){this.observer.disconnect()}render(){const t=this.wallet?.badge_type==="certified";return g`
      <button>
        ${this.imageTemplate()}
        <wui-flex flexDirection="row" alignItems="center" justifyContent="center" gap="1">
          <wui-text
            variant="md-regular"
            color="inherit"
            class=${ae(t?"certified":void 0)}
            >${this.wallet?.name}</wui-text
          >
          ${t?g`<wui-icon size="sm" name="walletConnectBrown"></wui-icon>`:null}
        </wui-flex>
      </button>
    `}imageTemplate(){return!this.visible&&!this.imageSrc||this.imageLoading?this.shimmerTemplate():g`
      <wui-wallet-image
        size="lg"
        imageSrc=${ae(this.imageSrc)}
        name=${ae(this.wallet?.name)}
        .installed=${this.wallet?.installed??!1}
        badgeSize="sm"
      >
      </wui-wallet-image>
    `}shimmerTemplate(){return g`<wui-shimmer width="56px" height="56px"></wui-shimmer>`}async fetchImageSrc(){this.wallet&&(this.imageSrc=De.getWalletImage(this.wallet),!this.imageSrc&&(this.imageLoading=!0,this.imageSrc=await De.fetchWalletImage(this.wallet.image_id),this.imageLoading=!1))}sendImpressionEvent(){!this.wallet||this.isImpressed||(this.isImpressed=!0,X.sendWalletImpressionEvent({name:this.wallet.name,walletRank:this.wallet.order,explorerId:this.explorerId,view:S.state.view,query:this.walletQuery,certified:this.certified,displayIndex:this.displayIndex}))}};en.styles=q5;Bn([T()],en.prototype,"visible",void 0);Bn([T()],en.prototype,"imageSrc",void 0);Bn([T()],en.prototype,"imageLoading",void 0);Bn([T()],en.prototype,"isImpressed",void 0);Bn([ve()],en.prototype,"explorerId",void 0);Bn([ve()],en.prototype,"walletQuery",void 0);Bn([ve()],en.prototype,"certified",void 0);Bn([ve()],en.prototype,"displayIndex",void 0);Bn([ve({type:Object})],en.prototype,"wallet",void 0);en=Bn([M("w3m-all-wallets-list-item")],en);const K5=Q`
  wui-grid {
    max-height: clamp(360px, 400px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
    grid-template-columns: repeat(auto-fill, 104px);
  }

  :host([data-mobile-fullscreen='true']) wui-grid {
    max-height: none;
  }

  @media (max-width: 350px) {
    wui-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  w3m-all-wallets-list-item {
    opacity: 0;
    animation-duration: ${({durations:e})=>e.xl};
    animation-timing-function: ${({easings:e})=>e["ease-inout-power-2"]};
    animation-name: fade-in;
    animation-fill-mode: forwards;
  }

  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  wui-loading-spinner {
    padding-top: ${({spacing:e})=>e[4]};
    padding-bottom: ${({spacing:e})=>e[4]};
    justify-content: center;
    grid-column: 1 / span 4;
  }
`;var Qs=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const Nh="local-paginator";let fi=class extends he{constructor(){super(),this.unsubscribe=[],this.paginationObserver=void 0,this.loading=!q.state.wallets.length,this.wallets=q.state.wallets,this.mobileFullScreen=R.state.enableMobileFullScreen,this.unsubscribe.push(q.subscribeKey("wallets",t=>this.wallets=t))}firstUpdated(){this.initialFetch(),this.createPaginationObserver()}disconnectedCallback(){this.unsubscribe.forEach(t=>t()),this.paginationObserver?.disconnect()}render(){return this.mobileFullScreen&&this.setAttribute("data-mobile-fullscreen","true"),g`
      <wui-grid
        data-scroll=${!this.loading}
        .padding=${["0","3","3","3"]}
        gap="2"
        justifyContent="space-between"
      >
        ${this.loading?this.shimmerTemplate(16):this.walletsTemplate()}
        ${this.paginationLoaderTemplate()}
      </wui-grid>
    `}async initialFetch(){this.loading=!0;const t=this.shadowRoot?.querySelector("wui-grid");t&&(await q.fetchWalletsByPage({page:1}),await t.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.loading=!1,t.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"}))}shimmerTemplate(t,n){return[...Array(t)].map(()=>g`
        <wui-card-select-loader type="wallet" id=${ae(n)}></wui-card-select-loader>
      `)}walletsTemplate(){return Xt.getWalletConnectWallets(this.wallets).map((t,n)=>g`
        <w3m-all-wallets-list-item
          data-testid="wallet-search-item-${t.id}"
          @click=${()=>this.onConnectWallet(t)}
          .wallet=${t}
          explorerId=${t.id}
          certified=${this.badge==="certified"}
          displayIndex=${n}
        ></w3m-all-wallets-list-item>
      `)}paginationLoaderTemplate(){const{wallets:t,recommended:n,featured:r,count:o,mobileFilteredOutWalletsLength:i}=q.state,s=window.innerWidth<352?3:4,a=t.length+n.length;let l=Math.ceil(a/s)*s-a+s;return l-=t.length?r.length%s:0,o===0&&r.length>0?null:o===0||[...r,...t,...n].length<o-(i??0)?this.shimmerTemplate(l,Nh):null}createPaginationObserver(){const t=this.shadowRoot?.querySelector(`#${Nh}`);t&&(this.paginationObserver=new IntersectionObserver(([n])=>{if(n?.isIntersecting&&!this.loading){const{page:r,count:o,wallets:i}=q.state;i.length<o&&q.fetchWalletsByPage({page:r+1})}}),this.paginationObserver.observe(t))}onConnectWallet(t){O.selectWalletConnector(t)}};fi.styles=K5;Qs([T()],fi.prototype,"loading",void 0);Qs([T()],fi.prototype,"wallets",void 0);Qs([T()],fi.prototype,"badge",void 0);Qs([T()],fi.prototype,"mobileFullScreen",void 0);fi=Qs([M("w3m-all-wallets-list")],fi);const G5=Vt`
  wui-grid,
  wui-loading-spinner,
  wui-flex {
    height: 360px;
  }

  wui-grid {
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
    grid-template-columns: repeat(auto-fill, 104px);
  }

  :host([data-mobile-fullscreen='true']) wui-grid {
    max-height: none;
    height: auto;
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  wui-loading-spinner {
    justify-content: center;
    align-items: center;
  }

  @media (max-width: 350px) {
    wui-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }
`;var ea=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let mi=class extends he{constructor(){super(...arguments),this.prevQuery="",this.prevBadge=void 0,this.loading=!0,this.mobileFullScreen=R.state.enableMobileFullScreen,this.query=""}render(){return this.mobileFullScreen&&this.setAttribute("data-mobile-fullscreen","true"),this.onSearch(),this.loading?g`<wui-loading-spinner color="accent-primary"></wui-loading-spinner>`:this.walletsTemplate()}async onSearch(){(this.query.trim()!==this.prevQuery.trim()||this.badge!==this.prevBadge)&&(this.prevQuery=this.query,this.prevBadge=this.badge,this.loading=!0,await q.searchWallet({search:this.query,badge:this.badge}),this.loading=!1)}walletsTemplate(){const{search:t}=q.state,n=Xt.markWalletsAsInstalled(t),r=Xt.filterWalletsByWcSupport(n);return r.length?g`
      <wui-grid
        data-testid="wallet-list"
        .padding=${["0","3","3","3"]}
        rowGap="4"
        columngap="2"
        justifyContent="space-between"
      >
        ${r.map((o,i)=>g`
            <w3m-all-wallets-list-item
              @click=${()=>this.onConnectWallet(o)}
              .wallet=${o}
              data-testid="wallet-search-item-${o.id}"
              explorerId=${o.id}
              certified=${this.badge==="certified"}
              walletQuery=${this.query}
              displayIndex=${i}
            ></w3m-all-wallets-list-item>
          `)}
      </wui-grid>
    `:g`
        <wui-flex
          data-testid="no-wallet-found"
          justifyContent="center"
          alignItems="center"
          gap="3"
          flexDirection="column"
        >
          <wui-icon-box size="lg" color="default" icon="wallet"></wui-icon-box>
          <wui-text data-testid="no-wallet-found-text" color="secondary" variant="md-medium">
            No Wallet found
          </wui-text>
        </wui-flex>
      `}onConnectWallet(t){O.selectWalletConnector(t)}};mi.styles=G5;ea([T()],mi.prototype,"loading",void 0);ea([T()],mi.prototype,"mobileFullScreen",void 0);ea([ve()],mi.prototype,"query",void 0);ea([ve()],mi.prototype,"badge",void 0);mi=ea([M("w3m-all-wallets-search")],mi);var eu=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let dc=class extends he{constructor(){super(...arguments),this.search="",this.badge=void 0,this.onDebouncedSearch=L.debounce(t=>{this.search=t})}render(){const t=this.search.length>=2;return g`
      <wui-flex .padding=${["1","3","3","3"]} gap="2" alignItems="center">
        <wui-search-bar @inputChange=${this.onInputChange.bind(this)}></wui-search-bar>
        <wui-certified-switch
          ?checked=${this.badge==="certified"}
          @certifiedSwitchChange=${this.onCertifiedSwitchChange.bind(this)}
          data-testid="wui-certified-switch"
        ></wui-certified-switch>
        ${this.qrButtonTemplate()}
      </wui-flex>
      ${t||this.badge?g`<w3m-all-wallets-search
            query=${this.search}
            .badge=${this.badge}
          ></w3m-all-wallets-search>`:g`<w3m-all-wallets-list .badge=${this.badge}></w3m-all-wallets-list>`}
    `}onInputChange(t){this.onDebouncedSearch(t.detail)}onCertifiedSwitchChange(t){t.detail?(this.badge="certified",Te.showSvg("Only WalletConnect certified",{icon:"walletConnectBrown",iconColor:"accent-100"})):this.badge=void 0}qrButtonTemplate(){return L.isMobile()?g`
        <wui-icon-box
          size="xl"
          iconSize="xl"
          color="accent-primary"
          icon="qrCode"
          border
          borderColor="wui-accent-glass-010"
          @click=${this.onWalletConnectQr.bind(this)}
        ></wui-icon-box>
      `:null}onWalletConnectQr(){S.push("ConnectingWalletConnect")}};eu([T()],dc.prototype,"search",void 0);eu([T()],dc.prototype,"badge",void 0);dc=eu([M("w3m-all-wallets-view")],dc);const Z5=Q`
  button {
    display: flex;
    gap: ${({spacing:e})=>e[1]};
    padding: ${({spacing:e})=>e[4]};
    width: 100%;
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[4]};
    justify-content: center;
    align-items: center;
  }

  :host([data-size='sm']) button {
    padding: ${({spacing:e})=>e[2]};
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  :host([data-size='md']) button {
    padding: ${({spacing:e})=>e[3]};
    border-radius: ${({borderRadius:e})=>e[3]};
  }

  button:hover {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  button:disabled {
    opacity: 0.5;
  }
`;var Co=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let _r=class extends de{constructor(){super(...arguments),this.text="",this.disabled=!1,this.size="lg",this.icon="copy",this.tabIdx=void 0}render(){this.dataset.size=this.size;const t=`${this.size}-regular`;return x`
      <button ?disabled=${this.disabled} tabindex=${Qe(this.tabIdx)}>
        <wui-icon name=${this.icon} size=${this.size} color="default"></wui-icon>
        <wui-text align="center" variant=${t} color="primary">${this.text}</wui-text>
      </button>
    `}};_r.styles=[we,Be,Z5];Co([m()],_r.prototype,"text",void 0);Co([m({type:Boolean})],_r.prototype,"disabled",void 0);Co([m()],_r.prototype,"size",void 0);Co([m()],_r.prototype,"icon",void 0);Co([m()],_r.prototype,"tabIdx",void 0);_r=Co([M("wui-list-button")],_r);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Y5=e=>e.strings===void 0;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Uo=(e,t)=>{const n=e._$AN;if(n===void 0)return!1;for(const r of n)r._$AO?.(t,!1),Uo(r,t);return!0},uc=e=>{let t,n;do{if((t=e._$AM)===void 0)break;n=t._$AN,n.delete(e),e=t}while(n?.size===0)},Pf=e=>{for(let t;t=e._$AM;e=t){let n=t._$AN;if(n===void 0)t._$AN=n=new Set;else if(n.has(e))break;n.add(e),Q5(t)}};function J5(e){this._$AN!==void 0?(uc(this),this._$AM=e,Pf(this)):this._$AM=e}function X5(e,t=!1,n=0){const r=this._$AH,o=this._$AN;if(o!==void 0&&o.size!==0)if(t)if(Array.isArray(r))for(let i=n;i<r.length;i++)Uo(r[i],!1),uc(r[i]);else r!=null&&(Uo(r,!1),uc(r));else Uo(this,e)}const Q5=e=>{e.type==xf.CHILD&&(e._$AP??=X5,e._$AQ??=J5)};class eC extends Tf{constructor(){super(...arguments),this._$AN=void 0}_$AT(t,n,r){super._$AT(t,n,r),Pf(this),this.isConnected=t._$AU}_$AO(t,n=!0){t!==this.isConnected&&(this.isConnected=t,t?this.reconnected?.():this.disconnected?.()),n&&(Uo(this,t),uc(this))}setValue(t){if(Y5(this._$Ct))this._$Ct._$AI(t,this);else{const n=[...this._$Ct._$AH];n[this._$Ci]=t,this._$Ct._$AI(n,this,0)}}disconnected(){}reconnected(){}}/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const tC=()=>new nC;class nC{}const dl=new WeakMap,rC=Sf(class extends eC{render(e){return Xe}update(e,[t]){const n=t!==this.G;return n&&this.G!==void 0&&this.rt(void 0),(n||this.lt!==this.ct)&&(this.G=t,this.ht=e.options?.host,this.rt(this.ct=e.element)),Xe}rt(e){if(this.isConnected||(e=void 0),typeof this.G=="function"){const t=this.ht??globalThis;let n=dl.get(t);n===void 0&&(n=new WeakMap,dl.set(t,n)),n.get(this.G)!==void 0&&this.G.call(this.ht,void 0),n.set(this.G,e),e!==void 0&&this.G.call(this.ht,e)}else this.G.value=e}get lt(){return typeof this.G=="function"?dl.get(this.ht??globalThis)?.get(this.G):this.G?.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}}),iC=Nt`
  :host {
    position: relative;
    display: inline-block;
    width: 100%;
  }
`;var ta=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let gi=class extends de{constructor(){super(...arguments),this.disabled=!1}render(){return x`
      <wui-input-text
        type="email"
        placeholder="Email"
        icon="mail"
        size="lg"
        .disabled=${this.disabled}
        .value=${this.value}
        data-testid="wui-email-input"
        tabIdx=${Qe(this.tabIdx)}
      ></wui-input-text>
      ${this.templateError()}
    `}templateError(){return this.errorMessage?x`<wui-text variant="sm-regular" color="error">${this.errorMessage}</wui-text>`:null}};gi.styles=[we,iC];ta([m()],gi.prototype,"errorMessage",void 0);ta([m({type:Boolean})],gi.prototype,"disabled",void 0);ta([m()],gi.prototype,"value",void 0);ta([m()],gi.prototype,"tabIdx",void 0);gi=ta([M("wui-email-input")],gi);const oC=Q`
  wui-separator {
    margin: ${({spacing:e})=>e[3]} calc(${({spacing:e})=>e[3]} * -1);
    width: calc(100% + ${({spacing:e})=>e[3]} * 2);
  }

  wui-email-input {
    width: 100%;
  }

  form {
    width: 100%;
    display: block;
    position: relative;
  }

  wui-icon-link,
  wui-loading-spinner {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
  }

  wui-icon-link {
    right: ${({spacing:e})=>e[2]};
  }

  wui-loading-spinner {
    right: ${({spacing:e})=>e[3]};
  }

  wui-text {
    margin: ${({spacing:e})=>e[2]} ${({spacing:e})=>e[3]}
      ${({spacing:e})=>e[0]} ${({spacing:e})=>e[3]};
  }
`;var ki=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let nr=class extends he{constructor(){super(),this.unsubscribe=[],this.formRef=tC(),this.email="",this.loading=!1,this.error="",this.remoteFeatures=R.state.remoteFeatures,this.hasExceededUsageLimit=q.state.plan.hasExceededUsageLimit,this.unsubscribe.push(R.subscribeKey("remoteFeatures",t=>{this.remoteFeatures=t}),q.subscribeKey("plan",t=>this.hasExceededUsageLimit=t.hasExceededUsageLimit))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}firstUpdated(){this.formRef.value?.addEventListener("keydown",t=>{t.key==="Enter"&&this.onSubmitEmail(t)})}render(){const t=U.hasAnyConnection(N.CONNECTOR_ID.AUTH);return g`
      <form ${rC(this.formRef)} @submit=${this.onSubmitEmail.bind(this)}>
        <wui-email-input
          @focus=${this.onFocusEvent.bind(this)}
          .disabled=${this.loading}
          @inputChange=${this.onEmailInputChange.bind(this)}
          tabIdx=${ae(this.tabIdx)}
          ?disabled=${t||this.hasExceededUsageLimit}
        >
        </wui-email-input>

        ${this.submitButtonTemplate()}${this.loadingTemplate()}
        <input type="submit" hidden />
      </form>
      ${this.templateError()}
    `}submitButtonTemplate(){return!this.loading&&this.email.length>3?g`
          <wui-icon-link
            size="sm"
            icon="chevronRight"
            iconcolor="accent-100"
            @click=${this.onSubmitEmail.bind(this)}
          >
          </wui-icon-link>
        `:null}loadingTemplate(){return this.loading?g`<wui-loading-spinner size="md" color="accent-primary"></wui-loading-spinner>`:null}templateError(){return this.error?g`<wui-text variant="sm-medium" color="error">${this.error}</wui-text>`:null}onEmailInputChange(t){this.email=t.detail.trim(),this.error=""}async onSubmitEmail(t){if(!Zi.isValidEmail(this.email)){Xp.open({displayMessage:L3.ALERT_WARNINGS.INVALID_EMAIL.displayMessage},"warning");return}if(!N.AUTH_CONNECTOR_SUPPORTED_CHAINS.find(r=>r===p.state.activeChain)){const r=p.getFirstCaipNetworkSupportsAuthConnector();if(r){S.push("SwitchNetwork",{network:r});return}}try{if(this.loading)return;this.loading=!0,t.preventDefault();const r=O.getAuthConnector();if(!r)throw new Error("w3m-email-login-widget: Auth connector not found");const{action:o}=await r.provider.connectEmail({email:this.email});if(X.sendEvent({type:"track",event:"EMAIL_SUBMITTED"}),o==="VERIFY_OTP")X.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_SENT"}),S.push("EmailVerifyOtp",{email:this.email});else if(o==="VERIFY_DEVICE")S.push("EmailVerifyDevice",{email:this.email});else if(o==="CONNECT"){const i=this.remoteFeatures?.multiWallet;await U.connectExternal(r,p.state.activeChain),i?(S.replace("ProfileWallets"),Te.showSuccess("New Wallet Added")):S.replace("Account")}}catch(r){L.parseError(r)?.includes("Invalid email")?this.error="Invalid email. Try again.":Te.showError(r)}finally{this.loading=!1}}onFocusEvent(){X.sendEvent({type:"track",event:"EMAIL_LOGIN_SELECTED"})}};nr.styles=oC;ki([ve()],nr.prototype,"tabIdx",void 0);ki([T()],nr.prototype,"email",void 0);ki([T()],nr.prototype,"loading",void 0);ki([T()],nr.prototype,"error",void 0);ki([T()],nr.prototype,"remoteFeatures",void 0);ki([T()],nr.prototype,"hasExceededUsageLimit",void 0);nr=ki([M("w3m-email-login-widget")],nr);const sC=Q`
  label {
    display: inline-flex;
    align-items: center;
    cursor: pointer;
    user-select: none;
    column-gap: ${({spacing:e})=>e[2]};
  }

  label > input[type='checkbox'] {
    height: 0;
    width: 0;
    opacity: 0;
    position: absolute;
  }

  label > span {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    width: 100%;
    border: 1px solid ${({colors:e})=>e.neutrals400};
    color: ${({colors:e})=>e.white};
    background-color: transparent;
    will-change: border-color, background-color;
  }

  label > span > wui-icon {
    opacity: 0;
    will-change: opacity;
  }

  label > input[type='checkbox']:checked + span > wui-icon {
    color: ${({colors:e})=>e.white};
  }

  label > input[type='checkbox']:not(:checked) > span > wui-icon {
    color: ${({colors:e})=>e.neutrals900};
  }

  label > input[type='checkbox']:checked + span > wui-icon {
    opacity: 1;
  }

  /* -- Sizes --------------------------------------------------- */
  label[data-size='lg'] > span {
    width: 24px;
    height: 24px;
    min-width: 24px;
    min-height: 24px;
    border-radius: ${({borderRadius:e})=>e[10]};
  }

  label[data-size='md'] > span {
    width: 20px;
    height: 20px;
    min-width: 20px;
    min-height: 20px;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  label[data-size='sm'] > span {
    width: 16px;
    height: 16px;
    min-width: 16px;
    min-height: 16px;
    border-radius: ${({borderRadius:e})=>e[1]};
  }

  /* -- Focus states --------------------------------------------------- */
  label > input[type='checkbox']:focus-visible + span,
  label > input[type='checkbox']:focus + span {
    border: 1px solid ${({tokens:e})=>e.core.borderAccentPrimary};
    box-shadow: 0px 0px 0px 4px rgba(9, 136, 240, 0.2);
  }

  /* -- Checked states --------------------------------------------------- */
  label > input[type='checkbox']:checked + span {
    background-color: ${({tokens:e})=>e.core.iconAccentPrimary};
    border: 1px solid transparent;
  }

  /* -- Hover states --------------------------------------------------- */
  input[type='checkbox']:not(:checked):not(:disabled) + span:hover {
    border: 1px solid ${({colors:e})=>e.neutrals700};
    background-color: ${({colors:e})=>e.neutrals800};
    box-shadow: none;
  }

  input[type='checkbox']:checked:not(:disabled) + span:hover {
    border: 1px solid transparent;
    background-color: ${({colors:e})=>e.accent080};
    box-shadow: none;
  }

  /* -- Disabled state --------------------------------------------------- */
  label > input[type='checkbox']:checked:disabled + span {
    border: 1px solid transparent;
    opacity: 0.3;
  }

  label > input[type='checkbox']:not(:checked):disabled + span {
    border: 1px solid ${({colors:e})=>e.neutrals700};
  }

  label:has(input[type='checkbox']:disabled) {
    cursor: auto;
  }

  label > input[type='checkbox']:disabled + span {
    cursor: not-allowed;
  }
`;var Wc=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const aC={lg:"md",md:"sm",sm:"sm"};let lo=class extends de{constructor(){super(...arguments),this.inputElementRef=Mc(),this.checked=void 0,this.disabled=!1,this.size="md"}render(){const t=aC[this.size];return x`
      <label data-size=${this.size}>
        <input
          ${Uc(this.inputElementRef)}
          ?checked=${Qe(this.checked)}
          ?disabled=${this.disabled}
          type="checkbox"
          @change=${this.dispatchChangeEvent}
        />
        <span>
          <wui-icon name="checkmarkBold" size=${t}></wui-icon>
        </span>
        <slot></slot>
      </label>
    `}dispatchChangeEvent(){this.dispatchEvent(new CustomEvent("checkboxChange",{detail:this.inputElementRef.value?.checked,bubbles:!0,composed:!0}))}};lo.styles=[we,sC];Wc([m({type:Boolean})],lo.prototype,"checked",void 0);Wc([m({type:Boolean})],lo.prototype,"disabled",void 0);Wc([m()],lo.prototype,"size",void 0);lo=Wc([M("wui-checkbox")],lo);const cC=Q`
  :host {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  wui-checkbox {
    padding: ${({spacing:e})=>e[3]};
  }
  a {
    text-decoration: none;
    color: ${({tokens:e})=>e.theme.textSecondary};
    font-weight: 500;
  }
`;var Lf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let hc=class extends he{constructor(){super(),this.unsubscribe=[],this.checked=qr.state.isLegalCheckboxChecked,this.unsubscribe.push(qr.subscribeKey("isLegalCheckboxChecked",t=>{this.checked=t}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){const{termsConditionsUrl:t,privacyPolicyUrl:n}=R.state,r=R.state.features?.legalCheckbox;return!t&&!n||!r?null:g`
      <wui-checkbox
        ?checked=${this.checked}
        @checkboxChange=${this.onCheckboxChange.bind(this)}
        data-testid="wui-checkbox"
      >
        <wui-text color="secondary" variant="sm-regular" align="left">
          I agree to our ${this.termsTemplate()} ${this.andTemplate()} ${this.privacyTemplate()}
        </wui-text>
      </wui-checkbox>
    `}andTemplate(){const{termsConditionsUrl:t,privacyPolicyUrl:n}=R.state;return t&&n?"and":""}termsTemplate(){const{termsConditionsUrl:t}=R.state;return t?g`<a rel="noreferrer" target="_blank" href=${t}>terms of service</a>`:null}privacyTemplate(){const{privacyPolicyUrl:t}=R.state;return t?g`<a rel="noreferrer" target="_blank" href=${t}>privacy policy</a>`:null}onCheckboxChange(){qr.setIsLegalCheckboxChecked(!this.checked)}};hc.styles=[cC];Lf([T()],hc.prototype,"checked",void 0);hc=Lf([M("w3m-legal-checkbox")],hc);const lC=Q`
  :host {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 40px;
    height: 40px;
    border-radius: ${({borderRadius:e})=>e[20]};
    overflow: hidden;
  }

  wui-icon {
    width: 100%;
    height: 100%;
  }
`;var Df=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let pc=class extends de{constructor(){super(...arguments),this.logo="google"}render(){return x`<wui-icon color="inherit" size="inherit" name=${this.logo}></wui-icon> `}};pc.styles=[we,lC];Df([m()],pc.prototype,"logo",void 0);pc=Df([M("wui-logo")],pc);const dC=Q`
  :host {
    width: 100%;
  }

  button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: ${({spacing:e})=>e[3]};
    width: 100%;
    background-color: transparent;
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  wui-text {
    text-transform: capitalize;
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    }
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;var na=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let wi=class extends de{constructor(){super(...arguments),this.logo="google",this.name="Continue with google",this.disabled=!1}render(){return x`
      <button ?disabled=${this.disabled} tabindex=${Qe(this.tabIdx)}>
        <wui-flex gap="2" alignItems="center">
          <wui-image ?boxed=${!0} logo=${this.logo}></wui-image>
          <wui-text variant="lg-regular" color="primary">${this.name}</wui-text>
        </wui-flex>
        <wui-icon name="chevronRight" size="lg" color="default"></wui-icon>
      </button>
    `}};wi.styles=[we,Be,dC];na([m()],wi.prototype,"logo",void 0);na([m()],wi.prototype,"name",void 0);na([m()],wi.prototype,"tabIdx",void 0);na([m({type:Boolean})],wi.prototype,"disabled",void 0);wi=na([M("wui-list-social")],wi);const uC=Q`
  :host {
    display: block;
    width: 100%;
  }

  button {
    width: 100%;
    height: 52px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  @media (hover: hover) {
    button:hover:enabled {
      background: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }

  button:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }
`;var jc=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let uo=class extends de{constructor(){super(...arguments),this.logo="google",this.disabled=!1,this.tabIdx=void 0}render(){return x`
      <button ?disabled=${this.disabled} tabindex=${Qe(this.tabIdx)}>
        <wui-icon size="xxl" name=${this.logo}></wui-icon>
      </button>
    `}};uo.styles=[we,Be,uC];jc([m()],uo.prototype,"logo",void 0);jc([m({type:Boolean})],uo.prototype,"disabled",void 0);jc([m()],uo.prototype,"tabIdx",void 0);uo=jc([M("wui-logo-select")],uo);const hC=Q`
  wui-separator {
    margin: ${({spacing:e})=>e[3]} calc(${({spacing:e})=>e[3]} * -1)
      ${({spacing:e})=>e[3]} calc(${({spacing:e})=>e[3]} * -1);
    width: calc(100% + ${({spacing:e})=>e[3]} * 2);
  }
`;var Rr=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const Rh=2,kh=6;let Ln=class extends he{constructor(){super(),this.unsubscribe=[],this.walletGuide="get-started",this.tabIdx=void 0,this.connectors=O.state.connectors,this.remoteFeatures=R.state.remoteFeatures,this.authConnector=this.connectors.find(t=>t.type==="AUTH"),this.isPwaLoading=!1,this.hasExceededUsageLimit=q.state.plan.hasExceededUsageLimit,this.unsubscribe.push(O.subscribeKey("connectors",t=>{this.connectors=t,this.authConnector=this.connectors.find(n=>n.type==="AUTH")}),R.subscribeKey("remoteFeatures",t=>this.remoteFeatures=t),q.subscribeKey("plan",t=>this.hasExceededUsageLimit=t.hasExceededUsageLimit))}connectedCallback(){super.connectedCallback(),this.handlePwaFrameLoad()}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return g`
      <wui-flex
        class="container"
        flexDirection="column"
        gap="2"
        data-testid="w3m-social-login-widget"
      >
        ${this.topViewTemplate()}${this.bottomViewTemplate()}
      </wui-flex>
    `}topViewTemplate(){const t=this.walletGuide==="explore";let n=this.remoteFeatures?.socials;return!n&&t?(n=ke.DEFAULT_SOCIALS,this.renderTopViewContent(n)):n?this.renderTopViewContent(n):null}renderTopViewContent(t){return t.length===2?g` <wui-flex gap="2">
        ${t.slice(0,Rh).map(n=>g`<wui-logo-select
              data-testid=${`social-selector-${n}`}
              @click=${()=>{this.onSocialClick(n)}}
              logo=${n}
              tabIdx=${ae(this.tabIdx)}
              ?disabled=${this.isPwaLoading||this.hasConnection()}
            ></wui-logo-select>`)}
      </wui-flex>`:g` <wui-list-button
      data-testid=${`social-selector-${t[0]}`}
      @click=${()=>{this.onSocialClick(t[0])}}
      size="lg"
      icon=${ae(t[0])}
      text=${`Continue with ${Fe.capitalize(t[0])}`}
      tabIdx=${ae(this.tabIdx)}
      ?disabled=${this.isPwaLoading||this.hasConnection()}
    ></wui-list-button>`}bottomViewTemplate(){let t=this.remoteFeatures?.socials;const n=this.walletGuide==="explore";return(!this.authConnector||!t||t.length===0)&&n&&(t=ke.DEFAULT_SOCIALS),!t||t.length<=Rh?null:t&&t.length>kh?g`<wui-flex gap="2">
        ${t.slice(1,kh-1).map(o=>g`<wui-logo-select
              data-testid=${`social-selector-${o}`}
              @click=${()=>{this.onSocialClick(o)}}
              logo=${o}
              tabIdx=${ae(this.tabIdx)}
              ?focusable=${this.tabIdx!==void 0&&this.tabIdx>=0}
              ?disabled=${this.isPwaLoading||this.hasConnection()}
            ></wui-logo-select>`)}
        <wui-logo-select
          logo="more"
          tabIdx=${ae(this.tabIdx)}
          @click=${this.onMoreSocialsClick.bind(this)}
          ?disabled=${this.isPwaLoading||this.hasConnection()}
          data-testid="social-selector-more"
        ></wui-logo-select>
      </wui-flex>`:t?g`<wui-flex gap="2">
      ${t.slice(1,t.length).map(o=>g`<wui-logo-select
            data-testid=${`social-selector-${o}`}
            @click=${()=>{this.onSocialClick(o)}}
            logo=${o}
            tabIdx=${ae(this.tabIdx)}
            ?focusable=${this.tabIdx!==void 0&&this.tabIdx>=0}
            ?disabled=${this.isPwaLoading||this.hasConnection()}
          ></wui-logo-select>`)}
    </wui-flex>`:null}onMoreSocialsClick(){S.push("ConnectSocials")}async onSocialClick(t){if(this.hasExceededUsageLimit){S.push("UsageExceeded");return}if(!N.AUTH_CONNECTOR_SUPPORTED_CHAINS.find(r=>r===p.state.activeChain)){const r=p.getFirstCaipNetworkSupportsAuthConnector();if(r){S.push("SwitchNetwork",{network:r});return}}t&&await I3(t)}async handlePwaFrameLoad(){if(L.isPWA()){this.isPwaLoading=!0;try{this.authConnector?.provider instanceof pw&&await this.authConnector.provider.init()}catch(t){Xp.open({displayMessage:"Error loading embedded wallet in PWA",debugMessage:t.message},"error")}finally{this.isPwaLoading=!1}}}hasConnection(){return U.hasAnyConnection(N.CONNECTOR_ID.AUTH)}};Ln.styles=hC;Rr([ve()],Ln.prototype,"walletGuide",void 0);Rr([ve()],Ln.prototype,"tabIdx",void 0);Rr([T()],Ln.prototype,"connectors",void 0);Rr([T()],Ln.prototype,"remoteFeatures",void 0);Rr([T()],Ln.prototype,"authConnector",void 0);Rr([T()],Ln.prototype,"isPwaLoading",void 0);Rr([T()],Ln.prototype,"hasExceededUsageLimit",void 0);Ln=Rr([M("w3m-social-login-widget")],Ln);const pC=Q`
  :host {
    position: relative;
    border-radius: ${({borderRadius:e})=>e[2]};
    width: 40px;
    height: 40px;
    overflow: hidden;
    background: ${({tokens:e})=>e.theme.foregroundPrimary};
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    column-gap: ${({spacing:e})=>e[1]};
    padding: ${({spacing:e})=>e[1]};
  }

  :host > wui-wallet-image {
    width: 14px;
    height: 14px;
    border-radius: 2px;
  }
`;var Mf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const ul=4;let fc=class extends de{constructor(){super(...arguments),this.walletImages=[]}render(){const t=this.walletImages.length<ul;return x`${this.walletImages.slice(0,ul).map(({src:n,walletName:r})=>x`
          <wui-wallet-image
            size="sm"
            imageSrc=${n}
            name=${Qe(r)}
          ></wui-wallet-image>
        `)}
    ${t?[...Array(ul-this.walletImages.length)].map(()=>x` <wui-wallet-image size="sm" name=""></wui-wallet-image>`):null} `}};fc.styles=[we,pC];Mf([m({type:Array})],fc.prototype,"walletImages",void 0);fc=Mf([M("wui-all-wallets-image")],fc);const fC=Q`
  :host {
    width: 100%;
  }

  button {
    column-gap: ${({spacing:e})=>e[2]};
    padding: ${({spacing:e})=>e[3]};
    width: 100%;
    background-color: transparent;
    border-radius: ${({borderRadius:e})=>e[4]};
    color: ${({tokens:e})=>e.theme.textPrimary};
  }

  button > wui-wallet-image {
    background: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  button > wui-text:nth-child(2) {
    display: flex;
    flex: 1;
  }

  button:hover:enabled {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  button[data-all-wallets='true'] {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  button[data-all-wallets='true']:hover:enabled {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  button:focus-visible:enabled {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    box-shadow: 0 0 0 4px ${({tokens:e})=>e.core.foregroundAccent020};
  }

  button:disabled {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    opacity: 0.5;
    cursor: not-allowed;
  }

  button:disabled > wui-tag {
    background-color: ${({tokens:e})=>e.core.glass010};
    color: ${({tokens:e})=>e.theme.foregroundTertiary};
  }

  wui-flex.namespace-icon {
    width: 16px;
    height: 16px;
    border-radius: ${({borderRadius:e})=>e.round};
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    box-shadow: 0 0 0 2px ${({tokens:e})=>e.theme.backgroundPrimary};
    transition: box-shadow var(--apkt-durations-lg) var(--apkt-easings-ease-out-power-2);
  }

  button:hover:enabled wui-flex.namespace-icon {
    box-shadow: 0 0 0 2px ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  wui-flex.namespace-icon > wui-icon {
    width: 10px;
    height: 10px;
  }

  wui-flex.namespace-icon:not(:first-child) {
    margin-left: -4px;
  }
`;var Ut=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const mC={eip155:"ethereum",solana:"solana",bip122:"bitcoin",polkadot:void 0,cosmos:void 0,sui:void 0,stacks:void 0,ton:"ton"};let gt=class extends de{constructor(){super(...arguments),this.walletImages=[],this.imageSrc="",this.name="",this.size="md",this.tabIdx=void 0,this.namespaces=[],this.disabled=!1,this.showAllWallets=!1,this.loading=!1,this.loadingSpinnerColor="accent-100"}render(){return this.dataset.size=this.size,x`
      <button
        ?disabled=${this.disabled}
        data-all-wallets=${this.showAllWallets}
        tabindex=${Qe(this.tabIdx)}
      >
        ${this.templateAllWallets()} ${this.templateWalletImage()}
        <wui-flex flexDirection="column" justifyContent="center" alignItems="flex-start" gap="1">
          <wui-text variant="lg-regular" color="inherit">${this.name}</wui-text>
          ${this.templateNamespaces()}
        </wui-flex>
        ${this.templateStatus()}
        <wui-icon name="chevronRight" size="lg" color="default"></wui-icon>
      </button>
    `}templateNamespaces(){return this.namespaces?.length?x`<wui-flex alignItems="center" gap="0">
        ${this.namespaces.map((t,n)=>x`<wui-flex
              alignItems="center"
              justifyContent="center"
              zIndex=${(this.namespaces?.length??0)*2-n}
              class="namespace-icon"
            >
              <wui-icon
                name=${Qe(mC[t])}
                size="sm"
                color="default"
              ></wui-icon>
            </wui-flex>`)}
      </wui-flex>`:null}templateAllWallets(){return this.showAllWallets&&this.imageSrc?x` <wui-all-wallets-image .imageeSrc=${this.imageSrc}> </wui-all-wallets-image> `:this.showAllWallets&&this.walletIcon?x` <wui-wallet-image .walletIcon=${this.walletIcon} size="sm"> </wui-wallet-image> `:null}templateWalletImage(){return!this.showAllWallets&&this.imageSrc?x`<wui-wallet-image
        size=${Qe(this.size==="sm"?"sm":"md")}
        imageSrc=${this.imageSrc}
        name=${this.name}
      ></wui-wallet-image>`:!this.showAllWallets&&!this.imageSrc?x`<wui-wallet-image size="sm" name=${this.name}></wui-wallet-image>`:null}templateStatus(){return this.loading?x`<wui-loading-spinner size="lg" color="accent-primary"></wui-loading-spinner>`:this.tagLabel&&this.tagVariant?x`<wui-tag size="sm" variant=${this.tagVariant}>${this.tagLabel}</wui-tag>`:null}};gt.styles=[we,Be,fC];Ut([m({type:Array})],gt.prototype,"walletImages",void 0);Ut([m()],gt.prototype,"imageSrc",void 0);Ut([m()],gt.prototype,"name",void 0);Ut([m()],gt.prototype,"size",void 0);Ut([m()],gt.prototype,"tagLabel",void 0);Ut([m()],gt.prototype,"tagVariant",void 0);Ut([m()],gt.prototype,"walletIcon",void 0);Ut([m()],gt.prototype,"tabIdx",void 0);Ut([m({type:Array})],gt.prototype,"namespaces",void 0);Ut([m({type:Boolean})],gt.prototype,"disabled",void 0);Ut([m({type:Boolean})],gt.prototype,"showAllWallets",void 0);Ut([m({type:Boolean})],gt.prototype,"loading",void 0);Ut([m({type:String})],gt.prototype,"loadingSpinnerColor",void 0);gt=Ut([M("wui-list-wallet")],gt);var vo=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let bi=class extends he{constructor(){super(),this.unsubscribe=[],this.tabIdx=void 0,this.connectors=O.state.connectors,this.count=q.state.count,this.filteredCount=q.state.filteredWallets.length,this.isFetchingRecommendedWallets=q.state.isFetchingRecommendedWallets,this.unsubscribe.push(O.subscribeKey("connectors",t=>this.connectors=t),q.subscribeKey("count",t=>this.count=t),q.subscribeKey("filteredWallets",t=>this.filteredCount=t.length),q.subscribeKey("isFetchingRecommendedWallets",t=>this.isFetchingRecommendedWallets=t))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){const t=this.connectors.find(l=>l.id==="walletConnect"),{allWallets:n}=R.state;if(!t||n==="HIDE"||n==="ONLY_MOBILE"&&!L.isMobile())return null;const r=q.state.featured.length,o=this.count+r,i=o<10?o:Math.floor(o/10)*10,s=this.filteredCount>0?this.filteredCount:i;let a=`${s}`;this.filteredCount>0?a=`${this.filteredCount}`:s<o&&(a=`${s}+`);const c=U.hasAnyConnection(N.CONNECTOR_ID.WALLET_CONNECT);return g`
      <wui-list-wallet
        name="Search Wallet"
        walletIcon="search"
        showAllWallets
        @click=${this.onAllWallets.bind(this)}
        tagLabel=${a}
        tagVariant="info"
        data-testid="all-wallets"
        tabIdx=${ae(this.tabIdx)}
        .loading=${this.isFetchingRecommendedWallets}
        ?disabled=${c}
        size="sm"
      ></wui-list-wallet>
    `}onAllWallets(){X.sendEvent({type:"track",event:"CLICK_ALL_WALLETS"}),S.push("AllWallets",{redirectView:S.state.data?.redirectView})}};vo([ve()],bi.prototype,"tabIdx",void 0);vo([T()],bi.prototype,"connectors",void 0);vo([T()],bi.prototype,"count",void 0);vo([T()],bi.prototype,"filteredCount",void 0);vo([T()],bi.prototype,"isFetchingRecommendedWallets",void 0);bi=vo([M("w3m-all-wallets-widget")],bi);const gC=Q`
  :host {
    margin-top: ${({spacing:e})=>e[1]};
  }
  wui-separator {
    margin: ${({spacing:e})=>e[3]} calc(${({spacing:e})=>e[3]} * -1)
      ${({spacing:e})=>e[2]} calc(${({spacing:e})=>e[3]} * -1);
    width: calc(100% + ${({spacing:e})=>e[3]} * 2);
  }
`;var Eo=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ar=class extends he{constructor(){super(),this.unsubscribe=[],this.explorerWallets=q.state.explorerWallets,this.connections=U.state.connections,this.connectorImages=rt.state.connectorImages,this.loadingTelegram=!1,this.unsubscribe.push(U.subscribeKey("connections",t=>this.connections=t),rt.subscribeKey("connectorImages",t=>this.connectorImages=t),q.subscribeKey("explorerFilteredWallets",t=>{this.explorerWallets=t?.length?t:q.state.explorerWallets}),q.subscribeKey("explorerWallets",t=>{this.explorerWallets?.length||(this.explorerWallets=t)})),L.isTelegram()&&L.isIos()&&(this.loadingTelegram=!U.state.wcUri,this.unsubscribe.push(U.subscribeKey("wcUri",t=>this.loadingTelegram=!t)))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return g`
      <wui-flex flexDirection="column" gap="2"> ${this.connectorListTemplate()} </wui-flex>
    `}connectorListTemplate(){return dt.connectorList().map((t,n)=>t.kind==="connector"?this.renderConnector(t,n):this.renderWallet(t,n))}getConnectorNamespaces(t){return t.subtype==="walletConnect"?[]:t.subtype==="multiChain"?t.connector.connectors?.map(n=>n.chain)||[]:[t.connector.chain]}renderConnector(t,n){const r=t.connector,o=De.getConnectorImage(r)||this.connectorImages[r?.imageId??""],s=(this.connections.get(r.chain)??[]).some(h=>Wt.isLowerCaseMatch(h.connectorId,r.id));let a,c;t.subtype==="walletConnect"?(a="qr code",c="accent"):t.subtype==="injected"||t.subtype==="announced"?(a=s?"connected":"installed",c=s?"info":"success"):(a=void 0,c=void 0);const l=U.hasAnyConnection(N.CONNECTOR_ID.WALLET_CONNECT),d=t.subtype==="walletConnect"||t.subtype==="external"?l:!1;return g`
      <w3m-list-wallet
        displayIndex=${n}
        imageSrc=${ae(o)}
        .installed=${!0}
        name=${r.name??"Unknown"}
        .tagVariant=${c}
        tagLabel=${ae(a)}
        data-testid=${`wallet-selector-${r.id.toLowerCase()}`}
        size="sm"
        @click=${()=>this.onClickConnector(t)}
        tabIdx=${ae(this.tabIdx)}
        ?disabled=${d}
        rdnsId=${ae(r.explorerWallet?.rdns||void 0)}
        walletRank=${ae(r.explorerWallet?.order)}
        .namespaces=${this.getConnectorNamespaces(t)}
      >
      </w3m-list-wallet>
    `}onClickConnector(t){const n=S.state.data?.redirectView;if(t.subtype==="walletConnect"){O.setActiveConnector(t.connector),L.isMobile()?S.push("AllWallets"):S.push("ConnectingWalletConnect",{redirectView:n});return}if(t.subtype==="multiChain"){O.setActiveConnector(t.connector),S.push("ConnectingMultiChain",{redirectView:n});return}if(t.subtype==="injected"){O.setActiveConnector(t.connector),S.push("ConnectingExternal",{connector:t.connector,redirectView:n,wallet:t.connector.explorerWallet});return}if(t.subtype==="announced"){if(t.connector.id==="walletConnect"){L.isMobile()?S.push("AllWallets"):S.push("ConnectingWalletConnect",{redirectView:n});return}S.push("ConnectingExternal",{connector:t.connector,redirectView:n,wallet:t.connector.explorerWallet});return}S.push("ConnectingExternal",{connector:t.connector,redirectView:n})}renderWallet(t,n){const r=t.wallet,o=De.getWalletImage(r),s=U.hasAnyConnection(N.CONNECTOR_ID.WALLET_CONNECT),a=this.loadingTelegram,c=t.subtype==="recent"?"recent":void 0,l=t.subtype==="recent"?"info":void 0;return g`
      <w3m-list-wallet
        displayIndex=${n}
        imageSrc=${ae(o)}
        name=${r.name??"Unknown"}
        @click=${()=>this.onClickWallet(t)}
        size="sm"
        data-testid=${`wallet-selector-${r.id}`}
        tabIdx=${ae(this.tabIdx)}
        ?loading=${a}
        ?disabled=${s}
        rdnsId=${ae(r.rdns||void 0)}
        walletRank=${ae(r.order)}
        tagLabel=${ae(c)}
        .tagVariant=${l}
      >
      </w3m-list-wallet>
    `}onClickWallet(t){const n=S.state.data?.redirectView,r=p.state.activeChain;if(t.subtype==="featured"){O.selectWalletConnector(t.wallet);return}if(t.subtype==="recent"){if(this.loadingTelegram)return;O.selectWalletConnector(t.wallet);return}if(t.subtype==="custom"){if(this.loadingTelegram)return;S.push("ConnectingWalletConnect",{wallet:t.wallet,redirectView:n});return}if(this.loadingTelegram)return;const o=r?O.getConnector({id:t.wallet.id,namespace:r}):void 0;o?S.push("ConnectingExternal",{connector:o,redirectView:n}):S.push("ConnectingWalletConnect",{wallet:t.wallet,redirectView:n})}};Ar.styles=gC;Eo([ve({type:Number})],Ar.prototype,"tabIdx",void 0);Eo([T()],Ar.prototype,"explorerWallets",void 0);Eo([T()],Ar.prototype,"connections",void 0);Eo([T()],Ar.prototype,"connectorImages",void 0);Eo([T()],Ar.prototype,"loadingTelegram",void 0);Ar=Eo([M("w3m-connector-list")],Ar);var Uf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let pd=class extends he{constructor(){super(...arguments),this.tabIdx=void 0}render(){return g`
      <wui-flex flexDirection="column" gap="2">
        <w3m-connector-list tabIdx=${ae(this.tabIdx)}></w3m-connector-list>
        <w3m-all-wallets-widget tabIdx=${ae(this.tabIdx)}></w3m-all-wallets-widget>
      </wui-flex>
    `}};Uf([ve()],pd.prototype,"tabIdx",void 0);pd=Uf([M("w3m-wallet-login-list")],pd);const wC=Q`
  :host {
    --connect-scroll--top-opacity: 0;
    --connect-scroll--bottom-opacity: 0;
    --connect-mask-image: none;
  }

  .connect {
    max-height: clamp(360px, 470px, 80vh);
    scrollbar-width: none;
    overflow-y: scroll;
    overflow-x: hidden;
    transition: opacity ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: opacity;
    mask-image: var(--connect-mask-image);
  }

  .guide {
    transition: opacity ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: opacity;
  }

  .connect::-webkit-scrollbar {
    display: none;
  }

  .all-wallets {
    flex-flow: column;
  }

  .connect.disabled,
  .guide.disabled {
    opacity: 0.3;
    pointer-events: none;
    user-select: none;
  }

  wui-separator {
    margin: ${({spacing:e})=>e[3]} calc(${({spacing:e})=>e[3]} * -1);
    width: calc(100% + ${({spacing:e})=>e[3]} * 2);
  }
`;var sn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const bC=470;let Ot=class extends he{constructor(){super(),this.unsubscribe=[],this.connectors=O.state.connectors,this.authConnector=this.connectors.find(t=>t.type==="AUTH"),this.features=R.state.features,this.remoteFeatures=R.state.remoteFeatures,this.enableWallets=R.state.enableWallets,this.noAdapters=p.state.noAdapters,this.walletGuide="get-started",this.checked=qr.state.isLegalCheckboxChecked,this.isEmailEnabled=this.remoteFeatures?.email&&!p.state.noAdapters,this.isSocialEnabled=this.remoteFeatures?.socials&&this.remoteFeatures.socials.length>0&&!p.state.noAdapters,this.isAuthEnabled=this.checkIfAuthEnabled(this.connectors),this.unsubscribe.push(O.subscribeKey("connectors",t=>{this.connectors=t,this.authConnector=this.connectors.find(n=>n.type==="AUTH"),this.isAuthEnabled=this.checkIfAuthEnabled(this.connectors)}),R.subscribeKey("features",t=>{this.features=t}),R.subscribeKey("remoteFeatures",t=>{this.remoteFeatures=t,this.setEmailAndSocialEnableCheck(this.noAdapters,this.remoteFeatures)}),R.subscribeKey("enableWallets",t=>this.enableWallets=t),p.subscribeKey("noAdapters",t=>this.setEmailAndSocialEnableCheck(t,this.remoteFeatures)),qr.subscribeKey("isLegalCheckboxChecked",t=>this.checked=t))}disconnectedCallback(){this.unsubscribe.forEach(n=>n()),this.resizeObserver?.disconnect(),this.shadowRoot?.querySelector(".connect")?.removeEventListener("scroll",this.handleConnectListScroll.bind(this))}firstUpdated(){const t=this.shadowRoot?.querySelector(".connect");t&&(requestAnimationFrame(this.handleConnectListScroll.bind(this)),t?.addEventListener("scroll",this.handleConnectListScroll.bind(this)),this.resizeObserver=new ResizeObserver(()=>{this.handleConnectListScroll()}),this.resizeObserver?.observe(t),this.handleConnectListScroll())}render(){const{termsConditionsUrl:t,privacyPolicyUrl:n}=R.state,r=R.state.features?.legalCheckbox,s=!!(t||n)&&!!r&&this.walletGuide==="get-started"&&!this.checked,a={connect:!0,disabled:s},c=R.state.enableWalletGuide,l=this.enableWallets,d=this.isSocialEnabled||this.authConnector,h=s?-1:void 0;return g`
      <wui-flex flexDirection="column">
        ${this.legalCheckboxTemplate()}
        <wui-flex
          data-testid="w3m-connect-scroll-view"
          flexDirection="column"
          .padding=${["0","0","4","0"]}
          class=${$f(a)}
        >
          <wui-flex
            class="connect-methods"
            flexDirection="column"
            gap="2"
            .padding=${d&&l&&c&&this.walletGuide==="get-started"?["0","3","0","3"]:["0","3","3","3"]}
          >
            ${this.renderConnectMethod(h)}
          </wui-flex>
        </wui-flex>
        ${this.reownBrandingTemplate()}
      </wui-flex>
    `}reownBrandingTemplate(){return Zi.hasFooter()||!this.remoteFeatures?.reownBranding?null:g`<wui-ux-by-reown></wui-ux-by-reown>`}setEmailAndSocialEnableCheck(t,n){this.isEmailEnabled=n?.email&&!t,this.isSocialEnabled=n?.socials&&n.socials.length>0&&!t,this.remoteFeatures=n,this.noAdapters=t}checkIfAuthEnabled(t){const n=t.filter(o=>o.type===ef.CONNECTOR_TYPE_AUTH).map(o=>o.chain);return N.AUTH_CONNECTOR_SUPPORTED_CHAINS.some(o=>n.includes(o))}renderConnectMethod(t){const n=Xt.getConnectOrderMethod(this.features,this.connectors);return g`${n.map((r,o)=>{switch(r){case"email":return g`${this.emailTemplate(t)} ${this.separatorTemplate(o,"email")}`;case"social":return g`${this.socialListTemplate(t)}
          ${this.separatorTemplate(o,"social")}`;case"wallet":return g`${this.walletListTemplate(t)}
          ${this.separatorTemplate(o,"wallet")}`;default:return null}})}`}checkMethodEnabled(t){switch(t){case"wallet":return this.enableWallets;case"social":return this.isSocialEnabled&&this.isAuthEnabled;case"email":return this.isEmailEnabled&&this.isAuthEnabled;default:return null}}checkIsThereNextMethod(t){const r=Xt.getConnectOrderMethod(this.features,this.connectors)[t+1];return r?this.checkMethodEnabled(r)?r:this.checkIsThereNextMethod(t+1):void 0}separatorTemplate(t,n){const r=this.checkIsThereNextMethod(t),o=this.walletGuide==="explore";switch(n){case"wallet":return this.enableWallets&&r&&!o?g`<wui-separator data-testid="wui-separator" text="or"></wui-separator>`:null;case"email":{const i=r==="social";return this.isAuthEnabled&&this.isEmailEnabled&&!i&&r?g`<wui-separator
              data-testid="w3m-email-login-or-separator"
              text="or"
            ></wui-separator>`:null}case"social":{const i=r==="email";return this.isAuthEnabled&&this.isSocialEnabled&&!i&&r?g`<wui-separator data-testid="wui-separator" text="or"></wui-separator>`:null}default:return null}}emailTemplate(t){return!this.isEmailEnabled||!this.isAuthEnabled?null:g`<w3m-email-login-widget tabIdx=${ae(t)}></w3m-email-login-widget>`}socialListTemplate(t){return!this.isSocialEnabled||!this.isAuthEnabled?null:g`<w3m-social-login-widget
      walletGuide=${this.walletGuide}
      tabIdx=${ae(t)}
    ></w3m-social-login-widget>`}walletListTemplate(t){const n=this.enableWallets,r=this.features?.emailShowWallets===!1,o=this.features?.collapseWallets,i=r||o;return!n||(L.isTelegram()&&(L.isSafari()||L.isIos())&&U.connectWalletConnect().catch(a=>({})),this.walletGuide==="explore")?null:this.isAuthEnabled&&(this.isEmailEnabled||this.isSocialEnabled)&&i?g`<wui-list-button
        data-testid="w3m-collapse-wallets-button"
        tabIdx=${ae(t)}
        @click=${this.onContinueWalletClick.bind(this)}
        text="Continue with a wallet"
      ></wui-list-button>`:g`<w3m-wallet-login-list tabIdx=${ae(t)}></w3m-wallet-login-list>`}legalCheckboxTemplate(){return this.walletGuide==="explore"?null:g`<w3m-legal-checkbox data-testid="w3m-legal-checkbox"></w3m-legal-checkbox>`}handleConnectListScroll(){const t=this.shadowRoot?.querySelector(".connect");if(!t)return;t.scrollHeight>bC?(t.style.setProperty("--connect-mask-image",`linear-gradient(
          to bottom,
          rgba(0, 0, 0, calc(1 - var(--connect-scroll--top-opacity))) 0px,
          rgba(200, 200, 200, calc(1 - var(--connect-scroll--top-opacity))) 1px,
          black 100px,
          black calc(100% - 100px),
          rgba(155, 155, 155, calc(1 - var(--connect-scroll--bottom-opacity))) calc(100% - 1px),
          rgba(0, 0, 0, calc(1 - var(--connect-scroll--bottom-opacity))) 100%
        )`),t.style.setProperty("--connect-scroll--top-opacity",Ja.interpolate([0,50],[0,1],t.scrollTop).toString()),t.style.setProperty("--connect-scroll--bottom-opacity",Ja.interpolate([0,50],[0,1],t.scrollHeight-t.scrollTop-t.offsetHeight).toString())):(t.style.setProperty("--connect-mask-image","none"),t.style.setProperty("--connect-scroll--top-opacity","0"),t.style.setProperty("--connect-scroll--bottom-opacity","0"))}onContinueWalletClick(){S.push("ConnectWallets")}};Ot.styles=wC;sn([T()],Ot.prototype,"connectors",void 0);sn([T()],Ot.prototype,"authConnector",void 0);sn([T()],Ot.prototype,"features",void 0);sn([T()],Ot.prototype,"remoteFeatures",void 0);sn([T()],Ot.prototype,"enableWallets",void 0);sn([T()],Ot.prototype,"noAdapters",void 0);sn([ve()],Ot.prototype,"walletGuide",void 0);sn([T()],Ot.prototype,"checked",void 0);sn([T()],Ot.prototype,"isEmailEnabled",void 0);sn([T()],Ot.prototype,"isSocialEnabled",void 0);sn([T()],Ot.prototype,"isAuthEnabled",void 0);Ot=sn([M("w3m-connect-view")],Ot);const yC=Q`
  :host {
    display: block;
    width: 100px;
    height: 100px;
  }

  svg {
    width: 100px;
    height: 100px;
  }

  rect {
    fill: none;
    stroke: ${e=>e.colors.accent100};
    stroke-width: 3px;
    stroke-linecap: round;
    animation: dash 1s linear infinite;
  }

  @keyframes dash {
    to {
      stroke-dashoffset: 0px;
    }
  }
`;var Bf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let mc=class extends de{constructor(){super(...arguments),this.radius=36}render(){return this.svgLoaderTemplate()}svgLoaderTemplate(){const t=this.radius>50?50:this.radius,r=36-t,o=116+r,i=245+r,s=360+r*1.75;return x`
      <svg viewBox="0 0 110 110" width="110" height="110">
        <rect
          x="2"
          y="2"
          width="106"
          height="106"
          rx=${t}
          stroke-dasharray="${o} ${i}"
          stroke-dashoffset=${s}
        />
      </svg>
    `}};mc.styles=[we,yC];Bf([m({type:Number})],mc.prototype,"radius",void 0);mc=Bf([M("wui-loading-thumbnail")],mc);const CC=Q`
  wui-flex {
    width: 100%;
    height: 52px;
    box-sizing: border-box;
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[5]};
    padding-left: ${({spacing:e})=>e[3]};
    padding-right: ${({spacing:e})=>e[3]};
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: ${({spacing:e})=>e[6]};
  }

  wui-text {
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  wui-icon {
    width: 12px;
    height: 12px;
  }
`;var Fc=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ho=class extends de{constructor(){super(...arguments),this.disabled=!1,this.label="",this.buttonLabel=""}render(){return x`
      <wui-flex justifyContent="space-between" alignItems="center">
        <wui-text variant="lg-regular" color="inherit">${this.label}</wui-text>
        <wui-button variant="accent-secondary" size="sm">
          ${this.buttonLabel}
          <wui-icon name="chevronRight" color="inherit" size="inherit" slot="iconRight"></wui-icon>
        </wui-button>
      </wui-flex>
    `}};ho.styles=[we,Be,CC];Fc([m({type:Boolean})],ho.prototype,"disabled",void 0);Fc([m()],ho.prototype,"label",void 0);Fc([m()],ho.prototype,"buttonLabel",void 0);ho=Fc([M("wui-cta-button")],ho);const vC=Q`
  :host {
    display: block;
    padding: 0 ${({spacing:e})=>e[5]} ${({spacing:e})=>e[5]};
  }
`;var Wf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let gc=class extends he{constructor(){super(...arguments),this.wallet=void 0}render(){if(!this.wallet)return this.style.display="none",null;const{name:t,app_store:n,play_store:r,chrome_store:o,homepage:i}=this.wallet,s=L.isMobile(),a=L.isIos(),c=L.isAndroid(),l=[n,r,i,o].filter(Boolean).length>1,d=Fe.getTruncateString({string:t,charsStart:12,charsEnd:0,truncate:"end"});return l&&!s?g`
        <wui-cta-button
          label=${`Don't have ${d}?`}
          buttonLabel="Get"
          @click=${()=>S.push("Downloads",{wallet:this.wallet})}
        ></wui-cta-button>
      `:!l&&i?g`
        <wui-cta-button
          label=${`Don't have ${d}?`}
          buttonLabel="Get"
          @click=${this.onHomePage.bind(this)}
        ></wui-cta-button>
      `:n&&a?g`
        <wui-cta-button
          label=${`Don't have ${d}?`}
          buttonLabel="Get"
          @click=${this.onAppStore.bind(this)}
        ></wui-cta-button>
      `:r&&c?g`
        <wui-cta-button
          label=${`Don't have ${d}?`}
          buttonLabel="Get"
          @click=${this.onPlayStore.bind(this)}
        ></wui-cta-button>
      `:(this.style.display="none",null)}onAppStore(){this.wallet?.app_store&&L.openHref(this.wallet.app_store,"_blank")}onPlayStore(){this.wallet?.play_store&&L.openHref(this.wallet.play_store,"_blank")}onHomePage(){this.wallet?.homepage&&L.openHref(this.wallet.homepage,"_blank")}};gc.styles=[vC];Wf([ve({type:Object})],gc.prototype,"wallet",void 0);gc=Wf([M("w3m-mobile-download-links")],gc);const EC=Q`
  @keyframes shake {
    0% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(3px);
    }
    50% {
      transform: translateX(-3px);
    }
    75% {
      transform: translateX(3px);
    }
    100% {
      transform: translateX(0);
    }
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-wallet-image {
    width: 56px;
    height: 56px;
  }

  wui-loading-thumbnail {
    position: absolute;
  }

  wui-icon-box {
    position: absolute;
    right: calc(${({spacing:e})=>e[1]} * -1);
    bottom: calc(${({spacing:e})=>e[1]} * -1);
    opacity: 0;
    transform: scale(0.5);
    transition-property: opacity, transform;
    transition-duration: ${({durations:e})=>e.lg};
    transition-timing-function: ${({easings:e})=>e["ease-out-power-2"]};
    will-change: opacity, transform;
  }

  wui-text[align='center'] {
    width: 100%;
    padding: 0px ${({spacing:e})=>e[4]};
  }

  [data-error='true'] wui-icon-box {
    opacity: 1;
    transform: scale(1);
  }

  [data-error='true'] > wui-flex:first-child {
    animation: shake 250ms ${({easings:e})=>e["ease-out-power-2"]} both;
  }

  [data-retry='false'] wui-link {
    display: none;
  }

  [data-retry='true'] wui-link {
    display: block;
    opacity: 1;
  }

  w3m-mobile-download-links {
    padding: 0px;
    width: 100%;
  }
`;var vn=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};class ct extends he{constructor(){super(),this.wallet=S.state.data?.wallet,this.connector=S.state.data?.connector,this.timeout=void 0,this.secondaryBtnIcon="refresh",this.onConnect=void 0,this.onRender=void 0,this.onAutoConnect=void 0,this.isWalletConnect=!0,this.unsubscribe=[],this.imageSrc=De.getConnectorImage(this.connector)??De.getWalletImage(this.wallet),this.name=this.wallet?.name??this.connector?.name??"Wallet",this.isRetrying=!1,this.uri=U.state.wcUri,this.error=U.state.wcError,this.ready=!1,this.showRetry=!1,this.label=void 0,this.secondaryBtnLabel="Try again",this.secondaryLabel="Accept connection request in the wallet",this.isLoading=!1,this.isMobile=!1,this.onRetry=void 0,this.unsubscribe.push(U.subscribeKey("wcUri",t=>{this.uri=t,this.isRetrying&&this.onRetry&&(this.isRetrying=!1,this.onConnect?.())}),U.subscribeKey("wcError",t=>this.error=t)),(L.isTelegram()||L.isSafari())&&L.isIos()&&U.state.wcUri&&this.onConnect?.()}firstUpdated(){this.onAutoConnect?.(),this.showRetry=!this.onAutoConnect}disconnectedCallback(){this.unsubscribe.forEach(t=>t()),U.setWcError(!1),clearTimeout(this.timeout)}render(){this.onRender?.(),this.onShowRetry();const t=this.error?"Connection can be declined if a previous request is still active":this.secondaryLabel;let n="";return this.label?n=this.label:(n=`Continue in ${this.name}`,this.error&&(n="Connection declined")),g`
      <wui-flex
        data-error=${ae(this.error)}
        data-retry=${this.showRetry}
        flexDirection="column"
        alignItems="center"
        .padding=${["10","5","5","5"]}
        gap="6"
      >
        <wui-flex gap="2" justifyContent="center" alignItems="center">
          <wui-wallet-image size="lg" imageSrc=${ae(this.imageSrc)}></wui-wallet-image>

          ${this.error?null:this.loaderTemplate()}

          <wui-icon-box
            color="error"
            icon="close"
            size="sm"
            border
            borderColor="wui-color-bg-125"
          ></wui-icon-box>
        </wui-flex>

        <wui-flex flexDirection="column" alignItems="center" gap="6"> <wui-flex
          flexDirection="column"
          alignItems="center"
          gap="2"
          .padding=${["2","0","0","0"]}
        >
          <wui-text align="center" variant="lg-medium" color=${this.error?"error":"primary"}>
            ${n}
          </wui-text>
          <wui-text align="center" variant="lg-regular" color="secondary">${t}</wui-text>
        </wui-flex>

        ${this.secondaryBtnLabel?g`
                <wui-button
                  variant="neutral-secondary"
                  size="md"
                  ?disabled=${this.isRetrying||this.isLoading}
                  @click=${this.onTryAgain.bind(this)}
                  data-testid="w3m-connecting-widget-secondary-button"
                >
                  <wui-icon
                    color="inherit"
                    slot="iconLeft"
                    name=${this.secondaryBtnIcon}
                  ></wui-icon>
                  ${this.secondaryBtnLabel}
                </wui-button>
              `:null}
      </wui-flex>

      ${this.isWalletConnect?g`
              <wui-flex .padding=${["0","5","5","5"]} justifyContent="center">
                <wui-link
                  @click=${this.onCopyUri}
                  variant="secondary"
                  icon="copy"
                  data-testid="wui-link-copy"
                >
                  Copy link
                </wui-link>
              </wui-flex>
            `:null}

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links></wui-flex>
      </wui-flex>
    `}onShowRetry(){this.error&&!this.showRetry&&(this.showRetry=!0,this.shadowRoot?.querySelector("wui-button")?.animate([{opacity:0},{opacity:1}],{fill:"forwards",easing:"ease"}))}onTryAgain(){U.setWcError(!1),this.onRetry?(this.isRetrying=!0,this.onRetry?.()):this.onConnect?.()}loaderTemplate(){const t=fr.state.themeVariables["--w3m-border-radius-master"],n=t?parseInt(t.replace("px",""),10):4;return g`<wui-loading-thumbnail radius=${n*9}></wui-loading-thumbnail>`}onCopyUri(){try{this.uri&&(L.copyToClopboard(this.uri),Te.showSuccess("Link copied"))}catch{Te.showError("Failed to copy")}}}ct.styles=EC;vn([T()],ct.prototype,"isRetrying",void 0);vn([T()],ct.prototype,"uri",void 0);vn([T()],ct.prototype,"error",void 0);vn([T()],ct.prototype,"ready",void 0);vn([T()],ct.prototype,"showRetry",void 0);vn([T()],ct.prototype,"label",void 0);vn([T()],ct.prototype,"secondaryBtnLabel",void 0);vn([T()],ct.prototype,"secondaryLabel",void 0);vn([T()],ct.prototype,"isLoading",void 0);vn([ve({type:Boolean})],ct.prototype,"isMobile",void 0);vn([ve()],ct.prototype,"onRetry",void 0);var _C=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ih=class extends ct{constructor(){if(super(),this.externalViewUnsubscribe=[],this.connectionsByNamespace=U.getConnections(this.connector?.chain),this.hasMultipleConnections=this.connectionsByNamespace.length>0,this.remoteFeatures=R.state.remoteFeatures,this.currentActiveConnectorId=O.state.activeConnectorIds[this.connector?.chain],!this.connector)throw new Error("w3m-connecting-view: No connector provided");const t=this.connector?.chain;this.isAlreadyConnected(this.connector)&&(this.secondaryBtnLabel=void 0,this.label=`This account is already linked, change your account in ${this.connector.name}`,this.secondaryLabel=`To link a new account, open ${this.connector.name} and switch to the account you want to link`),X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.connector.name??"Unknown",platform:"browser",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:S.state.view}}),this.onConnect=this.onConnectProxy.bind(this),this.onAutoConnect=this.onConnectProxy.bind(this),this.isWalletConnect=!1,this.externalViewUnsubscribe.push(O.subscribeKey("activeConnectorIds",n=>{const r=n[t],o=this.remoteFeatures?.multiWallet,{redirectView:i}=S.state.data??{};r!==this.currentActiveConnectorId&&(this.hasMultipleConnections&&o?(S.replace("ProfileWallets"),Te.showSuccess("New Wallet Added")):i?S.replace(i):ye.close())}),U.subscribeKey("connections",this.onConnectionsChange.bind(this)))}disconnectedCallback(){this.externalViewUnsubscribe.forEach(t=>t())}async onConnectProxy(){try{if(this.error=!1,this.connector){if(this.isAlreadyConnected(this.connector))return;(this.connector.id!==N.CONNECTOR_ID.COINBASE_SDK||!this.error)&&await U.connectExternal(this.connector,this.connector.chain)}}catch(t){t instanceof In&&t.originalName===Yt.PROVIDER_RPC_ERROR_NAME.USER_REJECTED_REQUEST?X.sendEvent({type:"track",event:"USER_REJECTED",properties:{message:t.message}}):X.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:t?.message??"Unknown"}}),this.error=!0}}onConnectionsChange(t){if(this.connector?.chain&&t.get(this.connector.chain)&&this.isAlreadyConnected(this.connector)){const n=t.get(this.connector.chain)??[],r=this.remoteFeatures?.multiWallet;if(n.length===0)S.replace("Connect");else{const o=dn.getConnectionsByConnectorId(this.connectionsByNamespace,this.connector.id).flatMap(s=>s.accounts),i=dn.getConnectionsByConnectorId(n,this.connector.id).flatMap(s=>s.accounts);i.length===0?this.hasMultipleConnections&&r?(S.replace("ProfileWallets"),Te.showSuccess("Wallet deleted")):ye.close():!o.every(a=>i.some(c=>Wt.isLowerCaseMatch(a.address,c.address)))&&r&&S.replace("ProfileWallets")}}}isAlreadyConnected(t){return!!t&&this.connectionsByNamespace.some(n=>Wt.isLowerCaseMatch(n.connectorId,t.id))}};Ih=_C([M("w3m-connecting-external-view")],Ih);const AC=Vt`
  wui-flex,
  wui-list-wallet {
    width: 100%;
  }
`;var jf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let wc=class extends he{constructor(){super(),this.unsubscribe=[],this.activeConnector=O.state.activeConnector,this.unsubscribe.push(O.subscribeKey("activeConnector",t=>this.activeConnector=t))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return g`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["3","5","5","5"]}
        gap="5"
      >
        <wui-flex justifyContent="center" alignItems="center">
          <wui-wallet-image
            size="lg"
            imageSrc=${ae(De.getConnectorImage(this.activeConnector))}
          ></wui-wallet-image>
        </wui-flex>
        <wui-flex
          flexDirection="column"
          alignItems="center"
          gap="2"
          .padding=${["0","3","0","3"]}
        >
          <wui-text variant="lg-medium" color="primary">
            Select Chain for ${this.activeConnector?.name}
          </wui-text>
          <wui-text align="center" variant="lg-regular" color="secondary"
            >Select which chain to connect to your multi chain wallet</wui-text
          >
        </wui-flex>
        <wui-flex
          flexGrow="1"
          flexDirection="column"
          alignItems="center"
          gap="2"
          .padding=${["2","0","2","0"]}
        >
          ${this.networksTemplate()}
        </wui-flex>
      </wui-flex>
    `}networksTemplate(){return this.activeConnector?.connectors?.map((t,n)=>t.name?g`
            <w3m-list-wallet
              displayIndex=${n}
              imageSrc=${ae(De.getChainImage(t.chain))}
              name=${N.CHAIN_NAME_MAP[t.chain]}
              @click=${()=>this.onConnector(t)}
              size="sm"
              data-testid="wui-list-chain-${t.chain}"
              rdnsId=${t.explorerWallet?.rdns}
            ></w3m-list-wallet>
          `:null)}onConnector(t){const n=this.activeConnector?.connectors?.find(o=>o.chain===t.chain),r=S.state.data?.redirectView;if(!n){Te.showError("Failed to find connector");return}n.id==="walletConnect"?L.isMobile()?S.push("AllWallets"):S.push("ConnectingWalletConnect",{redirectView:r}):S.push("ConnectingExternal",{connector:n,redirectView:r,wallet:this.activeConnector?.explorerWallet})}};wc.styles=AC;jf([T()],wc.prototype,"activeConnector",void 0);wc=jf([M("w3m-connecting-multi-chain-view")],wc);var tu=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let bc=class extends he{constructor(){super(...arguments),this.platformTabs=[],this.unsubscribe=[],this.platforms=[],this.onSelectPlatfrom=void 0}disconnectCallback(){this.unsubscribe.forEach(t=>t())}render(){const t=this.generateTabs();return g`
      <wui-flex justifyContent="center" .padding=${["0","0","4","0"]}>
        <wui-tabs .tabs=${t} .onTabChange=${this.onTabChange.bind(this)}></wui-tabs>
      </wui-flex>
    `}generateTabs(){const t=this.platforms.map(n=>n==="browser"?{label:"Browser",icon:"extension",platform:"browser"}:n==="mobile"?{label:"Mobile",icon:"mobile",platform:"mobile"}:n==="qrcode"?{label:"Mobile",icon:"mobile",platform:"qrcode"}:n==="web"?{label:"Webapp",icon:"browser",platform:"web"}:n==="desktop"?{label:"Desktop",icon:"desktop",platform:"desktop"}:{label:"Browser",icon:"extension",platform:"unsupported"});return this.platformTabs=t.map(({platform:n})=>n),t}onTabChange(t){const n=this.platformTabs[t];n&&this.onSelectPlatfrom?.(n)}};tu([ve({type:Array})],bc.prototype,"platforms",void 0);tu([ve()],bc.prototype,"onSelectPlatfrom",void 0);bc=tu([M("w3m-connecting-header")],bc);var xC=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Oh=class extends ct{constructor(){if(super(),!this.wallet)throw new Error("w3m-connecting-wc-browser: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.onAutoConnect=this.onConnectProxy.bind(this),X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"browser",displayIndex:this.wallet?.display_index,walletRank:this.wallet.order,view:S.state.view}})}async onConnectProxy(){try{this.error=!1;const{connectors:t}=O.state,n=t.find(r=>r.type==="ANNOUNCED"&&r.info?.rdns===this.wallet?.rdns||r.type==="INJECTED"||r.name===this.wallet?.name);if(n)await U.connectExternal(n,n.chain);else throw new Error("w3m-connecting-wc-browser: No connector found");ye.close()}catch(t){t instanceof In&&t.originalName===Yt.PROVIDER_RPC_ERROR_NAME.USER_REJECTED_REQUEST?X.sendEvent({type:"track",event:"USER_REJECTED",properties:{message:t.message}}):X.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:t?.message??"Unknown"}}),this.error=!0}}};Oh=xC([M("w3m-connecting-wc-browser")],Oh);var SC=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ph=class extends ct{constructor(){if(super(),!this.wallet)throw new Error("w3m-connecting-wc-desktop: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.onRender=this.onRenderProxy.bind(this),X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"desktop",displayIndex:this.wallet?.display_index,walletRank:this.wallet.order,view:S.state.view}})}onRenderProxy(){!this.ready&&this.uri&&(this.ready=!0,this.onConnect?.())}onConnectProxy(){if(this.wallet?.desktop_link&&this.uri)try{this.error=!1;const{desktop_link:t,name:n}=this.wallet,{redirect:r,href:o}=L.formatNativeUrl(t,this.uri);U.setWcLinking({name:n,href:o}),U.setRecentWallet(this.wallet),L.openHref(r,"_blank")}catch{this.error=!0}}};Ph=SC([M("w3m-connecting-wc-desktop")],Ph);var _o=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let yi=class extends ct{constructor(){if(super(),this.btnLabelTimeout=void 0,this.redirectDeeplink=void 0,this.redirectUniversalLink=void 0,this.target=void 0,this.preferUniversalLinks=R.state.experimental_preferUniversalLinks,this.isLoading=!0,this.onConnect=()=>{dn.onConnectMobile(this.wallet)},!this.wallet)throw new Error("w3m-connecting-wc-mobile: No wallet provided");this.secondaryBtnLabel="Open",this.secondaryLabel=ke.CONNECT_LABELS.MOBILE,this.secondaryBtnIcon="externalLink",this.onHandleURI(),this.unsubscribe.push(U.subscribeKey("wcUri",()=>{this.onHandleURI()})),X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"mobile",displayIndex:this.wallet?.display_index,walletRank:this.wallet.order,view:S.state.view}})}disconnectedCallback(){super.disconnectedCallback(),clearTimeout(this.btnLabelTimeout)}onHandleURI(){this.isLoading=!this.uri,!this.ready&&this.uri&&(this.ready=!0,this.onConnect?.())}onTryAgain(){U.setWcError(!1),this.onConnect?.()}};_o([T()],yi.prototype,"redirectDeeplink",void 0);_o([T()],yi.prototype,"redirectUniversalLink",void 0);_o([T()],yi.prototype,"target",void 0);_o([T()],yi.prototype,"preferUniversalLinks",void 0);_o([T()],yi.prototype,"isLoading",void 0);yi=_o([M("w3m-connecting-wc-mobile")],yi);var Bi={},hl,Lh;function TC(){return Lh||(Lh=1,hl=function(){return typeof Promise=="function"&&Promise.prototype&&Promise.prototype.then}),hl}var pl={},cr={},Dh;function Ii(){if(Dh)return cr;Dh=1;let e;const t=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];return cr.getSymbolSize=function(r){if(!r)throw new Error('"version" cannot be null or undefined');if(r<1||r>40)throw new Error('"version" should be in range from 1 to 40');return r*4+17},cr.getSymbolTotalCodewords=function(r){return t[r]},cr.getBCHDigit=function(n){let r=0;for(;n!==0;)r++,n>>>=1;return r},cr.setToSJISFunction=function(r){if(typeof r!="function")throw new Error('"toSJISFunc" is not a valid function.');e=r},cr.isKanjiModeEnabled=function(){return typeof e<"u"},cr.toSJIS=function(r){return e(r)},cr}var fl={},Mh;function nu(){return Mh||(Mh=1,(function(e){e.L={bit:1},e.M={bit:0},e.Q={bit:3},e.H={bit:2};function t(n){if(typeof n!="string")throw new Error("Param is not a string");switch(n.toLowerCase()){case"l":case"low":return e.L;case"m":case"medium":return e.M;case"q":case"quartile":return e.Q;case"h":case"high":return e.H;default:throw new Error("Unknown EC Level: "+n)}}e.isValid=function(r){return r&&typeof r.bit<"u"&&r.bit>=0&&r.bit<4},e.from=function(r,o){if(e.isValid(r))return r;try{return t(r)}catch{return o}}})(fl)),fl}var ml,Uh;function $C(){if(Uh)return ml;Uh=1;function e(){this.buffer=[],this.length=0}return e.prototype={get:function(t){const n=Math.floor(t/8);return(this.buffer[n]>>>7-t%8&1)===1},put:function(t,n){for(let r=0;r<n;r++)this.putBit((t>>>n-r-1&1)===1)},getLengthInBits:function(){return this.length},putBit:function(t){const n=Math.floor(this.length/8);this.buffer.length<=n&&this.buffer.push(0),t&&(this.buffer[n]|=128>>>this.length%8),this.length++}},ml=e,ml}var gl,Bh;function NC(){if(Bh)return gl;Bh=1;function e(t){if(!t||t<1)throw new Error("BitMatrix size must be defined and greater than 0");this.size=t,this.data=new Uint8Array(t*t),this.reservedBit=new Uint8Array(t*t)}return e.prototype.set=function(t,n,r,o){const i=t*this.size+n;this.data[i]=r,o&&(this.reservedBit[i]=!0)},e.prototype.get=function(t,n){return this.data[t*this.size+n]},e.prototype.xor=function(t,n,r){this.data[t*this.size+n]^=r},e.prototype.isReserved=function(t,n){return this.reservedBit[t*this.size+n]},gl=e,gl}var wl={},Wh;function RC(){return Wh||(Wh=1,(function(e){const t=Ii().getSymbolSize;e.getRowColCoords=function(r){if(r===1)return[];const o=Math.floor(r/7)+2,i=t(r),s=i===145?26:Math.ceil((i-13)/(2*o-2))*2,a=[i-7];for(let c=1;c<o-1;c++)a[c]=a[c-1]-s;return a.push(6),a.reverse()},e.getPositions=function(r){const o=[],i=e.getRowColCoords(r),s=i.length;for(let a=0;a<s;a++)for(let c=0;c<s;c++)a===0&&c===0||a===0&&c===s-1||a===s-1&&c===0||o.push([i[a],i[c]]);return o}})(wl)),wl}var bl={},jh;function kC(){if(jh)return bl;jh=1;const e=Ii().getSymbolSize,t=7;return bl.getPositions=function(r){const o=e(r);return[[0,0],[o-t,0],[0,o-t]]},bl}var yl={},Fh;function IC(){return Fh||(Fh=1,(function(e){e.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};const t={N1:3,N2:3,N3:40,N4:10};e.isValid=function(o){return o!=null&&o!==""&&!isNaN(o)&&o>=0&&o<=7},e.from=function(o){return e.isValid(o)?parseInt(o,10):void 0},e.getPenaltyN1=function(o){const i=o.size;let s=0,a=0,c=0,l=null,d=null;for(let h=0;h<i;h++){a=c=0,l=d=null;for(let f=0;f<i;f++){let w=o.get(h,f);w===l?a++:(a>=5&&(s+=t.N1+(a-5)),l=w,a=1),w=o.get(f,h),w===d?c++:(c>=5&&(s+=t.N1+(c-5)),d=w,c=1)}a>=5&&(s+=t.N1+(a-5)),c>=5&&(s+=t.N1+(c-5))}return s},e.getPenaltyN2=function(o){const i=o.size;let s=0;for(let a=0;a<i-1;a++)for(let c=0;c<i-1;c++){const l=o.get(a,c)+o.get(a,c+1)+o.get(a+1,c)+o.get(a+1,c+1);(l===4||l===0)&&s++}return s*t.N2},e.getPenaltyN3=function(o){const i=o.size;let s=0,a=0,c=0;for(let l=0;l<i;l++){a=c=0;for(let d=0;d<i;d++)a=a<<1&2047|o.get(l,d),d>=10&&(a===1488||a===93)&&s++,c=c<<1&2047|o.get(d,l),d>=10&&(c===1488||c===93)&&s++}return s*t.N3},e.getPenaltyN4=function(o){let i=0;const s=o.data.length;for(let c=0;c<s;c++)i+=o.data[c];return Math.abs(Math.ceil(i*100/s/5)-10)*t.N4};function n(r,o,i){switch(r){case e.Patterns.PATTERN000:return(o+i)%2===0;case e.Patterns.PATTERN001:return o%2===0;case e.Patterns.PATTERN010:return i%3===0;case e.Patterns.PATTERN011:return(o+i)%3===0;case e.Patterns.PATTERN100:return(Math.floor(o/2)+Math.floor(i/3))%2===0;case e.Patterns.PATTERN101:return o*i%2+o*i%3===0;case e.Patterns.PATTERN110:return(o*i%2+o*i%3)%2===0;case e.Patterns.PATTERN111:return(o*i%3+(o+i)%2)%2===0;default:throw new Error("bad maskPattern:"+r)}}e.applyMask=function(o,i){const s=i.size;for(let a=0;a<s;a++)for(let c=0;c<s;c++)i.isReserved(c,a)||i.xor(c,a,n(o,c,a))},e.getBestMask=function(o,i){const s=Object.keys(e.Patterns).length;let a=0,c=1/0;for(let l=0;l<s;l++){i(l),e.applyMask(l,o);const d=e.getPenaltyN1(o)+e.getPenaltyN2(o)+e.getPenaltyN3(o)+e.getPenaltyN4(o);e.applyMask(l,o),d<c&&(c=d,a=l)}return a}})(yl)),yl}var _a={},zh;function Ff(){if(zh)return _a;zh=1;const e=nu(),t=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],n=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];return _a.getBlocksCount=function(o,i){switch(i){case e.L:return t[(o-1)*4+0];case e.M:return t[(o-1)*4+1];case e.Q:return t[(o-1)*4+2];case e.H:return t[(o-1)*4+3];default:return}},_a.getTotalCodewordsCount=function(o,i){switch(i){case e.L:return n[(o-1)*4+0];case e.M:return n[(o-1)*4+1];case e.Q:return n[(o-1)*4+2];case e.H:return n[(o-1)*4+3];default:return}},_a}var Cl={},Ro={},Hh;function OC(){if(Hh)return Ro;Hh=1;const e=new Uint8Array(512),t=new Uint8Array(256);return(function(){let r=1;for(let o=0;o<255;o++)e[o]=r,t[r]=o,r<<=1,r&256&&(r^=285);for(let o=255;o<512;o++)e[o]=e[o-255]})(),Ro.log=function(r){if(r<1)throw new Error("log("+r+")");return t[r]},Ro.exp=function(r){return e[r]},Ro.mul=function(r,o){return r===0||o===0?0:e[t[r]+t[o]]},Ro}var Vh;function PC(){return Vh||(Vh=1,(function(e){const t=OC();e.mul=function(r,o){const i=new Uint8Array(r.length+o.length-1);for(let s=0;s<r.length;s++)for(let a=0;a<o.length;a++)i[s+a]^=t.mul(r[s],o[a]);return i},e.mod=function(r,o){let i=new Uint8Array(r);for(;i.length-o.length>=0;){const s=i[0];for(let c=0;c<o.length;c++)i[c]^=t.mul(o[c],s);let a=0;for(;a<i.length&&i[a]===0;)a++;i=i.slice(a)}return i},e.generateECPolynomial=function(r){let o=new Uint8Array([1]);for(let i=0;i<r;i++)o=e.mul(o,new Uint8Array([1,t.exp(i)]));return o}})(Cl)),Cl}var vl,qh;function LC(){if(qh)return vl;qh=1;const e=PC();function t(n){this.genPoly=void 0,this.degree=n,this.degree&&this.initialize(this.degree)}return t.prototype.initialize=function(r){this.degree=r,this.genPoly=e.generateECPolynomial(this.degree)},t.prototype.encode=function(r){if(!this.genPoly)throw new Error("Encoder not initialized");const o=new Uint8Array(r.length+this.degree);o.set(r);const i=e.mod(o,this.genPoly),s=this.degree-i.length;if(s>0){const a=new Uint8Array(this.degree);return a.set(i,s),a}return i},vl=t,vl}var El={},_l={},Al={},Kh;function zf(){return Kh||(Kh=1,Al.isValid=function(t){return!isNaN(t)&&t>=1&&t<=40}),Al}var _n={},Gh;function Hf(){if(Gh)return _n;Gh=1;const e="[0-9]+",t="[A-Z $%*+\\-./:]+";let n="(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";n=n.replace(/u/g,"\\u");const r="(?:(?![A-Z0-9 $%*+\\-./:]|"+n+`)(?:.|[\r
]))+`;_n.KANJI=new RegExp(n,"g"),_n.BYTE_KANJI=new RegExp("[^A-Z0-9 $%*+\\-./:]+","g"),_n.BYTE=new RegExp(r,"g"),_n.NUMERIC=new RegExp(e,"g"),_n.ALPHANUMERIC=new RegExp(t,"g");const o=new RegExp("^"+n+"$"),i=new RegExp("^"+e+"$"),s=new RegExp("^[A-Z0-9 $%*+\\-./:]+$");return _n.testKanji=function(c){return o.test(c)},_n.testNumeric=function(c){return i.test(c)},_n.testAlphanumeric=function(c){return s.test(c)},_n}var Zh;function Oi(){return Zh||(Zh=1,(function(e){const t=zf(),n=Hf();e.NUMERIC={id:"Numeric",bit:1,ccBits:[10,12,14]},e.ALPHANUMERIC={id:"Alphanumeric",bit:2,ccBits:[9,11,13]},e.BYTE={id:"Byte",bit:4,ccBits:[8,16,16]},e.KANJI={id:"Kanji",bit:8,ccBits:[8,10,12]},e.MIXED={bit:-1},e.getCharCountIndicator=function(i,s){if(!i.ccBits)throw new Error("Invalid mode: "+i);if(!t.isValid(s))throw new Error("Invalid version: "+s);return s>=1&&s<10?i.ccBits[0]:s<27?i.ccBits[1]:i.ccBits[2]},e.getBestModeForData=function(i){return n.testNumeric(i)?e.NUMERIC:n.testAlphanumeric(i)?e.ALPHANUMERIC:n.testKanji(i)?e.KANJI:e.BYTE},e.toString=function(i){if(i&&i.id)return i.id;throw new Error("Invalid mode")},e.isValid=function(i){return i&&i.bit&&i.ccBits};function r(o){if(typeof o!="string")throw new Error("Param is not a string");switch(o.toLowerCase()){case"numeric":return e.NUMERIC;case"alphanumeric":return e.ALPHANUMERIC;case"kanji":return e.KANJI;case"byte":return e.BYTE;default:throw new Error("Unknown mode: "+o)}}e.from=function(i,s){if(e.isValid(i))return i;try{return r(i)}catch{return s}}})(_l)),_l}var Yh;function DC(){return Yh||(Yh=1,(function(e){const t=Ii(),n=Ff(),r=nu(),o=Oi(),i=zf(),s=7973,a=t.getBCHDigit(s);function c(f,w,v){for(let y=1;y<=40;y++)if(w<=e.getCapacity(y,v,f))return y}function l(f,w){return o.getCharCountIndicator(f,w)+4}function d(f,w){let v=0;return f.forEach(function(y){const $=l(y.mode,w);v+=$+y.getBitsLength()}),v}function h(f,w){for(let v=1;v<=40;v++)if(d(f,v)<=e.getCapacity(v,w,o.MIXED))return v}e.from=function(w,v){return i.isValid(w)?parseInt(w,10):v},e.getCapacity=function(w,v,y){if(!i.isValid(w))throw new Error("Invalid QR Code version");typeof y>"u"&&(y=o.BYTE);const $=t.getSymbolTotalCodewords(w),I=n.getTotalCodewordsCount(w,v),k=($-I)*8;if(y===o.MIXED)return k;const D=k-l(y,w);switch(y){case o.NUMERIC:return Math.floor(D/10*3);case o.ALPHANUMERIC:return Math.floor(D/11*2);case o.KANJI:return Math.floor(D/13);case o.BYTE:default:return Math.floor(D/8)}},e.getBestVersionForData=function(w,v){let y;const $=r.from(v,r.M);if(Array.isArray(w)){if(w.length>1)return h(w,$);if(w.length===0)return 1;y=w[0]}else y=w;return c(y.mode,y.getLength(),$)},e.getEncodedBits=function(w){if(!i.isValid(w)||w<7)throw new Error("Invalid QR Code version");let v=w<<12;for(;t.getBCHDigit(v)-a>=0;)v^=s<<t.getBCHDigit(v)-a;return w<<12|v}})(El)),El}var xl={},Jh;function MC(){if(Jh)return xl;Jh=1;const e=Ii(),t=1335,n=21522,r=e.getBCHDigit(t);return xl.getEncodedBits=function(i,s){const a=i.bit<<3|s;let c=a<<10;for(;e.getBCHDigit(c)-r>=0;)c^=t<<e.getBCHDigit(c)-r;return(a<<10|c)^n},xl}var Sl={},Tl,Xh;function UC(){if(Xh)return Tl;Xh=1;const e=Oi();function t(n){this.mode=e.NUMERIC,this.data=n.toString()}return t.getBitsLength=function(r){return 10*Math.floor(r/3)+(r%3?r%3*3+1:0)},t.prototype.getLength=function(){return this.data.length},t.prototype.getBitsLength=function(){return t.getBitsLength(this.data.length)},t.prototype.write=function(r){let o,i,s;for(o=0;o+3<=this.data.length;o+=3)i=this.data.substr(o,3),s=parseInt(i,10),r.put(s,10);const a=this.data.length-o;a>0&&(i=this.data.substr(o),s=parseInt(i,10),r.put(s,a*3+1))},Tl=t,Tl}var $l,Qh;function BC(){if(Qh)return $l;Qh=1;const e=Oi(),t=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ","$","%","*","+","-",".","/",":"];function n(r){this.mode=e.ALPHANUMERIC,this.data=r}return n.getBitsLength=function(o){return 11*Math.floor(o/2)+6*(o%2)},n.prototype.getLength=function(){return this.data.length},n.prototype.getBitsLength=function(){return n.getBitsLength(this.data.length)},n.prototype.write=function(o){let i;for(i=0;i+2<=this.data.length;i+=2){let s=t.indexOf(this.data[i])*45;s+=t.indexOf(this.data[i+1]),o.put(s,11)}this.data.length%2&&o.put(t.indexOf(this.data[i]),6)},$l=n,$l}var Nl,ep;function WC(){return ep||(ep=1,Nl=function(t){for(var n=[],r=t.length,o=0;o<r;o++){var i=t.charCodeAt(o);if(i>=55296&&i<=56319&&r>o+1){var s=t.charCodeAt(o+1);s>=56320&&s<=57343&&(i=(i-55296)*1024+s-56320+65536,o+=1)}if(i<128){n.push(i);continue}if(i<2048){n.push(i>>6|192),n.push(i&63|128);continue}if(i<55296||i>=57344&&i<65536){n.push(i>>12|224),n.push(i>>6&63|128),n.push(i&63|128);continue}if(i>=65536&&i<=1114111){n.push(i>>18|240),n.push(i>>12&63|128),n.push(i>>6&63|128),n.push(i&63|128);continue}n.push(239,191,189)}return new Uint8Array(n).buffer}),Nl}var Rl,tp;function jC(){if(tp)return Rl;tp=1;const e=WC(),t=Oi();function n(r){this.mode=t.BYTE,typeof r=="string"&&(r=e(r)),this.data=new Uint8Array(r)}return n.getBitsLength=function(o){return o*8},n.prototype.getLength=function(){return this.data.length},n.prototype.getBitsLength=function(){return n.getBitsLength(this.data.length)},n.prototype.write=function(r){for(let o=0,i=this.data.length;o<i;o++)r.put(this.data[o],8)},Rl=n,Rl}var kl,np;function FC(){if(np)return kl;np=1;const e=Oi(),t=Ii();function n(r){this.mode=e.KANJI,this.data=r}return n.getBitsLength=function(o){return o*13},n.prototype.getLength=function(){return this.data.length},n.prototype.getBitsLength=function(){return n.getBitsLength(this.data.length)},n.prototype.write=function(r){let o;for(o=0;o<this.data.length;o++){let i=t.toSJIS(this.data[o]);if(i>=33088&&i<=40956)i-=33088;else if(i>=57408&&i<=60351)i-=49472;else throw new Error("Invalid SJIS character: "+this.data[o]+`
Make sure your charset is UTF-8`);i=(i>>>8&255)*192+(i&255),r.put(i,13)}},kl=n,kl}var Il={exports:{}},rp;function zC(){return rp||(rp=1,(function(e){var t={single_source_shortest_paths:function(n,r,o){var i={},s={};s[r]=0;var a=t.PriorityQueue.make();a.push(r,0);for(var c,l,d,h,f,w,v,y,$;!a.empty();){c=a.pop(),l=c.value,h=c.cost,f=n[l]||{};for(d in f)f.hasOwnProperty(d)&&(w=f[d],v=h+w,y=s[d],$=typeof s[d]>"u",($||y>v)&&(s[d]=v,a.push(d,v),i[d]=l))}if(typeof o<"u"&&typeof s[o]>"u"){var I=["Could not find a path from ",r," to ",o,"."].join("");throw new Error(I)}return i},extract_shortest_path_from_predecessor_list:function(n,r){for(var o=[],i=r;i;)o.push(i),n[i],i=n[i];return o.reverse(),o},find_path:function(n,r,o){var i=t.single_source_shortest_paths(n,r,o);return t.extract_shortest_path_from_predecessor_list(i,o)},PriorityQueue:{make:function(n){var r=t.PriorityQueue,o={},i;n=n||{};for(i in r)r.hasOwnProperty(i)&&(o[i]=r[i]);return o.queue=[],o.sorter=n.sorter||r.default_sorter,o},default_sorter:function(n,r){return n.cost-r.cost},push:function(n,r){var o={value:n,cost:r};this.queue.push(o),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return this.queue.length===0}}};e.exports=t})(Il)),Il.exports}var ip;function HC(){return ip||(ip=1,(function(e){const t=Oi(),n=UC(),r=BC(),o=jC(),i=FC(),s=Hf(),a=Ii(),c=zC();function l(I){return unescape(encodeURIComponent(I)).length}function d(I,k,D){const C=[];let A;for(;(A=I.exec(D))!==null;)C.push({data:A[0],index:A.index,mode:k,length:A[0].length});return C}function h(I){const k=d(s.NUMERIC,t.NUMERIC,I),D=d(s.ALPHANUMERIC,t.ALPHANUMERIC,I);let C,A;return a.isKanjiModeEnabled()?(C=d(s.BYTE,t.BYTE,I),A=d(s.KANJI,t.KANJI,I)):(C=d(s.BYTE_KANJI,t.BYTE,I),A=[]),k.concat(D,C,A).sort(function(P,B){return P.index-B.index}).map(function(P){return{data:P.data,mode:P.mode,length:P.length}})}function f(I,k){switch(k){case t.NUMERIC:return n.getBitsLength(I);case t.ALPHANUMERIC:return r.getBitsLength(I);case t.KANJI:return i.getBitsLength(I);case t.BYTE:return o.getBitsLength(I)}}function w(I){return I.reduce(function(k,D){const C=k.length-1>=0?k[k.length-1]:null;return C&&C.mode===D.mode?(k[k.length-1].data+=D.data,k):(k.push(D),k)},[])}function v(I){const k=[];for(let D=0;D<I.length;D++){const C=I[D];switch(C.mode){case t.NUMERIC:k.push([C,{data:C.data,mode:t.ALPHANUMERIC,length:C.length},{data:C.data,mode:t.BYTE,length:C.length}]);break;case t.ALPHANUMERIC:k.push([C,{data:C.data,mode:t.BYTE,length:C.length}]);break;case t.KANJI:k.push([C,{data:C.data,mode:t.BYTE,length:l(C.data)}]);break;case t.BYTE:k.push([{data:C.data,mode:t.BYTE,length:l(C.data)}])}}return k}function y(I,k){const D={},C={start:{}};let A=["start"];for(let _=0;_<I.length;_++){const P=I[_],B=[];for(let j=0;j<P.length;j++){const W=P[j],z=""+_+j;B.push(z),D[z]={node:W,lastCount:0},C[z]={};for(let Y=0;Y<A.length;Y++){const ue=A[Y];D[ue]&&D[ue].node.mode===W.mode?(C[ue][z]=f(D[ue].lastCount+W.length,W.mode)-f(D[ue].lastCount,W.mode),D[ue].lastCount+=W.length):(D[ue]&&(D[ue].lastCount=W.length),C[ue][z]=f(W.length,W.mode)+4+t.getCharCountIndicator(W.mode,k))}}A=B}for(let _=0;_<A.length;_++)C[A[_]].end=0;return{map:C,table:D}}function $(I,k){let D;const C=t.getBestModeForData(I);if(D=t.from(k,C),D!==t.BYTE&&D.bit<C.bit)throw new Error('"'+I+'" cannot be encoded with mode '+t.toString(D)+`.
 Suggested mode is: `+t.toString(C));switch(D===t.KANJI&&!a.isKanjiModeEnabled()&&(D=t.BYTE),D){case t.NUMERIC:return new n(I);case t.ALPHANUMERIC:return new r(I);case t.KANJI:return new i(I);case t.BYTE:return new o(I)}}e.fromArray=function(k){return k.reduce(function(D,C){return typeof C=="string"?D.push($(C,null)):C.data&&D.push($(C.data,C.mode)),D},[])},e.fromString=function(k,D){const C=h(k,a.isKanjiModeEnabled()),A=v(C),_=y(A,D),P=c.find_path(_.map,"start","end"),B=[];for(let j=1;j<P.length-1;j++)B.push(_.table[P[j]].node);return e.fromArray(w(B))},e.rawSplit=function(k){return e.fromArray(h(k,a.isKanjiModeEnabled()))}})(Sl)),Sl}var op;function VC(){if(op)return pl;op=1;const e=Ii(),t=nu(),n=$C(),r=NC(),o=RC(),i=kC(),s=IC(),a=Ff(),c=LC(),l=DC(),d=MC(),h=Oi(),f=HC();function w(_,P){const B=_.size,j=i.getPositions(P);for(let W=0;W<j.length;W++){const z=j[W][0],Y=j[W][1];for(let ue=-1;ue<=7;ue++)if(!(z+ue<=-1||B<=z+ue))for(let V=-1;V<=7;V++)Y+V<=-1||B<=Y+V||(ue>=0&&ue<=6&&(V===0||V===6)||V>=0&&V<=6&&(ue===0||ue===6)||ue>=2&&ue<=4&&V>=2&&V<=4?_.set(z+ue,Y+V,!0,!0):_.set(z+ue,Y+V,!1,!0))}}function v(_){const P=_.size;for(let B=8;B<P-8;B++){const j=B%2===0;_.set(B,6,j,!0),_.set(6,B,j,!0)}}function y(_,P){const B=o.getPositions(P);for(let j=0;j<B.length;j++){const W=B[j][0],z=B[j][1];for(let Y=-2;Y<=2;Y++)for(let ue=-2;ue<=2;ue++)Y===-2||Y===2||ue===-2||ue===2||Y===0&&ue===0?_.set(W+Y,z+ue,!0,!0):_.set(W+Y,z+ue,!1,!0)}}function $(_,P){const B=_.size,j=l.getEncodedBits(P);let W,z,Y;for(let ue=0;ue<18;ue++)W=Math.floor(ue/3),z=ue%3+B-8-3,Y=(j>>ue&1)===1,_.set(W,z,Y,!0),_.set(z,W,Y,!0)}function I(_,P,B){const j=_.size,W=d.getEncodedBits(P,B);let z,Y;for(z=0;z<15;z++)Y=(W>>z&1)===1,z<6?_.set(z,8,Y,!0):z<8?_.set(z+1,8,Y,!0):_.set(j-15+z,8,Y,!0),z<8?_.set(8,j-z-1,Y,!0):z<9?_.set(8,15-z-1+1,Y,!0):_.set(8,15-z-1,Y,!0);_.set(j-8,8,1,!0)}function k(_,P){const B=_.size;let j=-1,W=B-1,z=7,Y=0;for(let ue=B-1;ue>0;ue-=2)for(ue===6&&ue--;;){for(let V=0;V<2;V++)if(!_.isReserved(W,ue-V)){let b=!1;Y<P.length&&(b=(P[Y]>>>z&1)===1),_.set(W,ue-V,b),z--,z===-1&&(Y++,z=7)}if(W+=j,W<0||B<=W){W-=j,j=-j;break}}}function D(_,P,B){const j=new n;B.forEach(function(V){j.put(V.mode.bit,4),j.put(V.getLength(),h.getCharCountIndicator(V.mode,_)),V.write(j)});const W=e.getSymbolTotalCodewords(_),z=a.getTotalCodewordsCount(_,P),Y=(W-z)*8;for(j.getLengthInBits()+4<=Y&&j.put(0,4);j.getLengthInBits()%8!==0;)j.putBit(0);const ue=(Y-j.getLengthInBits())/8;for(let V=0;V<ue;V++)j.put(V%2?17:236,8);return C(j,_,P)}function C(_,P,B){const j=e.getSymbolTotalCodewords(P),W=a.getTotalCodewordsCount(P,B),z=j-W,Y=a.getBlocksCount(P,B),ue=j%Y,V=Y-ue,b=Math.floor(j/Y),E=Math.floor(z/Y),H=E+1,F=b-E,re=new c(F);let Z=0;const Ne=new Array(Y),We=new Array(Y);let He=0;const Re=new Uint8Array(_.buffer);for(let St=0;St<Y;St++){const it=St<V?E:H;Ne[St]=Re.slice(Z,Z+it),We[St]=re.encode(Ne[St]),Z+=it,He=Math.max(He,it)}const Ve=new Uint8Array(j);let Wn=0,lt,bt;for(lt=0;lt<He;lt++)for(bt=0;bt<Y;bt++)lt<Ne[bt].length&&(Ve[Wn++]=Ne[bt][lt]);for(lt=0;lt<F;lt++)for(bt=0;bt<Y;bt++)Ve[Wn++]=We[bt][lt];return Ve}function A(_,P,B,j){let W;if(Array.isArray(_))W=f.fromArray(_);else if(typeof _=="string"){let b=P;if(!b){const E=f.rawSplit(_);b=l.getBestVersionForData(E,B)}W=f.fromString(_,b||40)}else throw new Error("Invalid data");const z=l.getBestVersionForData(W,B);if(!z)throw new Error("The amount of data is too big to be stored in a QR Code");if(!P)P=z;else if(P<z)throw new Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: `+z+`.
`);const Y=D(P,B,W),ue=e.getSymbolSize(P),V=new r(ue);return w(V,P),v(V),y(V,P),I(V,B,0),P>=7&&$(V,P),k(V,Y),isNaN(j)&&(j=s.getBestMask(V,I.bind(null,V,B))),s.applyMask(j,V),I(V,B,j),{modules:V,version:P,errorCorrectionLevel:B,maskPattern:j,segments:W}}return pl.create=function(P,B){if(typeof P>"u"||P==="")throw new Error("No input text");let j=t.M,W,z;return typeof B<"u"&&(j=t.from(B.errorCorrectionLevel,t.M),W=l.from(B.version),z=s.from(B.maskPattern),B.toSJISFunc&&e.setToSJISFunction(B.toSJISFunc)),A(P,W,j,z)},pl}var Ol={},Pl={},sp;function Vf(){return sp||(sp=1,(function(e){function t(n){if(typeof n=="number"&&(n=n.toString()),typeof n!="string")throw new Error("Color should be defined as hex string");let r=n.slice().replace("#","").split("");if(r.length<3||r.length===5||r.length>8)throw new Error("Invalid hex color: "+n);(r.length===3||r.length===4)&&(r=Array.prototype.concat.apply([],r.map(function(i){return[i,i]}))),r.length===6&&r.push("F","F");const o=parseInt(r.join(""),16);return{r:o>>24&255,g:o>>16&255,b:o>>8&255,a:o&255,hex:"#"+r.slice(0,6).join("")}}e.getOptions=function(r){r||(r={}),r.color||(r.color={});const o=typeof r.margin>"u"||r.margin===null||r.margin<0?4:r.margin,i=r.width&&r.width>=21?r.width:void 0,s=r.scale||4;return{width:i,scale:i?4:s,margin:o,color:{dark:t(r.color.dark||"#000000ff"),light:t(r.color.light||"#ffffffff")},type:r.type,rendererOpts:r.rendererOpts||{}}},e.getScale=function(r,o){return o.width&&o.width>=r+o.margin*2?o.width/(r+o.margin*2):o.scale},e.getImageWidth=function(r,o){const i=e.getScale(r,o);return Math.floor((r+o.margin*2)*i)},e.qrToImageData=function(r,o,i){const s=o.modules.size,a=o.modules.data,c=e.getScale(s,i),l=Math.floor((s+i.margin*2)*c),d=i.margin*c,h=[i.color.light,i.color.dark];for(let f=0;f<l;f++)for(let w=0;w<l;w++){let v=(f*l+w)*4,y=i.color.light;if(f>=d&&w>=d&&f<l-d&&w<l-d){const $=Math.floor((f-d)/c),I=Math.floor((w-d)/c);y=h[a[$*s+I]?1:0]}r[v++]=y.r,r[v++]=y.g,r[v++]=y.b,r[v]=y.a}}})(Pl)),Pl}var ap;function qC(){return ap||(ap=1,(function(e){const t=Vf();function n(o,i,s){o.clearRect(0,0,i.width,i.height),i.style||(i.style={}),i.height=s,i.width=s,i.style.height=s+"px",i.style.width=s+"px"}function r(){try{return document.createElement("canvas")}catch{throw new Error("You need to specify a canvas element")}}e.render=function(i,s,a){let c=a,l=s;typeof c>"u"&&(!s||!s.getContext)&&(c=s,s=void 0),s||(l=r()),c=t.getOptions(c);const d=t.getImageWidth(i.modules.size,c),h=l.getContext("2d"),f=h.createImageData(d,d);return t.qrToImageData(f.data,i,c),n(h,l,d),h.putImageData(f,0,0),l},e.renderToDataURL=function(i,s,a){let c=a;typeof c>"u"&&(!s||!s.getContext)&&(c=s,s=void 0),c||(c={});const l=e.render(i,s,c),d=c.type||"image/png",h=c.rendererOpts||{};return l.toDataURL(d,h.quality)}})(Ol)),Ol}var Ll={},cp;function KC(){if(cp)return Ll;cp=1;const e=Vf();function t(o,i){const s=o.a/255,a=i+'="'+o.hex+'"';return s<1?a+" "+i+'-opacity="'+s.toFixed(2).slice(1)+'"':a}function n(o,i,s){let a=o+i;return typeof s<"u"&&(a+=" "+s),a}function r(o,i,s){let a="",c=0,l=!1,d=0;for(let h=0;h<o.length;h++){const f=Math.floor(h%i),w=Math.floor(h/i);!f&&!l&&(l=!0),o[h]?(d++,h>0&&f>0&&o[h-1]||(a+=l?n("M",f+s,.5+w+s):n("m",c,0),c=0,l=!1),f+1<i&&o[h+1]||(a+=n("h",d),d=0)):c++}return a}return Ll.render=function(i,s,a){const c=e.getOptions(s),l=i.modules.size,d=i.modules.data,h=l+c.margin*2,f=c.color.light.a?"<path "+t(c.color.light,"fill")+' d="M0 0h'+h+"v"+h+'H0z"/>':"",w="<path "+t(c.color.dark,"stroke")+' d="'+r(d,l,c.margin)+'"/>',v='viewBox="0 0 '+h+" "+h+'"',$='<svg xmlns="http://www.w3.org/2000/svg" '+(c.width?'width="'+c.width+'" height="'+c.width+'" ':"")+v+' shape-rendering="crispEdges">'+f+w+`</svg>
`;return typeof a=="function"&&a(null,$),$},Ll}var lp;function GC(){if(lp)return Bi;lp=1;const e=TC(),t=VC(),n=qC(),r=KC();function o(i,s,a,c,l){const d=[].slice.call(arguments,1),h=d.length,f=typeof d[h-1]=="function";if(!f&&!e())throw new Error("Callback required as last argument");if(f){if(h<2)throw new Error("Too few arguments provided");h===2?(l=a,a=s,s=c=void 0):h===3&&(s.getContext&&typeof l>"u"?(l=c,c=void 0):(l=c,c=a,a=s,s=void 0))}else{if(h<1)throw new Error("Too few arguments provided");return h===1?(a=s,s=c=void 0):h===2&&!s.getContext&&(c=a,a=s,s=void 0),new Promise(function(w,v){try{const y=t.create(a,c);w(i(y,s,c))}catch(y){v(y)}})}try{const w=t.create(a,c);l(null,i(w,s,c))}catch(w){l(w)}}return Bi.create=t.create,Bi.toCanvas=o.bind(null,n.render),Bi.toDataURL=o.bind(null,n.renderToDataURL),Bi.toString=o.bind(null,function(i,s,a){return r.render(i,a)}),Bi}var ZC=GC();const YC=Ei(ZC),JC=.1,dp=2.5,Vn=7;function Dl(e,t,n){return e===t?!1:(e-t<0?t-e:e-t)<=n+JC}function XC(e,t){const n=Array.prototype.slice.call(YC.create(e,{errorCorrectionLevel:t}).modules.data,0),r=Math.sqrt(n.length);return n.reduce((o,i,s)=>(s%r===0?o.push([i]):o[o.length-1].push(i))&&o,[])}const QC={generate({uri:e,size:t,logoSize:n,padding:r=8,dotColor:o="var(--apkt-colors-black)"}){const s=[],a=XC(e,"Q"),c=(t-2*r)/a.length,l=[{x:0,y:0},{x:1,y:0},{x:0,y:1}];l.forEach(({x:y,y:$})=>{const I=(a.length-Vn)*c*y+r,k=(a.length-Vn)*c*$+r,D=.45;for(let C=0;C<l.length;C+=1){const A=c*(Vn-C*2);s.push(pe`
            <rect
              fill=${C===2?"var(--apkt-colors-black)":"var(--apkt-colors-white)"}
              width=${C===0?A-10:A}
              rx= ${C===0?(A-10)*D:A*D}
              ry= ${C===0?(A-10)*D:A*D}
              stroke=${o}
              stroke-width=${C===0?10:0}
              height=${C===0?A-10:A}
              x= ${C===0?k+c*C+10/2:k+c*C}
              y= ${C===0?I+c*C+10/2:I+c*C}
            />
          `)}});const d=Math.floor((n+25)/c),h=a.length/2-d/2,f=a.length/2+d/2-1,w=[];a.forEach((y,$)=>{y.forEach((I,k)=>{if(a[$][k]&&!($<Vn&&k<Vn||$>a.length-(Vn+1)&&k<Vn||$<Vn&&k>a.length-(Vn+1))&&!($>h&&$<f&&k>h&&k<f)){const D=$*c+c/2+r,C=k*c+c/2+r;w.push([D,C])}})});const v={};return w.forEach(([y,$])=>{v[y]?v[y]?.push($):v[y]=[$]}),Object.entries(v).map(([y,$])=>{const I=$.filter(k=>$.every(D=>!Dl(k,D,c)));return[Number(y),I]}).forEach(([y,$])=>{$.forEach(I=>{s.push(pe`<circle cx=${y} cy=${I} fill=${o} r=${c/dp} />`)})}),Object.entries(v).filter(([y,$])=>$.length>1).map(([y,$])=>{const I=$.filter(k=>$.some(D=>Dl(k,D,c)));return[Number(y),I]}).map(([y,$])=>{$.sort((k,D)=>k<D?-1:1);const I=[];for(const k of $){const D=I.find(C=>C.some(A=>Dl(k,A,c)));D?D.push(k):I.push([k])}return[y,I.map(k=>[k[0],k[k.length-1]])]}).forEach(([y,$])=>{$.forEach(([I,k])=>{s.push(pe`
              <line
                x1=${y}
                x2=${y}
                y1=${I}
                y2=${k}
                stroke=${o}
                stroke-width=${c/(dp/2)}
                stroke-linecap="round"
              />
            `)})}),s}},e4=Q`
  :host {
    position: relative;
    user-select: none;
    display: block;
    overflow: hidden;
    aspect-ratio: 1 / 1;
    width: 100%;
    height: 100%;
    background-color: ${({colors:e})=>e.white};
    border: 1px solid ${({tokens:e})=>e.theme.borderPrimary};
  }

  :host {
    border-radius: ${({borderRadius:e})=>e[4]};
    display: flex;
    align-items: center;
    justify-content: center;
  }

  :host([data-clear='true']) > wui-icon {
    display: none;
  }

  svg:first-child,
  wui-image,
  wui-icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translateY(-50%) translateX(-50%);
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
    box-shadow: inset 0 0 0 4px ${({tokens:e})=>e.theme.backgroundPrimary};
    border-radius: ${({borderRadius:e})=>e[6]};
  }

  wui-image {
    width: 25%;
    height: 25%;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  wui-icon {
    width: 100%;
    height: 100%;
    color: #3396ff !important;
    transform: translateY(-50%) translateX(-50%) scale(0.25);
  }

  wui-icon > svg {
    width: inherit;
    height: inherit;
  }
`;var kr=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Dn=class extends de{constructor(){super(...arguments),this.uri="",this.size=500,this.theme="dark",this.imageSrc=void 0,this.alt=void 0,this.arenaClear=void 0,this.farcaster=void 0}render(){return this.dataset.theme=this.theme,this.dataset.clear=String(this.arenaClear),x`<wui-flex
      alignItems="center"
      justifyContent="center"
      class="wui-qr-code"
      direction="column"
      gap="4"
      width="100%"
      style="height: 100%"
    >
      ${this.templateVisual()} ${this.templateSvg()}
    </wui-flex>`}templateSvg(){return pe`
      <svg viewBox="0 0 ${this.size} ${this.size}" width="100%" height="100%">
        ${QC.generate({uri:this.uri,size:this.size,logoSize:this.arenaClear?0:this.size/4})}
      </svg>
    `}templateVisual(){return this.imageSrc?x`<wui-image src=${this.imageSrc} alt=${this.alt??"logo"}></wui-image>`:this.farcaster?x`<wui-icon
        class="farcaster"
        size="inherit"
        color="inherit"
        name="farcaster"
      ></wui-icon>`:x`<wui-icon size="inherit" color="inherit" name="walletConnect"></wui-icon>`}};Dn.styles=[we,e4];kr([m()],Dn.prototype,"uri",void 0);kr([m({type:Number})],Dn.prototype,"size",void 0);kr([m()],Dn.prototype,"theme",void 0);kr([m()],Dn.prototype,"imageSrc",void 0);kr([m()],Dn.prototype,"alt",void 0);kr([m({type:Boolean})],Dn.prototype,"arenaClear",void 0);kr([m({type:Boolean})],Dn.prototype,"farcaster",void 0);Dn=kr([M("wui-qr-code")],Dn);const t4=Q`
  wui-shimmer {
    width: 100%;
    aspect-ratio: 1 / 1;
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  wui-qr-code {
    opacity: 0;
    animation-duration: ${({durations:e})=>e.xl};
    animation-timing-function: ${({easings:e})=>e["ease-out-power-2"]};
    animation-name: fade-in;
    animation-fill-mode: forwards;
  }

  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
`;var qf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let yc=class extends ct{constructor(){super(),this.basic=!1}firstUpdated(){this.basic||X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet?.name??"WalletConnect",platform:"qrcode",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:S.state.view}})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.forEach(t=>t())}render(){return this.onRenderProxy(),g`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["0","5","5","5"]}
        gap="5"
      >
        <wui-shimmer width="100%"> ${this.qrCodeTemplate()} </wui-shimmer>
        <wui-text variant="lg-medium" color="primary"> Scan this QR Code with your phone </wui-text>
        ${this.copyTemplate()}
      </wui-flex>
      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `}onRenderProxy(){!this.ready&&this.uri&&(this.ready=!0)}qrCodeTemplate(){if(!this.uri||!this.ready)return null;const t=this.wallet?this.wallet.name:void 0;U.setWcLinking(void 0),U.setRecentWallet(this.wallet);const n=fr.state.themeVariables["--apkt-qr-color"]??fr.state.themeVariables["--w3m-qr-color"];return g` <wui-qr-code
      theme=${fr.state.themeMode}
      uri=${this.uri}
      imageSrc=${ae(De.getWalletImage(this.wallet))}
      color=${ae(n)}
      alt=${ae(t)}
      data-testid="wui-qr-code"
    ></wui-qr-code>`}copyTemplate(){const t=!this.uri||!this.ready;return g`<wui-button
      .disabled=${t}
      @click=${this.onCopyUri}
      variant="neutral-secondary"
      size="sm"
      data-testid="copy-wc2-uri"
    >
      Copy link
      <wui-icon size="sm" color="inherit" name="copy" slot="iconRight"></wui-icon>
    </wui-button>`}};yc.styles=t4;qf([ve({type:Boolean})],yc.prototype,"basic",void 0);yc=qf([M("w3m-connecting-wc-qrcode")],yc);var n4=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let up=class extends he{constructor(){if(super(),this.wallet=S.state.data?.wallet,!this.wallet)throw new Error("w3m-connecting-wc-unsupported: No wallet provided");X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"browser",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:S.state.view}})}render(){return g`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["10","5","5","5"]}
        gap="5"
      >
        <wui-wallet-image
          size="lg"
          imageSrc=${ae(De.getWalletImage(this.wallet))}
        ></wui-wallet-image>

        <wui-text variant="md-regular" color="primary">Not Detected</wui-text>
      </wui-flex>

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `}};up=n4([M("w3m-connecting-wc-unsupported")],up);var Kf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let fd=class extends ct{constructor(){if(super(),this.isLoading=!0,!this.wallet)throw new Error("w3m-connecting-wc-web: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.secondaryBtnLabel="Open",this.secondaryLabel=ke.CONNECT_LABELS.MOBILE,this.secondaryBtnIcon="externalLink",this.updateLoadingState(),this.unsubscribe.push(U.subscribeKey("wcUri",()=>{this.updateLoadingState()})),X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"web",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:S.state.view}})}updateLoadingState(){this.isLoading=!this.uri}onConnectProxy(){if(this.wallet?.webapp_link&&this.uri)try{this.error=!1;const{webapp_link:t,name:n}=this.wallet,{redirect:r,href:o}=L.formatUniversalUrl(t,this.uri);U.setWcLinking({name:n,href:o}),U.setRecentWallet(this.wallet),L.openHref(r,"_blank")}catch{this.error=!0}}};Kf([T()],fd.prototype,"isLoading",void 0);fd=Kf([M("w3m-connecting-wc-web")],fd);const r4=Q`
  :host([data-mobile-fullscreen='true']) {
    height: 100%;
    display: flex;
    flex-direction: column;
  }

  :host([data-mobile-fullscreen='true']) wui-ux-by-reown {
    margin-top: auto;
  }
`;var Pi=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let rr=class extends he{constructor(){super(),this.wallet=S.state.data?.wallet,this.unsubscribe=[],this.platform=void 0,this.platforms=[],this.isSiwxEnabled=!!R.state.siwx,this.remoteFeatures=R.state.remoteFeatures,this.displayBranding=!0,this.basic=!1,this.determinePlatforms(),this.initializeConnection(),this.unsubscribe.push(R.subscribeKey("remoteFeatures",t=>this.remoteFeatures=t))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return R.state.enableMobileFullScreen&&this.setAttribute("data-mobile-fullscreen","true"),g`
      ${this.headerTemplate()}
      <div class="platform-container">${this.platformTemplate()}</div>
      ${this.reownBrandingTemplate()}
    `}reownBrandingTemplate(){return!this.remoteFeatures?.reownBranding||!this.displayBranding?null:g`<wui-ux-by-reown></wui-ux-by-reown>`}async initializeConnection(t=!1){if(!(this.platform==="browser"||R.state.manualWCControl&&!t))try{const{wcPairingExpiry:n,status:r}=U.state,{redirectView:o}=S.state.data??{};if(t||R.state.enableEmbedded||L.isPairingExpired(n)||r==="connecting"){const i=U.getConnections(p.state.activeChain),s=this.remoteFeatures?.multiWallet,a=i.length>0;await U.connectWalletConnect({cache:"never"}),this.isSiwxEnabled||(a&&s?(S.replace("ProfileWallets"),Te.showSuccess("New Wallet Added")):o?S.replace(o):ye.close())}}catch(n){if(n instanceof Error&&n.message.includes("An error occurred when attempting to switch chain")&&!R.state.enableNetworkSwitch&&p.state.activeChain){p.setActiveCaipNetwork(tf.getUnsupportedNetwork(`${p.state.activeChain}:${p.state.activeCaipNetwork?.id}`)),p.showUnsupportedChainUI();return}n instanceof In&&n.originalName===Yt.PROVIDER_RPC_ERROR_NAME.USER_REJECTED_REQUEST?X.sendEvent({type:"track",event:"USER_REJECTED",properties:{message:n.message}}):X.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:n?.message??"Unknown"}}),U.setWcError(!0),Te.showError(n.message??"Connection error"),U.resetWcConnection(),S.goBack()}}determinePlatforms(){if(!this.wallet){this.platforms.push("qrcode"),this.platform="qrcode";return}if(this.platform)return;const{mobile_link:t,desktop_link:n,webapp_link:r,injected:o,rdns:i}=this.wallet,s=o?.map(({injected_id:v})=>v).filter(Boolean),a=[...i?[i]:s??[]],c=R.state.isUniversalProvider?!1:a.length,l=t,d=r,h=U.checkInstalled(a),f=c&&h,w=n&&!L.isMobile();f&&!p.state.noAdapters&&this.platforms.push("browser"),l&&this.platforms.push(L.isMobile()?"mobile":"qrcode"),d&&this.platforms.push("web"),w&&this.platforms.push("desktop"),!f&&c&&!p.state.noAdapters&&this.platforms.push("unsupported"),this.platform=this.platforms[0]}platformTemplate(){switch(this.platform){case"browser":return g`<w3m-connecting-wc-browser></w3m-connecting-wc-browser>`;case"web":return g`<w3m-connecting-wc-web></w3m-connecting-wc-web>`;case"desktop":return g`
          <w3m-connecting-wc-desktop .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-desktop>
        `;case"mobile":return g`
          <w3m-connecting-wc-mobile isMobile .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-mobile>
        `;case"qrcode":return g`<w3m-connecting-wc-qrcode ?basic=${this.basic}></w3m-connecting-wc-qrcode>`;default:return g`<w3m-connecting-wc-unsupported></w3m-connecting-wc-unsupported>`}}headerTemplate(){return this.platforms.length>1?g`
      <w3m-connecting-header
        .platforms=${this.platforms}
        .onSelectPlatfrom=${this.onSelectPlatform.bind(this)}
      >
      </w3m-connecting-header>
    `:null}async onSelectPlatform(t){const n=this.shadowRoot?.querySelector("div");n&&(await n.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.platform=t,n.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"}))}};rr.styles=r4;Pi([T()],rr.prototype,"platform",void 0);Pi([T()],rr.prototype,"platforms",void 0);Pi([T()],rr.prototype,"isSiwxEnabled",void 0);Pi([T()],rr.prototype,"remoteFeatures",void 0);Pi([ve({type:Boolean})],rr.prototype,"displayBranding",void 0);Pi([ve({type:Boolean})],rr.prototype,"basic",void 0);rr=Pi([M("w3m-connecting-wc-view")],rr);var ru=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Cc=class extends he{constructor(){super(),this.unsubscribe=[],this.isMobile=L.isMobile(),this.remoteFeatures=R.state.remoteFeatures,this.unsubscribe.push(R.subscribeKey("remoteFeatures",t=>this.remoteFeatures=t))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){if(this.isMobile){const{featured:t,recommended:n}=q.state,{customWallets:r}=R.state,o=G.getRecentWallets(),i=t.length||n.length||r?.length||o.length;return g`<wui-flex flexDirection="column" gap="2" .margin=${["1","3","3","3"]}>
        ${i?g`<w3m-connector-list></w3m-connector-list>`:null}
        <w3m-all-wallets-widget></w3m-all-wallets-widget>
      </wui-flex>`}return g`<wui-flex flexDirection="column" .padding=${["0","0","4","0"]}>
        <w3m-connecting-wc-view ?basic=${!0} .displayBranding=${!1}></w3m-connecting-wc-view>
        <wui-flex flexDirection="column" .padding=${["0","3","0","3"]}>
          <w3m-all-wallets-widget></w3m-all-wallets-widget>
        </wui-flex>
      </wui-flex>
      ${this.reownBrandingTemplate()} `}reownBrandingTemplate(){return this.remoteFeatures?.reownBranding?g` <wui-flex flexDirection="column" .padding=${["1","0","1","0"]}>
      <wui-ux-by-reown></wui-ux-by-reown>
    </wui-flex>`:null}};ru([T()],Cc.prototype,"isMobile",void 0);ru([T()],Cc.prototype,"remoteFeatures",void 0);Cc=ru([M("w3m-connecting-wc-basic-view")],Cc);const i4=Vt`
  .continue-button-container {
    width: 100%;
  }
`;var Gf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let vc=class extends he{constructor(){super(...arguments),this.loading=!1}render(){return g`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        gap="6"
        .padding=${["0","0","4","0"]}
      >
        ${this.onboardingTemplate()} ${this.buttonsTemplate()}
        <wui-link
          @click=${()=>{L.openHref(Gm.URLS.FAQ,"_blank")}}
        >
          Learn more about names
          <wui-icon color="inherit" slot="iconRight" name="externalLink"></wui-icon>
        </wui-link>
      </wui-flex>
    `}onboardingTemplate(){return g` <wui-flex
      flexDirection="column"
      gap="6"
      alignItems="center"
      .padding=${["0","6","0","6"]}
    >
      <wui-flex gap="3" alignItems="center" justifyContent="center">
        <wui-icon-box icon="id" size="xl" iconSize="xxl" color="default"></wui-icon-box>
      </wui-flex>
      <wui-flex flexDirection="column" alignItems="center" gap="3">
        <wui-text align="center" variant="lg-medium" color="primary">
          Choose your account name
        </wui-text>
        <wui-text align="center" variant="md-regular" color="primary">
          Finally say goodbye to 0x addresses, name your account to make it easier to exchange
          assets
        </wui-text>
      </wui-flex>
    </wui-flex>`}buttonsTemplate(){return g`<wui-flex
      .padding=${["0","8","0","8"]}
      gap="3"
      class="continue-button-container"
    >
      <wui-button
        fullWidth
        .loading=${this.loading}
        size="lg"
        borderRadius="xs"
        @click=${this.handleContinue.bind(this)}
        >Choose name
      </wui-button>
    </wui-flex>`}handleContinue(){S.push("RegisterAccountName"),X.sendEvent({type:"track",event:"OPEN_ENS_FLOW",properties:{isSmartAccount:ut(p.state.activeChain)===je.ACCOUNT_TYPES.SMART_ACCOUNT}})}};vc.styles=i4;Gf([T()],vc.prototype,"loading",void 0);vc=Gf([M("w3m-choose-account-name-view")],vc);var o4=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let hp=class extends he{constructor(){super(...arguments),this.wallet=S.state.data?.wallet}render(){if(!this.wallet)throw new Error("w3m-downloads-view");return g`
      <wui-flex gap="2" flexDirection="column" .padding=${["3","3","4","3"]}>
        ${this.chromeTemplate()} ${this.iosTemplate()} ${this.androidTemplate()}
        ${this.homepageTemplate()}
      </wui-flex>
    `}chromeTemplate(){return this.wallet?.chrome_store?g`<wui-list-item
      variant="icon"
      icon="chromeStore"
      iconVariant="square"
      @click=${this.onChromeStore.bind(this)}
      chevron
    >
      <wui-text variant="md-medium" color="primary">Chrome Extension</wui-text>
    </wui-list-item>`:null}iosTemplate(){return this.wallet?.app_store?g`<wui-list-item
      variant="icon"
      icon="appStore"
      iconVariant="square"
      @click=${this.onAppStore.bind(this)}
      chevron
    >
      <wui-text variant="md-medium" color="primary">iOS App</wui-text>
    </wui-list-item>`:null}androidTemplate(){return this.wallet?.play_store?g`<wui-list-item
      variant="icon"
      icon="playStore"
      iconVariant="square"
      @click=${this.onPlayStore.bind(this)}
      chevron
    >
      <wui-text variant="md-medium" color="primary">Android App</wui-text>
    </wui-list-item>`:null}homepageTemplate(){return this.wallet?.homepage?g`
      <wui-list-item
        variant="icon"
        icon="browser"
        iconVariant="square-blue"
        @click=${this.onHomePage.bind(this)}
        chevron
      >
        <wui-text variant="md-medium" color="primary">Website</wui-text>
      </wui-list-item>
    `:null}openStore(t){t.href&&this.wallet&&(X.sendEvent({type:"track",event:"GET_WALLET",properties:{name:this.wallet.name,walletRank:this.wallet.order,explorerId:this.wallet.id,type:t.type}}),L.openHref(t.href,"_blank"))}onChromeStore(){this.wallet?.chrome_store&&this.openStore({href:this.wallet.chrome_store,type:"chrome_store"})}onAppStore(){this.wallet?.app_store&&this.openStore({href:this.wallet.app_store,type:"app_store"})}onPlayStore(){this.wallet?.play_store&&this.openStore({href:this.wallet.play_store,type:"play_store"})}onHomePage(){this.wallet?.homepage&&this.openStore({href:this.wallet.homepage,type:"homepage"})}};hp=o4([M("w3m-downloads-view")],hp);var s4=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const a4="https://walletconnect.com/explorer";let pp=class extends he{render(){return g`
      <wui-flex flexDirection="column" .padding=${["0","3","3","3"]} gap="2">
        ${this.recommendedWalletsTemplate()}
        <w3m-list-wallet
          name="Explore all"
          showAllWallets
          walletIcon="allWallets"
          icon="externalLink"
          size="sm"
          @click=${()=>{L.openHref("https://walletconnect.com/explorer?type=wallet","_blank")}}
        ></w3m-list-wallet>
      </wui-flex>
    `}recommendedWalletsTemplate(){const{recommended:t,featured:n}=q.state,{customWallets:r}=R.state;return[...n,...r??[],...t].slice(0,4).map((i,s)=>g`
        <w3m-list-wallet
          displayIndex=${s}
          name=${i.name??"Unknown"}
          tagVariant="accent"
          size="sm"
          imageSrc=${ae(De.getWalletImage(i))}
          @click=${()=>{this.onWalletClick(i)}}
        ></w3m-list-wallet>
      `)}onWalletClick(t){X.sendEvent({type:"track",event:"GET_WALLET",properties:{name:t.name,walletRank:void 0,explorerId:t.id,type:"homepage"}}),L.openHref(t.homepage??a4,"_blank")}};pp=s4([M("w3m-get-wallet-view")],pp);const c4=pe`<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="64" height="64" fill="#F7931A"/>
  <g clip-path="url(#clip0_1045_17)">
    <path d="M63.0394 39.7409C58.7654 56.8839 41.4024 67.3169 24.2574 63.0419C7.11937 58.7679 -3.31363 41.4039 0.962367 24.2619C5.23437 7.11686 22.5974 -3.31714 39.7374 0.956863C56.8814 5.23086 67.3134 22.5969 63.0394 39.7409Z" fill="#F7931A"/>
    <path d="M46.1092 27.4409C46.7462 23.1829 43.5042 20.8939 39.0712 19.3669L40.5092 13.5989L36.9982 12.7239L35.5982 18.3399C34.6752 18.1099 33.7272 17.8929 32.7852 17.6779L34.1952 12.0249L30.6862 11.1499L29.2472 16.9159C28.4832 16.7419 27.7332 16.5699 27.0052 16.3889L27.0092 16.3709L22.1672 15.1619L21.2332 18.9119C21.2332 18.9119 23.8382 19.5089 23.7832 19.5459C25.2052 19.9009 25.4622 20.8419 25.4192 21.5879L23.7812 28.1589C23.8792 28.1839 24.0062 28.2199 24.1462 28.2759C24.0292 28.2469 23.9042 28.2149 23.7752 28.1839L21.4792 37.3889C21.3052 37.8209 20.8642 38.4689 19.8702 38.2229C19.9052 38.2739 17.3182 37.5859 17.3182 37.5859L15.5752 41.6049L20.1442 42.7439C20.9942 42.9569 21.8272 43.1799 22.6472 43.3899L21.1942 49.2239L24.7012 50.0989L26.1402 44.3269C27.0982 44.5869 28.0282 44.8269 28.9382 45.0529L27.5042 50.7979L31.0152 51.6729L32.4682 45.8499C38.4552 46.9829 42.9572 46.5259 44.8522 41.1109C46.3792 36.7509 44.7762 34.2359 41.6262 32.5959C43.9202 32.0669 45.6482 30.5579 46.1092 27.4409ZM38.0872 38.6899C37.0022 43.0499 29.6612 40.6929 27.2812 40.1019L29.2092 32.3729C31.5892 32.9669 39.2212 34.1429 38.0872 38.6899ZM39.1732 27.3779C38.1832 31.3439 32.0732 29.3289 30.0912 28.8349L31.8392 21.8249C33.8212 22.3189 40.2042 23.2409 39.1732 27.3779Z" fill="white"/>
  </g>
  <defs>
    <clipPath id="clip0_1045_17">
      <rect width="64" height="64" fill="white"/>
    </clipPath>
  </defs>
</svg>
`,l4=pe`<svg fill="none" viewBox="0 0 60 60">
  <rect width="60" height="60" fill="#1DC956" rx="30" />
  <circle cx="30" cy="30" r="3" fill="#fff" />
  <path
    fill="#2BEE6C"
    stroke="#fff"
    stroke-width="2"
    d="m45.32 17.9-.88-.42.88.42.02-.05c.1-.2.21-.44.26-.7l-.82-.15.82.16a2 2 0 0 0-.24-1.4c-.13-.23-.32-.42-.47-.57a8.42 8.42 0 0 1-.04-.04l-.04-.04a2.9 2.9 0 0 0-.56-.47l-.51.86.5-.86a2 2 0 0 0-1.4-.24c-.26.05-.5.16-.69.26l-.05.02-15.05 7.25-.1.05c-1.14.55-1.85.89-2.46 1.37a7 7 0 0 0-1.13 1.14c-.5.6-.83 1.32-1.38 2.45l-.05.11-7.25 15.05-.02.05c-.1.2-.21.43-.26.69a2 2 0 0 0 .24 1.4l.85-.5-.85.5c.13.23.32.42.47.57l.04.04.04.04c.15.15.34.34.56.47a2 2 0 0 0 1.41.24l-.2-.98.2.98c.25-.05.5-.17.69-.26l.05-.02-.42-.87.42.87 15.05-7.25.1-.05c1.14-.55 1.85-.89 2.46-1.38a7 7 0 0 0 1.13-1.13 12.87 12.87 0 0 0 1.43-2.56l7.25-15.05Z"
  />
  <path
    fill="#1DC956"
    d="M33.38 32.72 30.7 29.3 15.86 44.14l.2.2a1 1 0 0 0 1.14.2l15.1-7.27a3 3 0 0 0 1.08-4.55Z"
  />
  <path
    fill="#86F999"
    d="m26.62 27.28 2.67 3.43 14.85-14.85-.2-.2a1 1 0 0 0-1.14-.2l-15.1 7.27a3 3 0 0 0-1.08 4.55Z"
  />
  <circle cx="30" cy="30" r="3" fill="#fff" transform="rotate(45 30 30)" />
  <rect width="59" height="59" x=".5" y=".5" stroke="#062B2B" stroke-opacity=".1" rx="29.5" />
</svg> `,d4=pe`<svg viewBox="0 0 60 60" fill="none">
  <g clip-path="url(#clip0_7734_50402)">
    <path
      d="M0 24.9C0 15.6485 0 11.0228 1.97053 7.56812C3.3015 5.23468 5.23468 3.3015 7.56812 1.97053C11.0228 0 15.6485 0 24.9 0H35.1C44.3514 0 48.9772 0 52.4319 1.97053C54.7653 3.3015 56.6985 5.23468 58.0295 7.56812C60 11.0228 60 15.6485 60 24.9V35.1C60 44.3514 60 48.9772 58.0295 52.4319C56.6985 54.7653 54.7653 56.6985 52.4319 58.0295C48.9772 60 44.3514 60 35.1 60H24.9C15.6485 60 11.0228 60 7.56812 58.0295C5.23468 56.6985 3.3015 54.7653 1.97053 52.4319C0 48.9772 0 44.3514 0 35.1V24.9Z"
      fill="#EB8B47"
    />
    <path
      d="M0.5 24.9C0.5 20.2652 0.50047 16.8221 0.744315 14.105C0.987552 11.3946 1.46987 9.45504 2.40484 7.81585C3.69145 5.56019 5.56019 3.69145 7.81585 2.40484C9.45504 1.46987 11.3946 0.987552 14.105 0.744315C16.8221 0.50047 20.2652 0.5 24.9 0.5H35.1C39.7348 0.5 43.1779 0.50047 45.895 0.744315C48.6054 0.987552 50.545 1.46987 52.1841 2.40484C54.4398 3.69145 56.3086 5.56019 57.5952 7.81585C58.5301 9.45504 59.0124 11.3946 59.2557 14.105C59.4995 16.8221 59.5 20.2652 59.5 24.9V35.1C59.5 39.7348 59.4995 43.1779 59.2557 45.895C59.0124 48.6054 58.5301 50.545 57.5952 52.1841C56.3086 54.4398 54.4398 56.3086 52.1841 57.5952C50.545 58.5301 48.6054 59.0124 45.895 59.2557C43.1779 59.4995 39.7348 59.5 35.1 59.5H24.9C20.2652 59.5 16.8221 59.4995 14.105 59.2557C11.3946 59.0124 9.45504 58.5301 7.81585 57.5952C5.56019 56.3086 3.69145 54.4398 2.40484 52.1841C1.46987 50.545 0.987552 48.6054 0.744315 45.895C0.50047 43.1779 0.5 39.7348 0.5 35.1V24.9Z"
      stroke="#062B2B"
      stroke-opacity="0.1"
    />
    <path
      d="M19 52C24.5228 52 29 47.5228 29 42C29 36.4772 24.5228 32 19 32C13.4772 32 9 36.4772 9 42C9 47.5228 13.4772 52 19 52Z"
      fill="#FF974C"
      stroke="white"
      stroke-width="2"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M42.8437 8.3264C42.4507 7.70891 41.5493 7.70891 41.1564 8.32641L28.978 27.4638C28.5544 28.1295 29.0326 29.0007 29.8217 29.0007H54.1783C54.9674 29.0007 55.4456 28.1295 55.022 27.4638L42.8437 8.3264Z"
      fill="white"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M42.3348 11.6456C42.659 11.7608 42.9061 12.1492 43.4005 12.926L50.7332 24.4488C51.2952 25.332 51.5763 25.7737 51.5254 26.1382C51.4915 26.3808 51.3698 26.6026 51.1833 26.7614C50.9031 27 50.3796 27 49.3327 27H34.6673C33.6204 27 33.0969 27 32.8167 26.7614C32.6302 26.6026 32.5085 26.3808 32.4746 26.1382C32.4237 25.7737 32.7048 25.332 33.2669 24.4488L40.5995 12.926C41.0939 12.1492 41.341 11.7608 41.6652 11.6456C41.8818 11.5687 42.1182 11.5687 42.3348 11.6456ZM35.0001 26.999C38.8661 26.999 42.0001 23.865 42.0001 19.999C42.0001 23.865 45.1341 26.999 49.0001 26.999H35.0001Z"
      fill="#FF974C"
    />
    <path
      d="M10.1061 9.35712C9.9973 9.67775 9.99867 10.0388 9.99978 10.3323C9.99989 10.3611 10 10.3893 10 10.4167V25.5833C10 25.6107 9.99989 25.6389 9.99978 25.6677C9.99867 25.9612 9.9973 26.3222 10.1061 26.6429C10.306 27.2317 10.7683 27.694 11.3571 27.8939C11.6777 28.0027 12.0388 28.0013 12.3323 28.0002C12.3611 28.0001 12.3893 28 12.4167 28H19C24.5228 28 29 23.5228 29 18C29 12.4772 24.5228 8 19 8H12.4167C12.3893 8 12.3611 7.99989 12.3323 7.99978C12.0388 7.99867 11.6778 7.9973 11.3571 8.10614C10.7683 8.306 10.306 8.76834 10.1061 9.35712Z"
      fill="#FF974C"
      stroke="white"
      stroke-width="2"
    />
    <circle cx="19" cy="18" r="4" fill="#EB8B47" stroke="white" stroke-width="2" />
    <circle cx="19" cy="42" r="4" fill="#EB8B47" stroke="white" stroke-width="2" />
  </g>
  <defs>
    <clipPath id="clip0_7734_50402">
      <rect width="60" height="60" fill="white" />
    </clipPath>
  </defs>
</svg> `,u4=pe`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <path
      fill="#1DC956"
      d="M0 25.01c0-9.25 0-13.88 1.97-17.33a15 15 0 0 1 5.6-5.6C11.02.11 15.65.11 24.9.11h10.2c9.25 0 13.88 0 17.33 1.97a15 15 0 0 1 5.6 5.6C60 11.13 60 15.76 60 25v10.2c0 9.25 0 13.88-1.97 17.33a15 15 0 0 1-5.6 5.6c-3.45 1.97-8.08 1.97-17.33 1.97H24.9c-9.25 0-13.88 0-17.33-1.97a15 15 0 0 1-5.6-5.6C0 49.1 0 44.46 0 35.21v-10.2Z"
    />
    <path
      fill="#2BEE6C"
      d="M16.1 60c-3.82-.18-6.4-.64-8.53-1.86a15 15 0 0 1-5.6-5.6C.55 50.06.16 46.97.04 41.98L4.2 40.6a4 4 0 0 0 2.48-2.39l4.65-12.4a2 2 0 0 1 2.5-1.2l2.53.84a2 2 0 0 0 2.43-1l2.96-5.94a2 2 0 0 1 3.7.32l3.78 12.58a2 2 0 0 0 3.03 1.09l3.34-2.23a2 2 0 0 0 .65-.7l5.3-9.72a2 2 0 0 1 1.42-1.01l4.14-.69a2 2 0 0 1 1.6.44l3.9 3.24a2 2 0 0 0 2.7-.12l4.62-4.63c.08 2.2.08 4.8.08 7.93v10.2c0 9.25 0 13.88-1.97 17.33a15 15 0 0 1-5.6 5.6c-2.13 1.22-4.7 1.68-8.54 1.86H16.11Z"
    />
    <path
      fill="#fff"
      d="m.07 43.03-.05-2.1 3.85-1.28a3 3 0 0 0 1.86-1.79l4.66-12.4a3 3 0 0 1 3.75-1.8l2.53.84a1 1 0 0 0 1.21-.5l2.97-5.94a3 3 0 0 1 5.56.48l3.77 12.58a1 1 0 0 0 1.51.55l3.34-2.23a1 1 0 0 0 .33-.35l5.3-9.71a3 3 0 0 1 2.14-1.53l4.13-.69a3 3 0 0 1 2.41.66l3.9 3.24a1 1 0 0 0 1.34-.06l5.28-5.28c.05.85.08 1.75.1 2.73L56 22.41a3 3 0 0 1-4.04.19l-3.9-3.25a1 1 0 0 0-.8-.21l-4.13.69a1 1 0 0 0-.72.5l-5.3 9.72a3 3 0 0 1-.97 1.05l-3.34 2.23a3 3 0 0 1-4.53-1.63l-3.78-12.58a1 1 0 0 0-1.85-.16l-2.97 5.94a3 3 0 0 1-3.63 1.5l-2.53-.84a1 1 0 0 0-1.25.6l-4.65 12.4a5 5 0 0 1-3.1 3L.07 43.02Z"
    />
    <path
      fill="#fff"
      fill-rule="evenodd"
      d="M49.5 19a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0Z"
      clip-rule="evenodd"
    />
    <path fill="#fff" d="M45 .28v59.66l-2 .1V.19c.7.02 1.37.05 2 .1Z" />
    <path fill="#2BEE6C" d="M47.5 19a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z" />
    <path
      stroke="#fff"
      stroke-opacity=".1"
      d="M.5 25.01c0-4.63 0-8.08.24-10.8.25-2.7.73-4.64 1.66-6.28a14.5 14.5 0 0 1 5.42-5.41C9.46 1.58 11.39 1.1 14.1.85A133 133 0 0 1 24.9.61h10.2c4.63 0 8.08 0 10.8.24 2.7.25 4.65.73 6.28 1.67a14.5 14.5 0 0 1 5.42 5.4c.93 1.65 1.41 3.58 1.66 6.3.24 2.71.24 6.16.24 10.79v10.2c0 4.64 0 8.08-.24 10.8-.25 2.7-.73 4.65-1.66 6.28a14.5 14.5 0 0 1-5.42 5.42c-1.63.93-3.57 1.41-6.28 1.66-2.72.24-6.17.24-10.8.24H24.9c-4.63 0-8.08 0-10.8-.24-2.7-.25-4.64-.73-6.28-1.66a14.5 14.5 0 0 1-5.42-5.42C1.47 50.66 1 48.72.74 46.01A133 133 0 0 1 .5 35.2v-10.2Z"
    />
  </g>
  <defs>
    <clipPath id="a"><path fill="#fff" d="M0 0h60v60H0z" /></clipPath>
  </defs>
</svg>`,h4=pe`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <rect width="60" height="60" fill="#C653C6" rx="30" />
    <path
      fill="#E87DE8"
      d="M57.98.01v19.5a4.09 4.09 0 0 0-2.63 2.29L50.7 34.2a2 2 0 0 1-2.5 1.2l-2.53-.84a2 2 0 0 0-2.42 1l-2.97 5.94a2 2 0 0 1-3.7-.32L32.8 28.6a2 2 0 0 0-3.02-1.09l-3.35 2.23a2 2 0 0 0-.64.7l-5.3 9.72a2 2 0 0 1-1.43 1.01l-4.13.69a2 2 0 0 1-1.61-.44l-3.9-3.24a2 2 0 0 0-2.69.12L2.1 42.93.02 43V.01h57.96Z"
    />
    <path
      fill="#fff"
      d="m61.95 16.94.05 2.1-3.85 1.28a3 3 0 0 0-1.86 1.79l-4.65 12.4a3 3 0 0 1-3.76 1.8l-2.53-.84a1 1 0 0 0-1.2.5l-2.98 5.94a3 3 0 0 1-5.55-.48l-3.78-12.58a1 1 0 0 0-1.5-.55l-3.35 2.23a1 1 0 0 0-.32.35l-5.3 9.72a3 3 0 0 1-2.14 1.52l-4.14.69a3 3 0 0 1-2.41-.66l-3.9-3.24a1 1 0 0 0-1.34.06l-5.28 5.28c-.05-.84-.08-1.75-.1-2.73l3.97-3.96a3 3 0 0 1 4.04-.19l3.89 3.25a1 1 0 0 0 .8.21l4.14-.68a1 1 0 0 0 .71-.51l5.3-9.71a3 3 0 0 1 .97-1.06l3.34-2.23a3 3 0 0 1 4.54 1.63l3.77 12.58a1 1 0 0 0 1.86.16l2.96-5.93a3 3 0 0 1 3.64-1.5l2.52.83a1 1 0 0 0 1.25-.6l4.66-12.4a5 5 0 0 1 3.1-2.99l4.43-1.48Z"
    />
    <path
      fill="#fff"
      fill-rule="evenodd"
      d="M35.5 27a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0Z"
      clip-rule="evenodd"
    />
    <path fill="#fff" d="M31 0v60h-2V0h2Z" />
    <path fill="#E87DE8" d="M33.5 27a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z" />
  </g>
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="29.5" />
  <defs>
    <clipPath id="a"><rect width="60" height="60" fill="#fff" rx="30" /></clipPath>
  </defs>
</svg> `,p4=pe`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <rect width="60" height="60" fill="#987DE8" rx="30" />
    <path
      fill="#fff"
      fill-rule="evenodd"
      d="m15.48 28.37 11.97-19.3a3 3 0 0 1 5.1 0l11.97 19.3a6 6 0 0 1 .9 3.14v.03a6 6 0 0 1-1.16 3.56L33.23 50.2a4 4 0 0 1-6.46 0L15.73 35.1a6 6 0 0 1-1.15-3.54v-.03a6 6 0 0 1 .9-3.16Z"
      clip-rule="evenodd"
    />
    <path
      fill="#643CDD"
      d="M30.84 10.11a1 1 0 0 0-.84-.46V24.5l12.6 5.53a2 2 0 0 0-.28-1.4L30.84 10.11Z"
    />
    <path
      fill="#BDADEB"
      d="M30 9.65a1 1 0 0 0-.85.46L17.66 28.64a2 2 0 0 0-.26 1.39L30 24.5V9.65Z"
    />
    <path
      fill="#643CDD"
      d="M30 50.54a1 1 0 0 0 .8-.4l11.24-15.38c.3-.44-.2-1-.66-.73l-9.89 5.68a3 3 0 0 1-1.5.4v10.43Z"
    />
    <path
      fill="#BDADEB"
      d="m17.97 34.76 11.22 15.37c.2.28.5.41.8.41V40.11a3 3 0 0 1-1.49-.4l-9.88-5.68c-.47-.27-.97.3-.65.73Z"
    />
    <path
      fill="#401AB3"
      d="M42.6 30.03 30 24.5v13.14a3 3 0 0 0 1.5-.4l10.14-5.83a2 2 0 0 0 .95-1.38Z"
    />
    <path
      fill="#7C5AE2"
      d="M30 37.64V24.46l-12.6 5.57a2 2 0 0 0 .97 1.39l10.13 5.82a3 3 0 0 0 1.5.4Z"
    />
  </g>
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="29.5" />
  <defs>
    <clipPath id="a"><rect width="60" height="60" fill="#fff" rx="30" /></clipPath>
  </defs>
</svg> `,f4=pe`<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="64" height="64" rx="30" fill="#1DC956"/>
  <rect x="0.5" y="0.5" width="63" height="63" rx="29.5" stroke="#141414" stroke-opacity="0.1"/>
  <path d="M32.4053 19.8031C35.3901 19.8031 38.0431 20.8349 40.1619 22.8247L45.9656 17.0211C42.4465 13.7416 37.8773 11.7333 32.4053 11.7333C24.4829 11.7333 17.6475 16.2841 14.3127 22.9168L21.056 28.1493C22.6589 23.359 27.136 19.8031 32.4053 19.8031Z" fill="#1DC956" stroke="white" stroke-width="2" stroke-linejoin="round"/>
  <path d="M32.4053 52.2667C37.8773 52.2667 42.465 50.4611 45.8182 47.3658L39.2407 42.2623C37.4351 43.4783 35.1321 44.2153 32.4053 44.2153C27.136 44.2153 22.6589 40.6594 21.056 35.8691L14.3127 41.1016C17.6475 47.7159 24.4829 52.2667 32.4053 52.2667Z" fill="#2BEE6C"/>
  <path d="M21.056 35.8507L19.5636 36.993L14.3127 41.0832M39.2407 42.2623L45.8182 47.3658C42.465 50.4611 37.8773 52.2667 32.4053 52.2667C24.4829 52.2667 17.6475 47.7159 14.3127 41.1016L21.056 35.8691C22.6589 40.6594 27.136 44.2153 32.4053 44.2153C35.1321 44.2153 37.4351 43.4783 39.2407 42.2623Z" stroke="white" stroke-width="2" stroke-linejoin="round"/>
  <path d="M51.8613 32.4606C51.8613 31.0235 51.7323 29.6417 51.4928 28.3151H32.4053V36.1638H43.3124C42.8334 38.688 41.3963 40.8252 39.2407 42.2623L45.8181 47.3658C49.6503 43.8283 51.8613 38.6327 51.8613 32.4606Z" fill="#1FAD7E" stroke="white" stroke-width="2" stroke-linejoin="round"/>
  <path d="M21.056 35.8507C20.6507 34.6347 20.4111 33.345 20.4111 32C20.4111 30.655 20.6507 29.3653 21.056 28.1493L14.3127 22.9169C12.9309 25.6437 12.1387 28.7205 12.1387 32C12.1387 35.2795 12.9309 38.3564 14.3127 41.0831L19.5636 36.993L21.056 35.8507Z" fill="#86F999"/>
  <path d="M21.056 35.8691L14.3127 41.1016M21.056 35.8507C20.6507 34.6347 20.4111 33.345 20.4111 32C20.4111 30.655 20.6507 29.3653 21.056 28.1493L14.3127 22.9169C12.9309 25.6437 12.1387 28.7205 12.1387 32C12.1387 35.2795 12.9309 38.3564 14.3127 41.0831L19.5636 36.993L21.056 35.8507Z" stroke="white" stroke-width="2" stroke-linejoin="round"/>
</svg>
`,m4=pe`<svg fill="none" viewBox="0 0 60 60">
  <rect width="60" height="60" fill="#1DC956" rx="3" />
  <path
    fill="#1FAD7E"
    stroke="#fff"
    stroke-width="2"
    d="m30.49 29.13-.49-.27-.49.27-12.77 7.1-.05.02c-.86.48-1.58.88-2.1 1.24-.54.37-1.04.81-1.28 1.45a3 3 0 0 0 0 2.12c.24.63.74 1.08 1.27 1.45.53.36 1.25.76 2.11 1.24l.05.03 6.33 3.51.17.1c2.33 1.3 3.72 2.06 5.22 2.32a9 9 0 0 0 3.08 0c1.5-.26 2.9-1.03 5.22-2.32l.18-.1 6.32-3.51.05-.03a26.9 26.9 0 0 0 2.1-1.24 3.21 3.21 0 0 0 1.28-1.45l-.94-.35.94.35a3 3 0 0 0 0-2.12l-.94.35.94-.35a3.21 3.21 0 0 0-1.27-1.45c-.53-.36-1.25-.76-2.11-1.24l-.05-.03-12.77-7.1Z"
  />
  <path
    fill="#2BEE6C"
    stroke="#fff"
    stroke-width="2"
    d="m30.49 19.13-.49-.27-.49.27-12.77 7.1-.05.02c-.86.48-1.58.88-2.1 1.24-.54.37-1.04.81-1.28 1.45a3 3 0 0 0 0 2.12c.24.63.74 1.08 1.27 1.45.53.36 1.25.76 2.11 1.24l.05.03 6.33 3.51.17.1c2.33 1.3 3.72 2.06 5.22 2.32a9 9 0 0 0 3.08 0c1.5-.26 2.9-1.03 5.22-2.32l.18-.1 6.32-3.51.05-.03a26.9 26.9 0 0 0 2.1-1.24 3.21 3.21 0 0 0 1.28-1.45l-.94-.35.94.35a3 3 0 0 0 0-2.12l-.94.35.94-.35a3.21 3.21 0 0 0-1.27-1.45c-.53-.36-1.25-.76-2.11-1.24l-.05-.03-12.77-7.1Z"
  />
  <path
    fill="#86F999"
    stroke="#fff"
    stroke-width="2"
    d="m46.69 21.06-.94-.35.94.35a3 3 0 0 0 0-2.12l-.94.35.94-.35a3.21 3.21 0 0 0-1.27-1.45c-.53-.36-1.25-.76-2.11-1.24l-.05-.03-6.32-3.51-.18-.1c-2.33-1.3-3.72-2.06-5.22-2.33a9 9 0 0 0-3.08 0c-1.5.27-2.9 1.04-5.22 2.33l-.17.1-6.33 3.51-.05.03c-.86.48-1.58.88-2.1 1.24-.54.37-1.04.81-1.28 1.45a3 3 0 0 0 0 2.12c.24.63.74 1.08 1.27 1.45.53.36 1.25.76 2.11 1.24l.05.03 6.33 3.51.17.1c2.33 1.3 3.72 2.06 5.22 2.32a9 9 0 0 0 3.08 0c1.5-.26 2.9-1.03 5.22-2.32l.18-.1 6.32-3.51.05-.03a26.9 26.9 0 0 0 2.1-1.24 3.21 3.21 0 0 0 1.28-1.45Z"
  />
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="2.5" />
</svg>`,g4=pe`<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g clip-path="url(#clip0_241_31636)">
    <path d="M0 26.5595C0 16.6913 0 11.7572 2.1019 8.07217C3.5216 5.58318 5.58366 3.52111 8.07266 2.10141C11.7577 -0.000488281 16.6918 -0.000488281 26.56 -0.000488281H37.44C47.3082 -0.000488281 52.2423 -0.000488281 55.9273 2.10141C58.4163 3.52111 60.4784 5.58318 61.8981 8.07217C64 11.7572 64 16.6913 64 26.5595V37.4395C64 47.3077 64 52.2418 61.8981 55.9269C60.4784 58.4159 58.4163 60.4779 55.9273 61.8976C52.2423 63.9995 47.3082 63.9995 37.44 63.9995H26.56C16.6918 63.9995 11.7577 63.9995 8.07266 61.8976C5.58366 60.4779 3.5216 58.4159 2.1019 55.9269C0 52.2418 0 47.3077 0 37.4395V26.5595Z" fill="#794CFF"/>
    <path d="M0.5 26.5595C0.5 21.6163 0.50047 17.942 0.760736 15.0418C1.02039 12.1485 1.53555 10.0742 2.53621 8.3199C3.91155 5.90869 5.90917 3.91106 8.32039 2.53572C10.0747 1.53506 12.1489 1.01991 15.0423 0.760247C17.9425 0.499981 21.6168 0.499512 26.56 0.499512H37.44C42.3832 0.499512 46.0575 0.499981 48.9577 0.760247C51.8511 1.01991 53.9253 1.53506 55.6796 2.53572C58.0908 3.91106 60.0885 5.90869 61.4638 8.3199C62.4645 10.0742 62.9796 12.1485 63.2393 15.0418C63.4995 17.942 63.5 21.6163 63.5 26.5595V37.4395C63.5 42.3827 63.4995 46.057 63.2393 48.9572C62.9796 51.8506 62.4645 53.9248 61.4638 55.6791C60.0885 58.0903 58.0908 60.088 55.6796 61.4633C53.9253 62.464 51.8511 62.9791 48.9577 63.2388C46.0575 63.499 42.3832 63.4995 37.44 63.4995H26.56C21.6168 63.4995 17.9425 63.499 15.0423 63.2388C12.1489 62.9791 10.0747 62.464 8.32039 61.4633C5.90917 60.088 3.91155 58.0903 2.53621 55.6791C1.53555 53.9248 1.02039 51.8506 0.760736 48.9572C0.50047 46.057 0.5 42.3827 0.5 37.4395V26.5595Z" stroke="#141414" stroke-opacity="0.1"/>
    <path d="M40 39.4595C44.7824 36.693 48 31.5222 48 25.6C48 16.7634 40.8366 9.59998 32 9.59998C23.1634 9.59998 16 16.7634 16 25.6C16 31.5222 19.2176 36.693 24 39.4595V45.8144H40V39.4595Z" fill="#906EF7"/>
    <path d="M24 49.9689C24 51.8192 24 52.7444 24.3941 53.4353C24.6603 53.902 25.0469 54.2886 25.5136 54.5548C26.2046 54.9489 27.1297 54.9489 28.98 54.9489H35.02C36.8703 54.9489 37.7954 54.9489 38.4864 54.5548C38.9531 54.2886 39.3397 53.902 39.6059 53.4353C40 52.7444 40 51.8192 40 49.9689V45.8144H24V49.9689Z" fill="#906EF7"/>
    <path d="M24 45.8144V39.4595C19.2176 36.693 16 31.5222 16 25.6C16 16.7634 23.1634 9.59998 32 9.59998C40.8366 9.59998 48 16.7634 48 25.6C48 31.5222 44.7824 36.693 40 39.4595V45.8144M24 45.8144H40M24 45.8144V49.9689C24 51.8192 24 52.7444 24.3941 53.4353C24.6603 53.902 25.0469 54.2886 25.5136 54.5548C26.2046 54.9489 27.1297 54.9489 28.98 54.9489H35.02C36.8703 54.9489 37.7954 54.9489 38.4864 54.5548C38.9531 54.2886 39.3397 53.902 39.6059 53.4353C40 52.7444 40 51.8192 40 49.9689V45.8144" stroke="white" stroke-width="2" stroke-linejoin="round"/>
    <path d="M24 49.9689C24 51.8192 24 52.7444 24.3941 53.4353C24.6603 53.902 25.0469 54.2886 25.5136 54.5548C26.2046 54.9489 27.1297 54.9489 28.98 54.9489H35.02C36.8703 54.9489 37.7954 54.9489 38.4864 54.5548C38.9531 54.2886 39.3397 53.902 39.6059 53.4353C40 52.7444 40 51.8192 40 49.9689V45.8144H24V49.9689Z" fill="#643CDD" stroke="white" stroke-width="2" stroke-linejoin="round"/>
    <path d="M29.6735 26.9101V29.1109H34.0753V26.9101C34.0753 25.6945 35.0607 24.7092 36.2762 24.7092C37.4917 24.7092 38.4771 25.6945 38.4771 26.9101C38.4771 28.1256 37.4917 29.1109 36.2762 29.1109H34.0753H29.6735H27.4726C26.2571 29.1109 25.2717 28.1256 25.2717 26.9101C25.2717 25.6945 26.2571 24.7092 27.4726 24.7092C28.6881 24.7092 29.6735 25.6945 29.6735 26.9101Z" fill="#906EF7"/>
    <path d="M29.6735 45.3183V26.9101C29.6735 25.6945 28.6881 24.7092 27.4726 24.7092V24.7092C26.2571 24.7092 25.2717 25.6945 25.2717 26.9101V26.9101C25.2717 28.1256 26.2571 29.1109 27.4726 29.1109H36.2762C37.4917 29.1109 38.4771 28.1256 38.4771 26.9101V26.9101C38.4771 25.6945 37.4917 24.7092 36.2762 24.7092V24.7092C35.0607 24.7092 34.0753 25.6945 34.0753 26.9101V45.3183" stroke="white" stroke-width="2" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_241_31636">
      <rect width="64" height="64" fill="white"/>
    </clipPath>
  </defs>
</svg>
`,w4=pe`<svg fill="none" viewBox="0 0 60 60">
  <rect width="60" height="60" fill="#C653C6" rx="3" />
  <path
    fill="#fff"
    d="M20.03 15.22C20 15.6 20 16.07 20 17v2.8c0 1.14 0 1.7-.2 2.12-.15.31-.3.5-.58.71-.37.28-1.06.42-2.43.7-.59.12-1.11.29-1.6.51a9 9 0 0 0-4.35 4.36C10 30 10 32.34 10 37c0 4.66 0 7 .84 8.8a9 9 0 0 0 4.36 4.36C17 51 19.34 51 24 51h12c4.66 0 7 0 8.8-.84a9 9 0 0 0 4.36-4.36C50 44 50 41.66 50 37c0-4.66 0-7-.84-8.8a9 9 0 0 0-4.36-4.36c-.48-.22-1-.39-1.6-.5-1.36-.29-2.05-.43-2.42-.7-.27-.22-.43-.4-.58-.72-.2-.42-.2-.98-.2-2.11V17c0-.93 0-1.4-.03-1.78a9 9 0 0 0-8.19-8.19C31.4 7 30.93 7 30 7s-1.4 0-1.78.03a9 9 0 0 0-8.19 8.19Z"
  />
  <path
    fill="#E87DE8"
    d="M22 17c0-.93 0-1.4.04-1.78a7 7 0 0 1 6.18-6.18C28.6 9 29.07 9 30 9s1.4 0 1.78.04a7 7 0 0 1 6.18 6.18c.04.39.04.85.04 1.78v4.5a1.5 1.5 0 0 1-3 0V17c0-.93 0-1.4-.08-1.78a4 4 0 0 0-3.14-3.14C31.39 12 30.93 12 30 12s-1.4 0-1.78.08a4 4 0 0 0-3.14 3.14c-.08.39-.08.85-.08 1.78v4.5a1.5 1.5 0 0 1-3 0V17Z"
  />
  <path
    fill="#E87DE8"
    fill-rule="evenodd"
    d="M12 36.62c0-4.32 0-6.48.92-8.09a7 7 0 0 1 2.61-2.61C17.14 25 19.3 25 23.62 25h6.86c.46 0 .7 0 .9.02 2.73.22 4.37 2.43 4.62 4.98.27-2.7 2.11-5 5.02-5A6.98 6.98 0 0 1 48 31.98v5.4c0 4.32 0 6.48-.92 8.09a7 7 0 0 1-2.61 2.61c-1.61.92-3.77.92-8.09.92h-5.86c-.46 0-.7 0-.9-.02-2.73-.22-4.37-2.43-4.62-4.98-.26 2.58-1.94 4.82-4.71 4.99l-.7.01c-.55 0-.82 0-1.05-.02a7 7 0 0 1-6.52-6.52c-.02-.23-.02-.5-.02-1.05v-4.79Zm21.24-.27a4 4 0 1 0-6.48 0 31.28 31.28 0 0 1 1.57 2.23c.17.4.17.81.17 1.24V42.5a1.5 1.5 0 0 0 3 0V39.82c0-.43 0-.85.17-1.24.09-.2.58-.87 1.57-2.23Z"
    clip-rule="evenodd"
  />
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="2.5" />
</svg>`,b4=pe`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <path
      fill="#EB8B47"
      d="M0 24.9c0-9.25 0-13.88 1.97-17.33a15 15 0 0 1 5.6-5.6C11.02 0 15.65 0 24.9 0h10.2c9.25 0 13.88 0 17.33 1.97a15 15 0 0 1 5.6 5.6C60 11.02 60 15.65 60 24.9v10.2c0 9.25 0 13.88-1.97 17.33a15 15 0 0 1-5.6 5.6C48.98 60 44.35 60 35.1 60H24.9c-9.25 0-13.88 0-17.33-1.97a15 15 0 0 1-5.6-5.6C0 48.98 0 44.35 0 35.1V24.9Z"
    />
    <path
      stroke="#062B2B"
      stroke-opacity=".1"
      d="M.5 24.9c0-4.64 0-8.08.24-10.8.25-2.7.73-4.65 1.66-6.28A14.5 14.5 0 0 1 7.82 2.4C9.46 1.47 11.39 1 14.1.74A133 133 0 0 1 24.9.5h10.2c4.63 0 8.08 0 10.8.24 2.7.25 4.65.73 6.28 1.66a14.5 14.5 0 0 1 5.42 5.42c.93 1.63 1.41 3.57 1.66 6.28.24 2.72.24 6.16.24 10.8v10.2c0 4.63 0 8.08-.24 10.8-.25 2.7-.73 4.64-1.66 6.28a14.5 14.5 0 0 1-5.42 5.41c-1.63.94-3.57 1.42-6.28 1.67-2.72.24-6.17.24-10.8.24H24.9c-4.63 0-8.08 0-10.8-.24-2.7-.25-4.64-.73-6.28-1.67a14.5 14.5 0 0 1-5.42-5.4C1.47 50.53 1 48.6.74 45.88A133 133 0 0 1 .5 35.1V24.9Z"
    />
    <path
      fill="#FF974C"
      stroke="#fff"
      stroke-width="2"
      d="M39.2 29.2a13 13 0 1 0-18.4 0l1.3 1.28a12.82 12.82 0 0 1 2.1 2.39 6 6 0 0 1 .6 1.47c.2.76.2 1.56.2 3.17v11.24c0 1.08 0 1.61.13 2.12a4 4 0 0 0 .41.98c.26.45.64.83 1.4 1.6l.3.29c.65.65.98.98 1.36 1.09.26.07.54.07.8 0 .38-.11.7-.44 1.36-1.1l3.48-3.47c.65-.65.98-.98 1.09-1.36a1.5 1.5 0 0 0 0-.8c-.1-.38-.44-.7-1.1-1.36l-.47-.48c-.65-.65-.98-.98-1.09-1.36a1.5 1.5 0 0 1 0-.8c.1-.38.44-.7 1.1-1.36l.47-.48c.65-.65.98-.98 1.09-1.36a1.5 1.5 0 0 0 0-.8c-.1-.38-.44-.7-1.1-1.36l-.48-.5c-.65-.64-.98-.97-1.08-1.35a1.5 1.5 0 0 1 0-.79c.1-.38.42-.7 1.06-1.36l5.46-5.55Z"
    />
    <circle cx="30" cy="17" r="4" fill="#EB8B47" stroke="#fff" stroke-width="2" />
  </g>
  <defs>
    <clipPath id="a"><path fill="#fff" d="M0 0h60v60H0z" /></clipPath>
  </defs>
</svg> `,y4=pe`<svg width="40" height="42" viewBox="0 0 40 42" fill="none">
<path opacity="0.7" d="M19.9526 41.9076L7.3877 34.655V26.1226L19.9526 33.3751V41.9076Z" fill="url(#paint0_linear_2113_32117)"/>
<path opacity="0.7" d="M19.9521 41.9076L32.5171 34.655V26.1226L19.9521 33.3751V41.9076Z" fill="url(#paint1_linear_2113_32117)"/>
<path opacity="0.7" d="M39.9095 7.34521V21.8562L32.5166 26.1225V11.6114L39.9095 7.34521Z" fill="url(#paint2_linear_2113_32117)"/>
<path d="M39.9099 7.34536L27.345 0.0927734L19.9521 4.359L32.5171 11.6116L39.9099 7.34536Z" fill="url(#paint3_linear_2113_32117)"/>
<path d="M0 7.34536L12.5649 0.0927734L19.9519 4.359L7.387 11.6116L0 7.34536Z" fill="#F969D3"/>
<path opacity="0.7" d="M0 7.34521V21.8562L7.387 26.1225V11.6114L0 7.34521Z" fill="url(#paint4_linear_2113_32117)"/>
<defs>
<linearGradient id="paint0_linear_2113_32117" x1="18.6099" y1="41.8335" x2="7.73529" y2="8.31842" gradientUnits="userSpaceOnUse">
<stop stop-color="#E98ADA"/>
<stop offset="1" stop-color="#7E4DBD"/>
</linearGradient>
<linearGradient id="paint1_linear_2113_32117" x1="26.2346" y1="26.1226" x2="26.2346" y2="41.9076" gradientUnits="userSpaceOnUse">
<stop stop-color="#719DED"/>
<stop offset="1" stop-color="#2545BE"/>
</linearGradient>
<linearGradient id="paint2_linear_2113_32117" x1="36.213" y1="7.34521" x2="36.213" y2="26.1225" gradientUnits="userSpaceOnUse">
<stop stop-color="#93EBFF"/>
<stop offset="1" stop-color="#197DDB"/>
</linearGradient>
<linearGradient id="paint3_linear_2113_32117" x1="29.931" y1="0.0927734" x2="38.2156" y2="14.8448" gradientUnits="userSpaceOnUse">
<stop stop-color="#F969D3"/>
<stop offset="1" stop-color="#4F51C0"/>
</linearGradient>
<linearGradient id="paint4_linear_2113_32117" x1="18.1251" y1="44.2539" x2="-7.06792" y2="15.2763" gradientUnits="userSpaceOnUse">
<stop stop-color="#E98ADA"/>
<stop offset="1" stop-color="#7E4DBD"/>
</linearGradient>
</defs>
</svg>`,C4=pe`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <rect width="60" height="60" fill="#00ACE6" rx="30" />
    <circle cx="64" cy="39" r="50" fill="#1AC6FF" stroke="#fff" stroke-width="2" />
    <circle cx="78" cy="30" r="50" fill="#4DD2FF" stroke="#fff" stroke-width="2" />
    <circle cx="72" cy="15" r="35" fill="#80DFFF" stroke="#fff" stroke-width="2" />
    <circle cx="34" cy="-17" r="45" stroke="#fff" stroke-width="2" />
    <circle cx="34" cy="-5" r="50" stroke="#fff" stroke-width="2" />
    <circle cx="30" cy="45" r="4" fill="#4DD2FF" stroke="#fff" stroke-width="2" />
    <circle cx="39.5" cy="27.5" r="4" fill="#80DFFF" stroke="#fff" stroke-width="2" />
    <circle cx="16" cy="24" r="4" fill="#19C6FF" stroke="#fff" stroke-width="2" />
  </g>
  <rect width="59" height="59" x=".5" y=".5" stroke="#062B2B" stroke-opacity=".1" rx="29.5" />
  <defs>
    <clipPath id="a"><rect width="60" height="60" fill="#fff" rx="30" /></clipPath>
  </defs>
</svg>`,v4=pe`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <rect width="60" height="60" fill="#C653C6" rx="3" />
    <path
      fill="#E87DE8"
      stroke="#fff"
      stroke-width="2"
      d="M52.1 47.34c0-4.24-1.44-9.55-5.9-12.4a2.86 2.86 0 0 0-1.6-3.89v-.82c0-1.19-.52-2.26-1.35-3a4.74 4.74 0 0 0-2.4-6.26v-5.5a11.31 11.31 0 1 0-22.63 0v2.15a3.34 3.34 0 0 0-1.18 5.05 4.74 4.74 0 0 0-.68 6.44A5.22 5.22 0 0 0 14 35.92c-3.06 4.13-6.1 8.3-6.1 15.64 0 2.67.37 4.86.74 6.39a20.3 20.3 0 0 0 .73 2.39l.02.04v.01l.92-.39-.92.4.26.6h38.26l.3-.49-.87-.51.86.5.02-.01.03-.07a16.32 16.32 0 0 0 .57-1.05c.36-.72.85-1.74 1.33-2.96a25.51 25.51 0 0 0 1.94-9.07Z"
    />
    <path
      fill="#fff"
      fill-rule="evenodd"
      d="M26.5 29.5c-3-.5-5.5-3-5.5-7v-7c0-.47 0-.7.03-.9a3 3 0 0 1 2.58-2.57c.2-.03.42-.03.89-.03 2 0 2.5-2.5 2.5-2.5s0 2.5 2.5 2.5c1.4 0 2.1 0 2.65.23a3 3 0 0 1 1.62 1.62c.23.55.23 1.25.23 2.65v6c0 4-3 7-6.5 7 1.35.23 4 0 6.5-2v9.53C34 38.5 31.5 40 28 40s-6-1.5-6-2.97L24 34l2.5 1.5v-6ZM26 47h4.5c2.5 0 3 4 3 5.5h-3l-1-1.5H26v-4Zm-6.25 5.5H24V57h-8c0-1 1-4.5 3.75-4.5Z"
      clip-rule="evenodd"
    />
  </g>
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="2.5" />
  <defs>
    <clipPath id="a"><rect width="60" height="60" fill="#fff" rx="3" /></clipPath>
  </defs>
</svg> `,E4=pe`<svg fill="none" viewBox="0 0 60 60">
  <rect width="60" height="60" fill="#794CFF" rx="3" />
  <path
    fill="#987DE8"
    stroke="#fff"
    stroke-width="2"
    d="M33 22.5v-1H16v5H8.5V36H13v-5h3v7.5h17V31h1v7.5h17v-17H34v5h-1v-4Z"
  />
  <path fill="#fff" d="M37.5 25h10v10h-10z" />
  <path fill="#4019B2" d="M42.5 25h5v10h-5z" />
  <path fill="#fff" d="M19.5 25h10v10h-10z" />
  <path fill="#4019B2" d="M24.5 25h5v10h-5z" />
  <path fill="#fff" d="M12 30.5h4V37h-4v-6.5Z" />
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="2.5" />
</svg>`,_4=pe`<svg width="60" height="60" viewBox="0 0 60 60" fill="none">
<g clip-path="url(#clip0_13859_31161)">
  <path d="M0 24.8995C0 15.6481 0 11.0223 1.97053 7.56763C3.3015 5.2342 5.23468 3.30101 7.56812 1.97004C11.0228 -0.000488281 15.6485 -0.000488281 24.9 -0.000488281H35.1C44.3514 -0.000488281 48.9772 -0.000488281 52.4319 1.97004C54.7653 3.30101 56.6985 5.2342 58.0295 7.56763C60 11.0223 60 15.6481 60 24.8995V35.0995C60 44.351 60 48.9767 58.0295 52.4314C56.6985 54.7648 54.7653 56.698 52.4319 58.029C48.9772 59.9995 44.3514 59.9995 35.1 59.9995H24.9C15.6485 59.9995 11.0228 59.9995 7.56812 58.029C5.23468 56.698 3.3015 54.7648 1.97053 52.4314C0 48.9767 0 44.351 0 35.0995V24.8995Z" fill="#EB8B47"/>
  <path d="M0.5 24.8995C0.5 20.2647 0.50047 16.8216 0.744315 14.1045C0.987552 11.3941 1.46987 9.45455 2.40484 7.81536C3.69145 5.55971 5.56019 3.69096 7.81585 2.40435C9.45504 1.46938 11.3946 0.987064 14.105 0.743826C16.8221 0.499981 20.2652 0.499512 24.9 0.499512H35.1C39.7348 0.499512 43.1779 0.499981 45.895 0.743826C48.6054 0.987064 50.545 1.46938 52.1841 2.40435C54.4398 3.69096 56.3086 5.55971 57.5952 7.81536C58.5301 9.45455 59.0124 11.3941 59.2557 14.1045C59.4995 16.8216 59.5 20.2647 59.5 24.8995V35.0995C59.5 39.7343 59.4995 43.1774 59.2557 45.8945C59.0124 48.6049 58.5301 50.5445 57.5952 52.1837C56.3086 54.4393 54.4398 56.3081 52.1841 57.5947C50.545 58.5296 48.6054 59.012 45.895 59.2552C43.1779 59.499 39.7348 59.4995 35.1 59.4995H24.9C20.2652 59.4995 16.8221 59.499 14.105 59.2552C11.3946 59.012 9.45504 58.5296 7.81585 57.5947C5.56019 56.3081 3.69145 54.4393 2.40484 52.1837C1.46987 50.5445 0.987552 48.6049 0.744315 45.8945C0.50047 43.1774 0.5 39.7343 0.5 35.0995V24.8995Z" stroke="#141414" stroke-opacity="0.1"/>
  <path d="M13 26.0335C13 21.7838 13 19.659 14.0822 18.1694C14.4318 17.6883 14.8548 17.2653 15.3359 16.9157C16.8255 15.8335 18.9503 15.8335 23.2 15.8335H36.8C41.0497 15.8335 43.1745 15.8335 44.6641 16.9157C45.1452 17.2653 45.5682 17.6883 45.9178 18.1694C47 19.659 47 21.7838 47 26.0335V33.9668C47 38.2165 47 40.3414 45.9178 41.831C45.5682 42.312 45.1452 42.7351 44.6641 43.0846C43.1745 44.1668 41.0497 44.1668 36.8 44.1668H23.2C18.9503 44.1668 16.8255 44.1668 15.3359 43.0846C14.8548 42.7351 14.4318 42.312 14.0822 41.831C13 40.3414 13 38.2165 13 33.9668V26.0335Z" fill="#FF974C" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M39.5 36.667H36.6666" stroke="white" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M45.2 23.0645H14.8C14.0501 23.0645 13.6751 23.0645 13.4122 23.2554C13.3273 23.3171 13.2527 23.3918 13.191 23.4767C13 23.7395 13 24.1145 13 24.8645V27.2645C13 28.0144 13 28.3894 13.191 28.6522C13.2527 28.7371 13.3273 28.8118 13.4122 28.8735C13.6751 29.0645 14.0501 29.0645 14.8 29.0645H45.2C45.9499 29.0645 46.3249 29.0645 46.5878 28.8735C46.6727 28.8118 46.7473 28.7371 46.809 28.6522C47 28.3894 47 28.0144 47 27.2645V24.8645C47 24.1145 47 23.7395 46.809 23.4767C46.7473 23.3918 46.6727 23.3171 46.5878 23.2554C46.3249 23.0645 45.9499 23.0645 45.2 23.0645Z" fill="white" fill-opacity="0.4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
  <clipPath id="clip0_13859_31161">
    <rect width="60" height="60" fill="white"/>
  </clipPath>
</defs>
</svg>`,A4=pe`<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g clip-path="url(#clip0_241_31635)">
    <path d="M0 26.5595C0 16.6913 0 11.7572 2.1019 8.07217C3.5216 5.58317 5.58366 3.52111 8.07266 2.10141C11.7577 -0.000488281 16.6918 -0.000488281 26.56 -0.000488281H37.44C47.3082 -0.000488281 52.2423 -0.000488281 55.9273 2.10141C58.4163 3.52111 60.4784 5.58317 61.8981 8.07217C64 11.7572 64 16.6913 64 26.5595V37.4395C64 47.3077 64 52.2418 61.8981 55.9268C60.4784 58.4158 58.4163 60.4779 55.9273 61.8976C52.2423 63.9995 47.3082 63.9995 37.44 63.9995H26.56C16.6918 63.9995 11.7577 63.9995 8.07266 61.8976C5.58366 60.4779 3.5216 58.4158 2.1019 55.9268C0 52.2418 0 47.3077 0 37.4395V26.5595Z" fill="#EB8B47"/>
    <path d="M0.5 26.5595C0.5 21.6163 0.50047 17.942 0.760736 15.0418C1.02039 12.1485 1.53555 10.0742 2.53621 8.3199C3.91155 5.90869 5.90917 3.91106 8.32039 2.53572C10.0747 1.53506 12.1489 1.01991 15.0423 0.760247C17.9425 0.499981 21.6168 0.499512 26.56 0.499512H37.44C42.3832 0.499512 46.0575 0.499981 48.9577 0.760247C51.8511 1.01991 53.9253 1.53506 55.6796 2.53572C58.0908 3.91106 60.0885 5.90869 61.4638 8.3199C62.4645 10.0742 62.9796 12.1485 63.2393 15.0418C63.4995 17.942 63.5 21.6163 63.5 26.5595V37.4395C63.5 42.3827 63.4995 46.057 63.2393 48.9572C62.9796 51.8506 62.4645 53.9248 61.4638 55.6791C60.0885 58.0903 58.0908 60.088 55.6796 61.4633C53.9253 62.464 51.8511 62.9791 48.9577 63.2388C46.0575 63.499 42.3832 63.4995 37.44 63.4995H26.56C21.6168 63.4995 17.9425 63.499 15.0423 63.2388C12.1489 62.9791 10.0747 62.464 8.32039 61.4633C5.90917 60.088 3.91155 58.0903 2.53621 55.6791C1.53555 53.9248 1.02039 51.8506 0.760736 48.9572C0.50047 46.057 0.5 42.3827 0.5 37.4395V26.5595Z" stroke="#141414" stroke-opacity="0.1"/>
    <path d="M28.1042 49.2329L13.1024 51.2077L15.0772 36.2059L37.1015 14.1815C39.2441 12.039 40.3154 10.9677 41.5718 10.624C42.4205 10.3918 43.3159 10.3918 44.1645 10.624C45.421 10.9677 46.4922 12.039 48.6348 14.1815L50.1286 15.6753C52.2711 17.8179 53.3424 18.8891 53.6861 20.1456C53.9183 20.9942 53.9183 21.8896 53.6861 22.7383C53.3424 23.9947 52.2711 25.066 50.1286 27.2086L28.1042 49.2329Z" fill="#FF974C" stroke="#E4E7E7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M38.5962 20.5376L22.4199 36.7139" stroke="#E4E7E7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M43.7727 25.714L27.5964 41.8903" stroke="#E4E7E7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M22.3703 36.7635C19.3258 39.808 16.0198 36.6395 16.2616 35.0324" stroke="#E4E7E7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M27.5466 41.9399C24.5034 44.9831 28.155 48.7098 29.2738 48.0475" stroke="#E4E7E7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M27.5468 41.9398C23.428 46.0586 18.2516 40.8822 22.3704 36.7634" stroke="#E4E7E7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M15.8191 50.5214C15.4711 49.5823 14.728 48.8392 13.7889 48.4912" stroke="#E4E7E7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M49.2862 29.5805L34.7275 15.0219" stroke="#E4E7E7" stroke-width="2" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_241_31635">
      <rect width="64" height="64" fill="white"/>
    </clipPath>
  </defs>
</svg>
`,x4=pe`<svg
  viewBox="0 0 60 60"
  fill="none"
>
  <g clip-path="url(#1)">
    <rect width="60" height="60" rx="30" fill="#00ACE6" />
    <path
      d="M59 73C59 89.0163 46.0163 102 30 102C13.9837 102 1 89.0163 1 73C1 56.9837 12 44 30 44C48 44 59 56.9837 59 73Z"
      fill="#1AC6FF"
      stroke="white"
      stroke-width="2"
    />
    <path
      d="M18.6904 19.9015C19.6264 15.3286 23.3466 11.8445 27.9708 11.2096C29.3231 11.024 30.6751 11.0238 32.0289 11.2096C36.6532 11.8445 40.3733 15.3286 41.3094 19.9015C41.4868 20.7681 41.6309 21.6509 41.7492 22.5271C41.8811 23.5041 41.8811 24.4944 41.7492 25.4715C41.6309 26.3476 41.4868 27.2304 41.3094 28.097C40.3733 32.6699 36.6532 36.154 32.0289 36.7889C30.6772 36.9744 29.3216 36.9743 27.9708 36.7889C23.3466 36.154 19.6264 32.6699 18.6904 28.097C18.513 27.2304 18.3689 26.3476 18.2506 25.4715C18.1186 24.4944 18.1186 23.5041 18.2506 22.5271C18.3689 21.6509 18.513 20.7681 18.6904 19.9015Z"
      fill="#1AC6FF"
      stroke="white"
      stroke-width="2"
    />
    <circle cx="24.5" cy="23.5" r="1.5" fill="white" />
    <circle cx="35.5" cy="23.5" r="1.5" fill="white" />
    <path
      d="M31 20L28 28H32"
      stroke="white"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </g>
  <rect x="0.5" y="0.5" width="59" height="59" rx="29.5" stroke="white" stroke-opacity="0.1" />
  <defs>
    <clipPath id="1">
      <rect width="60" height="60" rx="30" fill="white" />
    </clipPath>
  </defs>
</svg> `,S4=pe`<svg fill="none" viewBox="0 0 80 80">
  <g clip-path="url(#a)">
    <path fill="url(#b)" d="M40 80a40 40 0 1 0 0-80 40 40 0 0 0 0 80Z" />
    <path
      stroke="#fff"
      stroke-opacity=".1"
      d="M79.5 40a39.5 39.5 0 1 1-79 0 39.5 39.5 0 0 1 79 0Z"
    />
    <path
      fill="#fff"
      d="m62.62 51.54-7.54 7.91a1.75 1.75 0 0 1-1.29.55H18.02a.9.9 0 0 1-.8-.52.84.84 0 0 1 .16-.92l7.55-7.92a1.75 1.75 0 0 1 1.28-.55h35.77a.87.87 0 0 1 .8.52.84.84 0 0 1-.16.93Zm-7.54-15.95a1.75 1.75 0 0 0-1.29-.54H18.02a.89.89 0 0 0-.8.51.84.84 0 0 0 .16.93l7.55 7.92a1.75 1.75 0 0 0 1.28.54h35.77a.89.89 0 0 0 .8-.51.84.84 0 0 0-.16-.93l-7.54-7.92ZM18.02 29.9h35.77a1.79 1.79 0 0 0 1.29-.54l7.54-7.92a.85.85 0 0 0 .16-.93.87.87 0 0 0-.8-.51H26.21a1.79 1.79 0 0 0-1.28.54l-7.55 7.92a.85.85 0 0 0-.16.93.89.89 0 0 0 .8.52Z"
    />
  </g>
  <defs>
    <linearGradient id="b" x1="6.75" x2="80.68" y1="81.91" y2="7.37" gradientUnits="userSpaceOnUse">
      <stop offset=".08" stop-color="#9945FF" />
      <stop offset=".3" stop-color="#8752F3" />
      <stop offset=".5" stop-color="#5497D5" />
      <stop offset=".6" stop-color="#43B4CA" />
      <stop offset=".72" stop-color="#28E0B9" />
      <stop offset=".97" stop-color="#19FB9B" />
    </linearGradient>
    <clipPath id="a"><path fill="#fff" d="M0 0h80v80H0z" /></clipPath>
  </defs>
</svg> `,T4=pe`<svg viewBox="0 0 60 60" fill="none">
  <g clip-path="url(#1)">
    <path
      d="M0 24.9C0 15.6485 0 11.0228 1.97053 7.56812C3.3015 5.23468 5.23468 3.3015 7.56812 1.97053C11.0228 0 15.6485 0 24.9 0H35.1C44.3514 0 48.9772 0 52.4319 1.97053C54.7653 3.3015 56.6985 5.23468 58.0295 7.56812C60 11.0228 60 15.6485 60 24.9V35.1C60 44.3514 60 48.9772 58.0295 52.4319C56.6985 54.7653 54.7653 56.6985 52.4319 58.0295C48.9772 60 44.3514 60 35.1 60H24.9C15.6485 60 11.0228 60 7.56812 58.0295C5.23468 56.6985 3.3015 54.7653 1.97053 52.4319C0 48.9772 0 44.3514 0 35.1V24.9Z"
      fill="#794CFF"
    />
    <path
      d="M0.5 24.9C0.5 20.2652 0.50047 16.8221 0.744315 14.105C0.987552 11.3946 1.46987 9.45504 2.40484 7.81585C3.69145 5.56019 5.56019 3.69145 7.81585 2.40484C9.45504 1.46987 11.3946 0.987552 14.105 0.744315C16.8221 0.50047 20.2652 0.5 24.9 0.5H35.1C39.7348 0.5 43.1779 0.50047 45.895 0.744315C48.6054 0.987552 50.545 1.46987 52.1841 2.40484C54.4398 3.69145 56.3086 5.56019 57.5952 7.81585C58.5301 9.45504 59.0124 11.3946 59.2557 14.105C59.4995 16.8221 59.5 20.2652 59.5 24.9V35.1C59.5 39.7348 59.4995 43.1779 59.2557 45.895C59.0124 48.6054 58.5301 50.545 57.5952 52.1841C56.3086 54.4398 54.4398 56.3086 52.1841 57.5952C50.545 58.5301 48.6054 59.0124 45.895 59.2557C43.1779 59.4995 39.7348 59.5 35.1 59.5H24.9C20.2652 59.5 16.8221 59.4995 14.105 59.2557C11.3946 59.0124 9.45504 58.5301 7.81585 57.5952C5.56019 56.3086 3.69145 54.4398 2.40484 52.1841C1.46987 50.545 0.987552 48.6054 0.744315 45.895C0.50047 43.1779 0.5 39.7348 0.5 35.1V24.9Z"
      stroke="#062B2B"
      stroke-opacity="0.1"
    />
    <path
      d="M35.1403 31.5016C35.1193 30.9637 35.388 30.4558 35.8446 30.1707C36.1207 29.9982 36.4761 29.8473 36.7921 29.7685C37.3143 29.6382 37.8664 29.7977 38.2386 30.1864C38.8507 30.8257 39.3004 31.6836 39.8033 32.408C40.2796 33.0942 41.4695 33.2512 41.9687 32.5047C42.4839 31.7341 42.9405 30.8229 43.572 30.1399C43.9375 29.7447 44.4866 29.5756 45.0111 29.6967C45.3283 29.7701 45.6863 29.9147 45.9655 30.0823C46.4269 30.3595 46.7045 30.8626 46.6928 31.4008C46.6731 32.3083 46.3764 33.2571 46.2158 34.1473C46.061 35.0048 46.9045 35.8337 47.7592 35.664C48.6464 35.4878 49.5899 35.1747 50.497 35.1391C51.0348 35.1181 51.5427 35.3868 51.8279 35.8433C52.0004 36.1195 52.1513 36.4749 52.2301 36.7908C52.3604 37.3131 52.2009 37.8651 51.8121 38.2374C51.1729 38.8495 50.3151 39.2991 49.5908 39.8019C48.9046 40.2782 48.7473 41.4683 49.4939 41.9675C50.2644 42.4827 51.1757 42.9393 51.8587 43.5708C52.2539 43.9362 52.423 44.4854 52.3018 45.0099C52.2285 45.3271 52.0839 45.6851 51.9162 45.9642C51.6391 46.4257 51.1359 46.7032 50.5978 46.6916C49.6903 46.6719 48.7417 46.3753 47.8516 46.2146C46.9939 46.0598 46.1648 46.9035 46.3346 47.7583C46.5108 48.6454 46.8239 49.5888 46.8594 50.4958C46.8805 51.0336 46.6117 51.5415 46.1552 51.8267C45.879 51.9992 45.5236 52.15 45.2077 52.2289C44.6854 52.3592 44.1334 52.1997 43.7611 51.8109C43.1491 51.1718 42.6996 50.314 42.1968 49.5897C41.7203 48.9034 40.5301 48.7463 40.0309 49.493C39.5157 50.2634 39.0592 51.1746 38.4278 51.8574C38.0623 52.2527 37.5132 52.4218 36.9887 52.3006C36.6715 52.2273 36.3135 52.0826 36.0343 51.915C35.5729 51.6379 35.2953 51.1347 35.307 50.5966C35.3267 49.6891 35.6233 48.7405 35.7839 47.8505C35.9388 46.9928 35.0951 46.1636 34.2402 46.3334C33.3531 46.5096 32.4098 46.8227 31.5028 46.8582C30.9649 46.8793 30.457 46.6105 30.1719 46.154C29.9994 45.8778 29.8485 45.5224 29.7697 45.2065C29.6394 44.6842 29.7989 44.1322 30.1877 43.7599C30.8269 43.1479 31.6847 42.6982 32.4091 42.1954C33.0954 41.7189 33.2522 40.5289 32.5056 40.0297C31.7351 39.5145 30.824 39.058 30.1411 38.4265C29.7459 38.0611 29.5768 37.5119 29.698 36.9875C29.7713 36.6702 29.9159 36.3122 30.0836 36.0331C30.3607 35.5717 30.8638 35.2941 31.402 35.3058C32.3095 35.3255 33.2583 35.6221 34.1485 35.7828C35.006 35.9376 35.8349 35.094 35.6652 34.2393C35.489 33.3521 35.1759 32.4087 35.1403 31.5016Z"
      fill="#906EF7"
      stroke="white"
      stroke-width="2"
    />
    <path
      d="M20.7706 8.22357C20.9036 7.51411 21.5231 7 22.2449 7H23.7551C24.4769 7 25.0964 7.51411 25.2294 8.22357C25.5051 9.69403 25.4829 11.6321 27.1202 12.2606C27.3092 12.3331 27.4958 12.4105 27.6798 12.4926C29.2818 13.2072 30.6374 11.8199 31.8721 10.9752C32.4678 10.5676 33.2694 10.6421 33.7798 11.1525L34.8477 12.2204C35.3581 12.7308 35.4326 13.5323 35.025 14.128C34.1802 15.3627 32.7931 16.7183 33.5077 18.3202C33.5898 18.5043 33.6672 18.6909 33.7398 18.88C34.3683 20.5171 36.3061 20.4949 37.7764 20.7706C38.4859 20.9036 39 21.5231 39 22.2449V23.7551C39 24.4769 38.4859 25.0964 37.7764 25.2294C36.3061 25.5051 34.3685 25.483 33.7401 27.1201C33.6675 27.3093 33.59 27.4961 33.5079 27.6803C32.7934 29.282 34.1803 30.6374 35.025 31.8719C35.4326 32.4677 35.3581 33.2692 34.8477 33.7796L33.7798 34.8475C33.2694 35.3579 32.4678 35.4324 31.8721 35.0248C30.6376 34.1801 29.2823 32.7934 27.6806 33.508C27.4962 33.5903 27.3093 33.6678 27.12 33.7405C25.483 34.3688 25.5051 36.3062 25.2294 37.7764C25.0964 38.4859 24.4769 39 23.7551 39H22.2449C21.5231 39 20.9036 38.4859 20.7706 37.7764C20.4949 36.3062 20.517 34.3688 18.88 33.7405C18.6908 33.6678 18.5039 33.5903 18.3196 33.5081C16.7179 32.7936 15.3625 34.1804 14.1279 35.0251C13.5322 35.4327 12.7307 35.3582 12.2203 34.8478L11.1524 33.7799C10.642 33.2695 10.5675 32.4679 10.9751 31.8722C11.8198 30.6376 13.2067 29.2822 12.4922 27.6804C12.41 27.4962 12.3325 27.3093 12.2599 27.1201C11.6315 25.483 9.69392 25.5051 8.22357 25.2294C7.51411 25.0964 7 24.4769 7 23.7551V22.2449C7 21.5231 7.51411 20.9036 8.22357 20.7706C9.69394 20.4949 11.6317 20.5171 12.2602 18.88C12.3328 18.6909 12.4103 18.5042 12.4924 18.3201C13.207 16.7181 11.8198 15.3625 10.975 14.1278C10.5674 13.5321 10.6419 12.7305 11.1523 12.2201L12.2202 11.1522C12.7306 10.6418 13.5322 10.5673 14.1279 10.9749C15.3626 11.8197 16.7184 13.2071 18.3204 12.4925C18.5044 12.4105 18.6909 12.3331 18.8799 12.2606C20.5171 11.6321 20.4949 9.69403 20.7706 8.22357Z"
      fill="#906EF7"
      stroke="white"
      stroke-width="2"
    />
    <circle cx="23" cy="23" r="6" fill="#794CFF" stroke="white" stroke-width="2" />
    <circle cx="41" cy="41" r="4" fill="#794CFF" stroke="white" stroke-width="2" />
  </g>
  <defs>
    <clipPath id="1">
      <rect width="60" height="60" fill="white" />
    </clipPath>
  </defs>
</svg> `,$4=Nt`
  :host {
    display: block;
    width: var(--local-size);
    height: var(--local-size);
  }

  :host svg {
    width: 100%;
    height: 100%;
  }
`;var iu=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const N4={browser:l4,dao:d4,defi:u4,defiAlt:h4,eth:p4,layers:m4,lock:w4,login:b4,network:C4,nft:v4,noun:E4,profile:x4,system:T4,meld:y4,onrampCard:_4,google:f4,pencil:A4,lightbulb:g4,solana:S4,ton:bf,bitcoin:c4};let Os=class extends de{constructor(){super(...arguments),this.name="browser",this.size="md"}render(){return this.style.cssText=`
       --local-size: var(--apkt-visual-size-${this.size});
   `,x`${N4[this.name]}`}};Os.styles=[we,$4];iu([m()],Os.prototype,"name",void 0);iu([m()],Os.prototype,"size",void 0);Os=iu([M("wui-visual")],Os);var Zf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let md=class extends he{constructor(){super(...arguments),this.data=[]}render(){return g`
      <wui-flex flexDirection="column" alignItems="center" gap="4">
        ${this.data.map(t=>g`
            <wui-flex flexDirection="column" alignItems="center" gap="5">
              <wui-flex flexDirection="row" justifyContent="center" gap="1">
                ${t.images.map(n=>g`<wui-visual size="sm" name=${n}></wui-visual>`)}
              </wui-flex>
            </wui-flex>
            <wui-flex flexDirection="column" alignItems="center" gap="1">
              <wui-text variant="md-regular" color="primary" align="center">${t.title}</wui-text>
              <wui-text variant="sm-regular" color="secondary" align="center"
                >${t.text}</wui-text
              >
            </wui-flex>
          `)}
      </wui-flex>
    `}};Zf([ve({type:Array})],md.prototype,"data",void 0);md=Zf([M("w3m-help-widget")],md);var R4=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const k4=[{images:["login","profile","lock"],title:"One login for all of web3",text:"Log in to any app by connecting your wallet. Say goodbye to countless passwords!"},{images:["defi","nft","eth"],title:"A home for your digital assets",text:"A wallet lets you store, send and receive digital assets like cryptocurrencies and NFTs."},{images:["browser","noun","dao"],title:"Your gateway to a new web",text:"With your wallet, you can explore and interact with DeFi, NFTs, DAOs, and much more."}];let fp=class extends he{render(){return g`
      <wui-flex
        flexDirection="column"
        .padding=${["6","5","5","5"]}
        alignItems="center"
        gap="5"
      >
        <w3m-help-widget .data=${k4}></w3m-help-widget>
        <wui-button variant="accent-primary" size="md" @click=${this.onGetWallet.bind(this)}>
          <wui-icon color="inherit" slot="iconLeft" name="wallet"></wui-icon>
          Get a wallet
        </wui-button>
      </wui-flex>
    `}onGetWallet(){X.sendEvent({type:"track",event:"CLICK_GET_WALLET_HELP"}),S.push("GetWallet")}};fp=R4([M("w3m-what-is-a-wallet-view")],fp);const I4=Q`
  wui-flex {
    max-height: clamp(360px, 540px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
    transition: opacity ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: opacity;
  }
  wui-flex::-webkit-scrollbar {
    display: none;
  }
  wui-flex.disabled {
    opacity: 0.3;
    pointer-events: none;
    user-select: none;
  }
`;var Yf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ec=class extends he{constructor(){super(),this.unsubscribe=[],this.checked=qr.state.isLegalCheckboxChecked,this.unsubscribe.push(qr.subscribeKey("isLegalCheckboxChecked",t=>{this.checked=t}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){const{termsConditionsUrl:t,privacyPolicyUrl:n}=R.state,r=R.state.features?.legalCheckbox,i=!!(t||n)&&!!r,s=i&&!this.checked,a=s?-1:void 0;return g`
      <w3m-legal-checkbox></w3m-legal-checkbox>
      <wui-flex
        flexDirection="column"
        .padding=${i?["0","3","3","3"]:"3"}
        gap="2"
        class=${ae(s?"disabled":void 0)}
      >
        <w3m-wallet-login-list tabIdx=${ae(a)}></w3m-wallet-login-list>
      </wui-flex>
    `}};Ec.styles=I4;Yf([T()],Ec.prototype,"checked",void 0);Ec=Yf([M("w3m-connect-wallets-view")],Ec);const O4=Q`
  :host {
    display: block;
    width: 120px;
    height: 120px;
  }

  svg {
    width: 120px;
    height: 120px;
    fill: none;
    stroke: transparent;
    stroke-linecap: round;
  }

  use {
    stroke: ${e=>e.colors.accent100};
    stroke-width: 2px;
    stroke-dasharray: 54, 118;
    stroke-dashoffset: 172;
    animation: dash 1s linear infinite;
  }

  @keyframes dash {
    to {
      stroke-dashoffset: 0px;
    }
  }
`;var P4=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let gd=class extends de{render(){return x`
      <svg viewBox="0 0 54 59">
        <path
          id="wui-loader-path"
          d="M17.22 5.295c3.877-2.277 5.737-3.363 7.72-3.726a11.44 11.44 0 0 1 4.12 0c1.983.363 3.844 1.45 7.72 3.726l6.065 3.562c3.876 2.276 5.731 3.372 7.032 4.938a11.896 11.896 0 0 1 2.06 3.63c.683 1.928.688 4.11.688 8.663v7.124c0 4.553-.005 6.735-.688 8.664a11.896 11.896 0 0 1-2.06 3.63c-1.3 1.565-3.156 2.66-7.032 4.937l-6.065 3.563c-3.877 2.276-5.737 3.362-7.72 3.725a11.46 11.46 0 0 1-4.12 0c-1.983-.363-3.844-1.449-7.72-3.726l-6.065-3.562c-3.876-2.276-5.731-3.372-7.032-4.938a11.885 11.885 0 0 1-2.06-3.63c-.682-1.928-.688-4.11-.688-8.663v-7.124c0-4.553.006-6.735.688-8.664a11.885 11.885 0 0 1 2.06-3.63c1.3-1.565 3.156-2.66 7.032-4.937l6.065-3.562Z"
        />
        <use xlink:href="#wui-loader-path"></use>
      </svg>
    `}};gd.styles=[we,O4];gd=P4([M("wui-loading-hexagon")],gd);const L4=pe`<svg width="86" height="96" fill="none">
  <path
    d="M78.3244 18.926L50.1808 2.45078C45.7376 -0.150261 40.2624 -0.150262 35.8192 2.45078L7.6756 18.926C3.23322 21.5266 0.5 26.3301 0.5 31.5248V64.4752C0.5 69.6699 3.23322 74.4734 7.6756 77.074L35.8192 93.5492C40.2624 96.1503 45.7376 96.1503 50.1808 93.5492L78.3244 77.074C82.7668 74.4734 85.5 69.6699 85.5 64.4752V31.5248C85.5 26.3301 82.7668 21.5266 78.3244 18.926Z"
  />
</svg>`,D4=pe`
  <svg fill="none" viewBox="0 0 36 40">
    <path
      d="M15.4 2.1a5.21 5.21 0 0 1 5.2 0l11.61 6.7a5.21 5.21 0 0 1 2.61 4.52v13.4c0 1.87-1 3.59-2.6 4.52l-11.61 6.7c-1.62.93-3.6.93-5.22 0l-11.6-6.7a5.21 5.21 0 0 1-2.61-4.51v-13.4c0-1.87 1-3.6 2.6-4.52L15.4 2.1Z"
    />
  </svg>
`,M4=Q`
  :host {
    position: relative;
    border-radius: inherit;
    display: flex;
    justify-content: center;
    align-items: center;
    width: var(--local-width);
    height: var(--local-height);
  }

  :host([data-round='true']) {
    background: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: 100%;
    outline: 1px solid ${({tokens:e})=>e.core.glass010};
  }

  svg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
  }

  svg > path {
    stroke: var(--local-stroke);
  }

  wui-image {
    width: 100%;
    height: 100%;
    -webkit-clip-path: var(--local-path);
    clip-path: var(--local-path);
    background: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  wui-icon {
    transform: translateY(-5%);
    width: var(--local-icon-size);
    height: var(--local-icon-size);
  }
`;var Li=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let ir=class extends de{constructor(){super(...arguments),this.size="md",this.name="uknown",this.networkImagesBySize={sm:D4,md:If,lg:L4},this.selected=!1,this.round=!1}render(){const t={sm:"4",md:"6",lg:"10"};return this.round?(this.dataset.round="true",this.style.cssText=`
      --local-width: var(--apkt-spacing-10);
      --local-height: var(--apkt-spacing-10);
      --local-icon-size: var(--apkt-spacing-4);
    `):this.style.cssText=`

      --local-path: var(--apkt-path-network-${this.size});
      --local-width:  var(--apkt-width-network-${this.size});
      --local-height:  var(--apkt-height-network-${this.size});
      --local-icon-size:  var(--apkt-spacing-${t[this.size]});
    `,x`${this.templateVisual()} ${this.svgTemplate()} `}svgTemplate(){return this.round?null:this.networkImagesBySize[this.size]}templateVisual(){return this.imageSrc?x`<wui-image src=${this.imageSrc} alt=${this.name}></wui-image>`:x`<wui-icon size="inherit" color="default" name="networkPlaceholder"></wui-icon>`}};ir.styles=[we,M4];Li([m()],ir.prototype,"size",void 0);Li([m()],ir.prototype,"name",void 0);Li([m({type:Object})],ir.prototype,"networkImagesBySize",void 0);Li([m()],ir.prototype,"imageSrc",void 0);Li([m({type:Boolean})],ir.prototype,"selected",void 0);Li([m({type:Boolean})],ir.prototype,"round",void 0);ir=Li([M("wui-network-image")],ir);const U4=Vt`
  @keyframes shake {
    0% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(3px);
    }
    50% {
      transform: translateX(-3px);
    }
    75% {
      transform: translateX(3px);
    }
    100% {
      transform: translateX(0);
    }
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-loading-hexagon {
    position: absolute;
  }

  wui-icon-box {
    position: absolute;
    right: 4px;
    bottom: 0;
    opacity: 0;
    transform: scale(0.5);
    z-index: 1;
  }

  wui-button {
    display: none;
  }

  [data-error='true'] wui-icon-box {
    opacity: 1;
    transform: scale(1);
  }

  [data-error='true'] > wui-flex:first-child {
    animation: shake 250ms cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
  }

  wui-button[data-retry='true'] {
    display: block;
    opacity: 1;
  }
`;var ou=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ps=class extends he{constructor(){super(),this.network=S.state.data?.network,this.unsubscribe=[],this.showRetry=!1,this.error=!1}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}firstUpdated(){this.onSwitchNetwork()}render(){if(!this.network)throw new Error("w3m-network-switch-view: No network provided");this.onShowRetry();const t=this.getLabel(),n=this.getSubLabel();return g`
      <wui-flex
        data-error=${this.error}
        flexDirection="column"
        alignItems="center"
        .padding=${["10","5","10","5"]}
        gap="7"
      >
        <wui-flex justifyContent="center" alignItems="center">
          <wui-network-image
            size="lg"
            imageSrc=${ae(De.getNetworkImage(this.network))}
          ></wui-network-image>

          ${this.error?null:g`<wui-loading-hexagon></wui-loading-hexagon>`}

          <wui-icon-box color="error" icon="close" size="sm"></wui-icon-box>
        </wui-flex>

        <wui-flex flexDirection="column" alignItems="center" gap="2">
          <wui-text align="center" variant="h6-regular" color="primary">${t}</wui-text>
          <wui-text align="center" variant="md-regular" color="secondary">${n}</wui-text>
        </wui-flex>

        <wui-button
          data-retry=${this.showRetry}
          variant="accent-primary"
          size="md"
          .disabled=${!this.error}
          @click=${this.onSwitchNetwork.bind(this)}
        >
          <wui-icon color="inherit" slot="iconLeft" name="refresh"></wui-icon>
          Try again
        </wui-button>
      </wui-flex>
    `}getSubLabel(){const t=O.getConnectorId(p.state.activeChain);return O.getAuthConnector()&&t===N.CONNECTOR_ID.AUTH?"":this.error?"Switch can be declined if chain is not supported by a wallet or previous request is still active":"Accept connection request in your wallet"}getLabel(){const t=O.getConnectorId(p.state.activeChain);return O.getAuthConnector()&&t===N.CONNECTOR_ID.AUTH?`Switching to ${this.network?.name??"Unknown"} network...`:this.error?"Switch declined":"Approve in wallet"}onShowRetry(){this.error&&!this.showRetry&&(this.showRetry=!0,this.shadowRoot?.querySelector("wui-button")?.animate([{opacity:0},{opacity:1}],{fill:"forwards",easing:"ease"}))}async onSwitchNetwork(){try{this.error=!1,p.state.activeChain!==this.network?.chainNamespace&&p.setIsSwitchingNamespace(!0),this.network&&(await p.switchActiveNetwork(this.network),await An.isAuthenticated()&&S.goBack())}catch{this.error=!0}}};Ps.styles=U4;ou([T()],Ps.prototype,"showRetry",void 0);ou([T()],Ps.prototype,"error",void 0);Ps=ou([M("w3m-network-switch-view")],Ps);const B4=Q`
  :host {
    width: 100%;
  }

  button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: ${({spacing:e})=>e[3]};
    width: 100%;
    background-color: transparent;
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  wui-text {
    text-transform: capitalize;
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    }
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;var ra=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ci=class extends de{constructor(){super(...arguments),this.imageSrc=void 0,this.name="Ethereum",this.disabled=!1}render(){return x`
      <button ?disabled=${this.disabled} tabindex=${Qe(this.tabIdx)}>
        <wui-flex gap="2" alignItems="center">
          ${this.imageTemplate()}
          <wui-text variant="lg-regular" color="primary">${this.name}</wui-text>
        </wui-flex>
        <wui-icon name="chevronRight" size="lg" color="default"></wui-icon>
      </button>
    `}imageTemplate(){return this.imageSrc?x`<wui-image ?boxed=${!0} src=${this.imageSrc}></wui-image>`:x`<wui-image
      ?boxed=${!0}
      icon="networkPlaceholder"
      size="lg"
      iconColor="default"
    ></wui-image>`}};Ci.styles=[we,Be,B4];ra([m()],Ci.prototype,"imageSrc",void 0);ra([m()],Ci.prototype,"name",void 0);ra([m()],Ci.prototype,"tabIdx",void 0);ra([m({type:Boolean})],Ci.prototype,"disabled",void 0);Ci=ra([M("wui-list-network")],Ci);const W4=Vt`
  .container {
    max-height: 360px;
    overflow: auto;
  }

  .container::-webkit-scrollbar {
    display: none;
  }
`;var ia=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let vi=class extends he{constructor(){super(),this.unsubscribe=[],this.network=p.state.activeCaipNetwork,this.requestedCaipNetworks=p.getCaipNetworks(),this.search="",this.onDebouncedSearch=L.debounce(t=>{this.search=t},100),this.unsubscribe.push(rt.subscribeNetworkImages(()=>this.requestUpdate()),p.subscribeKey("activeCaipNetwork",t=>this.network=t),p.subscribe(()=>{this.requestedCaipNetworks=p.getAllRequestedCaipNetworks()}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return g`
      ${this.templateSearchInput()}
      <wui-flex
        class="container"
        .padding=${["0","3","3","3"]}
        flexDirection="column"
        gap="2"
      >
        ${this.networksTemplate()}
      </wui-flex>
    `}templateSearchInput(){return g`
      <wui-flex gap="2" .padding=${["0","3","3","3"]}>
        <wui-input-text
          @inputChange=${this.onInputChange.bind(this)}
          class="network-search-input"
          size="md"
          placeholder="Search network"
          icon="search"
        ></wui-input-text>
      </wui-flex>
    `}onInputChange(t){this.onDebouncedSearch(t.detail)}networksTemplate(){const t=p.getAllApprovedCaipNetworkIds(),n=L.sortRequestedNetworks(t,this.requestedCaipNetworks);return this.search?this.filteredNetworks=n?.filter(r=>r?.name?.toLowerCase().includes(this.search.toLowerCase())):this.filteredNetworks=n,this.filteredNetworks?.map(r=>g`
        <wui-list-network
          .selected=${this.network?.id===r.id}
          imageSrc=${ae(De.getNetworkImage(r))}
          type="network"
          name=${r.name??r.id}
          @click=${()=>this.onSwitchNetwork(r)}
          .disabled=${p.isCaipNetworkDisabled(r)}
          data-testid=${`w3m-network-switch-${r.name??r.id}`}
        ></wui-list-network>
      `)}onSwitchNetwork(t){Yp.onSwitchNetwork({network:t})}};vi.styles=W4;ia([T()],vi.prototype,"network",void 0);ia([T()],vi.prototype,"requestedCaipNetworks",void 0);ia([T()],vi.prototype,"filteredNetworks",void 0);ia([T()],vi.prototype,"search",void 0);vi=ia([M("w3m-networks-view")],vi);const j4=Q`
  @keyframes shake {
    0% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(3px);
    }
    50% {
      transform: translateX(-3px);
    }
    75% {
      transform: translateX(3px);
    }
    100% {
      transform: translateX(0);
    }
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-loading-thumbnail {
    position: absolute;
  }

  wui-visual {
    border-radius: calc(
      ${({borderRadius:e})=>e[1]} * 9 - ${({borderRadius:e})=>e[3]}
    );
    position: relative;
    overflow: hidden;
  }

  wui-visual::after {
    content: '';
    display: block;
    width: 100%;
    height: 100%;
    position: absolute;
    inset: 0;
    border-radius: calc(
      ${({borderRadius:e})=>e[1]} * 9 - ${({borderRadius:e})=>e[3]}
    );
    box-shadow: inset 0 0 0 1px ${({tokens:e})=>e.core.glass010};
  }

  wui-icon-box {
    position: absolute;
    right: calc(${({spacing:e})=>e[1]} * -1);
    bottom: calc(${({spacing:e})=>e[1]} * -1);
    opacity: 0;
    transform: scale(0.5);
    transition:
      opacity ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      transform ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]};
    will-change: opacity, transform;
  }

  wui-text[align='center'] {
    width: 100%;
    padding: 0px ${({spacing:e})=>e[4]};
  }

  [data-error='true'] wui-icon-box {
    opacity: 1;
    transform: scale(1);
  }

  [data-error='true'] > wui-flex:first-child {
    animation: shake 250ms ${({easings:e})=>e["ease-out-power-2"]} both;
  }

  [data-retry='false'] wui-link {
    display: none;
  }

  [data-retry='true'] wui-link {
    display: block;
    opacity: 1;
  }

  wui-link {
    padding: ${({spacing:e})=>e["01"]} ${({spacing:e})=>e[2]};
  }

  .capitalize {
    text-transform: capitalize;
  }
`;var Jf=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const F4={eip155:"eth",solana:"solana",bip122:"bitcoin",polkadot:void 0};let _c=class extends he{constructor(){super(...arguments),this.unsubscribe=[],this.switchToChain=S.state.data?.switchToChain,this.caipNetwork=S.state.data?.network,this.activeChain=p.state.activeChain}firstUpdated(){this.unsubscribe.push(p.subscribeKey("activeChain",t=>this.activeChain=t))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){const t=this.switchToChain?N.CHAIN_NAME_MAP[this.switchToChain]:"supported";if(!this.switchToChain)return null;const n=N.CHAIN_NAME_MAP[this.switchToChain];return g`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["4","2","2","2"]}
        gap="4"
      >
        <wui-flex justifyContent="center" flexDirection="column" alignItems="center" gap="2">
          <wui-visual
            size="md"
            name=${ae(F4[this.switchToChain])}
          ></wui-visual>
          <wui-flex gap="2" flexDirection="column" alignItems="center">
            <wui-text
              data-testid=${`w3m-switch-active-chain-to-${n}`}
              variant="lg-regular"
              color="primary"
              align="center"
              >Switch to <span class="capitalize">${n}</span></wui-text
            >
            <wui-text variant="md-regular" color="secondary" align="center">
              Connected wallet doesn't support connecting to ${t} chain. You
              need to connect with a different wallet.
            </wui-text>
          </wui-flex>
          <wui-button
            data-testid="w3m-switch-active-chain-button"
            size="md"
            @click=${this.switchActiveChain.bind(this)}
            >Switch</wui-button
          >
        </wui-flex>
      </wui-flex>
    `}async switchActiveChain(){this.switchToChain&&(p.setIsSwitchingNamespace(!0),O.setFilterByNamespace(this.switchToChain),this.caipNetwork?await p.switchActiveNetwork(this.caipNetwork):p.setActiveNamespace(this.switchToChain),S.reset("Connect"))}};_c.styles=j4;Jf([ve()],_c.prototype,"activeChain",void 0);_c=Jf([M("w3m-switch-active-chain-view")],_c);var z4=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};const H4=[{images:["network","layers","system"],title:"The system’s nuts and bolts",text:"A network is what brings the blockchain to life, as this technical infrastructure allows apps to access the ledger and smart contract services."},{images:["noun","defiAlt","dao"],title:"Designed for different uses",text:"Each network is designed differently, and may therefore suit certain apps and experiences."}];let mp=class extends he{render(){return g`
      <wui-flex
        flexDirection="column"
        .padding=${["6","5","5","5"]}
        alignItems="center"
        gap="5"
      >
        <w3m-help-widget .data=${H4}></w3m-help-widget>
        <wui-button
          variant="accent-primary"
          size="md"
          @click=${()=>{L.openHref("https://ethereum.org/en/developers/docs/networks/","_blank")}}
        >
          Learn more
          <wui-icon color="inherit" slot="iconRight" name="externalLink"></wui-icon>
        </wui-button>
      </wui-flex>
    `}};mp=z4([M("w3m-what-is-a-network-view")],mp);const V4=Vt`
  :host > wui-flex {
    max-height: clamp(360px, 540px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
  }

  :host > wui-flex::-webkit-scrollbar {
    display: none;
  }
`;var su=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ls=class extends he{constructor(){super(),this.swapUnsupportedChain=S.state.data?.swapUnsupportedChain,this.unsubscribe=[],this.disconnecting=!1,this.remoteFeatures=R.state.remoteFeatures,this.unsubscribe.push(rt.subscribeNetworkImages(()=>this.requestUpdate()),R.subscribeKey("remoteFeatures",t=>{this.remoteFeatures=t}))}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return g`
      <wui-flex class="container" flexDirection="column" gap="0">
        <wui-flex
          class="container"
          flexDirection="column"
          .padding=${["3","5","2","5"]}
          alignItems="center"
          gap="5"
        >
          ${this.descriptionTemplate()}
        </wui-flex>

        <wui-flex flexDirection="column" padding="3" gap="2"> ${this.networksTemplate()} </wui-flex>

        <wui-separator text="or"></wui-separator>
        <wui-flex flexDirection="column" padding="3" gap="2">
          <wui-list-item
            variant="icon"
            iconVariant="overlay"
            icon="signOut"
            ?chevron=${!1}
            .loading=${this.disconnecting}
            @click=${this.onDisconnect.bind(this)}
            data-testid="disconnect-button"
          >
            <wui-text variant="md-medium" color="secondary">Disconnect</wui-text>
          </wui-list-item>
        </wui-flex>
      </wui-flex>
    `}descriptionTemplate(){return this.swapUnsupportedChain?g`
        <wui-text variant="sm-regular" color="secondary" align="center">
          The swap feature doesn’t support your current network. Switch to an available option to
          continue.
        </wui-text>
      `:g`
      <wui-text variant="sm-regular" color="secondary" align="center">
        This app doesn’t support your current network. Switch to an available option to continue.
      </wui-text>
    `}networksTemplate(){const t=p.getAllRequestedCaipNetworks(),n=p.getAllApprovedCaipNetworkIds(),r=L.sortRequestedNetworks(n,t);return(this.swapUnsupportedChain?r.filter(i=>ke.SWAP_SUPPORTED_NETWORKS.includes(i.caipNetworkId)):r).map(i=>g`
        <wui-list-network
          imageSrc=${ae(De.getNetworkImage(i))}
          name=${i.name??"Unknown"}
          @click=${()=>this.onSwitchNetwork(i)}
        >
        </wui-list-network>
      `)}async onDisconnect(){try{this.disconnecting=!0;const t=p.state.activeChain,r=U.getConnections(t).length>0,o=t&&O.state.activeConnectorIds[t],i=this.remoteFeatures?.multiWallet;await U.disconnect(i?{id:o,namespace:t}:{}),r&&i&&(S.push("ProfileWallets"),Te.showSuccess("Wallet deleted"))}catch{X.sendEvent({type:"track",event:"DISCONNECT_ERROR",properties:{message:"Failed to disconnect"}}),Te.showError("Failed to disconnect")}finally{this.disconnecting=!1}}async onSwitchNetwork(t){const n=p.getActiveCaipAddress(),r=p.getAllApprovedCaipNetworkIds(),o=p.getNetworkProp("supportsAllNetworks",t.chainNamespace),i=S.state.data;n?r?.includes(t.caipNetworkId)?await p.switchActiveNetwork(t):o?S.push("SwitchNetwork",{...i,network:t}):S.push("SwitchNetwork",{...i,network:t}):n||(p.setActiveCaipNetwork(t),S.push("Connect"))}};Ls.styles=V4;su([T()],Ls.prototype,"disconnecting",void 0);su([T()],Ls.prototype,"remoteFeatures",void 0);Ls=su([M("w3m-unsupported-chain-view")],Ls);const q4=Q`
  wui-flex {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: ${({spacing:e})=>e[2]};
    border-radius: ${({borderRadius:e})=>e[4]};
    padding: ${({spacing:e})=>e[3]};
  }

  /* -- Types --------------------------------------------------------- */
  wui-flex[data-type='info'] {
    color: ${({tokens:e})=>e.theme.textSecondary};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  wui-flex[data-type='success'] {
    color: ${({tokens:e})=>e.core.textSuccess};
    background-color: ${({tokens:e})=>e.core.backgroundSuccess};
  }

  wui-flex[data-type='error'] {
    color: ${({tokens:e})=>e.core.textError};
    background-color: ${({tokens:e})=>e.core.backgroundError};
  }

  wui-flex[data-type='warning'] {
    color: ${({tokens:e})=>e.core.textWarning};
    background-color: ${({tokens:e})=>e.core.backgroundWarning};
  }

  wui-flex[data-type='info'] wui-icon-box {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  wui-flex[data-type='success'] wui-icon-box {
    background-color: ${({tokens:e})=>e.core.backgroundSuccess};
  }

  wui-flex[data-type='error'] wui-icon-box {
    background-color: ${({tokens:e})=>e.core.backgroundError};
  }

  wui-flex[data-type='warning'] wui-icon-box {
    background-color: ${({tokens:e})=>e.core.backgroundWarning};
  }

  wui-text {
    flex: 1;
  }
`;var zc=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let po=class extends de{constructor(){super(...arguments),this.icon="externalLink",this.text="",this.type="info"}render(){return x`
      <wui-flex alignItems="center" data-type=${this.type}>
        <wui-icon-box size="sm" color="inherit" icon=${this.icon}></wui-icon-box>
        <wui-text variant="md-regular" color="inherit">${this.text}</wui-text>
      </wui-flex>
    `}};po.styles=[we,Be,q4];zc([m()],po.prototype,"icon",void 0);zc([m()],po.prototype,"text",void 0);zc([m()],po.prototype,"type",void 0);po=zc([M("wui-banner")],po);const K4=Vt`
  :host > wui-flex {
    max-height: clamp(360px, 540px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
  }

  :host > wui-flex::-webkit-scrollbar {
    display: none;
  }
`;var G4=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let wd=class extends he{constructor(){super(),this.unsubscribe=[]}disconnectedCallback(){this.unsubscribe.forEach(t=>t())}render(){return g` <wui-flex flexDirection="column" .padding=${["2","3","3","3"]} gap="2">
      <wui-banner
        icon="warningCircle"
        text="You can only receive assets on these networks"
      ></wui-banner>
      ${this.networkTemplate()}
    </wui-flex>`}networkTemplate(){const t=p.getAllRequestedCaipNetworks(),n=p.getAllApprovedCaipNetworkIds(),r=p.state.activeCaipNetwork,o=p.checkIfSmartAccountEnabled();let i=L.sortRequestedNetworks(n,t);if(o&&ut(r?.chainNamespace)===je.ACCOUNT_TYPES.SMART_ACCOUNT){if(!r)return null;i=[r]}return i.filter(a=>a.chainNamespace===r?.chainNamespace).map(a=>g`
        <wui-list-network
          imageSrc=${ae(De.getNetworkImage(a))}
          name=${a.name??"Unknown"}
          ?transparent=${!0}
        >
        </wui-list-network>
      `)}};wd.styles=K4;wd=G4([M("w3m-wallet-compatible-networks-view")],wd);const Z4=Q`
  :host {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 56px;
    height: 56px;
    box-shadow: 0 0 0 8px ${({tokens:e})=>e.theme.borderPrimary};
    border-radius: ${({borderRadius:e})=>e[4]};
    overflow: hidden;
  }

  :host([data-border-radius-full='true']) {
    border-radius: 50px;
  }

  wui-icon {
    width: 32px;
    height: 32px;
  }
`;var Hc=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let fo=class extends de{render(){return this.dataset.borderRadiusFull=this.borderRadiusFull?"true":"false",x`${this.templateVisual()}`}templateVisual(){return this.imageSrc?x`<wui-image src=${this.imageSrc} alt=${this.alt??""}></wui-image>`:x`<wui-icon
      data-parent-size="md"
      size="inherit"
      color="inherit"
      name="wallet"
    ></wui-icon>`}};fo.styles=[we,Z4];Hc([m()],fo.prototype,"imageSrc",void 0);Hc([m()],fo.prototype,"alt",void 0);Hc([m({type:Boolean})],fo.prototype,"borderRadiusFull",void 0);fo=Hc([M("wui-visual-thumbnail")],fo);const Y4=Q`
  :host {
    display: flex;
    justify-content: center;
    gap: ${({spacing:e})=>e[4]};
  }

  wui-visual-thumbnail:nth-child(1) {
    z-index: 1;
  }
`;var J4=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let bd=class extends he{constructor(){super(...arguments),this.dappImageUrl=R.state.metadata?.icons,this.walletImageUrl=p.getAccountData()?.connectedWalletInfo?.icon}firstUpdated(){const t=this.shadowRoot?.querySelectorAll("wui-visual-thumbnail");t?.[0]&&this.createAnimation(t[0],"translate(18px)"),t?.[1]&&this.createAnimation(t[1],"translate(-18px)")}render(){return g`
      <wui-visual-thumbnail
        ?borderRadiusFull=${!0}
        .imageSrc=${this.dappImageUrl?.[0]}
      ></wui-visual-thumbnail>
      <wui-visual-thumbnail .imageSrc=${this.walletImageUrl}></wui-visual-thumbnail>
    `}createAnimation(t,n){t.animate([{transform:"translateX(0px)"},{transform:n}],{duration:1600,easing:"cubic-bezier(0.56, 0, 0.48, 1)",direction:"alternate",iterations:1/0})}};bd.styles=Y4;bd=J4([M("w3m-siwx-sign-message-thumbnails")],bd);var au=function(e,t,n,r){var o=arguments.length,i=o<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(s=e[a])&&(i=(o<3?s(i):o>3?s(t,n,i):s(t,n))||i);return o>3&&i&&Object.defineProperty(t,n,i),i};let Ac=class extends he{constructor(){super(...arguments),this.dappName=R.state.metadata?.name,this.isCancelling=!1,this.isSigning=!1}render(){return g`
      <wui-flex justifyContent="center" .padding=${["8","0","6","0"]}>
        <w3m-siwx-sign-message-thumbnails></w3m-siwx-sign-message-thumbnails>
      </wui-flex>
      <wui-flex .padding=${["0","20","5","20"]} gap="3" justifyContent="space-between">
        <wui-text variant="lg-medium" align="center" color="primary"
          >${this.dappName??"Dapp"} needs to connect to your wallet</wui-text
        >
      </wui-flex>
      <wui-flex .padding=${["0","10","4","10"]} gap="3" justifyContent="space-between">
        <wui-text variant="md-regular" align="center" color="secondary"
          >Sign this message to prove you own this wallet and proceed. Canceling will disconnect
          you.</wui-text
        >
      </wui-flex>
      <wui-flex .padding=${["4","5","5","5"]} gap="3" justifyContent="space-between">
        <wui-button
          size="lg"
          borderRadius="xs"
          fullWidth
          variant="neutral-secondary"
          ?loading=${this.isCancelling}
          @click=${this.onCancel.bind(this)}
          data-testid="w3m-connecting-siwe-cancel"
        >
          ${this.isCancelling?"Cancelling...":"Cancel"}
        </wui-button>
        <wui-button
          size="lg"
          borderRadius="xs"
          fullWidth
          variant="neutral-primary"
          @click=${this.onSign.bind(this)}
          ?loading=${this.isSigning}
          data-testid="w3m-connecting-siwe-sign"
        >
          ${this.isSigning?"Signing...":"Sign"}
        </wui-button>
      </wui-flex>
    `}async onSign(){this.isSigning=!0;try{await An.requestSignMessage()}catch(t){if(t instanceof Error&&t.message.includes("OTP is required")){Te.showError({message:"Something went wrong. We need to verify your account again."}),S.replace("DataCapture");return}throw t}finally{this.isSigning=!1}}async onCancel(){this.isCancelling=!0,await An.cancelSignMessage().finally(()=>this.isCancelling=!1)}};au([T()],Ac.prototype,"isCancelling",void 0);au([T()],Ac.prototype,"isSigning",void 0);Ac=au([M("w3m-siwx-sign-message-view")],Ac);Ic({tagName:"appkit-button",elementClass:rd,react:xc});Ic({tagName:"appkit-network-button",elementClass:od,react:xc});Ic({tagName:"appkit-connect-button",elementClass:id,react:xc});Ic({tagName:"appkit-account-button",elementClass:nd,react:xc});export{ce as $,Xp as A,_e as B,p as C,Mc as D,X as E,Ke as F,Uc as G,Vt as H,he as I,g as J,De as K,ae as L,T as M,Ji as N,Nt as O,S2 as P,gf as Q,S as R,G as S,fr as T,Fe as U,Sn as V,je as W,ve as X,nt as Y,R as Z,se as _,Wo as a,Lw as a$,ye as a0,tC as a1,rC as a2,ef as a3,q as a4,I3 as a5,pw as a6,qr as a7,Ea as a8,L3 as a9,Wp as aA,Hr as aB,Km as aC,Jt as aD,Bs as aE,Wt as aF,Av as aG,yw as aH,mo as aI,Ga as aJ,fa as aK,$d as aL,Ra as aM,dv as aN,lv as aO,xr as aP,av as aQ,Nd as aR,pv as aS,fv as aT,to as aU,is as aV,zp as aW,me as aX,kd as aY,Ow as aZ,Pw as a_,Da as aa,tt as ab,Se as ac,Qe as ad,Zi as ae,Gm as af,rt as ag,Ja as ah,In as ai,Yt as aj,An as ak,Bv as al,x2 as am,Ue as an,Ru as ao,hv as ap,Dp as aq,uv as ar,Tw as as,Sw as at,ov as au,jp as av,fw as aw,vw as ax,gw as ay,Fp as az,Q4 as b,ts as b$,Dw as b0,Mw as b1,Uw as b2,Bw as b3,Ww as b4,jw as b5,Fw as b6,mv as b7,sv as b8,Hw as b9,Lm as bA,sh as bB,Wv as bC,Gn as bD,Xt as bE,ma as bF,jv as bG,O3 as bH,R2 as bI,Di as bJ,Rd as bK,Po as bL,qp as bM,Lu as bN,Qw as bO,da as bP,$w as bQ,Bp as bR,ww as bS,bw as bT,Iu as bU,ys as bV,bs as bW,ws as bX,us as bY,ms as bZ,rs as b_,gv as ba,Vp as bb,zw as bc,Vw as bd,qw as be,wv as bf,vv as bg,bv as bh,Cv as bi,yv as bj,Ev as bk,_v as bl,cv as bm,nv as bn,rv as bo,k2 as bp,Tv as bq,Ym as br,$v as bs,f3 as bt,Nv as bu,Sv as bv,xv as bw,dn as bx,dt as by,tf as bz,im as c,as as c0,ro as c1,ns as c2,Br as c3,es as c4,ds as c5,Ht as c6,os as c7,ss as c8,Pt as c9,_t as cA,pi as cB,dc as cC,Ot as cD,Ih as cE,wc as cF,rr as cG,Cc as cH,vc as cI,hp as cJ,pp as cK,fp as cL,Ec as cM,Ps as cN,vi as cO,_c as cP,mp as cQ,Ls as cR,wd as cS,Ac as cT,hs as ca,no as cb,cs as cc,gs as cd,Rw as ce,fs as cf,ps as cg,ls as ch,Vr as ci,t2 as cj,mw as ck,Aw as cl,xw as cm,Yw as cn,_h as co,nd as cp,Ah as cq,rd as cr,xh as cs,id as ct,Sh as cu,od as cv,$s as cw,Ts as cx,vr as cy,hd as cz,O as d,U as e,L as f,N as g,Te as h,sm as i,ut as j,T2 as k,Id as l,ke as m,Za as n,st as o,ze as p,Q as q,we as r,ot as s,Be as t,Fv as u,m as v,gn as w,M as x,de as y,x as z};
